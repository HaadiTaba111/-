PRAGMA foreign_keys = ON;

CREATE TABLE metadata (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

CREATE TABLE sources (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL UNIQUE,
    sequence_page_start INTEGER NOT NULL,
    sequence_page_end INTEGER NOT NULL,
    printed_page_offset INTEGER NOT NULL,
    printed_page_start INTEGER NOT NULL,
    printed_page_end INTEGER NOT NULL,
    page_count INTEGER NOT NULL CHECK (page_count > 0),
    sha256 TEXT NOT NULL
);

CREATE TABLE categories (
    id TEXT PRIMARY KEY,
    name_fa TEXT NOT NULL,
    sort_order INTEGER NOT NULL
);

CREATE TABLE pages (
    id TEXT PRIMARY KEY,
    source_id TEXT NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    pdf_page_index INTEGER NOT NULL CHECK (pdf_page_index >= 0),
    sequence_page INTEGER NOT NULL,
    printed_page INTEGER,
    ocr_text_raw TEXT NOT NULL,
    ocr_top_region_raw TEXT NOT NULL DEFAULT '',
    ocr_analysis_region_raw TEXT NOT NULL DEFAULT '',
    ocr_method TEXT NOT NULL,
    quality_score REAL NOT NULL CHECK (quality_score BETWEEN 0 AND 1),
    review_status TEXT NOT NULL,
    UNIQUE(source_id, pdf_page_index),
    UNIQUE(source_id, sequence_page)
);

CREATE TABLE entries (
    id TEXT PRIMARY KEY,
    category_id TEXT NOT NULL REFERENCES categories(id),
    content_type TEXT NOT NULL CHECK (content_type IN ('feature','article','multi_panel')),
    title_fa TEXT NOT NULL,
    visual_cue_fa TEXT,
    description_fa TEXT NOT NULL DEFAULT '',
    analysis_fa TEXT,
    source_id TEXT NOT NULL REFERENCES sources(id),
    page_id TEXT NOT NULL REFERENCES pages(id) ON DELETE CASCADE,
    sequence_page INTEGER NOT NULL,
    printed_page INTEGER,
    review_status TEXT NOT NULL,
    sort_order INTEGER NOT NULL
);

CREATE TABLE entry_tags (
    entry_id TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    tag TEXT NOT NULL,
    PRIMARY KEY(entry_id, tag)
);

-- Reserved for future illustration crops or app assets.
CREATE TABLE assets (
    id TEXT PRIMARY KEY,
    entry_id TEXT REFERENCES entries(id) ON DELETE SET NULL,
    asset_type TEXT NOT NULL,
    relative_path TEXT NOT NULL,
    mime_type TEXT,
    width INTEGER,
    height INTEGER,
    sha256 TEXT
);

-- Keeps later PDF/JSON additions auditable and incremental.
CREATE TABLE import_batches (
    id TEXT PRIMARY KEY,
    imported_at TEXT NOT NULL,
    source_count INTEGER NOT NULL,
    page_count INTEGER NOT NULL,
    entry_count INTEGER NOT NULL,
    note TEXT
);

-- App/about information shown in the Persian and English interfaces.
CREATE TABLE app_profile (
    key TEXT PRIMARY KEY,
    value_fa TEXT,
    value_en TEXT,
    is_public INTEGER NOT NULL DEFAULT 1 CHECK (is_public IN (0,1))
);

-- English and other translations can be added after Persian proofreading.
CREATE TABLE translations (
    entry_id TEXT NOT NULL REFERENCES entries(id) ON DELETE CASCADE,
    language_code TEXT NOT NULL,
    title TEXT,
    visual_cue TEXT,
    description TEXT,
    analysis TEXT,
    review_status TEXT NOT NULL DEFAULT 'draft',
    updated_at TEXT,
    PRIMARY KEY(entry_id, language_code)
);

-- Machine validation and human-review queue used by the admin dashboard.
CREATE TABLE validation_issues (
    id TEXT PRIMARY KEY,
    source_id TEXT REFERENCES sources(id) ON DELETE CASCADE,
    page_id TEXT REFERENCES pages(id) ON DELETE CASCADE,
    entry_id TEXT REFERENCES entries(id) ON DELETE CASCADE,
    severity TEXT NOT NULL CHECK (severity IN ('info','warning','error')),
    issue_code TEXT NOT NULL,
    message_fa TEXT NOT NULL,
    message_en TEXT NOT NULL,
    resolved INTEGER NOT NULL DEFAULT 0 CHECK (resolved IN (0,1)),
    created_at TEXT NOT NULL
);

-- Reserved audit trail for edits submitted by a future authenticated backend.
CREATE TABLE review_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    entry_id TEXT REFERENCES entries(id) ON DELETE SET NULL,
    admin_name TEXT,
    field_name TEXT NOT NULL,
    old_value TEXT,
    new_value TEXT,
    changed_at TEXT NOT NULL
);

-- Internal product roadmap shown in the admin dashboard.
CREATE TABLE project_tasks (
    id TEXT PRIMARY KEY,
    phase_id TEXT NOT NULL,
    title_fa TEXT NOT NULL,
    title_en TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('done','in_progress','next','planned','blocked','optional')),
    priority TEXT NOT NULL,
    owner TEXT NOT NULL,
    note_fa TEXT,
    note_en TEXT,
    sort_order INTEGER NOT NULL,
    updated_at TEXT NOT NULL
);

CREATE INDEX idx_project_tasks_phase ON project_tasks(phase_id, sort_order);
CREATE INDEX idx_project_tasks_status ON project_tasks(status, priority);
CREATE INDEX idx_pages_sequence_page ON pages(sequence_page);
CREATE INDEX idx_pages_printed_page ON pages(printed_page);
CREATE INDEX idx_entries_category ON entries(category_id, sort_order);
CREATE INDEX idx_entries_source_page ON entries(source_id, sequence_page);
CREATE INDEX idx_entries_title_fa ON entries(title_fa);

-- Contentless FTS5 search table; populated by the build script.
CREATE VIRTUAL TABLE entries_fts USING fts5(
    title_fa,
    visual_cue_fa,
    description_fa,
    analysis_fa,
    tokenize='unicode61'
);
