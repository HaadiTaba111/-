#!/usr/bin/env python3
"""Embed the current JSON dataset in a standalone offline admin dashboard."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "data/face_reading_fa.json"
template = ROOT / "dashboard/admin_dashboard.template.html"
output = ROOT / "dashboard/admin_dashboard.html"

data = json.loads(source.read_text("utf-8"))
payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
# Prevent a data value from terminating the surrounding script element.
payload = payload.replace("<", "\\u003c").replace("\u2028", "\\u2028").replace("\u2029", "\\u2029")
html = template.read_text("utf-8").replace("__DATA_JSON__", payload)
output.write_text(html, "utf-8")
print(f"Wrote {output} ({output.stat().st_size:,} bytes; {len(data['entries'])} entries)")
