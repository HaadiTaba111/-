#!/usr/bin/env python3
"""Apply the approved offline/on-device architecture to the project roadmap."""
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
path = ROOT / "project/roadmap.json"
roadmap = json.loads(path.read_text("utf-8"))
roadmap["version"] = "1.1.0"
roadmap["updated_at"] = "2026-08-18T00:00:00+03:30"

phase = next(x for x in roadmap["phases"] if x["id"] == "request_delivery")
phase["title_fa"] = "قابلیت‌های آنلاین اختیاری آینده"
phase["title_en"] = "Optional future online features"

for task in roadmap["tasks"]:
    if task["phase_id"] == "request_delivery":
        task["status"] = "optional"
        task["priority"] = "low"
        task["note_fa"] = "خارج از معماری اصلی آفلاین؛ فقط در صورت تصمیم جدید در آینده."
        task["note_en"] = "Outside the offline core; revisit only after a future product decision."

optional_admin = {
    "admin_backend", "admin_auth_rbac", "admin_request_queue", "admin_backup"
}
for task in roadmap["tasks"]:
    if task["id"] in optional_admin:
        task["status"] = "optional"
        task["priority"] = "low"
        task["note_fa"] = "برای اپ آفلاین لازم نیست؛ داشبورد فعلی مستقل و محلی است."
        task["note_en"] = "Not required by the offline app; the current dashboard is local and standalone."
    if task["id"] == "live_server_nonce":
        task["status"] = "optional"
        task["priority"] = "low"
        task["note_fa"] = "در نسخه آفلاین، چالش با SecureRandom محلی ساخته می‌شود."
        task["note_en"] = "The offline version uses locally generated SecureRandom challenges."
    if task["id"] == "privacy_no_raw_photo":
        task["status"] = "next"

new_tasks = [
    {"id":"product_offline_decision","phase_id":"product","title_fa":"تأیید معماری کاملاً آفلاین و بدون حساب/سرور","title_en":"Approve fully offline architecture without accounts or servers","status":"done","priority":"critical","owner":"hadi","sort_order":5,"note_fa":"اینترنت فقط برای نصب یا به‌روزرسانی برنامه از فروشگاه استفاده می‌شود."},
    {"id":"android_no_internet_permission","phase_id":"android","title_fa":"حذف مجوز INTERNET از AndroidManifest","title_en":"Omit the INTERNET permission from AndroidManifest","status":"next","priority":"critical","owner":"developer","sort_order":15},
    {"id":"android_preview_analysis_only","phase_id":"android","title_fa":"استفاده فقط از CameraX Preview و ImageAnalysis و عدم استفاده از ImageCapture","title_en":"Use CameraX Preview and ImageAnalysis only; do not use ImageCapture","status":"planned","priority":"critical","owner":"developer","sort_order":25},
    {"id":"android_embedded_room","phase_id":"android","title_fa":"قرار دادن SQLite نهایی داخل اپ و خواندن آن با Room","title_en":"Embed the final SQLite database and access it with Room","status":"planned","priority":"critical","owner":"developer","sort_order":75},
    {"id":"android_no_default_history","phase_id":"android","title_fa":"عدم ایجاد تاریخچه تحلیل به‌صورت پیش‌فرض","title_en":"Do not create an analysis history by default","status":"planned","priority":"critical","owner":"developer","sort_order":105},
    {"id":"android_report_saf","phase_id":"android","title_fa":"ذخیره اختیاری گزارش PDF/JSON/TXT با Storage Access Framework","title_en":"Optionally export PDF/JSON/TXT reports with Storage Access Framework","status":"planned","priority":"high","owner":"developer","sort_order":115},
    {"id":"android_report_without_face","phase_id":"android","title_fa":"تضمین نبود عکس، فریم یا embedding چهره در گزارش","title_en":"Ensure reports contain no face image, frame, or embedding","status":"planned","priority":"critical","owner":"developer","sort_order":120},
    {"id":"live_local_secure_random","phase_id":"liveness","title_fa":"تولید چالش تصادفی محلی با SecureRandom","title_en":"Generate randomized local challenges with SecureRandom","status":"planned","priority":"critical","owner":"developer","sort_order":15},
    {"id":"privacy_no_network_sdks","phase_id":"privacy_security","title_fa":"حذف Analytics، تبلیغات، Remote Config و SDKهای شبکه‌ای","title_en":"Exclude analytics, ads, Remote Config, and network SDKs","status":"planned","priority":"critical","owner":"developer","sort_order":45},
    {"id":"privacy_memory_only_frames","phase_id":"privacy_security","title_fa":"بازبینی فنی برای جلوگیری از نوشتن فریم در cache یا فایل موقت","title_en":"Audit the app to prevent frames from reaching caches or temp files","status":"planned","priority":"critical","owner":"security","sort_order":47},
    {"id":"admin_offline_content_build","phase_id":"admin","title_fa":"ساخت خط تولید محلی برای تبدیل اصلاحات داشبورد به SQLite داخل نسخه بعدی اپ","title_en":"Build a local pipeline from dashboard corrections to the next embedded SQLite release","status":"next","priority":"high","owner":"assistant","sort_order":25},
    {"id":"qa_network_absence","phase_id":"quality_release","title_fa":"تست قطعی نبود ترافیک شبکه و نبود مجوز INTERNET","title_en":"Verify zero network traffic and absence of INTERNET permission","status":"planned","priority":"critical","owner":"qa","sort_order":65}
]
existing = {x["id"] for x in roadmap["tasks"]}
roadmap["tasks"].extend(x for x in new_tasks if x["id"] not in existing)
roadmap["tasks"].sort(key=lambda x: (next(p["sort_order"] for p in roadmap["phases"] if p["id"] == x["phase_id"]), x["sort_order"], x["id"]))
path.write_text(json.dumps(roadmap, ensure_ascii=False, indent=2) + "\n", "utf-8")
print(f"Updated {path}: {len(roadmap['tasks'])} tasks")
