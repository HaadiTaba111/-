#!/usr/bin/env python3
"""OCR scanned Persian face-reading PDFs into per-page TXT/TSV files.

Usage:
  python scripts/ocr_pdfs.py [PDF ...]

Environment overrides:
  TESSERACT_BIN, TESSDATA_PREFIX, OCR_WORKERS
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pymupdf
from PIL import Image, ImageEnhance, ImageFilter, ImageOps

ROOT = Path(__file__).resolve().parents[1]
DEFAULT_INPUT = ROOT.parent / "uploads"
OUT = ROOT / "ocr"
TMP = ROOT / ".ocr_tmp"
TESS = Path(os.getenv("TESSERACT_BIN", ROOT.parent / ".local/tesseract/usr/bin/tesseract"))
TESSDATA = Path(os.getenv("TESSDATA_PREFIX", ROOT.parent / ".local/tessdata-best"))
LOCAL_LIB = ROOT.parent / ".local/tesseract/usr/lib/x86_64-linux-gnu"
WORKERS = int(os.getenv("OCR_WORKERS", "6"))

RANGE_RE = re.compile(r"\[(\d+)\s*[-–]\s*(\d+)\]")


def source_range(pdf: Path) -> tuple[int, int]:
    match = RANGE_RE.search(pdf.stem)
    if not match:
        raise ValueError(f"No [start-end] page range in filename: {pdf.name}")
    return int(match.group(1)), int(match.group(2))


def safe_source_id(pdf: Path) -> str:
    start, end = source_range(pdf)
    return f"face_reading_3_{start:03d}_{end:03d}"


def preprocess_page(pdf_path: str, pdf_index: int, image_path: str) -> None:
    doc = pymupdf.open(pdf_path)
    page = doc[pdf_index]
    # The source scans respond best to a clean 2x RGB render. More aggressive
    # scaling/thresholding causes Tesseract to lose small Persian text lines.
    pix = page.get_pixmap(matrix=pymupdf.Matrix(2.0, 2.0), colorspace=pymupdf.csRGB, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
    image.save(image_path, format="PNG", optimize=True)


def ocr_one(task: tuple[str, int, int, str]) -> tuple[int, str]:
    pdf_path, pdf_index, book_page, source_id = task
    source_dir = OUT / source_id
    source_dir.mkdir(parents=True, exist_ok=True)
    outbase = source_dir / f"page_{book_page:03d}"
    txt = outbase.with_suffix(".txt")
    tsv = outbase.with_suffix(".tsv")
    if txt.exists() and tsv.exists() and txt.stat().st_size > 20:
        return book_page, "cached"

    TMP.mkdir(parents=True, exist_ok=True)
    image_path = TMP / f"{source_id}_{book_page:03d}.png"
    preprocess_page(pdf_path, pdf_index, str(image_path))

    env = os.environ.copy()
    env["TESSDATA_PREFIX"] = str(TESSDATA)
    env["LD_LIBRARY_PATH"] = str(LOCAL_LIB) + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    cmd = [
        str(TESS), str(image_path), str(outbase),
        "-l", "fas+eng", "--oem", "1", "--psm", "3",
        "-c", "preserve_interword_spaces=1", "txt", "tsv",
    ]
    try:
        subprocess.run(cmd, check=True, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    finally:
        image_path.unlink(missing_ok=True)
    return book_page, "ocr"


def main() -> None:
    pdfs = [Path(x) for x in sys.argv[1:]] if len(sys.argv) > 1 else sorted(DEFAULT_INPUT.glob("*.pdf"))
    tasks: list[tuple[str, int, int, str]] = []
    for pdf in sorted(pdfs):
        start, end = source_range(pdf)
        doc = pymupdf.open(pdf)
        if len(doc) != end - start + 1:
            raise ValueError(f"Range/page-count mismatch for {pdf.name}: {len(doc)} pages vs [{start}-{end}]")
        source_id = safe_source_id(pdf)
        for index in range(len(doc)):
            tasks.append((str(pdf), index, start + index, source_id))
        doc.close()

    print(f"OCR: {len(tasks)} pages from {len(pdfs)} PDF files; workers={WORKERS}")
    completed = 0
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        futures = [pool.submit(ocr_one, task) for task in tasks]
        for future in as_completed(futures):
            page, status = future.result()
            completed += 1
            print(f"[{completed:03d}/{len(tasks):03d}] page {page}: {status}", flush=True)
    print("Done.")


if __name__ == "__main__":
    main()
