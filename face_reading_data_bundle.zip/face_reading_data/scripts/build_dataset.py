#!/usr/bin/env python3
"""Build normalized JSON and SQLite deliverables from OCR page files."""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import unicodedata
from difflib import SequenceMatcher
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
OCR = ROOT / "ocr"
DATA = ROOT / "data"
DB_DIR = ROOT / "database"
UPLOADS = WORKSPACE / "uploads"

CREATED_AT = "2026-08-18T00:00:00+03:30"
SCHEMA_VERSION = "1.0.0"

# Keys are sequence numbers from the uploaded split filenames, not printed book pages.
TITLES = {
    91: "انقطاع بین بینی و پیشانی",
    92: "برآمدگی بالای بینی",
    93: "وجود گره در بالای بینی",
    94: "تقعر در بالای بینی",
    95: "تحدب در بالای بینی (بینی عقابی)",
    96: "پهنای بینی",
    97: "بینی پهن",
    98: "بینی نازک",
    99: "خطوط سطحی بالای پره بینی",
    100: "خطوط عمیق بالای پره بینی",
    101: "سربالا",
    102: "سربالا و نوک‌تیز",
    103: "بدون زاویه",
    104: "سرپایین",
    105: "سرپایین و نوک‌تیز",
    106: "نوک پهن",
    107: "نوک گرد",
    108: "نوک نازک",
    109: "شیار در نوک بینی",
    110: "دل‌گون",
    111: "سوراخ بینی خیلی تنگ",
    112: "سوراخ بینی خیلی گشاد",
    113: "سوراخ بینی تنگ و بلند",
    114: "سوراخ بینی بسیار گشاد و مخروطی",
    115: "سوراخ بینی گرد",
    116: "سوراخ بینی مستطیلی",
    117: "سوراخ بینی ریز و مثلثی",
    118: "افتادگی قسمت پایینی بینی",
    119: "گوش بزرگ",
    120: "گوش کوچک",
    211: "خطوط راز",
    212: "خط عمیق عمودی روی پیشانی",
    213: "سبیل",
    214: "ریش گرد",
    215: "ریش زاویه‌دار",
    216: "ریش نوک‌تیز",
    217: "صورت پهن متمایل به صورت مربعی",
    218: "صورت باریک",
    219: "صورت لوزی",
    220: "صورت گلابی‌شکل",
    221: "صورت تخت",
    222: "بزرگ‌تر بودن ناحیه میانی",
    223: "کوچک‌تر بودن ناحیه میانی",
    224: "بزرگ‌تر بودن ناحیه پایینی",
    225: "کوچک‌تر بودن ناحیه پایینی",
    226: "بزرگ‌تر بودن ناحیه بالایی",
    227: "کوچک‌تر بودن ناحیه بالایی",
    228: "محدب",
    229: "فوق‌العاده محدب",
    230: "نسبتاً محدب",
    231: "مقعر",
    232: "فوق‌العاده مقعر",
    233: "متناسب",
    234: "محدب / مقعر",
    235: "مقعر / محدب",
    236: "فرق سر بالا / پیشانی پایین",
    237: "فرق سر پایین / پیشانی بالا",
    238: "سر گرد",
    239: "سر مربعی",
    240: "فکری",
    241: "جسمی",
    242: "احساسی",
    243: "فکری / جسمی",
    244: "فکری / احساسی",
    245: "جسمی / احساسی",
    246: "خال‌ها – بخش ۱",
    247: "خال‌ها – بخش ۲",
    248: "خال‌ها – بخش ۳",
    249: "خال‌ها – بخش ۴",
    250: "خال‌ها – بخش ۵",
    251: "خال‌ها – بخش ۶",
    252: "شناخت افراد در جمع چندنفره",
}

CATEGORIES = [
    {"id": "nose_bridge", "name_fa": "پل بینی و اتصال پیشانی", "sort_order": 10},
    {"id": "nose", "name_fa": "بینی", "sort_order": 20},
    {"id": "ear", "name_fa": "گوش", "sort_order": 30},
    {"id": "mouth_lines", "name_fa": "دهان و خطوط چهره", "sort_order": 40},
    {"id": "facial_hair", "name_fa": "موی صورت", "sort_order": 50},
    {"id": "face_shape", "name_fa": "فرم صورت و سر", "sort_order": 60},
    {"id": "face_temperament", "name_fa": "حالت کلی صورت", "sort_order": 70},
    {"id": "moles", "name_fa": "خال‌ها", "sort_order": 80},
    {"id": "group_reading", "name_fa": "تحلیل افراد در جمع", "sort_order": 90},
]


def category_for(page: int) -> str:
    if 91 <= page <= 95: return "nose_bridge"
    if 96 <= page <= 118: return "nose"
    if 119 <= page <= 120: return "ear"
    if 211 <= page <= 212: return "mouth_lines"
    if 213 <= page <= 216: return "facial_hair"
    if 217 <= page <= 239: return "face_shape"
    if 240 <= page <= 245: return "face_temperament"
    if 246 <= page <= 251: return "moles"
    return "group_reading"


def source_meta(page: int) -> tuple[str, str, int, int, int]:
    if 91 <= page <= 120:
        return "face_reading_3_091_120", "صورت شناسی 3 [91-120].pdf", 91, 120, 4
    if 211 <= page <= 240:
        return "face_reading_3_211_240", "صورت شناسی 3 [211-240].pdf", 211, 240, 6
    if 241 <= page <= 252:
        return "face_reading_3_241_252", "صورت شناسی 3 [241-252].pdf", 241, 252, 6
    raise ValueError(page)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_chars(text: str) -> str:
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Cf")
    return text.translate(str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "هٔ"}))


def clean_line(line: str) -> str:
    line = normalize_chars(line)
    line = re.sub(r"[A-Za-z]+", " ", line)
    line = re.sub(r"[\u0660-\u0669\d]+", " ", line)
    line = re.sub(r"[|~=^_<>\\/]+", " ", line)
    line = re.sub(r"\s+", " ", line).strip(" .،؛:-–—+*#")
    line = re.sub(r"\s+([،؛:.!?؟])", r"\1", line)
    return line.strip()


def persian_count(text: str) -> int:
    return len(re.findall(r"[\u0600-\u06FF]", text))


def useful_lines(text: str, min_persian: int = 7) -> list[str]:
    result = []
    for raw in text.splitlines():
        cleaned = clean_line(raw)
        p = persian_count(cleaned)
        alnum = len(re.findall(r"[\w\u0600-\u06FF]", cleaned))
        if p >= min_persian and (not alnum or p / alnum >= 0.68):
            result.append(cleaned)
    return result


def join_lines(lines: list[str]) -> str:
    text = " ".join(lines)
    text = re.sub(r"\s+", " ", text).strip()
    # Conservative typographic fixes only; the raw OCR is retained separately.
    text = text.replace("می شود", "می‌شود").replace("می کنند", "می‌کنند")
    text = text.replace("می کند", "می‌کند").replace("می دهند", "می‌دهند")
    return text


def strip_heading(lines: list[str], title: str) -> list[str]:
    generic = {
        "صورت", "زاویه بینی", "گوش", "گوش بزرگ", "ریش", "خال‌ها",
        "شناخت روحیات از روی حالت صورت", "شناخت افراد در جمع چندنفره", "تحلیل موضوعی",
    }

    def compact(value: str) -> str:
        return "".join(re.findall(r"[\u0600-\u06FF]", value))

    title_compact = compact(title)
    generic_compact = {compact(x) for x in generic}
    title_words = set(re.findall(r"[\u0600-\u06FF]+", title))
    out = []
    for line in lines:
        line_compact = compact(line)
        words = set(re.findall(r"[\u0600-\u06FF]+", line))
        if line_compact in generic_compact:
            continue
        # OCR often drops spaces or one short word from headings. A compact
        # character comparison catches forms such as «بینیپهن» and «خطوطراز».
        if len(line) <= 65 and line_compact and SequenceMatcher(None, line_compact, title_compact).ratio() >= 0.62:
            continue
        if len(line) <= 45 and words and len(words & title_words) / max(1, len(words | title_words)) >= 0.55:
            continue
        out.append(line)
    return out


def split_entry(page: int, raw: str, top: str, analysis_region: str) -> tuple[str | None, str, str | None]:
    title = TITLES[page]

    def parse_main(candidate: str) -> tuple[str | None, str]:
        # Never let the lower analysis block leak into the main description.
        candidate = candidate.split("تحلیل موضوعی", 1)[0]
        lines = strip_heading(useful_lines(candidate), title)
        cue = None
        description_lines = []
        for line in lines:
            if cue is None and (line.startswith("(") or line.endswith(")")) and persian_count(line) >= 6:
                cue = line.strip("() ")
            else:
                description_lines.append(line)
        return cue, join_lines(description_lines)

    # Region OCR usually has cleaner spacing, while whole-page OCR sometimes
    # captures an extra final line. Select the more complete transcription.
    top_visual, top_description = parse_main(top)
    raw_visual, raw_description = parse_main(raw)
    if persian_count(raw_description) > persian_count(top_description):
        visual, description = raw_visual or top_visual, raw_description
    else:
        visual, description = top_visual or raw_visual, top_description

    # Prefer the longer of whole-page and region OCR for the optional analysis.
    raw_analysis = raw.split("تحلیل موضوعی", 1)[1] if "تحلیل موضوعی" in raw else ""
    region_analysis = analysis_region.split("تحلیل موضوعی", 1)[1] if "تحلیل موضوعی" in analysis_region else ""
    candidates = [join_lines(useful_lines(x)) for x in (raw_analysis, region_analysis)]
    analysis = max(candidates, key=persian_count) if any(candidates) else ""

    # Mole diagrams and the final list use multi-panel/full-page layouts; preserve
    # the best full-page transcription instead of forcing the standard template.
    if 246 <= page <= 252:
        all_text = join_lines(strip_heading(useful_lines(raw, min_persian=6), title))
        description = all_text or description
        visual = None
        analysis = ""

    return visual or None, description, analysis or None


def quality_estimate(raw: str, description: str) -> float:
    p = persian_count(raw)
    latin = len(re.findall(r"[A-Za-z]", normalize_chars(raw)))
    contamination = latin / max(1, p + latin)
    length_factor = min(1.0, persian_count(description) / 280)
    score = 0.56 + 0.25 * (1 - min(1, contamination * 3)) + 0.12 * length_factor
    return round(max(0.35, min(0.92, score)), 2)


def make_sources() -> list[dict]:
    records = []
    for sid, filename, start, end, offset in [
        ("face_reading_3_091_120", "صورت شناسی 3 [91-120].pdf", 91, 120, 4),
        ("face_reading_3_211_240", "صورت شناسی 3 [211-240].pdf", 211, 240, 6),
        ("face_reading_3_241_252", "صورت شناسی 3 [241-252].pdf", 241, 252, 6),
    ]:
        path = UPLOADS / filename
        records.append({
            "id": sid,
            "file_name": filename,
            "sequence_page_start": start,
            "sequence_page_end": end,
            "printed_page_offset": offset,
            "printed_page_start": start + offset,
            "printed_page_end": end + offset,
            "page_count": end - start + 1,
            "sha256": sha256(path),
        })
    return records


def load_pages() -> tuple[list[dict], list[dict]]:
    page_records, entries = [], []
    for sequence_page in sorted(TITLES):
        sid, filename, start, end, offset = source_meta(sequence_page)
        base = OCR / sid / f"page_{sequence_page:03d}"
        raw = base.with_suffix(".txt").read_text("utf-8").strip()
        top_path = Path(str(base) + "_top.txt")
        analysis_path = Path(str(base) + "_analysis.txt")
        top = top_path.read_text("utf-8").strip() if top_path.exists() else raw
        analysis_region = analysis_path.read_text("utf-8").strip() if analysis_path.exists() else ""
        visual, description, analysis = split_entry(sequence_page, raw, top, analysis_region)
        q = quality_estimate(raw, description)
        page_id = f"page_{sequence_page:03d}"
        review = "high_priority_review" if 246 <= sequence_page <= 251 else "needs_review"
        page_records.append({
            "id": page_id,
            "source_id": sid,
            "source_file": filename,
            "pdf_page_index": sequence_page - start,
            "sequence_page": sequence_page,
            "printed_page": sequence_page + offset,
            "ocr_text_raw": normalize_chars(raw),
            "ocr_top_region_raw": normalize_chars(top),
            "ocr_analysis_region_raw": normalize_chars(analysis_region),
            "quality": {
                "method": "Tesseract 5.5 / fas+eng / whole page plus region OCR",
                "estimated_score": q,
                "review_status": review,
                "human_verified": False,
            },
        })
        entries.append({
            "id": f"entry_{sequence_page:03d}",
            "category_id": category_for(sequence_page),
            "content_type": "multi_panel" if 246 <= sequence_page <= 251 else ("article" if sequence_page in (96, 252) else "feature"),
            "title_fa": TITLES[sequence_page],
            "visual_cue_fa": visual,
            "description_fa": description,
            "analysis_fa": analysis,
            "source": {
                "source_id": sid,
                "page_id": page_id,
                "sequence_page": sequence_page,
                "printed_page": sequence_page + offset,
            },
            "review_status": review,
            "sort_order": sequence_page,
            "tags": [category_for(sequence_page), "صورت‌شناسی", "فارسی"],
        })
    return page_records, entries


def build_sqlite(dataset: dict, path: Path) -> None:
    path.unlink(missing_ok=True)
    con = sqlite3.connect(path)
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=DELETE")
    con.executescript((ROOT / "database" / "schema.sql").read_text("utf-8"))
    meta = {
        "schema_version": SCHEMA_VERSION,
        "dataset_id": dataset["dataset_id"],
        "language": dataset["language"],
        "created_at": dataset["created_at"],
        "scientific_status": "digitized_source_claims_not_scientifically_validated",
    }
    con.executemany("INSERT INTO metadata(key,value) VALUES (?,?)", meta.items())
    for s in dataset["sources"]:
        con.execute(
            "INSERT INTO sources VALUES (?,?,?,?,?,?,?,?,?)",
            (s["id"], s["file_name"], s["sequence_page_start"], s["sequence_page_end"],
             s["printed_page_offset"], s["printed_page_start"], s["printed_page_end"], s["page_count"], s["sha256"]),
        )
    for c in dataset["categories"]:
        con.execute("INSERT INTO categories VALUES (?,?,?)", (c["id"], c["name_fa"], c["sort_order"]))
    for p in dataset["pages"]:
        con.execute(
            "INSERT INTO pages VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (p["id"], p["source_id"], p["pdf_page_index"], p["sequence_page"], p["printed_page"],
             p["ocr_text_raw"], p["ocr_top_region_raw"], p["ocr_analysis_region_raw"],
             p["quality"]["method"], p["quality"]["estimated_score"], p["quality"]["review_status"]),
        )
    for e in dataset["entries"]:
        con.execute(
            "INSERT INTO entries VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (e["id"], e["category_id"], e["content_type"], e["title_fa"], e["visual_cue_fa"],
             e["description_fa"], e["analysis_fa"], e["source"]["source_id"], e["source"]["page_id"],
             e["source"]["sequence_page"], e["source"]["printed_page"], e["review_status"], e["sort_order"]),
        )
        con.executemany("INSERT INTO entry_tags(entry_id,tag) VALUES (?,?)", [(e["id"], t) for t in e["tags"]])
        con.execute(
            "INSERT INTO entries_fts(rowid,title_fa,visual_cue_fa,description_fa,analysis_fa) "
            "SELECT rowid,title_fa,coalesce(visual_cue_fa,''),description_fa,coalesce(analysis_fa,'') FROM entries WHERE id=?",
            (e["id"],),
        )
    con.execute("INSERT INTO import_batches(id, imported_at, source_count, page_count, entry_count, note) VALUES (?,?,?,?,?,?)",
                ("batch_2026_08_18_001", CREATED_AT, len(dataset["sources"]), len(dataset["pages"]), len(dataset["entries"]), "Initial three uploaded PDF ranges"))
    con.commit()
    con.execute("VACUUM")
    con.close()


def main() -> None:
    DATA.mkdir(parents=True, exist_ok=True)
    DB_DIR.mkdir(parents=True, exist_ok=True)
    pages, entries = load_pages()
    dataset = {
        "schema_version": SCHEMA_VERSION,
        "dataset_id": "face_reading_fa",
        "language": "fa",
        "direction": "rtl",
        "created_at": CREATED_AT,
        "title_fa": "داده‌های صورت‌شناسی فارسی",
        "disclaimer_fa": (
            "این مجموعه صرفاً دیجیتال‌سازی ادعاهای منبع است و اعتبار علمی آن را تأیید نمی‌کند. "
            "از این محتوا برای تصمیم‌های استخدامی، اعتباری، پزشکی، حقوقی، امنیتی یا سایر تصمیم‌های مهم درباره افراد استفاده نشود."
        ),
        "sources": make_sources(),
        "categories": CATEGORIES,
        "stats": {"source_count": 3, "page_count": len(pages), "entry_count": len(entries)},
        "pages": pages,
        "entries": entries,
    }
    json_path = DATA / "face_reading_fa.json"
    json_path.write_text(json.dumps(dataset, ensure_ascii=False, indent=2) + "\n", "utf-8")
    build_sqlite(dataset, DB_DIR / "face_reading_fa.sqlite")
    print(f"Wrote {json_path} ({json_path.stat().st_size:,} bytes)")
    print(f"Wrote {DB_DIR / 'face_reading_fa.sqlite'} ({(DB_DIR / 'face_reading_fa.sqlite').stat().st_size:,} bytes)")
    print(json.dumps(dataset["stats"], ensure_ascii=False))


if __name__ == "__main__":
    main()
