#!/usr/bin/env python3
"""Repair, normalize and merge the two user-supplied text datasets.

The script intentionally records every repair and missing range. It never treats
truncated input as complete.
"""
from __future__ import annotations

import hashlib
import json
import re
import sqlite3
import unicodedata
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = ROOT.parent
UPLOADS = WORKSPACE / "uploads"
DATASET_PATH = ROOT / "data/face_reading_fa.json"
DB_PATH = ROOT / "database/face_reading_fa.sqlite"
IMPORTS = ROOT / "imports"
ROADMAP_PATH = ROOT / "project/roadmap.json"
CREATED_AT = "2026-08-18T00:00:00+03:30"
SCHEMA_VERSION = "1.1.0"

CATEGORY_DEFS = {
    "face_components": ("کاربرد اجزای صورت", 5),
    "hair": ("مو", 8),
    "face_combinations": ("ترکیب ویژگی‌های صورت", 55),
    "eyebrows": ("ابرو", 56),
    "chin": ("چانه", 57),
    "forehead_lines": ("خطوط پیشانی", 58),
    "facial_lines": ("خطوط صورت", 59),
}

CATEGORY_181 = {
    "face_types": "face_combinations",
    "eyebrow_types": "eyebrows",
    "chin_types": "chin",
    "forehead_lines": "forehead_lines",
    "mouth_lines": "facial_lines",
    "other_features": "facial_lines",
}

VERBS = (
    "باشد|باشند|بود|بودند|شود|شوند|شد|شدند|کند|کنند|کرد|کردند|دهد|دهند|"
    "گوید|گویند|تواند|توانند|آید|آیند|گیرد|گیرند|رود|روند|سازد|سازند|"
    "برد|برند|پذیرد|پذیرند|خواهد|خواهند|رسد|رسند|ماند|مانند|بیند|بینند"
)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def normalize_fa(value):
    if value is None:
        return None
    if isinstance(value, list):
        return [normalize_fa(x) for x in value]
    if not isinstance(value, str):
        return value
    text = unicodedata.normalize("NFC", value)
    text = "".join(ch for ch in text if unicodedata.category(ch) != "Cf" or ch == "\u200c")
    text = text.translate(str.maketrans({"ي": "ی", "ى": "ی", "ك": "ک", "ۀ": "هٔ"}))
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\s+([،؛:.!?؟])", r"\1", text)
    text = re.sub(r"([،؛:!?؟])(?=[آ-ی])", r"\1 ", text)
    text = re.sub(fr"\b(ن?می)\s*({VERBS})\b", r"\1‌\2", text)
    replacements = {
        "آنها": "آن‌ها", "اینها": "این‌ها", "آن طور": "آن‌طور",
        "همین طور": "همین‌طور", "به طور": "به‌طور", "فوق العاده": "فوق‌العاده",
        "اعتماد به نفس": "اعتمادبه‌نفس", "بی نهایت": "بی‌نهایت",
        "دست کم": "دست‌کم", "کم کم": "کم‌کم", "همیشـه": "همیشه",
        "ریاست طلب": "ریاست‌طلب", "صلح طلب": "صلح‌طلب", "کمال گرا": "کمال‌گرا",
        "تکامل طلب": "تکامل‌طلب", "شوخ طبع": "شوخ‌طبع", "خوش ذات": "خوش‌ذات",
        "سخت گیر": "سخت‌گیر", "مشکل کشا": "مشکل‌گشا",
        "می باشد": "می‌باشد", "می شوند": "می‌شوند", "می شود": "می‌شود",
        "می کنند": "می‌کنند", "می کند": "می‌کند", "نمی شود": "نمی‌شود",
        "نمی کنند": "نمی‌کنند", "نمی کند": "نمی‌کند",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.strip()


def repair_181() -> dict:
    source = UPLOADS / "181-210.txt"
    text = source.read_text("utf-8-sig")
    # One stray array-closing bracket follows the final item's analysis value.
    marker = '          "analysis": "اگر اطرافیانتان چنین خطی روی نرمی گوشمشان وجود داشته باشد حتما نسبت به درمان ایشان اقدام کنید. پیشنهادی که غالبا به مخاطبین می‌شود این است که از پودر هسته خرما استفاده نمایید. در کشور ما بعد از تصادفات بیشترین آمار علت مرگ و میر متعلق به سکته قلبی است. پس بهتر است این موضوع را جدی بگیرید. حتما لاله گوش عزیزانتان را مشاهده کنید و اگر دارای این خط هستند، حتما نسبت به درمان آنها اقدام کنید."\n          ]'
    replacement = marker.rsplit("\n", 1)[0]
    if marker not in text:
        raise ValueError("Expected repair marker not found in 181-210.txt")
    repaired = text.replace(marker, replacement, 1)
    parsed = json.loads(repaired)
    IMPORTS.mkdir(parents=True, exist_ok=True)
    (IMPORTS / "181-210.repaired.json").write_text(
        json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", "utf-8"
    )
    return parsed


def repair_35_partial() -> dict:
    source = UPLOADS / "35-94.txt"
    text = source.read_text("utf-8-sig").rstrip()
    # File ends after a complete field in the last complete record but omits the
    # record, array and root delimiters. Content after source page 39 is absent.
    repaired = text + "\n    }\n  ]\n}\n"
    parsed = json.loads(repaired)
    pages = sorted({r["source_page"] for r in parsed["records"]})
    if pages != [35, 36, 37, 38, 39]:
        raise ValueError(f"Unexpected recovered page coverage: {pages}")
    IMPORTS.mkdir(parents=True, exist_ok=True)
    (IMPORTS / "35-94.partial.repaired.json").write_text(
        json.dumps(parsed, ensure_ascii=False, indent=2) + "\n", "utf-8"
    )
    return parsed


def add_categories(dataset: dict) -> None:
    existing = {c["id"] for c in dataset["categories"]}
    for cid, (name, order) in CATEGORY_DEFS.items():
        if cid not in existing:
            dataset["categories"].append({"id": cid, "name_fa": name, "sort_order": order})
    dataset["categories"].sort(key=lambda x: x["sort_order"])


def make_page(source_id: str, source_file: str, page: int, start: int, raw: str, status: str, score: float) -> dict:
    return {
        "id": f"page_{source_id}_{page:03d}",
        "source_id": source_id,
        "source_file": source_file,
        "pdf_page_index": page - start,
        "sequence_page": page,
        "printed_page": page,
        "ocr_text_raw": raw,
        "ocr_top_region_raw": "",
        "ocr_analysis_region_raw": "",
        "quality": {
            "method": "User-supplied structured text; repaired JSON delimiters",
            "estimated_score": score,
            "review_status": status,
            "human_verified": False,
        },
    }


def entry_181(category_key: str, category_title: str, item: dict, index: int) -> dict:
    absolute_page = 180 + int(item["page"])
    title = normalize_fa(item.get("type") or f"رکورد {item['id']}")
    if title.startswith("چانه‌ی کرد"):
        title = title.replace("چانه‌ی کرد", "چانه‌ی گرد", 1)
    description = normalize_fa(" ".join(item.get("characteristics") or []))
    description = (description.replace("چانه‌ی کرد نمایانگر", "چانه‌ی گرد نمایانگر")
                   .replace("متقان", "متقن").replace("محتمم", "مصمم")
                   .replace("گوشا بوده", "کوشا بوده").replace("پرآمدگی", "برآمدگی"))
    if title == "چای پای کلاغ":
        title = "جای پای کلاغ"
    return {
        "id": f"txt181_{category_key}_{int(item['id']):03d}",
        "category_id": CATEGORY_181.get(category_key, "face_combinations"),
        "content_type": "feature",
        "title_fa": title,
        "visual_cue_fa": normalize_fa(item.get("subtitle")),
        "description_fa": description,
        "analysis_fa": normalize_fa(item.get("analysis")),
        "source": {
            "source_id": "json_181_210",
            "page_id": f"page_json_181_210_{absolute_page:03d}",
            "sequence_page": absolute_page,
            "printed_page": absolute_page,
            "original_relative_page": int(item["page"]),
        },
        "review_status": "needs_review",
        "sort_order": absolute_page * 100 + index,
        "tags": [normalize_fa(category_title), "صورت‌شناسی", "فارسی"],
        "original_entry_id": str(item["id"]),
    }


def category_35(value: str) -> str:
    return "face_components" if value == "کاربرد اجزای صورت" else "hair"


def entry_35(record: dict, index: int) -> dict:
    page = int(record["source_page"])
    tags = list(record.get("keywords") or []) + [record.get("category", ""), "صورت‌شناسی", "فارسی"]
    return {
        "id": f"txt035_{record['id']}",
        "category_id": category_35(record.get("category", "")),
        "content_type": "article" if record["id"] == "hair_general" else "feature",
        "title_fa": normalize_fa(record.get("title") or record["id"]),
        "visual_cue_fa": normalize_fa(record.get("visual_criterion")),
        "description_fa": normalize_fa(record.get("description") or ""),
        "analysis_fa": normalize_fa(record.get("analysis")),
        "source": {
            "source_id": "json_035_094_partial",
            "page_id": f"page_json_035_094_partial_{page:03d}",
            "sequence_page": page,
            "printed_page": page,
        },
        "review_status": "partial_source_needs_review",
        "sort_order": page * 100 + index,
        "tags": [normalize_fa(x) for x in tags if x],
        "original_entry_id": record["id"],
    }


def normalize_existing_entries(dataset: dict) -> None:
    for entry in dataset["entries"]:
        for key in ("title_fa", "visual_cue_fa", "description_fa", "analysis_fa"):
            entry[key] = normalize_fa(entry.get(key))
        entry["tags"] = normalize_fa(entry.get("tags", []))


def append_validation(dataset: dict) -> list[dict]:
    issues = [
        {
            "id": "issue_json_181_syntax_repaired", "source_id": "json_181_210", "page_id": None, "entry_id": None,
            "severity": "warning", "issue_code": "json_syntax_repaired",
            "message_fa": "یک براکت اضافه در فایل ۱۸۱–۲۱۰ حذف شد و ساختار JSON ترمیم گردید.",
            "message_en": "One extra bracket was removed from 181-210 and the JSON structure was repaired.",
            "resolved": 1, "created_at": CREATED_AT,
        },
        {
            "id": "issue_json_181_page_191", "source_id": "json_181_210", "page_id": "page_json_181_210_191", "entry_id": None,
            "severity": "warning", "issue_code": "page_has_no_record",
            "message_fa": "صفحهٔ نسبی ۱۱ (معادل صفحهٔ ۱۹۱) هیچ رکوردی ندارد؛ با منبع تصویری بررسی شود.",
            "message_en": "Relative page 11 (sequence page 191) has no record; compare it with the scanned source.",
            "resolved": 0, "created_at": CREATED_AT,
        },
        {
            "id": "issue_json_035_truncated", "source_id": "json_035_094_partial", "page_id": None, "entry_id": None,
            "severity": "error", "issue_code": "source_truncated",
            "message_fa": "فایل ۳۵–۹۴ ناقص و در میانهٔ خروجی قطع شده است؛ فقط صفحات ۳۵ تا ۳۹ بازیابی شدند.",
            "message_en": "The 35-94 file is truncated; only source pages 35 through 39 were recovered.",
            "resolved": 0, "created_at": CREATED_AT,
        },
        {
            "id": "issue_json_035_missing_40_94", "source_id": "json_035_094_partial", "page_id": None, "entry_id": None,
            "severity": "error", "issue_code": "declared_pages_missing",
            "message_fa": "صفحات اعلام‌شدهٔ ۴۰ تا ۹۴ در فایل وجود ندارند و باید دوباره ارسال شوند.",
            "message_en": "Declared pages 40 through 94 are absent and must be supplied again.",
            "resolved": 0, "created_at": CREATED_AT,
        },
        {
            "id": "issue_json_035_overlap_91_94", "source_id": "json_035_094_partial", "page_id": None, "entry_id": None,
            "severity": "info", "issue_code": "declared_range_overlap",
            "message_fa": "بازهٔ اعلام‌شدهٔ ۹۱ تا ۹۴ با PDF موجود ۹۱–۱۲۰ هم‌پوشانی دارد؛ پس از دریافت نسخهٔ کامل باید ادغام و رفع تکرار شود.",
            "message_en": "The declared 91-94 range overlaps the existing 91-120 PDF; deduplication is required after the complete file arrives.",
            "resolved": 0, "created_at": CREATED_AT,
        },
        {
            "id": "issue_medical_claim_210", "source_id": "json_181_210", "page_id": "page_json_181_210_210", "entry_id": "txt181_other_features_029",
            "severity": "warning", "issue_code": "medical_claim_policy_review",
            "message_fa": "این رکورد حاوی ادعای پزشکی/درمانی است و پیش از انتشار در گوگل‌پلی باید بازنویسی، منبع‌دهی یا از توصیه‌های اپ حذف شود.",
            "message_en": "This record contains a medical/treatment claim and needs policy review, sourcing, or removal from app recommendations before Google Play release.",
            "resolved": 0, "created_at": CREATED_AT,
        },
    ]
    dataset["validation_issues"] = issues
    return issues


def merge() -> dict:
    dataset = json.loads(DATASET_PATH.read_text("utf-8"))
    d181 = repair_181()
    d35 = repair_35_partial()
    dataset["schema_version"] = SCHEMA_VERSION
    normalize_existing_entries(dataset)
    add_categories(dataset)
    for source in dataset["sources"]:
        source.setdefault("source_type", "pdf_scan")
        source.setdefault("import_status", "ocr_needs_review")

    dataset["sources"].extend([
        {
            "id": "json_181_210", "file_name": "181-210.txt", "source_type": "structured_text",
            "sequence_page_start": 181, "sequence_page_end": 210, "printed_page_offset": 0,
            "printed_page_start": 181, "printed_page_end": 210, "page_count": 30,
            "actual_content_page_start": 181, "actual_content_page_end": 210,
            "actual_content_page_count": 29, "missing_content_pages": [191],
            "sha256": sha256(UPLOADS / "181-210.txt"), "import_status": "repaired_needs_review",
        },
        {
            "id": "json_035_094_partial", "file_name": "35-94.txt", "source_type": "structured_text",
            "sequence_page_start": 35, "sequence_page_end": 94, "printed_page_offset": 0,
            "printed_page_start": 35, "printed_page_end": 94, "page_count": 60,
            "actual_content_page_start": 35, "actual_content_page_end": 39,
            "actual_content_page_count": 5, "missing_content_ranges": [[40, 94]],
            "sha256": sha256(UPLOADS / "35-94.txt"), "import_status": "partial_truncated",
        },
    ])

    grouped181 = defaultdict(list)
    entries181 = []
    index = 0
    for category_key, section in d181["main_categories"].items():
        for item in section["items"]:
            index += 1
            e = entry_181(category_key, section["title"], item, index)
            entries181.append(e)
            grouped181[e["source"]["sequence_page"]].append(e)
    for page in range(181, 211):
        related = grouped181.get(page, [])
        raw = json.dumps(related, ensure_ascii=False) if related else ""
        status = "needs_review" if related else "missing_source_content"
        dataset["pages"].append(make_page("json_181_210", "181-210.txt", page, 181, raw, status, 0.93 if related else 0.0))

    grouped35 = defaultdict(list)
    entries35 = []
    for index, record in enumerate(d35["records"], 1):
        e = entry_35(record, index)
        entries35.append(e)
        grouped35[e["source"]["sequence_page"]].append(e)
    for page in sorted(grouped35):
        raw = json.dumps(grouped35[page], ensure_ascii=False)
        dataset["pages"].append(make_page("json_035_094_partial", "35-94.txt", page, 35, raw, "partial_source_needs_review", 0.88))

    dataset["entries"].extend(entries181 + entries35)
    dataset["app_profile"] = {
        "app_name_fa": "صورت‌شناسی",
        "app_name_en": "Face Reading",
        "owner_name_fa": "هادی طباطبایی",
        "owner_name_en": "Hadi Tabatabaei",
        "owner_city_fa": "تهران",
        "owner_city_en": "Tehran",
        "contact_email": "Hadi.tabatabaei@gmail.com",
        "assistant_name_fa": "دستیار هوشمند Arena.ai",
        "assistant_name_en": "Arena.ai Intelligent Assistant",
        "assistant_role_fa": "طراحی ساختار داده، اعتبارسنجی و داشبورد بازخوانی",
        "assistant_role_en": "Data architecture, validation, and review-dashboard assistance",
        "ui_languages": ["fa", "en"],
        "content_translation_status": "Persian proofreading first; English translation pending",
        "operation_mode": "offline_on_device",
        "internet_permission_required": False,
        "raw_face_photo_storage": False,
        "raw_face_photo_transmission": False,
        "report_export": "user_initiated_local_only",
    }
    append_validation(dataset)
    dataset["project_checklist"] = json.loads(ROADMAP_PATH.read_text("utf-8"))

    covered = sorted({p["sequence_page"] for p in dataset["pages"] if p["quality"]["review_status"] != "missing_source_content"})
    task_statuses = defaultdict(int)
    for task in dataset["project_checklist"]["tasks"]:
        task_statuses[task["status"]] += 1
    dataset["stats"] = {
        "source_count": len(dataset["sources"]),
        "page_record_count": len(dataset["pages"]),
        "entry_count": len(dataset["entries"]),
        "covered_sequence_page_count": len(set(covered)),
        "declared_source_page_count": sum(s["page_count"] for s in dataset["sources"]),
        "validation_issue_count": len(dataset["validation_issues"]),
        "unresolved_validation_issue_count": sum(not x["resolved"] for x in dataset["validation_issues"]),
        "project_task_count": len(dataset["project_checklist"]["tasks"]),
        "project_task_statuses": dict(task_statuses),
    }
    dataset["imports"] = [
        {"id": "batch_2026_08_18_002", "files": ["181-210.txt", "35-94.txt"], "status": "one repaired; one partial", "imported_at": CREATED_AT}
    ]
    return dataset


def insert_sqlite(dataset: dict) -> None:
    con = sqlite3.connect(DB_PATH)
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES ('schema_version',?)", (SCHEMA_VERSION,))
    new_sources = [s for s in dataset["sources"] if s["id"].startswith("json_")]
    for s in new_sources:
        con.execute(
            "INSERT INTO sources VALUES (?,?,?,?,?,?,?,?,?)",
            (s["id"], s["file_name"], s["sequence_page_start"], s["sequence_page_end"], s["printed_page_offset"],
             s["printed_page_start"], s["printed_page_end"], s["page_count"], s["sha256"]),
        )
    existing_categories = {r[0] for r in con.execute("SELECT id FROM categories")}
    for c in dataset["categories"]:
        if c["id"] not in existing_categories:
            con.execute("INSERT INTO categories VALUES (?,?,?)", (c["id"], c["name_fa"], c["sort_order"]))

    # Normalize already structured display columns in the DB, then rebuild FTS.
    base_entries = [e for e in dataset["entries"] if not e["id"].startswith("txt")]
    for e in base_entries:
        con.execute(
            "UPDATE entries SET title_fa=?,visual_cue_fa=?,description_fa=?,analysis_fa=? WHERE id=?",
            (e["title_fa"], e["visual_cue_fa"], e["description_fa"], e["analysis_fa"], e["id"]),
        )

    new_pages = [p for p in dataset["pages"] if p["source_id"].startswith("json_")]
    for p in new_pages:
        q = p["quality"]
        con.execute(
            "INSERT INTO pages VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (p["id"], p["source_id"], p["pdf_page_index"], p["sequence_page"], p["printed_page"],
             p["ocr_text_raw"], p["ocr_top_region_raw"], p["ocr_analysis_region_raw"], q["method"], q["estimated_score"], q["review_status"]),
        )
    new_entries = [e for e in dataset["entries"] if e["id"].startswith("txt")]
    for e in new_entries:
        con.execute(
            "INSERT INTO entries VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (e["id"], e["category_id"], e["content_type"], e["title_fa"], e["visual_cue_fa"], e["description_fa"],
             e["analysis_fa"], e["source"]["source_id"], e["source"]["page_id"], e["source"]["sequence_page"],
             e["source"]["printed_page"], e["review_status"], e["sort_order"]),
        )
        con.executemany("INSERT INTO entry_tags(entry_id,tag) VALUES (?,?)", [(e["id"], t) for t in sorted(set(e["tags"]))])

    con.execute("DELETE FROM entries_fts")
    con.execute(
        "INSERT INTO entries_fts(rowid,title_fa,visual_cue_fa,description_fa,analysis_fa) "
        "SELECT rowid,title_fa,coalesce(visual_cue_fa,''),description_fa,coalesce(analysis_fa,'') FROM entries"
    )
    profile = dataset["app_profile"]
    bilingual = {
        "app_name": (profile["app_name_fa"], profile["app_name_en"]),
        "owner_name": (profile["owner_name_fa"], profile["owner_name_en"]),
        "owner_city": (profile["owner_city_fa"], profile["owner_city_en"]),
        "contact_email": (profile["contact_email"], profile["contact_email"]),
        "assistant_name": (profile["assistant_name_fa"], profile["assistant_name_en"]),
        "assistant_role": (profile["assistant_role_fa"], profile["assistant_role_en"]),
        "operation_mode": ("کاملاً آفلاین و روی دستگاه", "Fully offline and on-device"),
        "internet_permission": ("ندارد", "Not requested"),
        "raw_photo_storage": ("غیرفعال", "Disabled"),
        "report_export": ("فقط با درخواست کاربر و روی دستگاه", "User-initiated, local-only"),
    }
    con.executemany("INSERT INTO app_profile(key,value_fa,value_en) VALUES (?,?,?)", [(k,*v) for k,v in bilingual.items()])
    for issue in dataset["validation_issues"]:
        con.execute(
            "INSERT INTO validation_issues VALUES (?,?,?,?,?,?,?,?,?,?)",
            (issue["id"], issue["source_id"], issue["page_id"], issue["entry_id"], issue["severity"], issue["issue_code"],
             issue["message_fa"], issue["message_en"], issue["resolved"], issue["created_at"],),
        )
    for task in dataset["project_checklist"]["tasks"]:
        con.execute(
            "INSERT INTO project_tasks VALUES (?,?,?,?,?,?,?,?,?,?,?)",
            (task["id"], task["phase_id"], task["title_fa"], task["title_en"], task["status"], task["priority"],
             task["owner"], task.get("note_fa"), task.get("note_en"), task["sort_order"], dataset["project_checklist"]["updated_at"]),
        )
    con.execute(
        "INSERT INTO import_batches(id, imported_at, source_count, page_count, entry_count, note) VALUES (?,?,?,?,?,?)",
        ("batch_2026_08_18_002", CREATED_AT, 2, len(new_pages), len(new_entries), "Imported repaired 181-210 and partial 35-94 text datasets"),
    )
    con.commit()
    con.execute("VACUUM")
    con.close()


def main() -> None:
    dataset = merge()
    DATASET_PATH.write_text(json.dumps(dataset, ensure_ascii=False, indent=2) + "\n", "utf-8")
    insert_sqlite(dataset)
    print(json.dumps(dataset["stats"], ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
