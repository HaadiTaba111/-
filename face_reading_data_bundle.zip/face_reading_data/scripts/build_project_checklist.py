#!/usr/bin/env python3
"""Render the structured roadmap as a human-readable Persian checklist."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
roadmap = json.loads((ROOT / "project/roadmap.json").read_text("utf-8"))
output = ROOT / "project/PROJECT_CHECKLIST.md"
icons = {"done": "✅", "in_progress": "🔄", "next": "⏭️", "planned": "⬜", "blocked": "⛔", "optional": "◻️"}
labels = {k: v["fa"] for k, v in roadmap["status_definitions"].items()}
counts = Counter(t["status"] for t in roadmap["tasks"])
lines = [
    "# چک‌لیست مادر پروژه صورت‌شناسی",
    "",
    f"آخرین به‌روزرسانی: `{roadmap['updated_at']}`",
    "",
    "## خلاصه وضعیت",
    "",
]
for status in ("done", "in_progress", "next", "planned", "blocked", "optional"):
    lines.append(f"- {icons[status]} **{labels[status]}:** {counts[status]}")
lines += [
    "",
    "> هدف حریم خصوصی: دریافت فقط از دوربین زنده، پردازش فریم در حافظه، عدم ذخیره یا ارسال عکس خام و بازگرداندن نتیجهٔ متنی.",
    "",
    "> هیچ سامانهٔ Liveness تشخیص صددرصد ندارد؛ خروجی باید امتیاز ریسک، Retry و مسیر بررسی دستی داشته باشد.",
    "",
]
phases = sorted(roadmap["phases"], key=lambda x: x["sort_order"])
for phase in phases:
    tasks = sorted((x for x in roadmap["tasks"] if x["phase_id"] == phase["id"]), key=lambda x: x["sort_order"])
    done = sum(x["status"] == "done" for x in tasks)
    lines += [f"## {phase['title_fa']}", "", f"پیشرفت ثبت‌شده: **{done}/{len(tasks)}**", ""]
    for task in tasks:
        checked = "x" if task["status"] == "done" else " "
        status = labels[task["status"]]
        note = f" — {task['note_fa']}" if task.get("note_fa") else ""
        lines.append(f"- [{checked}] {icons[task['status']]} **{task['title_fa']}** — `{status}` · اولویت `{task['priority']}` · مسئول `{task['owner']}`{note}")
    lines.append("")
lines += [
    "## تصمیم معماری اصلی آفلاین",
    "",
    "- اپ مجوز `INTERNET` ندارد و برای تحلیل به حساب، سرور یا API وابسته نیست.",
    "- فقط CameraX `Preview` و `ImageAnalysis` استفاده می‌شوند؛ `ImageCapture` و گالری وجود ندارند.",
    "- فریم‌ها فقط در RAM تحلیل و بلافاصله آزاد می‌شوند؛ عکس، thumbnail یا embedding ذخیره نمی‌شود.",
    "- مدل تشخیص، Liveness، قواعد و SQLite داخل APK/AAB قرار می‌گیرند.",
    "- گزارش فقط با انتخاب صریح کاربر و بدون عکس، به PDF/JSON/TXT روی گوشی ذخیره می‌شود.",
    "- داشبورد ادمین ابزار محلی تولید محتواست و دیتابیس تأییدشده همراه نسخه بعدی اپ منتشر می‌شود.",
    "- سایت، Request ID، Magic Link، حساب و Backend فقط قابلیت اختیاری آینده‌اند و جزو نسخه اصلی نیستند.",
    "",
    "## اصول غیرقابل مذاکره",
    "",
    "1. عدم ذخیره یا ارسال عکس خام چهره.",
    "2. عدم پذیرش عکس از گالری یا فایل سایت.",
    "3. رضایت آگاهانه قبل از دوربین.",
    "4. عدم استفاده برای سلامت، استخدام، اعتبار، حقوق، امنیت یا تصمیم‌های مهم.",
    "5. معرفی محتوا به‌عنوان سرگرمی/خودشناسی و نه تشخیص علمی شخصیت.",
    "6. امکان حذف درخواست و دادهٔ کاربر.",
    "7. تست عملی حملات چاپ، نمایشگر، گوشی‌به‌گوشی، ویدئو و دیپ‌فیک.",
]
output.write_text("\n".join(lines) + "\n", "utf-8")
print(f"Wrote {output} ({len(roadmap['tasks'])} tasks)")
