#!/usr/bin/env python3
"""Supplement whole-page OCR with fixed top/bottom text-region OCR.

These books use a stable layout: title and description above an illustration,
then an optional "تحلیل موضوعی" block below it. Region OCR recovers lines that
whole-page auto-layout sometimes misses.
"""
from __future__ import annotations

import os
import re
import subprocess
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import pymupdf
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT.parent / "uploads"
OUT = ROOT / "ocr"
TMP = ROOT / ".ocr_tmp"
TESS = ROOT.parent / ".local/tesseract/usr/bin/tesseract"
TESSDATA = ROOT.parent / ".local/tessdata-best"
LOCAL_LIB = ROOT.parent / ".local/tesseract/usr/lib/x86_64-linux-gnu"
WORKERS = int(os.getenv("OCR_WORKERS", "8"))
RANGE_RE = re.compile(r"\[(\d+)\s*[-–]\s*(\d+)\]")
REGIONS = {
    "top": (90, 90, 1110, 820),
    "analysis": (110, 850, 1110, 1410),
}


def process(task: tuple[str, int, int, str, str]) -> tuple[int, str]:
    pdf_path, pdf_index, book_page, source_id, region = task
    doc = pymupdf.open(pdf_path)
    pix = doc[pdf_index].get_pixmap(matrix=pymupdf.Matrix(2, 2), colorspace=pymupdf.csRGB, alpha=False)
    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples).crop(REGIONS[region])
    TMP.mkdir(parents=True, exist_ok=True)
    image_path = TMP / f"{source_id}_{book_page:03d}_{region}.png"
    image.save(image_path, "PNG", optimize=True)
    outbase = OUT / source_id / f"page_{book_page:03d}_{region}"
    env = os.environ.copy()
    env["TESSDATA_PREFIX"] = str(TESSDATA)
    env["LD_LIBRARY_PATH"] = str(LOCAL_LIB) + (":" + env["LD_LIBRARY_PATH"] if env.get("LD_LIBRARY_PATH") else "")
    try:
        subprocess.run(
            [str(TESS), str(image_path), str(outbase), "-l", "fas+eng", "--oem", "1", "--psm", "6", "txt"],
            check=True, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        )
    finally:
        image_path.unlink(missing_ok=True)
    return book_page, region


def main() -> None:
    tasks = []
    for pdf in sorted(INPUT.glob("*.pdf")):
        match = RANGE_RE.search(pdf.stem)
        if not match:
            continue
        start, end = map(int, match.groups())
        source_id = f"face_reading_3_{start:03d}_{end:03d}"
        doc = pymupdf.open(pdf)
        if len(doc) != end - start + 1:
            raise ValueError(f"Page mismatch: {pdf}")
        for i in range(len(doc)):
            for region in REGIONS:
                tasks.append((str(pdf), i, start + i, source_id, region))
        doc.close()
    print(f"Region OCR: {len(tasks)} jobs")
    with ProcessPoolExecutor(max_workers=WORKERS) as pool:
        for n, fut in enumerate(as_completed([pool.submit(process, t) for t in tasks]), 1):
            page, region = fut.result()
            print(f"[{n:03d}/{len(tasks):03d}] {page} {region}", flush=True)


if __name__ == "__main__":
    main()
