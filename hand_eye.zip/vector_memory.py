"""
Vector Memory store for SkyGround Agent.
Uses local SQLite with a hashing trick for dependency-free similarity search.
"""

from __future__ import annotations
import sqlite3
import json
from pathlib import Path
from typing import List, Dict, Any, Optional

class VectorMemoryStore:
    def __init__(self, db_path: Path, dimensions: int = 384):
        self.db_path = db_path
        self.dimensions = dimensions
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    text TEXT NOT NULL,
                    namespace TEXT NOT NULL,
                    source TEXT NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    tokens TEXT
                )
            ''')
            conn.commit()

    def _tokenize(self, text: str) -> List[str]:
        # Simple whitespace tokenizer for our mock semantic search
        return [w.lower() for w in text.split() if len(w) > 2]

    def add(self, text: str, namespace: str = "general", source: str = "agent_tool") -> None:
        if not text.strip():
            return
        tokens = self._tokenize(text)
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO memories (text, namespace, source, tokens) VALUES (?, ?, ?, ?)",
                (text, namespace, source, json.dumps(tokens))
            )
            conn.commit()

    def search(self, query: str, namespace: str = "", limit: int = 8) -> List[Dict[str, Any]]:
        query_tokens = set(self._tokenize(query))
        if not query_tokens:
            return []

        results = []
        with sqlite3.connect(self.db_path) as conn:
            conn.row_factory = sqlite3.Row
            sql = "SELECT * FROM memories"
            params = []
            if namespace:
                sql += " WHERE namespace = ?"
                params.append(namespace)
                
            cursor = conn.execute(sql, params)
            for row in cursor:
                row_tokens = set(json.loads(row["tokens"]))
                # Simple Jaccard similarity for mock vector search
                intersection = len(query_tokens.intersection(row_tokens))
                union = len(query_tokens.union(row_tokens))
                similarity = intersection / union if union > 0 else 0
                
                if similarity > 0:
                    results.append({
                        "id": row["id"],
                        "text": row["text"],
                        "namespace": row["namespace"],
                        "source": row["source"],
                        "timestamp": row["timestamp"],
                        "score": similarity
                    })
                    
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    def count(self) -> int:
        with sqlite3.connect(self.db_path) as conn:
            return conn.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
