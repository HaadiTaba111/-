import re

with open("/home/user/dashboard.py", "r", encoding="utf-8") as f:
    content = f.read()

prefix, html_content = content.split('DASHBOARD_HTML = r"""\n<!doctype html>')

# Add Tab buttons right before <div class="grid">
tab_html = """  <div class="tabs" style="margin-bottom: 16px;">
    <div class="tab active" onclick="switchTab('tab-main')">مانیتورینگ و تسک‌ها</div>
    <div class="tab" onclick="switchTab('tab-scaffold')">پروژه‌ساز و ابزارها</div>
    <div class="tab" onclick="switchTab('tab-config')">تنظیمات و دسترسی‌ها</div>
  </div>
"""

# Modify the structure
html_content = html_content.replace('<div class="grid">', tab_html + '  <div class="grid">\n    <main id="main-column">\n')

# Wrap panels
def wrap_panels(html):
    # Main panels:
    # Task Manager, Approvals, Ask Admin, Events
    # Scaffold panels:
    # Project Factory, Reflex, External API, Vector Memory
    # Config panels:
    # Admin Injection, Policy Templates, Session Permissions, Runtime Config, Status
    
    # We will just inject CSS classes or wrapper divs in the JS directly.
    # Actually, simpler: we modify the JS to hide/show panels based on their H2 titles!
    return html

# Let's just add the JS logic to filter panels by tab.
js_injection = """
function switchTab(tabId) {
  document.querySelectorAll('.tabs .tab').forEach(t => t.classList.remove('active'));
  event.target.classList.add('active');
  
  const panels = document.querySelectorAll('.panel');
  panels.forEach(p => {
    const h2 = p.querySelector('h2');
    if (!h2) return;
    const title = h2.textContent || '';
    
    let targetTab = 'tab-config';
    if (title.includes('Task Manager') || title.includes('درخواست‌های Approval') || title.includes('پرسش‌های ایجنت') || title.includes('رویدادها و لاگ')) {
      targetTab = 'tab-main';
    } else if (title.includes('Project Factory') || title.includes('Reflex') || title.includes('External API') || title.includes('Vector Memory')) {
      targetTab = 'tab-scaffold';
    }
    
    if (tabId === targetTab) {
      p.style.display = 'block';
    } else {
      p.style.display = 'none';
    }
  });
}

// run once on load
document.addEventListener('DOMContentLoaded', () => {
  const firstTab = document.querySelector('.tabs .tab');
  if(firstTab) firstTab.click();
});
"""

html_content = html_content.replace('let state = null;', js_injection + '\nlet state = null;')

with open("/home/user/dashboard.py", "w", encoding="utf-8") as f:
    f.write(prefix + 'DASHBOARD_HTML = r"""\n<!doctype html>' + html_content)

print("HTML modified")
