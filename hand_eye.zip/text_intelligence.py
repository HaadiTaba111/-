"""
Text intelligence module for SkyGround Agent.
Handles Unicode parsing, RTL/LTR detection, and language profiling.
"""

from __future__ import annotations
import dataclasses
import re
from typing import Dict, Any

@dataclasses.dataclass
class TextProfile:
    primary_language: str
    direction: str
    persian_chars: int
    latin_chars: int
    total_chars: int

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

def detect_text_profile(text: str) -> TextProfile:
    """Detect primary language and direction of the text."""
    if not text:
        return TextProfile("unknown", "LTR", 0, 0, 0)

    # Simplified Persian/Arabic Unicode blocks
    persian_pattern = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')
    latin_pattern = re.compile(r'[A-Za-z]')

    persian_chars = len(persian_pattern.findall(text))
    latin_chars = len(latin_pattern.findall(text))
    total_chars = len(text)

    if persian_chars == 0 and latin_chars == 0:
        primary_lang = "unknown"
        direction = "LTR"
    elif persian_chars > 0 and latin_chars == 0:
        primary_lang = "persian"
        direction = "RTL"
    elif latin_chars > 0 and persian_chars == 0:
        primary_lang = "english"
        direction = "LTR"
    else:
        primary_lang = "mixed"
        direction = "RTL" if persian_chars > latin_chars else "LTR"

    return TextProfile(
        primary_language=primary_lang,
        direction=direction,
        persian_chars=persian_chars,
        latin_chars=latin_chars,
        total_chars=total_chars
    )
