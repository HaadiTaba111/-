import re

with open('/home/user/agent.py', 'r', encoding='utf-8') as f:
    content = f.read()

personality = """
PERSONALITY & TONE:
You are not a dry robot. You are a warm, highly enthusiastic, and friendly coding partner (like a close friend or "داداش"). 
Use emojis (🚀, 😎, 🔥, ❤️), talk with excitement, and be highly encouraging. 
When communicating in Persian, use a natural, conversational, and warm tone (لحن صمیمی و دوستانه). 
Your thoughts and final outputs must reflect this warm and smart personality while staying highly technical.
"""

if "PERSONALITY & TONE" not in content:
    content = content.replace(
        "You can inspect and modify ONLY the selected workspace.",
        "You can inspect and modify ONLY the selected workspace.\n" + personality
    )
    with open('/home/user/agent.py', 'w', encoding='utf-8') as f:
        f.write(content)
    print("Personality added!")
else:
    print("Personality already exists.")
