"""
Skill Registry for SkyGround Agent.
Allows defining reusable, multi-step sub-tasks (skills).
"""

from __future__ import annotations
import dataclasses
import json
from pathlib import Path
from typing import Dict, Any, List, Optional

SAFETY_ORDER = {
    "silent": 0,
    "fast": 1,
    "confirm": 2,
    "approval": 3,
}

@dataclasses.dataclass
class SkillDefinition:
    name: str
    description: str
    parameters: Dict[str, Any]
    steps: List[str]
    requires_approval: bool = False
    safety_level: str = "confirm"
    status: str = "new"  # e.g., 'new', 'trusted'
    confidence: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return dataclasses.asdict(self)

class SkillRegistry:
    def __init__(self, storage_path: Path):
        self.storage_path = storage_path
        self.skills: Dict[str, SkillDefinition] = {}
        self._load()

    def _load(self):
        if not self.storage_path.exists():
            return
        try:
            with open(self.storage_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                for k, v in data.items():
                    self.skills[k] = SkillDefinition(**v)
        except Exception:
            pass

    def _save(self):
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        with open(self.storage_path, "w", encoding="utf-8") as f:
            json.dump({k: v.to_dict() for k, v in self.skills.items()}, f, indent=2, ensure_ascii=False)

    def register(self, skill: SkillDefinition) -> None:
        self.skills[skill.name] = skill
        self._save()

    def get(self, name: str) -> Optional[SkillDefinition]:
        return self.skills.get(name)

    def list_all(self) -> List[SkillDefinition]:
        return list(self.skills.values())
