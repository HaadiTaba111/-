#!/usr/bin/env bash
# ================================================================
# 🧠 مغز فارسی PRO - Persian Brain Professional
# 
# قابلیت‌های ویژه:
#   📄 تزریق PDF و اسناد (حتی از لینک!)
#   🎭 تشخیص خودکار حالت: جدی / شعر / گفتگو
#   🌀 معماری اسپیرال-تایم جای کسینوس
#   ⏳ محو خودکار اطلاعات قدیمی
#   🔗 اتصال به Gemma FT + LoRA
# ================================================================

set -euo pipefail
VERSION="3.0.0-PRO"

# رنگ‌بندی
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; PURPLE='\033[0;35m'; CYAN='\033[0;36m'
WHITE='\033[1;37m'; NC='\033[0m'; BOLD='\033[1m'

# ═══════════════════════════════════════════════
# 📂 تنظیمات
# ═══════════════════════════════════════════════

DATA_DIR="$HOME/.persian-brain-pro"
PDF_DIR="$DATA_DIR/pdfs"
MEMORY_FILE="$DATA_DIR/spiral-memory.json"
CONFIG_FILE="$DATA_DIR/config.json"
LOG_FILE="$DATA_DIR/brain-pro.log"

# تنظیمات اسپیرال-تایم
SPIRAL_R0=1.0
SPIRAL_V=0.05
SPIRAL_OMEGA=0.5
TIME_LAMBDA=0.1
HALF_LIFE=7  # روز

# ================================================================
# 📚 توابع پایه
# ================================================================

init() {
    mkdir -p "$DATA_DIR" "$PDF_DIR"
    [[ -f "$MEMORY_FILE" ]] || echo '[]' > "$MEMORY_FILE"
    [[ -f "$CONFIG_FILE" ]] || echo '{"mode":"auto","gemma_url":"","gemma_key":""}' > "$CONFIG_FILE"
}

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $*" | tee -a "$LOG_FILE"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*" | tee -a "$LOG_FILE"; }
error() { echo -e "${RED}[ERROR]${NC} $*" | tee -a "$LOG_FILE"; }

# ================================================================
# 📄 تزریق PDF و متن
# ================================================================

inject_text() {
    local text="$1"
    local title="${2:-سند بدون عنوان}"
    local poet="${3:-}"
    
    log "📥 تزریق: ${title}"
    
    # استخراج ابیات
    local verses=()
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        if [[ "$line" == *"/"* && ${#line} -ge 15 ]]; then
            verses+=("$line")
        fi
    done < <(echo "$text" | sed 's/\. /\n/g; s/،/\n/g')
    
    log "  🌸 ${#verses[@]} بیت استخراج شد"
    
    # ذخیره در حافظه اسپیرال
    local timestamp=$(date +%s%N)
    local importance=0.7
    
    # محاسبه موقعیت اسپیرال
    local mem_count=$(jq length "$MEMORY_FILE" 2>/dev/null || echo 0)
    local theta=$(echo "$SPIRAL_OMEGA * $mem_count" | bc -l 2>/dev/null || echo 0)
    local radius=$(echo "$SPIRAL_R0 + $SPIRAL_V * $mem_count" | bc -l 2>/dev/null || echo 1.0)
    local x=$(echo "$radius * c($theta)" | bc -l 2>/dev/null || echo 1.0)
    local y=$(echo "$radius * s($theta)" | bc -l 2>/dev/null || echo 0.0)
    
    # ذخیره در حافظه
    local entry=$(cat <<EOF
{
    "id": "doc-$(date +%s)-$RANDOM",
    "title": "$title",
    "text": $(echo "$text" | head -c 500 | jq -Rs '.'),
    "timestamp": $timestamp,
    "importance": $importance,
    "spiral": [$x, $y, $mem_count],
    "timeWeight": 1.0,
    "isDecayed": false,
    "verses": $(printf '%s\n' "${verses[@]}" | head -5 | jq -R '. | {text: .}' | jq -s '.')
}
EOF
)
    
    local tmp=$(mktemp)
    jq ". += [$entry]" "$MEMORY_FILE" > "$tmp" && mv "$tmp" "$MEMORY_FILE"
    
    log "  ✅ تزریق شد در موقعیت اسپیرال ($x, $y, $mem_count)"
}

# تزریق از URL
inject_url() {
    local url="$1"
    local title="${2:-$(basename "$url")}"
    
    log "🌐 دریافت از: $url"
    
    local data=$(curl -sL --max-time 15 -A "Mozilla/5.0 (PersianBrain-PRO)" "$url" 2>/dev/null || true)
    local text=""
    
    # تشخیص نوع
    if echo "$data" | head -1 | grep -q '^\s*[{\[]'; then
        # JSON
        text=$(echo "$data" | jq -r '.. | .text? // .content? // .verse? // empty' 2>/dev/null | tr '\n' '\n')
    else
        # HTML/Text
        text=$(echo "$data" | sed 's/<[^>]*>//g; s/&nbsp;//g; s/&[^;]*;//g')
    fi
    
    [[ -z "$text" ]] && { warn "  ⚠️ متنی دریافت نشد"; return 1; }
    
    inject_text "$text" "$title"
}

# ================================================================
# 🎭 تشخیص حالت پاسخ
# ================================================================

detect_mode() {
    local query="$1"
    local lower=$(echo "$query" | tr '[:upper:]' '[:lower:]')
    
    local serious=0
    local poetic=0
    local chat=0
    
    # کلمات جدی
    for word in "راهنمایی" "آموزش" "مشکل" "خطا" "help" "کمک" "تحلیل" "قانون" "چطور کار" "نصب"; do
        if [[ "$query" == *"$word"* ]]; then serious=$((serious + 2)); fi
    done
    
    # کلمات شعری
    for word in "شعر" "غزل" "حافظ" "سعدی" "بیت" "بگو" "بخون" "داستان" "گل" "عشق"; do
        if [[ "$query" == *"$word"* ]]; then poetic=$((poetic + 2)); fi
    done
    
    # کلمات گفتگو
    for word in "سلام" "چطوری" "خوبی" "داداش" "مرسی" "خوبم"; do
        if [[ "$query" == *"$word"* ]]; then chat=$((chat + 2)); fi
    done
    
    if [[ $serious -ge $poetic && $serious -ge $chat && $serious -ge 2 ]]; then
        echo "serious"
    elif [[ $poetic -ge $serious && $poetic -ge $chat && $poetic -ge 2 ]]; then
        echo "poetic"
    elif [[ $chat -gt 0 ]]; then
        echo "chat"
    else
        echo "auto"
    fi
}

respond() {
    local query="$1"
    local mode="${2:-auto}"
    
    if [[ "$mode" == "auto" ]]; then
        mode=$(detect_mode "$query")
    fi
    
    echo -e "\n${BOLD}${CYAN}🧠 حالت: ${mode}${NC}\n"
    
    case "$mode" in
        serious)
            echo -e "${RED}⚠️ حالت جدی: بدون شعر و جوک${NC}"
            echo -e "${WHITE}[پاسخ دقیق و مستند]${NC}"
            echo -e "  ${query}"
            echo -e "\n${GREEN}در حال پردازش سوال شما با دقت بالا...${NC}"
            ;;
        poetic)
            echo -e "${PURPLE}🌸 حالت شعری${NC}"
            echo -e "${WHITE}[پاسخ ادبی و هنری]${NC}"
            
            # یافتن شعر مرتبط از حافظه
            local verses=$(jq -r '[last(.[])? | .verses[]?.text // empty] | .[:3][]' "$MEMORY_FILE" 2>/dev/null)
            if [[ -n "$verses" ]]; then
                echo -e "\n${YELLOW}🌸 از حافظه اسپیرال:${NC}"
                echo "$verses" | while IFS= read -r v; do
                    [[ -n "$v" ]] && echo -e "  ${WHITE}$v${NC}"
                done
            fi
            ;;
        chat)
            echo -e "${BLUE}💬 حالت گفتگو${NC}"
            echo -e "${WHITE}[پاسخ صمیمی و محاوره‌ای]${NC}"
            echo -e "  ${query}"
            echo -e "\n${GREEN}چطوری می‌تونم کمک کنم؟${NC}"
            ;;
    esac
}

# ================================================================
# 🌀 نمایش اطلاعات اسپیرال
# ================================================================

show_spiral_info() {
    echo -e "${BOLD}${CYAN}🌀 معماری اسپیرال-تایم${NC}"
    echo "═══════════════════════════════════════════"
    echo -e "  ${WHITE}r₀ = ${SPIRAL_R0}${NC} (رادیوس اولیه)"
    echo -e "  ${WHITE}v  = ${SPIRAL_V}${NC} (سرعت شعاعی)"
    echo -e "  ${WHITE}ω  = ${SPIRAL_OMEGA}${NC} (سرعت زاویه‌ای)"
    echo -e "  ${WHITE}λ  = ${TIME_LAMBDA}${NC} (نرخ فراموشی)"
    echo -e "  ${WHITE}τ  = ${HALF_LIFE} روز${NC} (نیمه‌عمر اطلاعات)"
    echo ""
    
    local count=$(jq length "$MEMORY_FILE" 2>/dev/null || echo 0)
    local active=$(jq 'map(select(.isDecayed == false)) | length' "$MEMORY_FILE" 2>/dev/null || echo 0)
    local avg_weight=$(jq 'map(.timeWeight) | add / length' "$MEMORY_FILE" 2>/dev/null || echo 0)
    
    echo -e "  📊 آمار حافظه:"
    echo -e "     🧠 ${count} آیتم کل"
    echo -e "     ✅ ${active} فعال"
    echo -e "     ⏳ $(echo "scale=1; $avg_weight" | bc 2>/dev/null || echo 0) میانگین وزن"
    echo ""
    
    echo -e "${YELLOW}مقایسه: کسینوس vs اسپیرال${NC}"
    echo "  🔴 کسینوس: تناوبی، بدون زمان، خطی"
    echo "  🟢 اسپیرال: یکتا، زمانی، ۳بعدی، خودمحو"
}

# ================================================================
# 📊 داشبورد
# ================================================================

show_dashboard() {
    clear
    echo -e "${PURPLE}"
    echo "    ╔═══════════════════════════════════════════╗"
    echo "    ║    🧠  مغز فارسی PRO                      ║"
    echo "    ║    Persian Brain Professional v${VERSION}  ║"
    echo "    ╚═══════════════════════════════════════════╝"
    echo -e "${NC}"
    
    local mem_count=$(jq length "$MEMORY_FILE" 2>/dev/null || echo 0)
    local verses_total=$(jq '[.[].verses[]?] | length' "$MEMORY_FILE" 2>/dev/null || echo 0)
    local active=$(jq 'map(select(.isDecayed == false)) | length' "$MEMORY_FILE" 2>/dev/null || echo 0)
    local last_doc=$(jq -r 'last(.[])?.title // "هیچ"' "$MEMORY_FILE" 2>/dev/null || echo "هیچ")
    
    echo -e "  ${BLUE}📄${NC} اسناد ذخیره شده:  ${WHITE}$mem_count${NC}"
    echo -e "  ${BLUE}🌸${NC} کل ابیات:       ${WHITE}$verses_total${NC}"
    echo -e "  ${BLUE}✅${NC} آیتم فعال:      ${WHITE}$active${NC}"
    echo -e "  ${BLUE}📌${NC} آخرین سند:      ${WHITE}$last_doc${NC}"
    echo ""
    echo -e "  ${CYAN}🌀${NC} معماری:         ${WHITE}اسپیرال-تایم (جایگزین کسینوس)${NC}"
    echo -e "  ${CYAN}⏳${NC} نیمه‌عمر:       ${WHITE}${HALF_LIFE} روز${NC}"
    echo ""
    echo -e "${BOLD}${GREEN}===== منو =====${NC}"
    echo "  1) 📄 تزریق متن"
    echo "  2) 🌐 تزریق از URL"
    echo "  3) 💬 گفتگو (تشخیص خودکار حالت)"
    echo "  4) 🌀 اطلاعات اسپیرال"
    echo "  5) 📊 آمار حافظه"
    echo "  0) خروج"
}

# ================================================================
# 🚀 اجرای اصلی
# ================================================================

main() {
    init
    
    while true; do
        show_dashboard
        echo ""
        echo -ne "${GREEN}انتخاب: ${NC}"
        read -r choice
        
        case "$choice" in
            1)
                echo -e "\n${YELLOW}متن را وارد کنید (با Ctrl+D تمام کنید):${NC}"
                local text=$(cat)
                echo -e "\n${YELLOW}عنوان:${NC}"
                read -r title
                inject_text "$text" "${title:-متن دستی}"
                echo -e "\n${GREEN}✅ تزریق شد! اینتر بزن...${NC}"
                read -r
                ;;
            2)
                echo -e "\n${YELLOW}URL:${NC}"
                read -r url
                echo -e "\n${YELLOW}عنوان (اختیاری):${NC}"
                read -r title
                inject_url "$url" "$title" || echo -e "\n${RED}❌ خطا در دریافت${NC}"
                echo -e "\n${GREEN}✅ اینتر بزن...${NC}"
                read -r
                ;;
            3)
                echo -e "\n${YELLOW}هر چی دوست داری بپرس:${NC}"
                read -r query
                local mode=$(detect_mode "$query")
                respond "$query" "$mode"
                echo -e "\n${GREEN}✅ اینتر بزن...${NC}"
                read -r
                ;;
            4)
                clear
                show_spiral_info
                echo -e "\n${GREEN}✅ اینتر بزن...${NC}"
                read -r
                ;;
            5)
                echo -e "\n${CYAN}📊 محتویات حافظه اسپیرال:${NC}"
                jq -r '.[] | "\(.id): \(.title) | ⏳\(.timeWeight) | 🌀(\(.spiral[0]|tostring[:6]), \(.spiral[1]|tostring[:6]))"' \
                    "$MEMORY_FILE" 2>/dev/null | head -20 || echo "خالی"
                echo -e "\n${GREEN}✅ اینتر بزن...${NC}"
                read -r
                ;;
            0)
                echo -e "\n${PURPLE}🧠 خدا نگهدار!${NC}\n"
                exit 0
                ;;
        esac
    done
}

main "$@"
