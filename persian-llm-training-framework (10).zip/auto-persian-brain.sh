#!/usr/bin/env bash
# ================================================================
# 🤖 مغز فارسی - اسکریپت یادگیری خودکار
# Persian Brain - Auto Learning Script
#
# این اسکریپت به صورت خودکار:
#   1. از Ganjoor.net اشعار جدید می‌گیره
#   2. از GitHub دیتاست شعر فارسی می‌خونه
#   3. از ویکی‌پدیا و ویکی‌نبشته متن می‌گیره
#   4. همه رو به مغز تزریق می‌کنه
#   5. دیتاست آموزشی تولید می‌کنه
#
# نصب در کرون (هر روز ساعت ۳ صبح):
#   crontab -e
#   0 3 * * * /path/to/auto-persian-brain.sh
#
# یا اجرای دستی:
#   ./auto-persian-brain.sh
# ================================================================

set -euo pipefail

VERSION="1.0.0"
LOG_FILE="$HOME/.persian-brain-auto-learn.log"
DATA_DIR="$HOME/.persian-brain-data"
API_URL="${1:-http://localhost:3000}"

# رنگ‌بندی
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

# ═══════════════════════════════════════════════
# تنظیمات منابع یادگیری
# ═══════════════════════════════════════════════

# منابع Ganjoor (شعر فارسی)
GANJOOR_SOURCES=(
    "https://ganjoor.net/hafez/ghazal/"
    "https://ganjoor.net/saadi/golestan/"
    "https://ganjoor.net/moulavi/masnavi/"
    "https://ganjoor.net/ferdowsi/shahnameh/"
    "https://ganjoor.net/khayyam/robaee/"
    "https://ganjoor.net/attar/manteghotteyr/"
)

# دیتاست‌های JSON از GitHub
GITHUB_JSON_SOURCES=(
    "https://raw.githubusercontent.com/nikiede/ganjoor-json/main/hafez.json"
    "https://raw.githubusercontent.com/ganjoor/ganjoor-api/main/JSON/poets.json"
)

# ویکی‌نبشته
WIKISOURCE_SOURCES=(
    "https://fa.wikisource.org/wiki/%D8%AF%DB%8C%D9%88%D8%A7%D9%86_%D8%AD%D8%A7%D9%81%D8%B8"
)

# ═══════════════════════════════════════════════
# توابع ابزاری
# ═══════════════════════════════════════════════

log() {
    local msg="$1"
    echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $msg"
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] $(echo "$msg" | sed 's/\x1b\[[0-9;]*m//g')" >> "$LOG_FILE"
}

error() {
    local msg="$1"
    echo -e "${RED}[ERROR]${NC} $msg"
    echo "[$(date +'%Y-%m-%d %H:%M:%S')] ERROR: $(echo "$msg" | sed 's/\x1b\[[0-9;]*m//g')" >> "$LOG_FILE"
}

warn() {
    local msg="$1"
    echo -e "${YELLOW}[WARN]${NC} $msg"
}

# ═══════════════════════════════════════════════
# موتورهای استخراج
# ═══════════════════════════════════════════════

extract_verses_from_html() {
    local html="$1"
    # الگوی بیت فارسی: دو بخش با /
    echo "$html" | grep -oP '[^\n<>]{5,}?/[^\n<>]{5,}' | \
        sed 's/<[^>]*>//g' | \
        sed 's/&nbsp;//g' | \
        sed 's/&[^;]*;//g' | \
        sed 's/  */ /g' | \
        grep -v 'http' | \
        awk 'length >= 15' | \
        sort -u
}

extract_verses_from_json() {
    local json="$1"
    # استخراج از JSON با jq (اگه نصب باشه)
    if command -v jq &>/dev/null; then
        echo "$json" | jq -r '
            .. | objects |
            select(.text != null) | .text,
            select(.verse != null) | .verse,
            select(.poem != null) | .poem,
            select(.content != null) | .content
        ' 2>/dev/null | grep '/' | awk 'length >= 15' | sort -u
    else
        # روش دستی با grep
        echo "$json" | grep -oP '"[^"]{10,}/[^"]{10,}"' | \
            tr -d '"' | \
            sort -u
    fi
}

# ═══════════════════════════════════════════════
# یادگیری از منابع
# ═══════════════════════════════════════════════

learn_from_url() {
    local url="$1"
    local name="$2"
    local type="$3"
    
    local output_file="$DATA_DIR/$(echo "$url" | md5sum 2>/dev/null | cut -d' ' -f1 || echo "$RANDOM").txt"
    
    log "📥 ${BLUE}$name${NC} - دریافت..."
    
    # دریافت با timeout
    local data
    data=$(curl -sL --max-time 15 -A "Mozilla/5.0 (compatible; PersianBrain/3.0)" "$url" 2>/dev/null || true)
    
    if [[ -z "$data" ]]; then
        warn "  ⚠️  داده‌ای دریافت نشد"
        return 0
    fi
    
    local verses=""
    if [[ "$type" == "json" ]]; then
        verses=$(extract_verses_from_json "$data")
    else
        verses=$(extract_verses_from_html "$data")
    fi
    
    local count=$(echo "$verses" | wc -l)
    
    if [[ $count -eq 0 ]]; then
        warn "  ⚠️  بیتی استخراج نشد"
        return 0
    fi
    
    # ذخیره در فایل
    echo "$verses" > "$output_file"
    
    log "  ${GREEN}✅ $count بیت${NC} استخراج و ذخیره شد"
    
    # تزریق به مغز (اختیاری - در صورت اجرای API)
    if [[ "$API_URL" != "no-api" ]]; then
        local injected=0
        while IFS= read -r verse; do
            [[ -z "$verse" ]] && continue
            # تزریق از طریق API
            curl -s -X POST "$API_URL/api/brain" \
                -H "Content-Type: application/json" \
                -d "{\"action\":\"inject-text\",\"text\":\"$verse\",\"title\":\"$name\",\"poet\":\"$(echo "$name" | sed 's/.* - //')\"}" \
                > /dev/null 2>&1 || true
            injected=$((injected + 1))
        done <<< "$verses"
        log "  💉 ${CYAN}$injected بیت${NC} به مغز تزریق شد"
    fi
    
    echo "$count"
}

# ═══════════════════════════════════════════════
# تولید دیتاست آموزشی
# ═══════════════════════════════════════════════

generate_dataset() {
    log "📦 ${PURPLE}تولید دیتاست آموزشی...${NC}"
    
    # جمع‌آوری همه اشعار ذخیره شده
    local all_verses="$DATA_DIR/all-verses.txt"
    cat "$DATA_DIR"/*.txt 2>/dev/null | sort -u > "$all_verses" || true
    
    local total=$(wc -l < "$all_verses" 2>/dev/null || echo 0)
    
    if [[ $total -eq 0 ]]; then
        warn "  ⚠️  بیتی برای دیتاست وجود ندارد"
        return 0
    fi
    
    # تولید JSON دیتاست
    local dataset_file="$DATA_DIR/persian-brain-dataset.json"
    
    echo '{' > "$dataset_file"
    echo '  "dataset": "Persian Brain Auto-Learned",' >> "$dataset_file"
    echo "  \"total_verses\": $total," >> "$dataset_file"
    echo '  "generated_at": "'$(date -Iseconds)'",' >> "$dataset_file"
    echo '  "sources": [' >> "$dataset_file"
    
    echo '    "Ganjoor.net", "GitHub", "Wikimedia"' >> "$dataset_file"
    echo '  ],' >> "$dataset_file"
    echo '  "verses": [' >> "$dataset_file"
    
    local i=0
    while IFS= read -r verse; do
        [[ -z "$verse" ]] && continue
        i=$((i + 1))
        local comma=""
        [[ $i -lt $total ]] && comma=","
        echo "    \"$(echo "$verse" | sed 's/"/\\"/g')\"$comma" >> "$dataset_file"
    done < "$all_verses"
    
    echo '  ]' >> "$dataset_file"
    echo '}' >> "$dataset_file"
    
    log "  ${GREEN}✅ دیتاست با $total بیت در $dataset_file${NC}"
    
    # کپی به مسیر جاری
    cp "$dataset_file" ./persian-brain-dataset.json 2>/dev/null || true
}

# ═══════════════════════════════════════════════
# گزارش
# ═══════════════════════════════════════════════

print_report() {
    echo ""
    echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}  🤖 گزارش یادگیری خودکار${NC}"
    echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"
    echo ""
    echo -e "  📅  ${WHITE}$(date '+%Y-%m-%d %H:%M:%S')${NC}"
    
    local total_ganjoor=0
    local total_github=0
    
    # محاسبه آمار
    for file in "$DATA_DIR"/*.txt; do
        [[ -f "$file" ]] || continue
        local count=$(wc -l < "$file")
        total_ganjoor=$((total_ganjoor + count))
    done
    
    local all_verses="$DATA_DIR/all-verses.txt"
    [[ -f "$all_verses" ]] && total_unique=$(wc -l < "$all_verses") || total_unique=0
    
    echo -e "  🏛️  ${WHITE}منابع Ganjoor:${NC}     ${#GANJOOR_SOURCES[@]}"
    echo -e "  📦  ${WHITE}منابع GitHub:${NC}      ${#GITHUB_JSON_SOURCES[@]}"
    echo -e "  📚  ${WHITE}بیت‌های استخراج شده:${NC} ${total_ganjoor}"
    echo -e "  🌸  ${WHITE}بیت‌های یکتا:${NC}       ${total_unique:-0}"
    echo -e "  📊  ${WHITE}دیتاست آموزشی:${NC}     $([ -f "$DATA_DIR/persian-brain-dataset.json" ] && echo "✅" || echo "❌")"
    echo ""
    echo -e "  ${YELLOW}📋  فایل‌ها:${NC}"
    echo -e "     📄  $DATA_DIR/"
    [[ -f "./persian-brain-dataset.json" ]] && echo -e "     📄  ./persian-brain-dataset.json"
    echo ""
}

# ═══════════════════════════════════════════════
# اجرای اصلی
# ═══════════════════════════════════════════════

main() {
    clear || true
    echo -e "${PURPLE}"
    echo "    ╔═══════════════════════════════════════════╗"
    echo "    ║    🤖  مغز فارسی - یادگیری خودکار        ║"
    echo "    ║    Persian Brain Auto-Learning Engine      ║"
    echo "    ║    v$VERSION                              ║"
    echo "    ╚═══════════════════════════════════════════╝"
    echo -e "${NC}"
    
    # ایجاد دایرکتوری داده
    mkdir -p "$DATA_DIR"
    
    echo -e "${BOLD}${YELLOW}📥 مرحله ۱: یادگیری از Ganjoor.net${NC}"
    echo "────────────────────────────────────────"
    for url in "${GANJOOR_SOURCES[@]}"; do
        local name=$(echo "$url" | sed 's|https://ganjoor.net/||' | sed 's|/| - |g' | sed 's|-$||')
        learn_from_url "$url" "گنجور - $name" "html" || true
    done
    
    echo ""
    echo -e "${BOLD}${YELLOW}📥 مرحله ۲: یادگیری از GitHub JSON${NC}"
    echo "────────────────────────────────────────"
    for url in "${GITHUB_JSON_SOURCES[@]}"; do
        local name=$(echo "$url" | sed 's|.*/||')
        learn_from_url "$url" "GitHub - $name" "json" || true
    done
    
    echo ""
    echo -e "${BOLD}${YELLOW}📥 مرحله ۳: یادگیری از ویکی‌نبشته${NC}"
    echo "────────────────────────────────────────"
    for url in "${WIKISOURCE_SOURCES[@]}"; do
        learn_from_url "$url" "ویکی‌نبشته - حافظ" "html" || true
    done
    
    echo ""
    echo -e "${BOLD}${YELLOW}📦 مرحله ۴: تولید دیتاست آموزشی${NC}"
    echo "────────────────────────────────────────"
    generate_dataset || true
    
    echo ""
    print_report
    
    echo -e "${GREEN}"
    echo "    ✅ یادگیری خودکار کامل شد!"
    echo "    📝 لاگ: $LOG_FILE"
    echo -e "${NC}"
}

# اجرا
main "$@"
