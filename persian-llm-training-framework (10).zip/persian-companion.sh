#!/usr/bin/env bash
# ================================================================
# 🗣️ همراه مغز فارسی - Persian Brain Companion (Linux CLI)
# 
# یک همراه هوشمند، آفلاین و همیشه در دسترس برای لینوکس
# قابلیت‌ها:
#   ✓ فارسی محاوره‌ای را می‌فهمد
#   ✓ الگوی رفتاری کاربر را کشف می‌کند
#   ✓ Voice support (با espeak یا mpv)
#   ✓ کاملاً آفلاین - بدون نیاز به اینترنت
#   ✓ ذخیره پروفایل و تاریخچه
# ================================================================

set -euo pipefail

VERSION="2.0.0"

# ═══════════════════════════════════════════════
# 🎨 رنگ‌بندی
# ═══════════════════════════════════════════════
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
NC='\033[0m'
BOLD='\033[1m'

# ═══════════════════════════════════════════════
# ⚙️ تنظیمات
# ═══════════════════════════════════════════════
USER_NAME="دوست"
VOICE_ENABLED=false
TEMPERATURE=0.7
MODE="free"
PROFILE_FILE="$HOME/.persian-brain-profile"
HISTORY_FILE="$HOME/.persian-brain-history"

# ═══════════════════════════════════════════════
# 📚 دیکشنری محاوره (Colloquial Map)
# ═══════════════════════════════════════════════
declare -A COLLOQUIAL
COLLOQUIAL["داداش"]="برادر"
COLLOQUIAL["چطوری"]="چگونه هستی"
COLLOQUIAL["چطورین"]="چگونه هستید"
COLLOQUIAL["خوبی"]="خوب هستی"
COLLOQUIAL["چخبر"]="چه خبر"
COLLOQUIAL["باشه"]="باشد"
COLLOQUIAL["آره"]="بله"
COLLOQUIAL["نه"]="خیر"
COLLOQUIAL["مرسی"]="متشکرم"
COLLOQUIAL["ممنون"]="متشکرم"
COLLOQUIAL["دمت گرم"]="سپاسگزارم"
COLLOQUIAL["خسته شدم"]="خسته شده‌ام"
COLLOQUIAL["دلم گرفته"]="غمگین هستم"
COLLOQUIAL["حالم بده"]="ناخوش هستم"
COLLOQUIAL["کیف کردم"]="لذت بردم"
COLLOQUIAL["بگو"]="بگو"
COLLOQUIAL["بخون"]="بخوان"
COLLOQUIAL["بنویس"]="بنویس"
COLLOQUIAL["بیا"]="بیا"
COLLOQUIAL["بزن قدش"]="موافقم"

# ═══════════════════════════════════════════════
# 📚 دیتاست اشعار (بانک اشعار)
# ═══════════════════════════════════════════════
declare -a VERSES
declare -a VERSE_POETS
declare -a VERSE_KEYWORDS
declare -a VERSE_MOODS

add_verse() {
    VERSES+=("$1")
    VERSE_POETS+=("$2")
    VERSE_KEYWORDS+=("$3")
    VERSE_MOODS+=("$4")
}

# حافظ
add_verse "ز کوی یار می‌آید نسیم باد نوروزی" "حافظ" "یار نسیم نوروز بهار" "شاد"
add_verse "اگر آن ترک شیرازی به دست آرد دل ما را" "حافظ" "ترک دل شیراز عشق" "عاشقانه"  
add_verse "بنفشه دوش به گل گفت خودفروشی چند" "حافظ" "بنفشه گل فروش دل" "شاد"
add_verse "دل می‌رود ز دستم به صاحب دلان خدا را" "حافظ" "دل صاحب دلان راز" "غمگین"
add_verse "سال‌ها دل طلب جام جم از ما می‌کرد" "حافظ" "دل جام جم طلب" "عرفانی"
add_verse "بده ساقی می باقی که در جنت نخواهی یافت" "حافظ" "ساقی می جنت گلگشت" "شاد"
add_verse "ای مرغ سحر عشق ز پروانه بیاموز" "حافظ" "مرغ سحر عشق پروانه" "عاشقانه"
add_verse "گل در بر و می در کف و معشوق به کام است" "حافظ" "گل می معشوق شادی" "شاد"
add_verse "بلبل ز شاخ گل به زبان آورید باز" "حافظ" "بلبل گل شاخ زبان" "شاد"
add_verse "دوش دیدم که ملایک در میخانه زدند" "حافظ" "ملایک میخانه گل" "عرفانی"

# سعدی
add_verse "بنی آدم اعضای یکدیگرند" "سعدی" "آدم اعضا یکدیگر دوستی" "عرفانی"
add_verse "توانا بود هر که دانا بود" "سعدی" "توانا دانا دانش" "آموزنده"
add_verse "چو ایران نباشد تن من مباد" "سعدی" "ایران تن وطن" "حماسی"
add_verse "بهار آمد و گل‌ها ز هر سو برست" "سعدی" "بهار گل بهار طبیعت" "شاد"
add_verse "مروت نباشد که در بوستان" "سعدی" "مروت بوستان دوست" "آموزنده"

# مولانا
add_verse "بشنو از نی چون حکایت می‌کند" "مولانا" "نی حکایت جدایی" "غمگین"
add_verse "سینه خواهم شرحه شرحه از فراق" "مولانا" "سینه فراق درد عشق" "غمگین"
add_verse "بازآی بازآی هر آنچه هستی بازآ" "مولانا" "بازآی بازگشت امید" "عاشقانه"
add_verse "عقل در شرحش چو خر در گل بخفت" "مولانا" "عقل خر گل عشق" "عرفانی"

# فردوسی
add_verse "به نام خداوند جان و خرد" "فردوسی" "خداوند جان خرد" "حماسی"
add_verse "توانا بود هر که دانا بود" "فردوسی" "توانا دانا دانش" "آموزنده"
add_verse "جهان را سراسر چو باغی نو است" "فردوسی" "جهان باغ گل سرو" "شاد"

# خیام
add_verse "از دی که گذشت هیچ ازو یاد مکن" "خیام" "دی گذشت فردا زندگی" "فلسفی"
add_verse "بر نامده و گذشته بنیاد مکن" "خیام" "گذشته حال زندگی" "فلسفی"
add_verse "بر چهرهٔ گل نسیم نوروز خوش است" "خیام" "گل نسیم نوروز بهار" "شاد"

# عطار
add_verse "ای همه هستی ز تو پیدا شده" "عطار" "هستی خدا خاک" "عرفانی"
add_verse "عشق آمد و کرد کارها بی‌باک" "عطار" "عشق عقل خاک" "عرفانی"

TOTAL_VERSE=${#VERSES[@]}

# ═══════════════════════════════════════════════
# 🧠 موتور تحلیل محاوره
# ═══════════════════════════════════════════════

detect_colloquial() {
    local text="$1"
    local normalized="$text"
    local detected=()
    
    for key in "${!COLLOQUIAL[@]}"; do
        if [[ "$text" == *"$key"* ]]; then
            detected+=("$key")
            normalized="${normalized//$key/${COLLOQUIAL[$key]}}"
        fi
    done
    
    echo "$normalized|${detected[*]}"
}

# تشخیص منظور
detect_intent() {
    local text="$1"
    local lower="${text,,}"
    
    # تشخیص سوال
    if [[ "$text" =~ (\?|\؟|چی|کی|کجا|چرا) ]]; then
        echo "question"
        return
    fi
    
    # تشخیص احساس
    if [[ "$text" =~ (غم|دلم گرفته|ناراحت|دلتنگ|داغون|حالم بد) ]]; then echo "sad"
    elif [[ "$text" =~ (شاد|خوشحال|کیف|عالی|خنده|خرّم) ]]; then echo "happy"
    elif [[ "$text" =~ (خسته|بی حال|کسال) ]]; then echo "tired"
    elif [[ "$text" =~ (عاشق|دوست دارم|عشق|دلبر|دل) ]]; then echo "love"
    elif [[ "$text" =~ (عصبی|عصبانی|اعصاب) ]]; then echo "angry"
    elif [[ "$text" =~ (سلام|درود|چطوری|خوبی|چخبر) ]]; then echo "greeting"
    elif [[ "$text" =~ (شعر|بگو|بخون|بنویس|غزل|بیت) ]]; then echo "poetry"
    elif [[ "$text" =~ (داستان|قصه|حکایت) ]]; then echo "story"
    elif [[ "$text" =~ (چه خبر|خوبم|مرسی|ممنون|دمت) ]]; then echo "thank"
    elif [[ "$text" =~ (کی هستی|چی هستی|تو کی) ]]; then echo "who"
    else echo "chat"
    fi
}

# ═══════════════════════════════════════════════
# 📊 پروفایل کاربر
# ═══════════════════════════════════════════════

load_profile() {
    if [[ -f "$PROFILE_FILE" ]]; then
        source "$PROFILE_FILE"
    else
        TOTAL_INTERACTIONS=0
        FAVORITE_POET=""
        DOMINANT_MOOD="خنثی"
        STREAK=0
    fi
}

save_profile() {
    cat > "$PROFILE_FILE" << EOF
TOTAL_INTERACTIONS=$TOTAL_INTERACTIONS
FAVORITE_POET="$FAVORITE_POET"
DOMINANT_MOOD="$DOMINANT_MOOD"
STREAK=$STREAK
USER_NAME="$USER_NAME"
EOF
}

update_profile() {
    local poet="$1"
    local mood="$2"
    
    TOTAL_INTERACTIONS=$((TOTAL_INTERACTIONS + 1))
    
    if [[ -n "$poet" ]]; then
        FAVORITE_POET="$poet"
    fi
    
    if [[ -n "$mood" && "$mood" != "خنثی" ]]; then
        DOMINANT_MOOD="$mood"
    fi
    
    STREAK=$((STREAK + 1))
    save_profile
}

# ═══════════════════════════════════════════════
# 🗣️ موتور Voice
# ═══════════════════════════════════════════════

speak_text() {
    local text="$1"
    if ! $VOICE_ENABLED; then return; fi
    
    # Try espeak first
    if command -v espeak &>/dev/null; then
        espeak -v fa "$text" 2>/dev/null || true
    # Then try mpv with Google TTS
    elif command -v mpv &>/dev/null; then
        local encoded=$(python3 -c "import urllib.parse; print(urllib.parse.quote('$text'))" 2>/dev/null || echo "$text")
        mpv "https://translate.google.com/translate_tts?ie=UTF-8&q=$encoded&tl=fa&client=tw-ob" --no-video 2>/dev/null || true
    else
        echo -e "${YELLOW}⚠️  برای Voice: sudo apt install espeak${NC}"
    fi
}

# ═══════════════════════════════════════════════
# 🧠 جستجوی اشعار
# ═══════════════════════════════════════════════

search_poems() {
    local query="$1"
    local poet_filter="$2"
    local results=()
    
    for ((i=0; i<TOTAL_VERSE; i++)); do
        local verse="${VERSES[$i]}"
        local poet="${VERSE_POETS[$i]}"
        local keywords="${VERSE_KEYWORDS[$i]}"
        
        # فیلتر شاعر
        if [[ -n "$poet_filter" && "$poet" != "$poet_filter" ]]; then
            continue
        fi
        
        # امتیازدهی
        local score=0
        for word in $query; do
            if [[ "$verse" == *"$word"* ]]; then score=$((score + 3)); fi
            if [[ "$keywords" == *"$word"* ]]; then score=$((score + 2)); fi
        done
        
        if [[ $score -gt 0 ]]; then
            results+=("$score|$verse|$poet")
        fi
    done
    
    # مرتب‌سازی
    IFS=$'\n' sorted=($(sort -t'|' -k1 -rn <<< "${results[*]}"))
    unset IFS
    
    echo "${sorted[*]}"
}

# ═══════════════════════════════════════════════
# 💭 تولید پاسخ
# ═══════════════════════════════════════════════

generate_response() {
    local input="$1"
    local intent="$2"
    local normalized="$3"
    
    # تشخیص شاعر
    local poet=""
    if [[ "$input" =~ (حافظ) ]]; then poet="حافظ"
    elif [[ "$input" =~ (سعدی) ]]; then poet="سعدی"
    elif [[ "$input" =~ (مولانا|مولوی) ]]; then poet="مولانا"
    elif [[ "$input" =~ (فردوسی|شاهنامه) ]]; then poet="فردوسی"
    elif [[ "$input" =~ (خیام) ]]; then poet="خیام"
    fi
    
    update_profile "$poet" "$(detect_intent "$input")"
    
    case "$intent" in
        greeting)
            echo -e "${GREEN}سلام $USER_NAME جان! چطوری؟ خوش اومدی 😊${NC}"
            speak_text "سلام $USER_NAME جان! چطوری؟ خوش اومدی"
            return
            ;;
        sad)
            echo -e "${YELLOW}$USER_NAME جان ناراحت نباش! یه شعر از حافظ حالت رو خوب می‌کنه:${NC}"
            echo -e "${WHITE}ز کوی یار می‌آید نسیم باد نوروزی${NC}"
            echo -e "${GREEN}— حافظ${NC}"
            speak_text "$USER_NAME جان ناراحت نباش! ز کوی یار می‌آید نسیم باد نوروزی"
            return
            ;;
        happy|love)
            echo -e "${GREEN}$USER_NAME جان چه عالی! 😍${NC}"
            echo -e "${WHITE}گل در بر و می در کف و معشوق به کام است${NC}"
            echo -e "${GREEN}— حافظ${NC}"
            speak_text "$USER_NAME جان چه عالی! گل در بر و می در کف و معشوق به کام است"
            return
            ;;
        tired)
            echo -e "${YELLOW}$USER_NAME جان خسته نباشی! خیام می‌گه:${NC}"
            echo -e "${WHITE}از دی که گذشت هیچ ازو یاد مکن${NC}"
            echo -e "${GREEN}— خیام${NC}"
            speak_text "$USER_NAME جان خسته نباشی"
            return
            ;;
        angry)
            echo -e "${YELLOW}$USER_NAME جان آروم باش! یه نفس عمیق بکش 🤗${NC}"
            echo -e "${WHITE}غم را به ساقی می‌گویم تا مست کند${NC}"
            speak_text "$USER_NAME جان آروم باش!"
            return
            ;;
        poetry|story)
            echo -e "${CYAN}🌸 جستجوی اشعار با موضوع «$input» ...${NC}"
            sleep 0.3
            
            local results=$(search_poems "$input" "$poet")
            IFS=' ' read -ra RES <<< "$results"
            
            if [[ ${#RES[@]} -eq 0 ]]; then
                # شعر تصادفی
                local ri=$((RANDOM % TOTAL_VERSE))
                echo -e "\n${WHITE}${VERSES[$ri]}${NC}"
                echo -e "${GREEN}— ${VERSE_POETS[$ri]}${NC}"
                speak_text "${VERSES[$ri]}"
            else
                local count=0
                for entry in "${RES[@]}"; do
                    [[ $count -ge 3 ]] && break
                    IFS='|' read -r score vtext vpoet <<< "$entry"
                    echo -e "\n${WHITE}${vtext}${NC}"
                    echo -e "${GREEN}— ${vpoet} (امتیاز: $score)${NC}"
                    if [[ $count -eq 0 ]]; then
                        speak_text "$vtext"
                    fi
                    count=$((count + 1))
                done
            fi
            return
            ;;
        who)
            echo -e "${PURPLE}سلام $USER_NAME جان! من مغز فارسی هستم 🧠${NC}"
            echo -e "همراه هوشمند آفلاین تو که:"
            echo -e "  ${GREEN}✓${NC} فارسی محاوره‌ای رو می‌فهمم"
            echo -e "  ${GREEN}✓${NC} اشعار حافظ، سعدی، مولانا و... بلدم"
            echo -e "  ${GREEN}✓${NC} حالت رو تشخیص می‌دم"
            echo -e "  ${GREEN}✓${NC} الگوی رفتاری تو رو کشف می‌کنم"
            echo -e "  ${GREEN}✓${NC} کاملاً آفلاین و همیشه در دسترس"
            speak_text "سلام $USER_NAME جان! من مغز فارسی هستم"
            return
            ;;
        thank)
            echo -e "${GREEN}خواهش می‌کنم $USER_NAME جان! 🥰 همیشه در خدمتم${NC}"
            speak_text "خواهش می‌کنم! همیشه در خدمتم"
            return
            ;;
        *)
            # پاسخ هوشمند پیش‌فرض
            local ri=$((RANDOM % 4))
            case $ri in
                0) echo -e "${CYAN}$USER_NAME جان جالب بود! 😅 می‌خوای یه شعر بگم؟${NC}" ;;
                1) echo -e "${PURPLE}$USER_NAME جان! هر چی دوست داری بپرس درباره شعر، عشق، زندگی 🌸${NC}" ;;
                2) echo -e "${BLUE}$USER_NAME جان بذار یه شعر قشنگ بگم برات:${NC}"
                   local ri=$((RANDOM % TOTAL_VERSE))
                   echo -e "\n${WHITE}${VERSES[$ri]}${NC}"
                   echo -e "${GREEN}— ${VERSE_POETS[$ri]}${NC}"
                   speak_text "${VERSES[$ri]}" ;;
                3) echo -e "${GREEN}جالبه! بیشتر بگو $USER_NAME جان 🤗${NC}" ;;
            esac
            ;;
    esac
}

# ═══════════════════════════════════════════════
# 📊 نمایش پروفایل
# ═══════════════════════════════════════════════

show_profile() {
    echo -e "\n${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BOLD}${CYAN}  📊  پروفایل ${USER_NAME}${NC}"
    echo -e "${BOLD}${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "  ${BLUE}تعاملات:${NC}    ${WHITE}$TOTAL_INTERACTIONS${NC}"
    echo -e "  ${BLUE}شاعر محبوب:${NC}  ${WHITE}${FAVORITE_POET:-نامشخص}${NC}"
    echo -e "  ${BLUE}حال و هوا:${NC}   ${WHITE}$DOMINANT_MOOD${NC}"
    echo -e "  ${BLUE}روزهای پیاپی:${NC} ${WHITE}$STREAK 🔥${NC}"
    echo -e "  ${BLUE}وضعیت:${NC}       ${WHITE}آفلاین ${GREEN}✓${NC}"
    echo ""
    
    if [[ $TOTAL_INTERACTIONS -gt 3 ]]; then
        echo -e "${PURPLE}🧠  تحلیل مغز:${NC}"
        echo -e "  به نظر می‌رسه ${FAVORITE_POET:-شعر فارسی} رو دوست داری!"
        echo -e "  حال و هوای ${DOMINANT_MOOD} همیشه باهاته"
        echo -e "  ${GREEN}🔥 $STREAK روز متوالی! عالی ${USER_NAME} جان!${NC}"
    fi
}

# ═══════════════════════════════════════════════
# 🎯 منوی اصلی
# ═══════════════════════════════════════════════

print_banner() {
    clear
    echo -e "${PURPLE}"
    echo "    ╔═══════════════════════════════════════════════╗"
    echo "    ║      🗣️  همراه مغز فارسی - Persian Companion  ║"
    echo "    ║    همراه هوشمند آفلاین برای لینوکس           ║"
    echo "    ║    می‌فهمه چی می‌گی! محاوره + Voice           ║"
    echo "    ╚═══════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    if [[ $TOTAL_INTERACTIONS -gt 0 ]]; then
        echo -e "  ${BLUE}${USER_NAME}:${NC} $TOTAL_INTERACTIONS گفتگو | 🔥 $STREAK روز | 🎭 $DOMINANT_MOOD"
        echo ""
    fi
}

companion_mode() {
    load_profile
    
    while true; do
        print_banner
        
        echo -e "${BOLD}${WHITE}  به فارسی محاوره‌ای بگو...${NC}"
        echo -e "  ${YELLOW}  مثال:${NC} سلام | چطوری؟ | دلم گرفته | یه شعر بگو | خسته شدم"
        echo -e "  ${YELLOW}  یا:${NC} از حافظ بگو | درباره دوستی | عاشقانه"
        echo ""
        echo -e "  ${CYAN}[s]${NC} پروفایل  ${CYAN}[v]${NC} Voice:$($VOICE_ENABLED && echo "${GREEN}ON${NC}" || echo "${RED}OFF${NC}")  ${CYAN}[m]${NC} تنظیمات  ${CYAN}[q]${NC} خروج"
        echo ""
        
        echo -ne "${GREEN}💬 ${USER_NAME}: ${NC}"
        read -r input
        
        case "$input" in
            [qQ])
                echo -e "\n${PURPLE}🧠 خدا نگهدار $USER_NAME جان! به امید دیدار 🌸${NC}"
                speak_text "خدا نگهدار! به امید دیدار"
                exit 0
                ;;
            [sS])
                show_profile
                echo -e "\n${YELLOW}▶ اینتر بزن...${NC}"
                read -r
                continue
                ;;
            [vV])
                if $VOICE_ENABLED; then
                    VOICE_ENABLED=false
                    echo -e "${RED}🔇 Voice غیرفعال شد${NC}"
                else
                    VOICE_ENABLED=true
                    echo -e "${GREEN}🔊 Voice فعال شد${NC}"
                    speak_text "سلام! حالت صوتی فعال شد"
                fi
                sleep 1
                continue
                ;;
            [mM])
                echo -e "\n${YELLOW}نام خود را وارد کن (پیش‌فرض: $USER_NAME):${NC} "
                read -r newname
                USER_NAME=${newname:-$USER_NAME}
                save_profile
                echo -e "${GREEN}✅ تنظیم شد!${NC}"
                sleep 1
                continue
                ;;
            "")
                continue
                ;;
        esac
        
        # تحلیل ورودی
        local result=$(detect_colloquial "$input")
        IFS='|' read -r normalized detected <<< "$result"
        
        local intent=$(detect_intent "$input")
        
        echo ""
        generate_response "$input" "$intent" "$normalized"
        
        # نمایش اطلاعات تشخیص
        if [[ -n "$detected" ]]; then
            echo -e "\n${BLUE}🔍 تشخیص:${NC} $detected → حالت: $intent"
        fi
        
        echo -e "\n${YELLOW}─────────────────────────────────────────${NC}"
        echo -e "${YELLOW}▶ اینتر بزن برای ادامه...${NC}"
        read -r
    done
}

# ═══════════════════════════════════════════════
# 🚀 شروع
# ═══════════════════════════════════════════════

# بررسی وابستگی‌ها
if command -v espeak &>/dev/null; then
    VOICE_SUPPORT="${GREEN}espeak${NC}"
elif command -v mpv &>/dev/null; then
    VOICE_SUPPORT="${GREEN}mpv${NC}"
else
    VOICE_SUPPORT="${RED}نصب نشده${NC}"
fi

# شروع
load_profile
companion_mode
