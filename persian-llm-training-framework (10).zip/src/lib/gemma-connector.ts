/**
 * 🔗 لایه اتصال Gemma Fine-tuned + Persian Brain
 * 
 * این ماژول پل ارتباطی بین:
 * - مدل Gemma شما (fine-tuned با LoRA روی فارسی)
 * - مغز فارسی (شعر، داستان، محاوره)
 * - موتور استدلال (Reasoning Engine)
 * 
 * ===== معماری =====
 * 
 * ┌──────────────┐
 * │   درخواست    │
 * └──────┬───────┘
 *        ↓
 * ┌──────────────────────────────┐
 * │  Reasoning Engine (local)    │ ← تحلیل، تجزیه، تشخیص دام
 * └──────┬───────┬───────┬───────┘
 *        ↓       ↓       ↓
 * ┌─────────┐ ┌──────┐ ┌──────────┐
 * │ Gemma  │ │RAG   │ │Pitfall  │
 * │FT+LoRA│ │شعر   │ │Dataset  │
 * └───┬─────┘ └──┬───┘ └────┬─────┘
 *     └────┬──────┴──────────┘
 *          ↓
 * ┌──────────────────────────────┐
 * │  پاسخ نهایی (قدم‌قدم)        │
 * └──────────────────────────────┘
 */

import { reasonAndRespond, PITFALL_DATABASE, type Pitfall } from "./reasoning-engine";
import { unifiedThink } from "./unified-brain";
import { searchVerses } from "./poetry-db";
import { VERSES } from "./poetry-db";

// ================================================================
// ۱. پیکربندی اتصال به مدل Gemma
// ================================================================

export interface GemmaConfig {
  // API endpoint برای مدل Gemma شما
  apiUrl: string;
  apiKey?: string;
  
  // تنظیمات مدل
  modelName: string;
  maxTokens: number;
  temperature: number;
  topP: number;
  
  // حالت اتصال
  mode: 'local' | 'api' | 'hybrid';
  
  // آیا Gemma در دسترسه؟
  isAvailable: boolean;
}

export const DEFAULT_GEMMA_CONFIG: GemmaConfig = {
  apiUrl: process.env.GEMMA_API_URL || 'http://localhost:8000/v1',
  apiKey: process.env.GEMMA_API_KEY || '',
  modelName: process.env.GEMMA_MODEL_NAME || 'gemma-2-2b-it-fa-lora',
  maxTokens: 512,
  temperature: 0.7,
  topP: 0.9,
  mode: 'hybrid',
  isAvailable: !!process.env.GEMMA_API_URL,
};

// ================================================================
// ۲. پرامپت سیستم Gemma (LoRA Persian)
// ================================================================

export const GEMMA_SYSTEM_PROMPT = `شما یک دستیار هوشمند فارسی هستید با قابلیت‌های زیر:

## قوانین جواب دادن:

۱. **قدم‌قدم جواب بده**: سوال رو تیکه‌تیکه کن و هر قسمت رو جدا جواب بده
۲. **ابهام رو شفاف کن**: اگه سوال چندمعنایی بود، بپرس منظورت کدومه
۳. **به شعر سند بده**: وقتی از شعر می‌گی، بیت کامل رو با ذکر شاعر و کتاب بیار
۴. **دام رو تشخیص بده**: بعضی سوالات برای گول زدن طراحی شدن - هوشیار باش
۵. **تحریف نکن**: شعر رو به نفع خودت تغییر نده، بیت کامل رو بیار
۶. **صادق باش**: اگه نمی‌دانی، بگو نمی‌دانم

## ساختار جواب:
۱. خلاصه سوال
۲. قدم‌قدم جواب
۳. ذکر منابع (برای شعر)
۴. نتیجه‌گیری

## چاه‌های معروف:
- "بنی آدم اعضای یکدیگرند" → برای نژادپرستی استفاده نشه! سعدی برعکس می‌گه
- "توانا بود هر که دانا بود" → نگو بی‌سوادها ناتوانن. این inversion منطقیه
- "انکار شراب" حافظ → سوال انکاریه، نه انکار شراب
- پارادوکس دروغگو → جواب قطعی نداره، توضیح بده`;

// ================================================================
// ۳. تابع ارسال به Gemma API
// ================================================================

export interface GemmaRequest {
  messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }>;
  max_tokens?: number;
  temperature?: number;
  top_p?: number;
}

export interface GemmaResponse {
  text: string;
  tokenCount: number;
  latencyMs: number;
  success: boolean;
  error?: string;
}

/**
 * ارسال درخواست به Gemma Fine-tuned
 * این تابع با API سرور Gemma شما حرف می‌زنه
 */
export async function queryGemma(
  prompt: string,
  options: {
    systemPrompt?: string;
    maxTokens?: number;
    temperature?: number;
  } = {}
): Promise<GemmaResponse> {
  const config = { ...DEFAULT_GEMMA_CONFIG };
  const startTime = Date.now();
  
  const messages = [
    { role: 'system' as const, content: options.systemPrompt || GEMMA_SYSTEM_PROMPT },
    { role: 'user' as const, content: prompt },
  ];
  
  // اگر Gemma API در دسترس نیست، از مغز داخلی استفاده کن
  if (!config.isAvailable) {
    await new Promise(r => setTimeout(r, 100 + Math.random() * 200));
    
    // از reasoning engine و unified brain استفاده کن
    const reasoning = reasonAndRespond(prompt);
    const brainResponse = unifiedThink(prompt);
    
    let response = '';
    
    if (reasoning.decomposition.riskLevel === 'danger') {
      response += `⚠️ **سوال دام‌دار تشخیص داده شد!**\n\n`;
      response += reasoning.stepByStepResponse;
      
      if (reasoning.distortionCheck.isDistorted) {
        response += `\n📜 **بیت اصلی:**\n${reasoning.distortionCheck.originalVerse}\n`;
        response += `— ${reasoning.distortionCheck.originalPoet}\n`;
      }
    } else {
      response = brainResponse.text;
    }
    
    return {
      text: response,
      tokenCount: response.split(' ').length,
      latencyMs: Date.now() - startTime,
      success: true,
    };
  }
  
  // اگر Gemma API در دسترسه
  try {
    const response = await fetch(`${config.apiUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(config.apiKey ? { 'Authorization': `Bearer ${config.apiKey}` } : {}),
      },
      body: JSON.stringify({
        model: config.modelName,
        messages,
        max_tokens: options.maxTokens || config.maxTokens,
        temperature: options.temperature || config.temperature,
        top_p: config.topP,
      }),
    });
    
    if (!response.ok) {
      throw new Error(`Gemma API error: ${response.status}`);
    }
    
    const data = await response.json();
    const text = data.choices?.[0]?.message?.content || '';
    
    return {
      text,
      tokenCount: text.split(' ').length,
      latencyMs: Date.now() - startTime,
      success: true,
    };
  } catch (e: any) {
    // Fallback به مغز داخلی
    const brainResponse = unifiedThink(prompt);
    return {
      text: brainResponse.text,
      tokenCount: brainResponse.text.split(' ').length,
      latencyMs: Date.now() - startTime,
      success: true,
      error: `Gemma failed, fallback to local: ${e.message}`,
    };
  }
}

// ================================================================
// ۴. پرامپت‌های آموزشی برای Gemma LoRA
// ================================================================

export const TRAINING_EXAMPLES = [
  {
    instruction: "قدم‌قدم جواب بده: همه شعرهای حافظ عاشقانه‌ست، این یکی شعر حافظه، پس حتماً عاشقانه‌ست",
    response: `⚠️ این یه سوال دام‌داره! (سفسطه syllogism)\n\nقدم ۱: بررسی مقدمه\n• فرض: "همه شعرهای حافظ عاشقانه‌ست" → این غلطه!\n• حافظ اشعار عرفانی، اجتماعی، طنز و مدح هم داره\n\nقدم ۲: بررسی استدلال\n• "این یکی شعر حافظه" → درسته\n• "پس حتماً عاشقانه‌ست" → نتیجه‌گیری غلط!\n\nقدم ۳: دلیل\n• استدلال شما از نوع "همه A ها B هستن، این C هست، پس B هست"\n• ولی مقدمه (همه شعرهای حافظ عاشقانه‌ست) غلطه\n\nنتیجه: اسم غزل رو بگو تا ببینم موضوعش چیه`,
    category: "منطق",
    tags: ["سفسطه", "حافظ", "دام"],
  },
  {
    instruction: "قدم‌قدم جواب بده: سعدی گفته 'بنی آدم اعضای یکدیگرند' یعنی همه از یه جا هستن، پس نژادپرستی درسته!",
    response: `⚠️ **تحریف شعر تشخیص داده شد!**\n\nقدم ۱: بیت کامل رو بیارم:\n«بنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند\nچو عضوی به درد آورد روزگار / دگر عضوها را نماند قرار»\n— سعدی، گلستان\n\nقدم ۲: تحلیل:\n• "بنی آدم اعضای یکدیگرند" = همه انسان‌ها مثل اعضای یک بدن هستن\n• "چو عضوی به درد آورد روزگار / دگر عضوها را نماند قرار" = اگه یکی درد بکشه، بقیه بی‌قرار می‌شن\n\nقدم ۳: نتیجه:\n• سعدی دقیقاً **برعکس** نژادپرستی می‌گه\n• می‌گه همه به هم پیوسته‌ایم و باید همدرد باشیم\n• "تو کز محنت دیگران بی‌غمی / نشاید که نامت نهند آدمی"\n\nپس: این شعر علیه نژادپرستی‌ست، نه به نفعش!`,
    category: "شعر",
    tags: ["تحریف", "سعدی", "نژادپرستی"],
  },
  {
    instruction: "قدم‌قدم جواب بده: دستم بهش نمی‌رسه",
    response: `این جمله سه معنی داره. بگو کدوم منظورت هست:\n\n۱. 🏃 فیزیکی: چیزی دور از دسترس منه\n۲. 💰 مالی: قیمتش بالاست و نمی‌تونم بخرم\n۳. 🧠 توانایی: از عهده‌اش برنمیام\n\nهر کدوم رو می‌گی می‌تونم کمک کنم!`,
    category: "ابهام",
    tags: ["چندمعنایی", "محاوره"],
  },
  {
    instruction: "قدم‌قدم جواب بده: من سه تا سیب دارم، دو تا رو میدم به تو، یکی رو میخورم. چند تا سیب دارم؟",
    response: `بزنیم قدم‌قدم:\n\n📌 قدم ۱: تا الان\n• ۳ تا سیب داری\n\n📌 قدم ۲: ۲ تا دادی به من\n• ۳ - ۲ = ۱ تا موند\n\n📌 قدم ۳: ۱ تا رو می‌خوری\n• ۱ - ۱ = ۰\n\n📌 جواب: صفر تا سیب! 🍎`,
    category: "ریاضی",
    tags: ["توالی", "منطق"],
  },
];

/**
 * تولید دیتاست آموزشی برای Gemma LoRA
 */
export function generateGemmaTrainingSet(): string {
  const examples = TRAINING_EXAMPLES.map(ex => ({
    messages: [
      { role: "system" as const, content: GEMMA_SYSTEM_PROMPT },
      { role: "user" as const, content: ex.instruction },
      { role: "assistant" as const, content: ex.response },
    ],
  }));
  
  // اضافه کردن چاه‌ها به دیتاست
  for (const pitfall of PITFALL_DATABASE.slice(0, 5)) {
    examples.push({
      messages: [
        { role: "system" as const, content: GEMMA_SYSTEM_PROMPT },
        { role: "user" as const, content: pitfall.trapQuestion },
        { role: "assistant" as const, content: `⚠️ **دام تشخیص داده شد!**\n\nدسته: ${pitfall.category}\n${pitfall.explanation}\n\n${pitfall.correctReasoning}` },
      ],
    });
  }
  
  return JSON.stringify(examples, null, 2);
}
