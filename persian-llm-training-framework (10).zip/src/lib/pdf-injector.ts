/**
 * 📄 تزریق‌کننده PDF و اسناد - Document Injection Engine
 * 
 * از PDF، Word، TXT و هر فایلی می‌تونه متن رو استخراج کنه
 * و به مغز تزریق کنه
 * 
 * ===== روش استفاده =====
 * 
 * ۱. Drag & Drop فایل تو صفحه
 * ۲. انتخاب نوع (شعر/داستان/مقاله/دانش)
 * ۳. تزریق خودکار به مغز با برچسب‌زنی
 * ۴. جستجو در اسناد تزریق شده
 */

// ========== تایپ‌ها ==========

export interface InjectedDocument {
  id: string;
  title: string;
  fileName: string;
  fileType: 'pdf' | 'docx' | 'txt' | 'json' | 'csv' | 'html' | 'md';
  size: number;           // bytes
  pages?: number;
  content: string;        // متن استخراج شده
  verses: string[];       // ابیات استخراج شده (اگر شعر باشه)
  conversations: string[]; // دیالوگ‌های استخراج شده (اگر داستان باشه)
  keywords: string[];
  topics: string[];
  poet?: string;
  type: 'poem' | 'story' | 'article' | 'knowledge' | 'conversation' | 'mixed';
  injectedAt: number;
  source: 'upload' | 'url' | 'text';
  tags: string[];
}

// ========== استخراج متن ==========

/**
 * استخراج متن از فایل‌های مختلف سمت کلاینت
 * با FileReader API
 */
export function extractTextFromFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const text = e.target?.result as string;
      resolve(text || '');
    };
    
    reader.onerror = () => reject(new Error('خطا در خواندن فایل'));
    
    // تشخیص نوع فایل
    if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
      // PDF رو سمت کلاینت نمی‌تونیم کامل parse کنیم
      // نیاز به pdf.js یا ارسال به سرور
      reject(new Error('PDF سمت کلاینت نیاز به pdf.js داره. لطفاً از طریق سرور آپلود کن.'));
    } else if (file.type.includes('json') || file.name.endsWith('.json')) {
      reader.readAsText(file);
    } else {
      reader.readAsText(file);
    }
  });
}

/**
 * استخراج ابیات از متن (با الگوی شعر فارسی)
 */
export function extractVersesFromDocument(text: string): string[] {
  const verses: string[] = [];
  const lines = text.split('\n');
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    
    // الگوی بیت: دو بخش با /
    if (line.includes('/') && line.length >= 15 && !line.includes('http')) {
      verses.push(line);
    }
    
    // الگوی دوبیتی: دو خط پشت سر هم که هر کدوم بلند باشن
    if (i < lines.length - 1) {
      const nextLine = lines[i + 1].trim();
      if (line.length > 15 && nextLine.length > 15) {
        const combined = `${line} / ${nextLine}`;
        if (combined.length >= 30) {
          verses.push(combined);
          i++; // خط بعدی رو هم خوندیم
        }
      }
    }
  }
  
  return [...new Set(verses)];
}

/**
 * استخراج دیالوگ‌های محاوره‌ای از متن
 */
export function extractConversations(text: string): string[] {
  const conversations: string[] = [];
  
  // الگوی گفتگو: نقل قول با «» یا " "
  const quotePatterns = [
    /[""]([^""]*)[""]/g,
    /[«»]([^«»]*)[«»]/g,
    /「([^」]*)」/g,
  ];
  
  for (const pattern of quotePatterns) {
    let match;
    while ((match = pattern.exec(text)) !== null) {
      const dialog = match[1].trim();
      if (dialog.length > 5 && dialog.length < 200) {
        conversations.push(dialog);
      }
    }
  }
  
  // الگوی دیالوگ‌های داستانی: "گفت: ..."
  const dialogueLines = text.split('\n').filter(line => {
    const trimmed = line.trim();
    return (
      (trimmed.includes('گفت') || trimmed.includes('گفت:') || trimmed.includes('گفت:')) &&
      trimmed.length > 10 &&
      trimmed.length < 300
    );
  });
  
  conversations.push(...dialogueLines);
  
  return [...new Set(conversations)].slice(0, 50);
}

/**
 * تشخیص خودکار نوع محتوا
 */
export function detectDocumentType(text: string, fileName: string): InjectedDocument['type'] {
  // از اسم فایل
  const name = fileName.toLowerCase();
  if (name.includes('شعر') || name.includes('غزل') || name.includes('حافظ') || name.includes('سعدی')) {
    return 'poem';
  }
  if (name.includes('داستان') || name.includes('قصه') || name.includes('حکایت')) {
    return 'story';
  }
  
  // از متن
  const textSample = text.slice(0, 500);
  if (/(غزل|بیت|مصراع|شعر|ابیات)/.test(textSample)) return 'poem';
  if (/(داستان|قصه|روزی روزگاری|حکایت)/.test(textSample)) return 'story';
  if (/(مقاله|گزارش|تحقیق|بررسی)/.test(textSample)) return 'article';
  if (/(دانش|علم|آموزش|یادگیری)/.test(textSample)) return 'knowledge';
  if (/(گفت|گفتگو|دیالوگ|مکالمه)/.test(textSample)) return 'conversation';
  
  return 'mixed';
}

/**
 * استخراج کلمات کلیدی از متن
 */
export function extractKeywords(text: string): string[] {
  const stopWords = new Set([
    'این', 'آن', 'با', 'به', 'از', 'در', 'و', 'یا', 'که', 'را', 'برای',
    'یک', 'دو', 'سه', 'تا', 'نه', 'هست', 'است', 'شد', 'شود', 'می', 'هم',
    'اگر', 'اما', 'ولی', 'باشد', 'بر', 'لا', 'های', 'ای', 'تو', 'ما', 'او',
  ]);
  
  const words = text.split(/[\s،,\.!?؟\n]+/);
  const freq: Record<string, number> = {};
  
  for (const word of words) {
    const clean = word.replace(/[^آ-ی\w]/g, '').trim();
    if (clean.length > 2 && !stopWords.has(clean)) {
      freq[clean] = (freq[clean] || 0) + 1;
    }
  }
  
  return Object.entries(freq)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([word]) => word);
}

// ========== ذخیره و بازیابی ==========

const STORAGE_KEY = 'persian-brain-injected-documents';

export function getInjectedDocuments(): InjectedDocument[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
  } catch { return []; }
}

export function saveInjectedDocument(doc: InjectedDocument): void {
  if (typeof window === 'undefined') return;
  const docs = getInjectedDocuments();
  docs.unshift(doc);
  if (docs.length > 30) docs.length = 30; // حداکثر ۳۰ سند
  localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
}

export function deleteInjectedDocument(id: string): void {
  if (typeof window === 'undefined') return;
  const docs = getInjectedDocuments().filter(d => d.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(docs));
}

export function searchInjectedDocuments(query: string): InjectedDocument[] {
  const docs = getInjectedDocuments();
  const q = query.toLowerCase();
  
  return docs.filter(d =>
    d.title.toLowerCase().includes(q) ||
    d.content.toLowerCase().includes(q) ||
    d.keywords.some(k => k.includes(q)) ||
    d.tags.some(t => t.includes(q))
  );
}

// ========== تزریق به مغز ==========

/**
 * تزریق یک سند کامل به مغز
 * - ابیات رو استخراج می‌کنه و به بانک شعر تزریق می‌کنه
 * - دیالوگ‌ها رو استخراج می‌کنه
 * - محتوای کلی رو به عنوان دانش تزریق می‌کنه
 */
export function injectDocumentToBrain(doc: InjectedDocument): {
  versesInjected: number;
  conversationsInjected: number;
  type: string;
} {
  // ذخیره سند
  saveInjectedDocument(doc);
  
  // تزریق ابیات به مغز (از localStorage مغز)
  const verses = doc.verses.slice(0, 30);
  let versesInjected = 0;
  
  for (const verse of verses) {
    try {
      if (typeof window === 'undefined') { versesInjected++; continue; }
      const existing = JSON.parse(localStorage.getItem('persian-brain-injected-sources') || '[]');
      existing.push({
        id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: doc.title,
        url: '',
        content: verse,
        verses: [verse],
        poet: doc.poet || undefined,
        type: 'poem',
        injectedAt: Date.now(),
        tags: [...doc.tags, 'pdf-injected', doc.type],
        source: 'upload',
      });
      localStorage.setItem('persian-brain-injected-sources', JSON.stringify(existing));
      versesInjected++;
    } catch {}
  }
  
  // تزریق دیالوگ‌ها به عنوان محاوره
  let conversationsInjected = 0;
  for (const conv of doc.conversations.slice(0, 20)) {
    try {
      if (typeof window === 'undefined') { conversationsInjected++; continue; }
      const existing = JSON.parse(localStorage.getItem('persian-brain-injected-sources') || '[]');
      existing.push({
        id: `conv-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        title: `${doc.title} - گفتگو`,
        url: '',
        content: conv,
        verses: [],
        type: 'conversation',
        injectedAt: Date.now(),
        tags: [...doc.tags, 'conversation', doc.type],
        source: 'upload',
      });
      localStorage.setItem('persian-brain-injected-sources', JSON.stringify(existing));
      conversationsInjected++;
    } catch {}
  }
  
  return { versesInjected, conversationsInjected, type: doc.type };
}

/**
 * تزریق متن ساده (مثل Paste کردن)
 */
export function injectPlainText(
  text: string,
  options: {
    title?: string;
    type?: InjectedDocument['type'];
    poet?: string;
    tags?: string[];
  } = {}
): InjectedDocument {
  const verses = extractVersesFromDocument(text);
  const conversations = extractConversations(text);
  const type = options.type || detectDocumentType(text, options.title || '');
  
  const doc: InjectedDocument = {
    id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    title: options.title || `سند ${new Date().toLocaleDateString('fa-IR')}`,
    fileName: '',
    fileType: 'txt',
    size: text.length,
    content: text.slice(0, 10000),
    verses,
    conversations,
    keywords: extractKeywords(text),
    topics: [],
    poet: options.poet || undefined,
    type,
    injectedAt: Date.now(),
    source: 'text',
    tags: options.tags || [type],
  };
  
  injectDocumentToBrain(doc);
  return doc;
}

// ========== آمار ==========

export function getDocumentStats() {
  const docs = getInjectedDocuments();
  
  const totalVerses = docs.reduce((a, d) => a + d.verses.length, 0);
  const totalConversations = docs.reduce((a, d) => a + d.conversations.length, 0);
  const totalSize = docs.reduce((a, d) => a + d.size, 0);
  
  const byType: Record<string, number> = {};
  for (const d of docs) {
    byType[d.type] = (byType[d.type] || 0) + 1;
  }
  
  return {
    total: docs.length,
    totalVerses,
    totalConversations,
    totalSizeMB: (totalSize / 1024 / 1024).toFixed(2),
    byType,
    recentDocs: docs.slice(0, 5),
  };
}
