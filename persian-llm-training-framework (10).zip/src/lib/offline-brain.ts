/**
 * 🧠 مغز آفلاین فارسی - Persian Offline Companion Brain
 * همراه همیشگی و هوشمند که روی گوشی و لینوکس اجرا می‌شه
 */

import { analyzeIntent, generateColloquialResponse, normalizeColloquial } from './colloquial-persian';
import { searchVerses, VERSES } from './poetry-db';
import { loadProfile, updateProfile, analyzePreferences, getTimeBasedGreeting, getFamiliarityLevel, detectMoodSwing } from './user-profile';

export type CompanionMode = 'free' | 'poetry' | 'conversation' | 'coach';

export interface CompanionResponse {
  text: string;
  verses: Array<{ text: string; poet: string; book?: string }>;
  analysis: ReturnType<typeof analyzeIntent>;
  suggestion?: string;
  mode: CompanionMode;
  isColloquial: boolean;
  shouldSpeak: boolean;
  profileInsight?: string;
}

/**
 * 🧠 پاسخ هوشمند از مغز آفلاین
 */
export function companionThink(
  input: string,
  options: {
    userName?: string;
    temperature?: number;
    mode?: CompanionMode;
  } = {}
): CompanionResponse {
  const { userName = 'دوست', temperature = 0.7, mode = 'free' } = options;
  
  // 1️⃣ نرمالایز کردن محاوره
  const normalized = normalizeColloquial(input);
  const textToAnalyze = normalized.normalized;
  
  // 2️⃣ تحلیل منظور
  const analysis = analyzeIntent(textToAnalyze);
  
  // 3️⃣ بارگذاری و بروزرسانی پروفایل
  const profile = loadProfile();
  
  // تشخیص شاعر از ورودی
  let detectedPoet: string | undefined;
  const poetMatch = input.match(/(حافظ|سعدی|مولانا|مولوی|فردوسی|خیام|عطار|پروین)/i);
  if (poetMatch) {
    const poetMap: Record<string, string> = { 'مولوی': 'مولانا' };
    detectedPoet = poetMap[poetMatch[1]] || poetMatch[1];
  }
  
  const updatedProfile = updateProfile(profile, {
    prompt: input,
    poet: detectedPoet,
    topics: analysis.topics,
    emotion: analysis.emotion,
  });
  
  // 4️⃣ تولید پاسخ بر اساس حالت
  let responseText = '';
  let verses: Array<{ text: string; poet: string; book?: string }> = [];
  let shouldSpeak = false;
  let profileInsight: string | undefined;
  
  // تشخیص نوع پاسخ
  const isColloquial = analysis.isColloquial || normalized.confidence > 0.3;
  
  if (mode === 'poetry' || analysis.intents.some(i => ['poetry', 'recite', 'write'].includes(i.intent))) {
    // حالت شعر
    const searchResults = searchVerses(textToAnalyze, {
      maxResults: Math.max(2, Math.ceil(temperature * 3)),
      poet: detectedPoet,
    });
    
    verses = searchResults.map(r => ({
      text: r.verse.text,
      poet: r.verse.poet,
      book: r.verse.book,
    }));
    
    if (verses.length > 0) {
      responseText = `🌸 شعر یافت شده با موضوع "${analysis.topics[0] || input.slice(0, 30)}":\n\n`;
      verses.forEach((v, i) => {
        responseText += `${v.text}\n— ${v.poet}${v.book ? ` (${v.book})` : ''}\n\n`;
      });
    } else {
      responseText = "🌸 شعر خاصی با این موضوع پیدا نکردم، ولی این شعر قشنگ رو ببین:\n\n";
      const randomVerse = VERSES[Math.floor(Math.random() * VERSES.length)];
      responseText += `${randomVerse.text}\n— ${randomVerse.poet}${randomVerse.book ? ` (${randomVerse.book})` : ''}`;
      verses = [{ text: randomVerse.text, poet: randomVerse.poet, book: randomVerse.book }];
    }
    shouldSpeak = true;
    
  } else if (analysis.emotion && analysis.intents.some(i => ['sad', 'happy', 'tired', 'angry', 'love'].includes(i.intent))) {
    // پاسخ احساسی
    responseText = generateColloquialResponse(analysis, userName);
    shouldSpeak = true;
    
    // اضافه کردن شعر مرتبط با احساس
    const moodPoems = searchVerses(analysis.emotion, { maxResults: 1 });
    if (moodPoems.length > 0) {
      responseText += `\n\n${moodPoems[0].verse.text}\n— ${moodPoems[0].verse.poet}`;
      verses = [{ text: moodPoems[0].verse.text, poet: moodPoems[0].verse.poet, book: moodPoems[0].verse.book }];
    }
    
  } else if (analysis.intents.some(i => ['greeting', 'how_are_you'].includes(i.intent))) {
    // احوال‌پرسی هوشمند
    const greeting = getTimeBasedGreeting();
    const familiarity = getFamiliarityLevel(updatedProfile);
    
    if (familiarity === 'new') {
      responseText = `${greeting} ${userName} جان! من مغز فارسی‌ام 🧠 هر سوالی درباره شعر، ادبیات یا هر چی داری بپرس!`;
    } else if (familiarity === 'close') {
      const prefs = analyzePreferences(updatedProfile);
      responseText = `${greeting} ${userName} جان! خوشحالم دیدمت 🤗 ${prefs.recommendation}`;
    } else {
      responseText = `${greeting} ${userName} جان! چه کار می‌تونم برات بکنم؟ 😊`;
    }
    shouldSpeak = true;
    
    // تشخیص نوسان خلقی
    const swing = detectMoodSwing(updatedProfile);
    if (swing) responseText += `\n\n${swing}`;
    profileInsight = swing || undefined;
    
  } else if (analysis.intents.some(i => i.intent === 'who_am_i' || i.intent === 'what_do_you_do')) {
    responseText = `سلام ${userName} جان! من مغز فارسی هستم 🧠\n\n`
      + `همراه هوشمند و آفلاین تو که:\n`
      + `• فارسی محاوره‌ای رو می‌فهمم 😎\n`
      + `• اشعار حافظ، سعدی، مولانا و... بلدم 📚\n`
      + `• حال و هوای تو رو تشخیص می‌دم 💭\n`
      + `• الگوی رفتاری تو رو کشف می‌کنم 📊\n`
      + `• همیشه در دسترس و آفلاین 📱\n\n`
      + `${getTimeBasedGreeting()}`;
    shouldSpeak = true;
    
  } else {
    // پیش‌فرض: پاسخ محاوره‌ای
    responseText = generateColloquialResponse(analysis, userName);
    shouldSpeak = true;
  }
  
  // اضافه کردن insight پروفایل (اگه کاربر قدیمیه)
  const familiarity = getFamiliarityLevel(updatedProfile);
  if (familiarity !== 'new' && !profileInsight && Math.random() > 0.7) {
    const prefs = analyzePreferences(updatedProfile);
    profileInsight = `📊 ${prefs.recommendation}`;
  }
  
  return {
    text: responseText,
    verses,
    analysis,
    suggestion: profileInsight,
    mode,
    isColloquial,
    shouldSpeak,
    profileInsight,
  };
}
