/**
 * 🗣️ موتور فهم فارسی محاوره‌ای - Colloquial Persian Engine
 * 
 * می‌فهمه کی می‌گی:
 * - "داداش چطوری?"، "سلام خوبی؟"، "چخبر؟"
 * - "دلم گرفته" ، "حالم بد" ، "خسته شدم"
 * - ترکیب فارسی و انگلیسی: "hey داداش", "OK خوبه", "no بابا"
 */

// ========== دیکشنری محاوره به رسمی ==========
export const COLLOQUIAL_MAP: [string, string][] = [
  // احوال‌پرسی
  ["چطوری", "چگونه هستی"],
  ["چطورین", "چگونه هستید"],
  ["چطوری؟", "چگونه هستی"],
  ["خوبی", "خوب هستی"],
  ["خوبین", "خوب هستید"],
  ["چخبر", "چه خبر"],
  ["چه خبرا", "چه خبر ها"],
  ["سلام علیک", "سلام بر تو"],
  ["علیک سلام", "بر تو سلام"],
  ["حالت چطوره", "حال تو چگونه است"],
  ["اوضاع چطوره", "اوضاع چگونه است"],
  
  // کلمات عامیانه روزمره
  ["داداش", "برادر"],
  ["دادا", "برادر"],
  ["برو", "برو"],
  ["بیا", "بیا"],
  ["بیاین", "بیایید"],
  ["ببین", "نگاه کن"],
  ["ببینم", "نگاه کنم"],
  ["نگا", "نگاه"],
  ["بده", "عطا کن"],
  ["بده به من", "به من عطا کن"],
  ["بکن", "انجام بده"],
  ["بکنیم", "انجام دهیم"],
  ["بزار", "بگذار"],
  ["بذار", "بگذار"],
  ["بزار ببینم", "بگذار ببینم"],
  ["بشین", "بنشین"],
  ["وایسا", "بایست"],
  ["بزن", "ضربه بزن"],
  ["بزن قدش", "موافقم"],
  ["قدش", "موافقم"],
  ["باشه", "باشد"],
  ["باش", "باشد"],
  ["اوکی", "موافقم"],
  ["اوکیه", "موافقم"],
  ["حله", "موافقم"],
  ["حل شد", "انجام شد"],
  ["درسته", "صحیح است"],
  ["آره", "بله"],
  ["آها", "متوجه شدم"],
  ["اوهوم", "متوجه شدم"],
  ["نه بابا", "خیر"],
  ["نه", "خیر"],
  ["آره بابا", "بله"],
  ["مرسی", "متشکرم"],
  ["ممنون", "متشکرم"],
  ["دمت گرم", "سپاسگزارم"],
  ["دمت", "سپاسگزارم"],
  ["قربونت", "فدای تو"],
  ["فدات", "فدای تو"],
  ["فدات شم", "فدای تو شوم"],
  ["جانم", "جان من"],
  ["جان", "عزیز"],
  
  // احساسات
  ["دلم گرفته", "اندوهگین هستم"],
  ["دلم تنگه", "دلتنگ هستم"],
  ["دلم برات تنگ شده", "برای تو دلتنگ شده‌ام"],
  ["حالم بده", "حال من بد است"],
  ["حالم خوب نی", "حال من خوب نیست"],
  ["حالم خرابه", "حالم خراب است"],
  ["خسته شدم", "خسته شده‌ام"],
  ["خسته‌ام", "خسته هستم"],
  ["دیگه طاقت ندارم", "طاقت ندارم"],
  ["عصبی‌ام", "عصبی هستم"],
  ["اعصابم خورده", "اعصابم خرد شده"],
  ["دیوونه شدم", "دیوانه شده‌ام"],
  ["داغونم", "داغون هستم"],
  ["کیف کردم", "لذت بردم"],
  ["کیف داد", "لذت بخش بود"],
  ["عالی بود", "عالی بود"],
  ["به‌به", "چه خوب"],
  ["احسنت", "آفرین"],
  ["ایول", "آفرین"],
  ["باحالی", "خوب هستی"],
  ["چقد باحالی", "چقدر خوب هستی"],
  
  // درخواست‌ها
  ["بگو", "بگو"],
  ["بگم", "بگویم"],
  ["بخون", "بخوان"],
  ["بخون برام", "برایم بخوان"],
  ["بنویس", "بنویس"],
  ["بنویس برام", "برایم بنویس"],
  ["بکش بیرون", "استخراج کن"],
  ["بده ببینم", "به من نشان بده"],
  ["نشون بده", "نمایش بده"],
  ["بگو ببینم", "بگو که ببینم"],
  ["ببینیم چیه", "ببینیم چیست"],
  ["یادم بده", "به من یاد بده"],
  ["یاد بده", "یاد بده"],
  ["بهم بگو", "به من بگو"],
  ["برام بگو", "برای من بگو"],
  ["برام", "برای من"],
  ["بهم", "به من"],
  ["باهات", "با تو"],
  ["باهاتم", "با تو هستم"],
  
  // کوتاه شده‌ها
  ["نمی‌دونم", "نمی‌دانم"],
  ["نمی‌خوام", "نمی‌خواهم"],
  ["می‌خوام", "می‌خواهم"],
  ["می‌خوای", "می‌خواهی"],
  ["می‌تونم", "می‌توانم"],
  ["می‌تونی", "می‌توانی"],
  ["میشه", "می‌شود"],
  ["نمیشه", "نمی‌شود"],
  ["چیزیم نی", "چیزی نیست"],
  ["هیچی", "هیچ چیز"],
  ["همین", "همین"],
  ["همینه", "همین است"],
  ["همون", "همان"],
  ["همونه", "همان است"],
  ["چرا", "چرا"],
  ["چرا که نه", "چرا که نه"],
  ["آخه", "زیرا"],
  ["واسه", "برای"],
  ["واسه چی", "برای چه"],
  ["چی", "چه چیز"],
  ["چیه", "چه چیز است"],
  ["کی", "چه کسی"],
  ["کیه", "چه کسی است"],
  ["کجان", "کجا هستند"],
  ["کجایی", "کجا هستی"],
  ["کدوما", "کدام‌ها"],
  ["چندتا", "چند عدد"],
  ["چقدر", "به چه میزان"],
  
  // علامت‌های انگلیسی
  ["ok", "بله"],
  ["okay", "بله"],
  ["yes", "بله"],
  ["no", "خیر"],
  ["hey", "سلام"],
  ["hi", "سلام"],
  ["hello", "سلام"],
  ["bye", "خداحافظ"],
  ["goodbye", "خداحافظ"],
  ["thanks", "متشکرم"],
  ["thank you", "متشکرم"],
  ["bro", "برادر"],
  ["dude", "رفیق"],
  ["man", "مرد"],
  ["wow", "به به"],
  ["nice", "خوب"],
  ["cool", "باحال"],
  ["sorry", "متاسفم"],
  ["please", "لطفا"],
  ["lol", "خنده دار"],
  ["omg", "خدای من"],
];

// ========== الگوهای محاوره‌ای ==========
export interface ColloquialPattern {
  pattern: RegExp;
  intent: string;
  formalEquivalent: string;
  category: 'greeting' | 'feeling' | 'request' | 'question' | 'response';
}

export const COLLOQUIAL_PATTERNS: ColloquialPattern[] = [
  // احوال‌پرسی
  { pattern: /(سلام|درود|سلاو|slm|hi|hey|hello)/i, intent: "greeting", formalEquivalent: "سلام", category: "greeting" },
  { pattern: /(چطوری|چطورین|چط|حالت چطور|خوبی|خوبین|چخبر|che khabar)/i, intent: "how_are_you", formalEquivalent: "چگونه هستید", category: "greeting" },
  { pattern: /(صبحت بخیر|صبح بخیر|عصرت بخیر|شبت بخیر|god night|good night|شب بخیر)/i, intent: "time_greeting", formalEquivalent: "روز بخیر", category: "greeting" },
  
  // احساسات
  { pattern: /(دلم گرفته|دلم تنگ|غمگین|غم|ناراحت|دلتنگ|داغون|حالم بد|حالم خراب)/i, intent: "sad", formalEquivalent: "غمگین هستم", category: "feeling" },
  { pattern: /(خوشحال|شاد|کیف کردم|کیف داد|عالی|خوبم|خوب|باحال|خندان)/i, intent: "happy", formalEquivalent: "خوشحال هستم", category: "feeling" },
  { pattern: /(خسته شدم|خسته‌ام|خستم|بی حال|بیحال|کسالم)/i, intent: "tired", formalEquivalent: "خسته هستم", category: "feeling" },
  { pattern: /(عصبی|عصبانی|اعصابم|عصبی‌ام|دیوونه|عقده)/i, intent: "angry", formalEquivalent: "عصبی هستم", category: "feeling" },
  { pattern: /(عاشق|دوست دارم|دوس دارم|دوسم داری|عاشقتم|دلبر)/i, intent: "love", formalEquivalent: "عشق", category: "feeling" },
  
  // درخواست‌ها
  { pattern: /(بگو|بخون|بخون برام|بگو ببینم|بگو برام|برام بگو)/i, intent: "recite", formalEquivalent: "بخوان", category: "request" },
  { pattern: /(بنویس|بنویس برام|برام بنویس|یک شعر)/i, intent: "write", formalEquivalent: "بنویس", category: "request" },
  { pattern: /(شعر|شعری|یک شعر|بیت|ابیات|غزل|رباعی)/i, intent: "poetry", formalEquivalent: "شعر", category: "request" },
  { pattern: /(داستان|قصه|حکایت|داستانی)/i, intent: "story", formalEquivalent: "داستان", category: "request" },
  { pattern: /(help|کمک|راهنما|یاری|بهم بگو)/i, intent: "help", formalEquivalent: "کمک", category: "request" },
  
  // سوالات
  { pattern: /(کی هستی|تو کی هستی|چی هستی|what are you|who are you)/i, intent: "who_am_i", formalEquivalent: "تو کی هستی", category: "question" },
  { pattern: /(چی کار میکنی|چه کار میکنی|what do you do)/i, intent: "what_do_you_do", formalEquivalent: "چه کار می‌کنی", category: "question" },
  { pattern: /(چی|چیه|چیست|چ|چه|چطور|چجوری|چگونه)/i, intent: "what", formalEquivalent: "چیست", category: "question" },
  { pattern: /(کجا|کجایی|کجاست|کجان|کدوم)/i, intent: "where", formalEquivalent: "کجا", category: "question" },
  { pattern: /(کی|کی بود|کی هست|کی میای|کی میری)/i, intent: "when", formalEquivalent: "کی", category: "question" },
  { pattern: /(چرا|واسه چی|برای چی|به چه دلیل)/i, intent: "why", formalEquivalent: "چرا", category: "question" },
  
  // پاسخ‌ها
  { pattern: /(باشه|حله|اوکی|ok|okay|yes|آره|آها|درست|قبول)/i, intent: "agree", formalEquivalent: "موافقم", category: "response" },
  { pattern: /(نه|no|nope|نه بابا|به هیچ وجه|هرگز|اصلا)/i, intent: "disagree", formalEquivalent: "مخالفم", category: "response" },
  { pattern: /(مرسی|ممنون|دمت گرم|دمت|تشکر|سپاس|thank|thanks)/i, intent: "thank", formalEquivalent: "متشکرم", category: "response" },
  { pattern: /(ببخش|ببخشید|معذرت|شرمنده|sorry|pardon)/i, intent: "sorry", formalEquivalent: "معذرت می‌خواهم", category: "response" },
];

// ========== توابع اصلی ==========

/**
 * 🧠 تشخیص محاوره بودن متن و تبدیل به رسمی
 */
export function normalizeColloquial(text: string): {
  original: string;
  normalized: string;
  detectedColloquialisms: string[];
  confidence: number;
} {
  let normalized = text;
  const detectedColloquialisms: string[] = [];
  
  // مرتب‌سازی از طولانی‌ترین به کوتاه‌ترین
  const sortedEntries = [...COLLOQUIAL_MAP].sort(
    ([a], [b]) => b.length - a.length
  );
  
  for (const [colloquial, formal] of sortedEntries) {
    const escaped = colloquial.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(escaped, 'gi');
    if (regex.test(normalized)) {
      detectedColloquialisms.push(colloquial);
      normalized = normalized.replace(regex, formal);
    }
  }
  
  const confidence = detectedColloquialisms.length > 0
    ? Math.min(1, detectedColloquialisms.length / 3)
    : 0;
  
  return { original: text, normalized, detectedColloquialisms, confidence };
}

/**
 * 🔍 تحلیل متن و تشخیص منظور کاربر
 */
export function analyzeIntent(text: string): {
  intents: Array<{ intent: string; category: string; confidence: number }>;
  emotion: string | null;
  topics: string[];
  isQuestion: boolean;
  isColloquial: boolean;
} {
  const results: Array<{ intent: string; category: string; confidence: number }> = [];
  const topics: string[] = [];
  let emotion: string | null = null;
  
  for (const pattern of COLLOQUIAL_PATTERNS) {
    const match = text.match(pattern.pattern);
    if (match) {
      const confidence = Math.min(1, (match[0].length / Math.max(text.length, 1)) + 0.3);
      results.push({ intent: pattern.intent, category: pattern.category, confidence });
      
      if (pattern.intent === "poetry" && !topics.includes("شعر")) topics.push("شعر");
      if (pattern.intent === "story" && !topics.includes("داستان")) topics.push("داستان");
      if (pattern.intent === "love" && !topics.includes("عشق")) topics.push("عشق");
    }
  }
  
  // تشخیص احساس
  if (/(غمگین|ناراحت|دلم گرفته|دلتنگ|داغون|حالم بد|گریه|اشک)/i.test(text)) emotion = "غمگین";
  else if (/(شاد|خوشحال|کیف|عالی|خوبم|خنده|خندان)/i.test(text)) emotion = "شاد";
  else if (/(عصبی|عصبانی|اعصاب|خشمگین)/i.test(text)) emotion = "عصبانی";
  else if (/(خسته|بی حال|بیحال|کسال)/i.test(text)) emotion = "خسته";
  else if (/(عاشق|دوست دارم|دوس دارم|عاشقتم)/i.test(text)) emotion = "عاشقانه";
  
  // تشخیص سوال
  const isQuestion = /(\?|\؟|چی|کی|کجا|چرا|چطور|آیا|چه|کدوم)$/i.test(text.trim());
  
  // تشخیص محاوره‌ای بودن
  const colloquialWords = COLLOQUIAL_MAP.filter(([cw]) =>
    new RegExp(cw.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(text)
  );
  const isColloquial = colloquialWords.length > 0 || /(داداش|آره|نه|باشه|مرسی|دمت)/i.test(text);
  
  // استخراج کلمات کلیدی موضوعی
  const topicWords: Record<string, string[]> = {
    "گل": ["گل", "بهار", "باغ", "بلبل", "چمن", "شکوفه"],
    "عشق": ["عشق", "دل", "دلبر", "یار", "دوست دارم", "عاشق"],
    "غم": ["غم", "درد", "ناراحت", "دلتنگی", "فراق"],
    "شادی": ["شاد", "خوشحال", "خنده", "کیف", "مستی"],
    "زندگی": ["زندگی", "مرگ", "روزگار", "عمر", "جهان"],
    "خدا": ["خدا", "خداوندا", "الهی", "رب", "دعا"],
    "دوستی": ["دوست", "رفیق", "یار", "همدم", "آشنا"],
  };
  
  for (const [topic, words] of Object.entries(topicWords)) {
    if (words.some(w => text.includes(w))) {
      if (!topics.includes(topic)) topics.push(topic);
    }
  }
  
  return { intents: results, emotion, topics, isQuestion, isColloquial };
}

/**
 * 🤖 تولید پاسخ محاوره‌ای
 */
export function generateColloquialResponse(
  analysis: ReturnType<typeof analyzeIntent>,
  userName?: string
): string {
  const name = userName || "دوست";
  const responses: Record<string, string[]> = {
    greeting: [
      `سلام ${name}! چطوری؟ خوش اومدی 😊`,
      `درود ${name}! چه خبرا؟ خوبی؟ 🌹`,
      `سلام علیک ${name}! خوشحالم دیدمت 😍`,
    ],
    how_are_you: [
      `خوبم ${name} جان! ممنون که پرسیدی 😊 تو چطوری؟`,
      `بحمدلله خوبم! تو بگو ${name} جان چه خبر؟ 🌸`,
      `عالی ${name} جان! با تو که هستم همیشه خوبم 💪`,
    ],
    sad: [
      `${name} جان ناراحت نباش! شعر حافظ حالت رو عوض می‌کنه:\nز کوی یار می‌آید نسیم باد نوروزی`,
      `${name} جان غمگین نباش! مولانا می‌گه:\nبازآی بازآی هر آنچه هستی بازآ`,
    ],
    happy: [
      `${name} جان چه عالی! خوشحالم که خوشحالی! 😍 گل در بر و می در کف و معشوق به کام است`,
      `آفرین ${name}! شادی تو باعث شادی منه! 🎉 بهار آمد و گل‌ها ز هر سو برست`,
    ],
    tired: [
      `${name} جان خسته نباشی! خیام می‌گه:\nاز دی که گذشت هیچ ازو یاد مکن / فردا که نیامده ست فریاد مکن`,
      `${name} جان دمی بیاسا! حالی خوش باش و عمر بر باد مکن`,
    ],
    love: [
      `${name} جان عشقی؟! 😍 عشق دردانه‌ای است من ندانم / کاین دردانه را که می‌کند دام`,
      `${name} جان عشق نعمت خداست: دل سراپردهٔ محبت اوست`,
    ],
    poetry: [
      `${name} جان شعر بگو برات! 🎵 کدوم شاعر رو دوست داری؟ حافظ، سعدی، مولانا؟`,
      `به به ${name} جان، شعر می‌خوای! 🌸 از کدوم شاعر و با چه موضوعی بگم؟`,
    ],
    who_am_i: [
      `سلام ${name} جان! من مغز فارسی هستم 🧠 همراه هوشمندی که شعر بلده، محاوره می‌فهمه و همیشه باهاتمه!`,
      `${name} جان! من مغز فارسی‌ام، آفلاین و همیشه همراه تو 🤗`,
    ],
    agree: [
      `آفرین ${name} جان! پس یه شعر قشنگ بگم؟ 🌸`,
      `حله ${name} جان! بزن قدش! 😎`,
    ],
    thank: [
      `خواهش می‌کنم ${name} جان!😊 افتخار من بود`,
      `قربانت ${name} جان! همیشه در خدمتم 🌹`,
    ],
    angry: [
      `${name} جان آروم باش! یه نفس عمیق بکش 🤗 غم را به ساقی می‌گویم تا مست کند`,
      `${name} جان عصبانی نباش! غصه نخور: حافظ می‌گه خوش باش`,
    ],
    sorry: [
      `اشکالی نداره ${name} جان! همه ما آدمیم 😊`,
      `مهم نیست ${name} جان! بازم می‌تونیم حرف بزنیم 🌸`,
    ],
    default: [
      `${name} جان چیز خاصی گفتی؟ 😅 بذار یه شعر از حافظ بگم:\nسخن در پرده می‌گویم چو گل از پرده بیرون آی`,
      `${name} جان! هر چی دوست داری بپرس: درباره شعر، عشق، زندگی 💬`,
    ],
  };
  
  // بهترین intent رو انتخاب کن
  let bestCategory = "default";
  let bestConfidence = 0;
  
  for (const intent of analysis.intents) {
    if (intent.confidence > bestConfidence) {
      bestConfidence = intent.confidence;
      const categoryMap: Record<string, string> = {
        "greeting": "greeting", "how_are_you": "how_are_you",
        "sad": "sad", "happy": "happy", "tired": "tired", "angry": "angry", "love": "love",
        "poetry": "poetry", "story": "poetry",
        "agree": "agree", "disagree": "default",
        "thank": "thank", "sorry": "sorry",
        "who_am_i": "who_am_i", "what_do_you_do": "who_am_i",
      };
      bestCategory = categoryMap[intent.intent] || "default";
    }
  }
  
  if (analysis.emotion) {
    const emotionMap: Record<string, string> = {
      "غمگین": "sad", "شاد": "happy", "عصبانی": "angry",
      "خسته": "tired", "عاشقانه": "love",
    };
    if (emotionMap[analysis.emotion]) bestCategory = emotionMap[analysis.emotion];
  }
  
  if (analysis.isQuestion && bestCategory === "default") bestCategory = "poetry";
  
  const options = responses[bestCategory] || responses.default;
  return options[Math.floor(Math.random() * options.length)];
}

/**
 * 📝 مثال‌های محاوره برای تست
 */
export const COLLOQUIAL_EXAMPLES = [
  "سلام داداش چطوری؟",
  "دلم گرفته یه شعر بگو",
  "عاشق شدم داداش!💕",
  "خسته شدم امروز",
  "داداش حالم بده",
  "اوکی خوبه مرسی",
  "بگو ببینم چه خبرا",
  "hey داداش good to see you",
  "no بابا این درست نی",
  "بنویس برام یه شعر قشنگ",
  "کیف کردم از این همه شعر!",
  "دمت گرم عالی بود👌",
  "حالت چطوره خوبی؟",
  "آره بابا بیا بریم",
  "واسه چی انقدر قشنگی؟😍",
];

/**
 * 🎵 عبارات قابل استفاده در Voice/Speech
 */
export const SPEECH_PHRASES = [
  { text: "سلام داداش، چطوری؟ خوش اومدی!", emotion: "cheerful" as const },
  { text: "دلم گرفته، یه شعر قشنگ بگو", emotion: "sad" as const },
  { text: "عاشقتم داداش! عشق که عیب نیست", emotion: "loving" as const },
  { text: "آفرین! دمت گرم عالی بود", emotion: "happy" as const },
  { text: "خسته نباشی داداش، غصه نخور", emotion: "caring" as const },
];
