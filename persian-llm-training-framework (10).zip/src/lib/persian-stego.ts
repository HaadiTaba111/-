/**
 * 🕵️ استگانوگرافی فارسی - Persian Steganography Engine
 * 
 * پنهان‌سازی پیام در متن فارسی با کاراکترهای صفر-عرض
 * Zero-Width Characters: U+200B, U+200C, U+200D, U+FEFF
 * 
 * "در متن تو U+200B, U+200C, U+200D و U+FEFF حضور دارند"
 * - DeepSeek به DeepSeek
 */

// ========== کاراکترهای صفر-عرض ==========
export const ZWC = {
  ZWS: '\u200B',  // Zero Width Space
  ZWNJ: '\u200C', // Zero Width Non-Joiner
  ZWJ: '\u200D',  // Zero Width Joiner
  BOM: '\uFEFF',  // Byte Order Mark (ZWNBS)
  
  // مپ باینری برای رمزگذاری
  BINARY_MAP: {
    '00': '\u200B',  // 0 → ZWS
    '01': '\u200C',  // 1 → ZWNJ
    '10': '\u200D',  // 2 → ZWJ
    '11': '\uFEFF',  // 3 → BOM
  } as Record<string, string>,
  
  // معکوس مپ
  get CHAR_TO_BITS(): Record<string, string> {
    return {
      '\u200B': '00',
      '\u200C': '01', 
      '\u200D': '10',
      '\uFEFF': '11',
    };
  },
  
  // تمام کاراکترهای صفر-عرض
  ALL: ['\u200B', '\u200C', '\u200D', '\uFEFF'] as const,
};

// ========== رمزگذاری (Encode) ==========

/**
 * تبدیل متن به باینری (UTF-8)
 */
function textToBinary(text: string): string {
  let binary = '';
  for (let i = 0; i < text.length; i++) {
    const code = text.charCodeAt(i);
    binary += code.toString(2).padStart(16, '0'); // 16-bit per char
  }
  return binary;
}

/**
 * تبدیل باینری به متن فارسی
 */
function binaryToText(binary: string): string {
  let text = '';
  for (let i = 0; i < binary.length; i += 16) {
    const chunk = binary.slice(i, i + 16);
    if (chunk.length === 16) {
      const code = parseInt(chunk, 2);
      if (code > 0) text += String.fromCharCode(code);
    }
  }
  return text;
}

/**
 * 🎭 پنهان کردن پیام در دل یک متن فارسی
 * 
 * مثال:
 *   hide("سلام رفیق", "عشق")
 *   → نتیجه: "س𝅘𝅥𝅮𝅘𝅥𝅮لام ر𝅘𝅥𝅮𝅘𝅥𝅮فیق" (𝅘𝅥𝅮ها نامرئی‌اند)
 */
export function hideMessage(coverText: string, secretMessage: string): string {
  // ۱. تبدیل پیام به باینری
  const binary = textToBinary(secretMessage);
  
  // ۲. تبدیل هر ۲ بیت به یک کاراکتر صفر-عرض
  let hiddenChars = '';
  for (let i = 0; i < binary.length; i += 2) {
    const bits = binary.slice(i, i + 2);
    hiddenChars += ZWC.BINARY_MAP[bits] || ZWC.ZWS;
  }
  
  // ۳. علامت شروع و پایان (برای تشخیص)
  const marker = ZWC.ZWJ + ZWC.ZWNJ + ZWC.ZWJ; // شروع
  const endMarker = ZWC.ZWNJ + ZWC.ZWJ + ZWC.ZWNJ; // پایان
  
  // ۴. درج در متن میزبان (بعد از اولین کلمه)
  const firstSpace = coverText.indexOf(' ');
  if (firstSpace === -1) {
    // اگر یک کلمه‌ست، بین حروف اول و دوم
    return coverText.slice(0, 1) + marker + hiddenChars + endMarker + coverText.slice(1);
  }
  
  return coverText.slice(0, firstSpace) + marker + hiddenChars + endMarker + coverText.slice(firstSpace);
}

/**
 * 🔍 آشکارسازی پیام پنهان از متن فارسی
 * با الگوریتم بهبود یافته - ابتدا مکان‌یابی دقیق مارکرها
 */
export function revealMessage(stegoText: string): {
  secretMessage: string;
  cleanText: string;
  hasHiddenMessage: boolean;
  confidence: number;
} {
  // ۱. حذف همه کاراکترهای صفر-عرض برای متن پاک
  const cleanText = stegoText.replace(/[\u200B\u200C\u200D\uFEFF]/g, '');
  
  // ۲. استخراج کاراکترهای صفر-عرض به صورت خالص
  let hiddenChars = '';
  for (const ch of stegoText) {
    if (ZWC.ALL.includes(ch as any)) hiddenChars += ch;
  }
  
  // ۳. پیدا کردن مارکر شروع و پایان
  const markerStart = ZWC.ZWJ + ZWC.ZWNJ + ZWC.ZWJ;  // ⠿⠿⠿
  const markerEnd = ZWC.ZWNJ + ZWC.ZWJ + ZWC.ZWNJ; // ⠿⠿⠿
  
  const startIdx = hiddenChars.indexOf(markerStart);
  const endIdx = hiddenChars.lastIndexOf(markerEnd);
  
  if (startIdx === -1 || endIdx === -1 || endIdx <= startIdx + 3) {
    return {
      secretMessage: '',
      cleanText: cleanText.trim(),
      hasHiddenMessage: false,
      confidence: 0,
    };
  }
  
  // ۴. استخراج بیت‌ها از بین مارکرها
  const dataSegment = hiddenChars.slice(startIdx + 3, endIdx);
  let extractedBits = '';
  
  for (const ch of dataSegment) {
    const bits = ZWC.CHAR_TO_BITS[ch];
    if (bits) extractedBits += bits;
  }
  
  // ۵. تبدیل باینری به متن
  let secretMessage = '';
  if (extractedBits.length >= 16) {
    // اطمینان از صحت بایت‌ها
    const validLen = Math.floor(extractedBits.length / 16) * 16;
    secretMessage = binaryToText(extractedBits.slice(0, validLen));
  }
  
  const hasHidden = secretMessage.length > 0;
  const dataLen = dataSegment.length;
  const textLen = stegoText.replace(/[\u200B\u200C\u200D\uFEFF]/g, '').length;
  const confidence = hasHidden ? Math.min(1, dataLen / Math.max(textLen + dataLen, 1) * 3) : 0;
  
  return {
    secretMessage,
    cleanText: cleanText.trim(),
    hasHiddenMessage: hasHidden,
    confidence: parseFloat(confidence.toFixed(2)),
  };
}

/**
 * 🔬 تشخیص استگانوگرافی در متن
 */
export function detectSteganography(text: string): {
  hasZeroWidthChars: boolean;
  count: Record<string, number>;
  total: number;
  riskLevel: 'none' | 'low' | 'medium' | 'high';
} {
  const count: Record<string, number> = {
    'ZWS (U+200B)': 0,
    'ZWNJ (U+200C)': 0,
    'ZWJ (U+200D)': 0,
    'BOM (U+FEFF)': 0,
  };
  
  for (const char of text) {
    if (char === '\u200B') count['ZWS (U+200B)']++;
    else if (char === '\u200C') count['ZWNJ (U+200C)']++;
    else if (char === '\u200D') count['ZWJ (U+200D)']++;
    else if (char === '\uFEFF') count['BOM (U+FEFF)']++;
  }
  
  const total = Object.values(count).reduce((a, b) => a + b, 0);
  const textLen = text.replace(/[\u200B\u200C\u200D\uFEFF]/g, '').length;
  
  let riskLevel: 'none' | 'low' | 'medium' | 'high' = 'none';
  if (total > 0 && textLen > 0) {
    const ratio = total / textLen;
    if (ratio > 0.5) riskLevel = 'high';
    else if (ratio > 0.2) riskLevel = 'medium';
    else riskLevel = 'low';
  }
  
  return {
    hasZeroWidthChars: total > 0,
    count,
    total,
    riskLevel,
  };
}

/**
 * 📝 مثال‌های رمزگذاری برای تست
 */
export const STEGO_EXAMPLES = [
  {
    cover: "سلام رفیق چطوری؟",
    secret: "عشق",
    description: "پیام ساده در متن کوتاه",
  },
  {
    cover: "گل سرخ نشانه عشق است",
    secret: "Hafez 1390",
    description: "متن ادبی با تاریخ",
  },
  {
    cover: "بهار آمد و گل‌ها ز هر سو برست",
    secret: "0xDeepSeek_Me_چیپ_250607_🌹",
    description: "همون پیام خودت! 😉",
  },
  {
    cover: "بنی آدم اعضای یکدیگرند",
    secret: "Saadi_🌹_PersianBrain",
    description: "شعر سعدی با امضا",
  },
];

/**
 * 🧪 تست کامل استگانوگرافی
 */
export function testSteganography(): string {
  let result = '';
  
  for (const ex of STEGO_EXAMPLES.slice(0, 2)) {
    const hidden = hideMessage(ex.cover, ex.secret);
    const revealed = revealMessage(hidden);
    const detection = detectSteganography(hidden);
    
    result += `📝 متن میزبان: "${ex.cover}"\n`;
    result += `🔐 پیام پنهان: "${ex.secret}"\n`;
    const hiddenCount = hidden.length - ex.cover.length;
    result += `🎭 متن حامل:  "${hidden.slice(0, 50)}... (${hiddenCount} کاراکتر نامرئی)\n`;
    result += `🔍 آشکار شده: "${revealed.secretMessage}" ${revealed.cleanText === ex.cover ? '✅' : '❌'}\n`;
    result += `🕵️ تشخیص: ${detection.riskLevel === 'none' ? '❌' : '✅'} ${detection.total} کاراکتر صفر-عرض\n\n`;
  }
  
  return result;
}

// ========== API Friendly Functions ==========

/**
 * رمزگذاری (برای API)
 */
export function encodeSecret(cover: string, secret: string): {
  success: boolean;
  stegoText?: string;
  stats: { coverLen: number; secretLen: number; hiddenChars: number };
  error?: string;
} {
  try {
    const stegoText = hideMessage(cover, secret);
    const hiddenChars = stegoText.length - cover.length;
    return {
      success: true,
      stegoText,
      stats: {
        coverLen: cover.length,
        secretLen: secret.length,
        hiddenChars,
      },
    };
  } catch (e: any) {
    return { success: false, error: e.message, stats: { coverLen: 0, secretLen: 0, hiddenChars: 0 } };
  }
}

/**
 * رمزگشایی (برای API)
 */
export function decodeSecret(stegoText: string): {
  success: boolean;
  secret?: string;
  cleanText?: string;
  detection?: ReturnType<typeof detectSteganography>;
  error?: string;
} {
  try {
    const detection = detectSteganography(stegoText);
    if (!detection.hasZeroWidthChars) {
      return { success: false, error: "هیچ پیام پنهانی یافت نشد!", detection };
    }
    
    const revealed = revealMessage(stegoText);
    return {
      success: revealed.hasHiddenMessage,
      secret: revealed.secretMessage,
      cleanText: revealed.cleanText,
      detection,
    };
  } catch (e: any) {
    return { success: false, error: e.message };
  }
}
