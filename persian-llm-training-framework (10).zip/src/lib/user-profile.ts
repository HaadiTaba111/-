/**
 * 👤 پروفایل و تحلیل الگوی رفتاری کاربر
 * User Behavior Profile - کاملاً سمت کاربر (آفلاین)
 */

export interface UserProfile {
  name: string;
  createdAt: number;
  lastActive: number;
  totalInteractions: number;
  favoritePoets: Record<string, number>;  // شاعر → تعداد دفعات
  favoriteTopics: Record<string, number>; // موضوع → تعداد
  emotionalHistory: Array<{
    emotion: string;
    timestamp: number;
    context: string;
  }>;
  recentPrompts: Array<{
    text: string;
    timestamp: number;
    sentiment: string;
  }>;
  preferences: {
    temperature: number;
    maxLength: number;
    voiceEnabled: boolean;
    mode: 'normal' | 'colloquial' | 'both';
  };
  streaks: {
    currentStreak: number;
    longestStreak: number;
    lastActiveDate: string;
  };
  // الگوهای روزانه
  dailyPattern: Record<string, number>; // ساعت → تعداد مراجعه
}

const STORAGE_KEY = 'persian-brain-user-profile';

/**
 * پروفایل پیش‌فرض
 */
function defaultProfile(): UserProfile {
  return {
    name: 'دوست',
    createdAt: Date.now(),
    lastActive: Date.now(),
    totalInteractions: 0,
    favoritePoets: {},
    favoriteTopics: {},
    emotionalHistory: [],
    recentPrompts: [],
    preferences: {
      temperature: 0.7,
      maxLength: 256,
      voiceEnabled: false,
      mode: 'both',
    },
    streaks: {
      currentStreak: 0,
      longestStreak: 0,
      lastActiveDate: new Date().toISOString().split('T')[0],
    },
    dailyPattern: {},
  };
}

/**
 * ذخیره پروفایل
 */
export function saveProfile(profile: UserProfile): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
  } catch (e) {
    console.warn('خطا در ذخیره پروفایل:', e);
  }
}

/**
 * بارگذاری پروفایل
 */
export function loadProfile(): UserProfile {
  if (typeof window === 'undefined') return defaultProfile();
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // اطمینان از وجود تمام فیلدها
      return { ...defaultProfile(), ...parsed };
    }
  } catch (e) {
    console.warn('خطا در بارگذاری پروفایل:', e);
  }
  return defaultProfile();
}

/**
 * بروزرسانی پروفایل با تعامل جدید
 */
export function updateProfile(
  profile: UserProfile,
  interaction: {
    prompt: string;
    poet?: string;
    topics: string[];
    emotion?: string | null;
  }
): UserProfile {
  const now = Date.now();
  const today = new Date().toISOString().split('T')[0];
  
  // بروزرسانی آمار
  profile.totalInteractions++;
  profile.lastActive = now;
  
  // بروزرسانی شاعران محبوب
  if (interaction.poet) {
    profile.favoritePoets[interaction.poet] =
      (profile.favoritePoets[interaction.poet] || 0) + 1;
  }
  
  // بروزرسانی موضوعات محبوب
  for (const topic of interaction.topics) {
    profile.favoriteTopics[topic] =
      (profile.favoriteTopics[topic] || 0) + 1;
  }
  
  // بروزرسانی تاریخچه احساسات
  if (interaction.emotion) {
    profile.emotionalHistory.push({
      emotion: interaction.emotion,
      timestamp: now,
      context: interaction.prompt.slice(0, 100),
    });
    // نگه داشتن ۵۰ مورد آخر
    if (profile.emotionalHistory.length > 50) {
      profile.emotionalHistory = profile.emotionalHistory.slice(-50);
    }
  }
  
  // بروزرسانی recent prompts
  const sentiment = interaction.emotion || 'خنثی';
  profile.recentPrompts.push({
    text: interaction.prompt.slice(0, 150),
    timestamp: now,
    sentiment,
  });
  if (profile.recentPrompts.length > 50) {
    profile.recentPrompts = profile.recentPrompts.slice(-50);
  }
  
  // بروزرسانی streaks
  if (profile.streaks.lastActiveDate === today) {
    // امروز قبلاً اومده بود
  } else if (profile.streaks.lastActiveDate === getYesterday()) {
    profile.streaks.currentStreak++;
    profile.streaks.longestStreak = Math.max(
      profile.streaks.longestStreak,
      profile.streaks.currentStreak
    );
  } else {
    profile.streaks.currentStreak = 1;
  }
  profile.streaks.lastActiveDate = today;
  
  // بروزرسانی الگوی روزانه
  const hour = new Date().getHours().toString();
  profile.dailyPattern[hour] = (profile.dailyPattern[hour] || 0) + 1;
  
  saveProfile(profile);
  return profile;
}

function getYesterday(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().split('T')[0];
}

/**
 * تحلیل سلیقه کاربر - کشف الگوهای رفتاری
 */
export function analyzePreferences(profile: UserProfile): {
  bestPoet: string | null;
  bestTopic: string | null;
  dominantEmotion: string | null;
  peakHour: string | null;
  isConsistent: boolean;
  recommendation: string;
} {
  // شاعر محبوب
  const bestPoet = getTopKey(profile.favoritePoets);
  
  // موضوع محبوب
  const bestTopic = getTopKey(profile.favoriteTopics);
  
  // احساس غالب
  const emotionCounts: Record<string, number> = {};
  for (const entry of profile.emotionalHistory) {
    emotionCounts[entry.emotion] = (emotionCounts[entry.emotion] || 0) + 1;
  }
  const dominantEmotion = getTopKey(emotionCounts);
  
  // ساعت اوج مراجعه
  const peakHour = getTopKey(profile.dailyPattern);
  
  // ثبات کاربر
  const isConsistent = profile.streaks.currentStreak >= 3;
  
  // توصیه شخصی‌سازی شده
  let recommendation = '';
  if (bestPoet) {
    recommendation = `به نظر می‌رسه ${bestPoet} رو خیلی دوست داری! `;
  }
  if (dominantEmotion) {
    const emotionAdvice: Record<string, string> = {
      'غمگین': 'بهت یه شعر شاد از حافظ پیشنهاد می‌دم 🌸',
      'شاد': 'انرژی مثبتت عالیه! بیا یه شعر حماسی از فردوسی بگم ⚔️',
      'عاشقانه': 'عشق که همیشه قشنگه! یه غزل از مولانا بگم 💖',
      'خسته': 'خسته نباشی! یه رباعی از خیام بگم 🍷',
    };
    recommendation += emotionAdvice[dominantEmotion] || '';
  }
  if (!recommendation) {
    recommendation = 'به نظر می‌رسه تنوع طلبی! برات یه شعر تصادفی بگم 🎲';
  }
  
  return { bestPoet, bestTopic, dominantEmotion, peakHour, isConsistent, recommendation };
}

function getTopKey(obj: Record<string, number>): string | null {
  const entries = Object.entries(obj);
  if (entries.length === 0) return null;
  return entries.sort((a, b) => b[1] - a[1])[0][0];
}

/**
 * تشخیص میزان آشنایی کاربر
 */
export function getFamiliarityLevel(profile: UserProfile): 'new' | 'familiar' | 'close' {
  if (profile.totalInteractions < 5) return 'new';
  if (profile.totalInteractions < 20) return 'familiar';
  return 'close';
}

/**
 * پیشنهاد بر اساس زمان روز
 */
export function getTimeBasedGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 6) return 'شب بخیر! چه خبر این وقت شب؟ 🌙';
  if (hour < 12) return 'صبحت بخیر! روز قشنگی در پیشه ☀️';
  if (hour < 17) return 'ظهر بخیر! امیدوارم روز خوبی داشته باشی 🌻';
  if (hour < 21) return 'عصرت بخیر! خسته نباشی 🌅';
  return 'شبت بخیر! شب آرومی داشته باشی 🌙';
}

/**
 * تشخیص نوسانات خلقی اخیر
 */
export function detectMoodSwing(profile: UserProfile): string | null {
  if (profile.emotionalHistory.length < 3) return null;
  
  const recent = profile.emotionalHistory.slice(-5);
  const emotions = recent.map(e => e.emotion);
  const unique = [...new Set(emotions)];
  
  if (unique.length >= 3) {
    return 'به نظر می‌رسه این روزا حال و هوات متغیره! می‌خوای باهات حرف بزنم؟ 🤗';
  }
  return null;
}
