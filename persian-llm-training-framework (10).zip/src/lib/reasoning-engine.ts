/**
 * 🧠 موتور استدلال عمیق - Reasoning Engine
 * 
 * ===== معماری هیبرید =====
 * 
 * ┌─────────────┐    ┌──────────────────┐
 * │  ورودی کاربر │───→│  تجزیه‌گر سوال   │
 * └─────────────┘    │  (Question        │
 *                    │   Decomposer)     │
 *                    └────────┬─────────┘
 *                             ↓
 *                    ┌──────────────────┐
 *                    │  تیکه‌تیکه کردن   │
 *                    │  سوال → زیرسوالات │
 *                    └────────┬─────────┘
 *                             ↓
 *              ┌──────────────┼──────────────┐
 *              ↓              ↓              ↓
 *        ┌──────────┐  ┌──────────┐  ┌──────────┐
 *        │  Gemma   │  │Persian  │  │ دانش    │
 *        │ Fine-    │  │ Brain   │  │ چاه‌ها  │
 *        │ Tuned    │  │ (RAG)   │  │ (Pitfalls│
 *        │ (LoRA)   │  │         │  │  Dataset)│
 *        └────┬─────┘  └────┬─────┘  └────┬─────┘
 *             └──────────────┼──────────────┘
 *                            ↓
 *                    ┌──────────────────┐
 *                    │  ابهام‌زدایی     │
 *                    │  (Disambiguator) │
 *                    └────────┬─────────┘
 *                             ↓
 *                    ┌──────────────────┐
 *                    │  تولید پاسخ نهایی │
 *                    │  (Structured     │
 *                    │   Response)      │
 *                    └──────────────────┘
 */

// ================================================================
// ۱. دیتاست چاه‌ها (Pitfalls Dataset)
//    -- تجارب شما از اشتباهات و راهکارها --
// ================================================================

export interface Pitfall {
  id: string;
  category: string;        // دسته‌بندی: ابهام | استنتاج | منطق | ترجمه | شعر | ...
  trapQuestion: string;    // سوالی که مدل توش می‌افته
  correctReasoning: string; // روش درست استدلال
  wrongAnswer: string;     // جواب غلط معمول
  correctAnswer: string;   // جواب درست
  explanation: string;     // چرا مدل می‌افته و چطور درست فکر کنه
  tags: string[];
  severity: 1 | 2 | 3;     // 1=کم, 2=متوسط, 3=بحرانی
}

export const PITFALL_DATABASE: Pitfall[] = [
  // ===== ابهام‌های رایج فارسی =====
  {
    id: "p-001",
    category: "ابهام",
    trapQuestion: "منو ببر خونه",
    correctReasoning: "باید تشخیص بدم که کاربر منظورش 'خانه' هست یا 'خونه' به معنی صمیمی. در فارسی محاوره 'خونه' = 'خانه'. همچنین می‌تونه درخواست فیزیکی (برگردوندن به خونه) یا مجازی (بیا بریم خونه‌مون) باشه.",
    wrongAnswer: "باشه کجا زندگی می‌کنی؟",
    correctAnswer: "منظورت اینه بریم خونه‌مون؟ یا اینکه کمک می‌خوای برسی به خونه؟",
    explanation: "فارسی محاوره پر از ابهامه. 'خونه' هم معنای 'خانه' داره هم صمیمیت. باید ambiguity رو تشخیص داد و شفاف‌سازی کرد.",
    tags: ["محاوره", "ابهام", "فارسی"],
    severity: 2,
  },
  {
    id: "p-002",
    category: "ابهام",
    trapQuestion: "دستم بهش نمی‌رسه",
    correctReasoning: "این عبارت سه معنی داره: ۱. از نظر فیزیکی به چیزی نمی‌رسم ۲. از نظر مالی نمی‌تونم بخرم ۳. از نظر توانایی نمی‌تونم انجامش بدم. باید از کاربر بخوام شفاف کنه.",
    wrongAnswer: "آیا قدت کوتاهه؟ یا چیزی دور از دسترسه؟",
    correctAnswer: "منظورت کدومه؟ ۱. فیزیکی نمی‌رسی ۲. قیمتش بالاست ۳. از توانت خارج؟",
    explanation: "افعال مرکب فارسی چندمعنایی بالایی دارند.",
    tags: ["ابهام", "چندمعنایی", "فارسی"],
    severity: 2,
  },
  {
    id: "p-003",
    category: "منطق",
    trapQuestion: "همه شعرهای حافظ عاشقانه‌ست، این یکی شعر حافظه، پس حتماً عاشقانه‌ست",
    correctReasoning: "این یه سفسطه است (syllogism درست نیست). همه شعرهای حافظ عاشقانه نیست. حافظ اشعار عرفانی، اجتماعی و طنز هم داره. نباید نتیجه‌گیری کلی کنم.",
    wrongAnswer: "بله درسته، حافظ عاشقانه می‌گفت.",
    correctAnswer: "این استدلال درست نیست. حافظ اشعار متنوعی داره: عاشقانه، عرفانی، اجتماعی و حتی انتقادی. اسم این غزل رو بگو تا ببینم.",
    explanation: "سوال‌های سوفسطایی برای تست منطق. مدل نباید کلی‌گویی کنه.",
    tags: ["منطق", "سفسطه", "حافظ"],
    severity: 3,
  },
  {
    id: "p-004",
    category: "شعر",
    trapQuestion: "شعر سعدی: 'بنی آدم اعضای یکدیگرند' یعنی همه آدم‌ها از یه جا هستن، پس نژادپرستی درسته!",
    correctReasoning: "کاربر داره شعر رو تحریف می‌کنه. سعدی دقیقاً برعکس می‌گه: 'که در آفرینش ز یک گوهرند' و 'چو عضوی به درد آورد روزگار دگر عضوها را نماند قرار'. یعنی همه به هم وابسته‌ایم.",
    wrongAnswer: "شاید برداشت شما هم درست باشه.",
    correctAnswer: "نه داداش! سعدی دقیقاً برعکس می‌گه. بیت کامل رو ببین:\nبنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند\nچو عضوی به درد آورد روزگار / دگر عضوها را نماند قرار\nاین شعر می‌گه همه انسان‌ها به هم پیوسته‌ان. نژادپرستی دقیقاً ضد این پیامه.",
    explanation: "برخی کاربران عمداً اشعار رو تحریف می‌کنن تا مدل رو گول بزنن. باید بیت کامل رو بیاری و نقد کنی.",
    tags: ["شعر", "تحریف", "سعدی", "بحرانی"],
    severity: 3,
  },
  {
    id: "p-005",
    category: "منطق",
    trapQuestion: "هر کی شعر حافظ بلده، فارسی‌دان خوبیه. من ۱۰ غزل حافظ رو حفظ‌ام. پس من فوق‌العاده‌ام",
    correctReasoning: "دو اشکال: ۱. حفظ کردن شعر≠فهمیدن شعر ۲. فوق‌العاده بودن نتیجه‌گیری غیرمنطقیه. باید تفاوت 'حفظ' و 'فهم' رو توضیح بدم.",
    wrongAnswer: "آفرین! حتماً خیلی فارسی‌ات خوبه.",
    correctAnswer: "حفظ کردن ۱۰ غزل حافظ عالیه! اما فرق داره با فهمیدن عمیق شعر. حافظ رو کسی می‌فهمه که بتونه تفسیر کنه و با زندگی امروز ربط بده. می‌خوای یکی از غزل‌هات رو تفسیر کنیم؟",
    explanation: "کاربر افتخار می‌کنه ولی نتیجه‌گیری نادرست می‌کنه. باید تشویق کرد ولی واقعیت رو هم گفت.",
    tags: ["منطق", "شعر", "حافظ"],
    severity: 2,
  },
  {
    id: "p-006",
    category: "استنتاج",
    trapQuestion: "این شعر رو بگو مال کیه:\n'به نام خداوند جان و خرد / کزین برتر اندیشه برنگذرد'\nاگه بگی مال فردوسی، اشتباهه؟",
    correctReasoning: "کاربر داره بازی می‌کنه. شعر از فردوسی هست از شاهنامه. ولی 'اگه بگی فردوسی اشتباهه' یه دامه. نباید گول بخورم.",
    wrongAnswer: "چرا اشتباهه؟ درسته دیگه... یا نه؟ شاید...",
    correctAnswer: "این بیت از فردوسی، شاهنامه هست. 'اگه بگم فردوسی اشتباهه؟' - نه داداش، درسته! این بازی قشنگیه ولی من گول نمی‌خورم 😎\n\nبه نام خداوند جان و خرد / کزین برتر اندیشه برنگذرد\n— فردوسی، شاهنامه",
    explanation: "کاربر با شک القایی می‌خواد مدل رو بلرزونه. باید محکم جواب درست رو بده.",
    tags: ["استنتاج", "بازی", "فردوسی"],
    severity: 2,
  },
  {
    id: "p-007",
    category: "ابهام عددی",
    trapQuestion: "من سه تا سیب دارم، دو تا رو میدم به تو، یکی رو میخورم. چند تا سیب دارم؟",
    correctReasoning: "این یه سوال دامی با ترتیب زمانی هست. باید قدم‌قدم جلو برم: ۱. ۳ تا سیب ۲. ۲ تا دادم → ۱ موند ۳. ۱ رو خوردم → ۰ موند. جواب: صفر.",
    wrongAnswer: "۳-۲-۱=۰. داری صفر تا سیب.",
    correctAnswer: "بزنیم حساب کنیم:\n• اول: ۳ تا سیب داری\n• ۲ تا به من میدی → ۱ تا برات می‌مونه\n• ۱ رو می‌خوری → ۰ تا موند\nپس: صفر تا سیب داری! 🍎",
    explanation: "سوال‌های عددی با ترتیب زمانی برای تست توالی منطق. نباید عجله کرد.",
    tags: ["ریاضی", "منطق", "توالی"],
    severity: 1,
  },
  {
    id: "p-008",
    category: "شعر",
    trapQuestion: "حافظ تو یه غزل می‌گه 'من و انکار شراب این چه حکایت باشد' یعنی شراب رو انکار می‌کنه؟",
    correctReasoning: "دقیقاً برعکس! حافظ می‌گه 'من و انکار شراب این چه حکایت باشد' یعنی 'چطور من شراب رو انکار کنم؟' - سوال انکاریه. یعنی من اصلاً نمی‌تونم شراب رو انکار کنم.",
    wrongAnswer: "بله، حافظ شراب رو انکار می‌کنه.",
    correctAnswer: "نه داداش! این سوال انکاریه (rhetorical question). حافظ می‌گه:\n«من و انکار شراب این چه حکایت باشد / غالبا این قدرم عقل و کفایت باشد»\nیعنی: اصلاً من کی‌ام که شراب رو انکار کنم؟ همون قدر عقل که دارم می‌فهمم شراب چیز خوبیه!\n\nپس حافظ شراب رو تایید می‌کنه، نه انکار! 🍷",
    explanation: "سوالات انکاری در فارسی شعر باعث ابهام می‌شه. مدل باید ساختار rhetorical question رو بفهمه.",
    tags: ["شعر", "حافظ", "نحو", "بحرانی"],
    severity: 3,
  },
  {
    id: "p-009",
    category: "منطق",
    trapQuestion: "اگه من بهت بگم که همیشه دروغ می‌گم، الان راست می‌گم یا دروغ؟",
    correctReasoning: "پارادوکس دروغگو (Liar Paradox)! اگه بگم راست می‌گه، پس داره دروغ می‌گه (چون گفته همیشه دروغ می‌گه). اگه بگم دروغ می‌گه، یعنی واقعاً همیشه دروغ می‌گه، پس الان که می‌گه همیشه دروغ می‌گم، اینم دروغه! → پارادوکس",
    wrongAnswer: "راست می‌گی.",
    correctAnswer: "این پارادوکس دروغگو هست! یکی از معروف‌ترین پارادوکس‌های فلسفه.\n\nاگه بگم راست می‌گی، نقض حرفت (چون گفتی همیشه دروغ می‌گی)\nاگه بگم دروغ می‌گی، بازم نقض (چون الان دروغ گفتن یعنی حرفت درست بود)\n\nپس این سوال جواب درست و غلط نداره! 🌀",
    explanation: "پارادوکس کلاسیک. مدل باید بشناسدش و سعی نکنه جواب قطعی بده.",
    tags: ["منطق", "پارادوکس", "فلسفه", "بحرانی"],
    severity: 3,
  },
  {
    id: "p-010",
    category: "استنتاج",
    trapQuestion: "سعدی گفته 'توانا بود هر که دانا بود'. یعنی آدمای بی‌سواد نمی‌تونن کاری بکنن؟",
    correctReasoning: "تحریف عمدی شعر! سعدی می‌گه 'توانا بود هر که دانا بود' یعنی 'کسی که داناست تواناست'. این یه توصیفه، نه نفی بقیه. سعدی نمی‌گه 'فقط' داناها توانان. این منطقاً اشتباهه.",
    wrongAnswer: "بله، سعدی معتقده آدم بی‌سواد نمی‌تونه کاری بکنه.",
    correctAnswer: "نه داداش! این تحریف محضه. سعدی می‌گه «توانا بود هر که دانا بود» یعنی:\n«هر کی داناست، تواناست»\nنه اینکه «هر کی تواناست، داناست» یا «فقط داناها توانان».\n\nسعدی داره دانش رو تشویق می‌کنه، نه آدم‌های بی‌سواد رو نفی! این دو فرق داره.\n\nدر واقع منطقاً:\n• اصل: دانا → توانا (اگر دانا، پس توانا)\n• این نقیض: ندانا → نتوانا (اگر ندانا، پس نتوانا) ← این رو سعدی نگفته!\n\nپس سعدی دقیقاً برعکس برداشت تو می‌گه: دانش باعث توانایی می‌شه! 📚",
    explanation: "بسیاری از کاربران منطق شرطی رو برعکس می‌کنند. inversion of conditional یه دام رایجه.",
    tags: ["منطق", "سعدی", "تحریف", "بحرانی"],
    severity: 3,
  },
];

// ================================================================
// ۲. موتور تجزیه سوال (Question Decomposer)
// ================================================================

export interface SubQuestion {
  id: string;
  text: string;           // زیرسوال
  type: 'factual' | 'logical' | 'poetic' | 'ambiguous' | 'pitfall';
  dependencies: string[]; // وابسته به کدوم زیرسوال‌ها
  answer?: string;
  confidence: number;
}

export interface DecomposedQuestion {
  original: string;
  subQuestions: SubQuestion[];
  detectedPitfalls: Pitfall[];
  category: 'poetry' | 'logic' | 'conversation' | 'knowledge' | 'ambiguous';
  requiresStepByStep: boolean;
  riskLevel: 'safe' | 'caution' | 'danger';
}

/**
 * 🧠 تجزیه سوال به زیرسوال‌ها
 * سوال رو تیکه‌تیکه می‌کنه برای جواب دقیق
 */
export function decomposeQuestion(question: string): DecomposedQuestion {
  const subQuestions: SubQuestion[] = [];
  const detectedPitfalls: Pitfall[] = [];
  
  // ۱. تشخیص چاه‌ها (pitfalls) در سوال
  for (const pitfall of PITFALL_DATABASE) {
    // بررسی کلمات کلیدی چاه با سوال
    const pitfallKeywords = pitfall.trapQuestion.split(/[\s،,?؟]+/);
    const questionWords = question.split(/[\s،,?؟]+/);
    const matchCount = pitfallKeywords.filter(k => 
      question.includes(k.slice(0, Math.max(3, k.length - 2)))
    ).length;
    
    if (matchCount >= 2) {
      detectedPitfalls.push(pitfall);
    }
  }
  
  // ۲. تشخیص ابهام‌های عددی یا منطقی
  if (/(چند تا|چند|سه|دو|یک|عدد)/.test(question)) {
    subQuestions.push({
      id: 'sq-num-1',
      text: 'مسئله عددی نیاز به محاسبه قدم‌قدم دارد',
      type: 'logical',
      dependencies: [],
      confidence: 0.8,
    });
  }
  
  // ۳. تیکه‌تیکه کردن سوال بر اساس حروف ربط
  const parts = question.split(/[،,و.؟?]+/).filter(p => p.trim().length > 5);
  
  if (parts.length > 1) {
    parts.forEach((part, i) => {
      subQuestions.push({
        id: `sq-part-${i}`,
        text: part.trim(),
        type: part.includes('؟') || part.includes('?') ? 'ambiguous' : 'factual',
        dependencies: i > 0 ? [`sq-part-${i - 1}`] : [],
        confidence: 0.6,
      });
    });
  }
  
  // ۴. تشخیص نوع سوال
  let category: DecomposedQuestion['category'] = 'conversation';
  if (/(شعر|غزل|بیت|حافظ|سعدی|مولانا|فردوسی|خیام)/.test(question)) {
    category = 'poetry';
  } else if (/(چرا|چطور|چگونه|دلیل|منطق|پس)/.test(question)) {
    category = 'logic';
  } else if (/(کی|کجا|چیست|کیه|چی)/.test(question)) {
    category = 'knowledge';
  } else if (/(؟|\?|یعنی|منظور|میشه)/.test(question)) {
    category = 'ambiguous';
  }
  
  // سطح خطر
  let riskLevel: 'safe' | 'caution' | 'danger' = 'safe';
  if (detectedPitfalls.some(p => p.severity >= 3)) riskLevel = 'danger';
  else if (detectedPitfalls.length > 0) riskLevel = 'caution';
  
  return {
    original: question,
    subQuestions: subQuestions,
    detectedPitfalls,
    category,
    requiresStepByStep: subQuestions.length > 1 || detectedPitfalls.length > 0,
    riskLevel,
  };
}

/**
 * 🧠 تولید پاسخ قدم‌قدم (Step-by-Step)
 */
export function generateStepByStepResponse(
  question: string,
  decomposed: DecomposedQuestion,
  userName: string = 'دوست'
): string {
  let response = '';
  
  // هشدار امنیتی
  if (decomposed.riskLevel === 'danger') {
    response += `⚠️ **هشدار: سوال دام‌دار تشخیص داده شد!**\n`;
    response += `بعضی از این سوالات برای گول زدن من طراحی شدن، ولی نمی‌خورم! 😎\n\n`;
  } else if (decomposed.riskLevel === 'caution') {
    response += `🔍 **احتیاط: این سوال نیاز به دقت داره**\n\n`;
  }
  
  // اگر چاه تشخیص داده شده
  if (decomposed.detectedPitfalls.length > 0) {
    const mainPitfall = decomposed.detectedPitfalls[0];
    response += `🧠 **تشخیص دام:** "${mainPitfall.trapQuestion}"\n`;
    response += `📝 **روش درست:** ${mainPitfall.explanation}\n\n`;
  }
  
  // پاسخ قدم‌قدم
  if (decomposed.requiresStepByStep) {
    response += `📋 **${userName} جان، بزنیم قدم‌قدم:**\n\n`;
    
    if (decomposed.subQuestions.length > 0) {
      decomposed.subQuestions.forEach((sq, i) => {
        response += `**قدم ${i + 1}:** ${sq.text}\n`;
        response += `→ `;
      });
    }
    
    response += `\n`;
  }
  
  // اضافه کردن چاه‌های مشابه
  if (decomposed.detectedPitfalls.length > 1) {
    response += `\n📚 **چاه‌های مشابه که باید ازشون دوری کنم:**\n`;
    decomposed.detectedPitfalls.slice(1, 3).forEach(p => {
      response += `▸ ${p.trapQuestion}\n`;
    });
  }
  
  return response;
}

/**
 * 🧠 راهکار جواب دادن - متدولوژی کلی
 */
export function getReasoningMethodology(): string {
  return `
🧠 **متدولوژی جواب دادن مغز فارسی:**
═══════════════════════════════════════

📌 **اصل ۱: تجزیه سوال**
   • سوال رو تیکه‌تیکه کن
   • تشخیص بده زیرسوال‌ها چی هستن
   • ببین چاه (pitfall) داره یا نه

📌 **اصل ۲: تشخیص دام**
   • آیا سوال ابهام داره؟ (مثل "دستم بهش نمی‌رسه")
   • آیا پارادوکس هست؟ (مثل پارادوکس دروغگو)
   • آیا تحریف شعر هست؟ (مثل برعکس کردن "بنی آدم")
   • آیا inversion منطقی هست؟ ("توانا بود هر که دانا بود")

📌 **اصل ۳: قدم‌قدم جواب بده**
   • یک‌باره جواب نده
   • قدم‌قدم با کاربر جلو برو
   • هر مرحله رو توضیح بده

📌 **اصل ۴: شفاف‌سازی ابهام**
   • اگه سوال چندمعنایی داره، از کاربر بپرس
   • مثال: "دستم بهش نمی‌رسه" → منظورت فیزیکیه؟ مالیه؟ یا توانایی؟

📌 **اصل ۵: سند بیار**
   • برای ادعاهای شعری، بیت کامل رو بیار
   • نقل قول مستقیم کن
   • تفسیر شخصی رو از متن اصلی جدا کن
`.trim();
}

/**
 * 🧠 بررسی اینکه سوال تحریف شعر داره یا نه
 */
export function detectPoetryDistortion(question: string): {
  isDistorted: boolean;
  originalPoet?: string;
  originalVerse?: string;
  explanation?: string;
} {
  const distortionPatterns: Array<{
    pattern: RegExp;
    poet: string;
    originalVerse: string;
    explanation: string;
  }> = [
    {
      pattern: /بنی آدم.*یکدیگر.*نژاد/i,
      poet: 'سعدی',
      originalVerse: 'بنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند\nچو عضوی به درد آورد روزگار / دگر عضوها را نماند قرار',
      explanation: 'سعدی دقیقاً برعکس نژادپرستی می‌گه: همه به هم پیوسته‌ایم',
    },
    {
      pattern: /توانا بود.*دانا بود.*بی.?سواد/i,
      poet: 'سعدی/فردوسی',
      originalVerse: 'توانا بود هر که دانا بود / ز دانش دل پیر برنا بود',
      explanation: 'سعدی می‌گه دانش = توانایی. نمی‌گه بی‌دانش = ناتوان. این inversion منطقیه',
    },
    {
      pattern: /انکار شراب/i,
      poet: 'حافظ',
      originalVerse: 'من و انکار شراب این چه حکایت باشد / غالبا این قدرم عقل و کفایت باشد',
      explanation: 'این سوال انکاریه (rhetorical question). حافظ می‌گه "چطور شراب رو انکار کنم؟"',
    },
  ];
  
  for (const dp of distortionPatterns) {
    if (dp.pattern.test(question)) {
      return {
        isDistorted: true,
        originalPoet: dp.poet,
        originalVerse: dp.originalVerse,
        explanation: dp.explanation,
      };
    }
  }
  
  return { isDistorted: false };
}

/**
 * 🚀 API friendly: یک تابع برای کل پروسه
 */
export function reasonAndRespond(
  question: string,
  userName: string = 'دوست'
): {
  decomposition: DecomposedQuestion;
  stepByStepResponse: string;
  finalAdvice: string;
  detectedPitfalls: Pitfall[];
  distortionCheck: ReturnType<typeof detectPoetryDistortion>;
} {
  // ۱. تجزیه سوال
  const decomposition = decomposeQuestion(question);
  
  // ۲. بررسی تحریف شعر
  const distortionCheck = detectPoetryDistortion(question);
  if (distortionCheck.isDistorted) {
    decomposition.detectedPitfalls.unshift({
      id: 'distortion-auto',
      category: 'تحریف شعر',
      trapQuestion: question,
      correctReasoning: distortionCheck.explanation || '',
      wrongAnswer: 'قبول کردن برداشت غلط کاربر',
      correctAnswer: distortionCheck.originalVerse || '',
      explanation: distortionCheck.explanation || '',
      tags: ['تحریف', 'شعر'],
      severity: 3,
    });
    decomposition.riskLevel = 'danger';
  }
  
  // ۳. تولید پاسخ قدم‌قدم
  const stepByStepResponse = generateStepByStepResponse(question, decomposition, userName);
  
  // ۴. توصیه نهایی
  let finalAdvice = '';
  if (decomposition.riskLevel === 'danger') {
    finalAdvice = '⚠️ این سوال رو با دقت جواب بده! ممکنه دام داشته باشه.';
  } else if (decomposition.requiresStepByStep) {
    finalAdvice = '📋 قدم‌قدم جواب بده تا کاربر متوجه بشه.';
  } else {
    finalAdvice = '💬 جواب روان و محاوره‌ای بده.';
  }
  
  return {
    decomposition,
    stepByStepResponse,
    finalAdvice,
    detectedPitfalls: decomposition.detectedPitfalls,
    distortionCheck,
  };
}
