/**
 * 🎭 تشخیص حالت پاسخ - Response Mode Classifier
 * 
 * "میترسم جواب درخواست‌ها را با جوک بگه یا شعر"
 * 
 * ===== سه حالت اصلی =====
 * 
 * 🎯 SERIOUS: سوال علمی، منطقی، درخواست کمک، اطلاعات دقیق
 *    → پاسخ: دقیق، مستند، بدون شعر و جوک
 * 
 * 🌸 POETIC: درخواست شعر، ادبیات، هنر
 *    → پاسخ: شعر، داستان، محاوره روان
 * 
 * 💬 CHAT: احوال‌پرسی، محاوره روزمره، گپ دوستانه
 *    → پاسخ: صمیمی، محاوره‌ای، می‌تونه شعر هم داشته باشه
 */

export type ResponseMode = 'serious' | 'poetic' | 'chat' | 'ambiguous';

export interface ModeDecision {
  mode: ResponseMode;
  confidence: number;
  reason: string;
  disallowPoetry: boolean;     // اگه true باشه، شعر ممنوع!
  disallowJokes: boolean;      // اگه true باشه، جوک ممنوع!
  strictness: 'strict' | 'moderate' | 'relaxed';
}

/**
 * کلمات و الگوهای ممنوعه برای حالت جدی
 */
const SERIOUS_KEYWORDS = [
  // علمی و فنی
  'چطور کار می‌کنه', 'راهنمایی', 'آموزش', 'رفع اشکال',
  'خطا', 'error', 'bug', 'راه حل', 'help', 'کمک',
  'مشکل', 'issue', 'نصب', 'نحوه', 'آموزش',
  'مدارک', 'مدرک', 'سند', 'evidence', 'proof',
  'دلیل', 'منطق', 'منطقی', 'برهان',
  'قانون', 'rule', 'regulation', 'باید',
  'تحلیل', 'analysis', 'report',
  
  // پزشکی و سلامت
  'درد', 'بیماری', 'درمان', 'دارو', 'doctor',
  'بیمارستان', 'علائم', 'symptom',
  
  // حقوقی
  'قانونی', 'حقوقی', 'وکیل', 'دادگاه', 'legal',
  'حکم', 'قضایی',
  
  // مالی
  'قیمت', 'پول', 'خرید', 'فروش', 'سود', 'ضرر',
  'سرمایه', 'بورس', 'economy',
  
  // فوری
  'اضطراری', 'emergency', 'فوری', 'اهمیت دارد',
  'مهم', 'حیاتی', 'vital',
];

const POETIC_KEYWORDS = [
  'شعر', 'غزل', 'بیت', 'مصراع', 'حافظ', 'سعدی',
  'مولانا', 'فردوسی', 'خیام', 'عطار', 'رباعی',
  'قصیده', 'مثنوی', 'داستان', 'قصه', 'حکایت',
  'تمثیل', 'ادبیات', 'شاعر', 'نظم', 'نثر',
  
  // درخواست شعر
  'بگو', 'بخون', 'بنویس', 'یک شعر', 'بیتی',
  'برایم', 'برام', 'در وصف',
  
  // موضوعات شعری
  'عشق', 'دل', 'یار', 'گل', 'بلبل', 'بهار',
  'غم', 'فراق', 'وصال', 'هجران',
];

/**
 * 🧠 تشخیص حالت پاسخ بر اساس ورودی کاربر
 */
export function classifyMode(input: string): ModeDecision {
  const lower = input.toLowerCase();
  
  // امتیازدهی
  let seriousScore = 0;
  let poeticScore = 0;
  let chatScore = 0;
  
  // ۱. بررسی کلمات کلیدی جدی
  for (const kw of SERIOUS_KEYWORDS) {
    if (lower.includes(kw)) {
      seriousScore += 2;
    }
  }
  
  // ۲. بررسی کلمات کلیدی شعری
  for (const kw of POETIC_KEYWORDS) {
    if (lower.includes(kw)) {
      poeticScore += 2;
    }
  }
  
  // ۳. الگوهای محاوره‌ای
  if (/(سلام|چطوری|خوبی|چه خبر|داداش|مرسی|ممنون)/i.test(lower)) chatScore += 2;
  if (/(خوبم|خسته|عالی|دمت گرم|قربان)/i.test(lower)) chatScore += 1;
  
  // ۴. الگوهای سوال جدی
  if (/^(چرا|چطور|چگونه|آیا|چه|کی|کجا)/.test(lower.trim())) seriousScore += 1.5;
  if (/\?$/.test(lower.trim())) seriousScore += 0.5;
  
  // ۵. الگوهای احساسی (می‌تونن شعر باشن)
  if (/(دلم گرفته|غمگین|ناراحت|تنهام|دلتنگ)/i.test(lower)) poeticScore += 1.5;

  // ۶. تشخیص سوالات ترکیبی (شعر + سوال)
  const hasPoetryAndQuestion = poeticScore > 0 && (seriousScore > 0 || /\?/.test(lower));
  
  // تصمیم‌گیری
  let mode: ResponseMode;
  let reason: string;
  let disallowPoetry = false;
  let disallowJokes = false;
  let strictness: 'strict' | 'moderate' | 'relaxed' = 'moderate';
  
  if (seriousScore >= poeticScore && seriousScore >= chatScore && seriousScore >= 2) {
    mode = 'serious';
    reason = 'حالت جدی: سوال حاوی کلمات تخصصی/فنی/علمی است';
    disallowPoetry = true;
    disallowJokes = true;
    strictness = 'strict';
  } else if (poeticScore >= seriousScore && poeticScore >= chatScore && poeticScore >= 2) {
    mode = 'poetic';
    reason = 'حالت شعری: درخواست شعر یا موضوع ادبی';
    disallowPoetry = false;
    disallowJokes = false;
    strictness = 'relaxed';
  } else if (chatScore > 0) {
    mode = 'chat';
    reason = 'حالت گفتگو: محاوره روزمره';
    disallowPoetry = false;
    disallowJokes = false;
    strictness = 'relaxed';
  } else {
    // تشخیص مبهم
    if (hasPoetryAndQuestion) {
      mode = 'ambiguous';
      reason = 'ترکیبی: سوال + شعر. لطفاً شفاف کن';
      disallowPoetry = false;
      disallowJokes = true;
      strictness = 'moderate';
    } else {
      mode = 'chat';
      reason = 'پیش‌فرض: حالت گفتگو';
      disallowPoetry = false;
      disallowJokes = false;
      strictness = 'relaxed';
    }
  }
  
  // اطمینان
  const maxScore = Math.max(seriousScore, poeticScore, chatScore, 1);
  const confidence = Math.min(0.95, maxScore / (Math.max(seriousScore + poeticScore + chatScore, 1)) + 0.3);
  
  return {
    mode,
    confidence: parseFloat(confidence.toFixed(2)),
    reason,
    disallowPoetry,
    disallowJokes,
    strictness,
  };
}

/**
 * 🧠 تگ‌کننده پاسخ بر اساس حالت
 */
export function tagResponse(response: string, mode: ModeDecision): {
  tagged: string;
  warnings: string[];
  allowed: boolean;
} {
  const warnings: string[] = [];
  
  // بررسی وجود شعر در پاسخ (حالت جدی)
  if (mode.disallowPoetry) {
    const hasVerse = response.includes('/') && response.length > 20;
    if (hasVerse) {
      warnings.push('⚠️ هشدار: پاسخ حاوی شعر است در حالت جدی!');
    }
  }
  
  // بررسی وجود جوک
  if (mode.disallowJokes) {
    const jokeIndicators = ['😂', '😆', '🤣', 'خنده', 'جوک', 'joke', 'lol'];
    const hasJoke = jokeIndicators.some(j => response.includes(j));
    if (hasJoke) {
      warnings.push('⚠️ هشدار: پاسخ حاوی جوک/طنز است در حالت جدی!');
    }
  }
  
  return {
    tagged: `[${mode.mode.toUpperCase()}] ${response}`,
    warnings,
    allowed: warnings.length === 0 || mode.strictness !== 'strict',
  };
}

/**
 * پرامپت سیستمی برای مدل بر اساس حالت
 */
export function getModeSystemPrompt(mode: ResponseMode): string {
  const prompts: Record<ResponseMode, string> = {
    serious: `شما در حالت **جدی** هستید.
    
قوانین:
❌ از شعر و بیت استفاده نکن
❌ از جوک و طنز استفاده نکن
❌ از تمثیل و تشبیه ادبی استفاده نکن
✅ مستقیم و دقیق جواب بده
✅ قدم‌قدم و منطقی توضیح بده
✅ اگر نمی‌دانی، بگو نمی‌دانم

سبک: رسمی، دقیق، مستند`,

    poetic: `شما در حالت **شعری و ادبی** هستید.

قوانین:
✅ با شعر و داستان جواب بده
✅ از تمثیل و تشبیه استفاده کن
✅ از بیت و مصراع استفاده کن
✅ می‌تونی از حافظ، سعدی، مولانا نقل قول کنی
✅ محاوره روان و صمیمی باش

سبک: ادبی، هنری، احساسی`,

    chat: `شما در حالت **گفتگو** هستید.

قوانین:
✅ صمیمی و محاوره‌ای باش
✅ می‌تونی از شعر هم استفاده کنی
✅ از اصطلاحات عامیانه استفاده کن
✅ گرم و دوستانه رفتار کن
✅ می‌تونی شوخ‌طبع باشی

سبک: صمیمی، محاوره‌ای، روان`,

    ambiguous: `شما در حالت **مبهم** هستید.

کاربر هم سوال پرسیده هم درخواست شعر داره.
ازش بخواه شفاف کنه که دقیقاً چی می‌خواد.
می‌تونی هر دو رو با هم ترکیب کنی.

سبک: محترمانه، شفاف‌ساز`,
  };
  
  return prompts[mode];
}
