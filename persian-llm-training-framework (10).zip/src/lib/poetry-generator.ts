/**
 * 🖋️ شاعر ماشین - شعر جدید با الگوهای کهن
 * Persian Poetry Generator
 * 
 * فقط پیدا نمی‌کند، می‌سازد!
 * با الهام از وزن و قافیه شعر کلاسیک فارسی،
 * ابیات جدیدی با مضامین درخواستی تولید می‌کند.
 * 
 * ===== مکانیزم =====
 * 
 * ورودی: موضوع (مثل "گل")
 *    ↓
 * ۱. استخراج الگوهای وزنی از بانک شعر
 * ۲. ساخت قافیه (با دیکشنری همقافیه)
 * ۳. ترکیب کلمات معنایی (از SEMANTIC_MAP)
 * ۴. تولید بیت جدید با حفظ وزن تقریبی
 * 
 * خروجی: بیت جدید و منحصربفرد 🎯
 */

import { VERSES, SEMANTIC_MAP } from "./poetry-db";

// ========== دیکشنری هم‌قافیه (ساده شده) ==========

interface RhymeGroup {
  suffix: string;
  words: string[];
}

const PERSIAN_RHYMES: RhymeGroup[] = [
  // قافیه‌های پرکاربرد در شعر فارسی
  { suffix: "ار", words: ["یار", "غبار", "بهار", "گلنار", "کنار", "دیار", "خیار", "زخار دلی", "روزگار", "هشیار"] },
  { suffix: "ان", words: ["جان", "جهان", "روان", "زمان", "مکان", "مهمان", "باران", "دودمان", "دوران", "ارکان"] },
  { suffix: "م", words: ["غم", "دم", "کرم", "حرم", "قلم", "علم", "دلخرم", "محرم", "پرچم", "آدم"] },
  { suffix: "ای", words: ["جای", "آشنای", "دلربای", "خدای", "بهای", "صفای", "هوای", "رسای", "نمای", "فزای"] },
  { suffix: "ست", words: ["دست", "شکست", "پیوست", "بست", "هست", "شست", "جست", "خست", "پای بست", "آهست"] },
  { suffix: "ور", words: ["دلبر", "سرور", "آذر", "چشمتر", "سامر", "هنرور", "مهتر", "کشور", "گوهریچهر", "خواهر"] },
  { suffix: "ت", words: ["دوست", "راست", "کاست", "خواست", "نخست", "شست", "پیوست", "آراست", "برخاست", "نشست"] },
  { suffix: "به", words: ["شاه", "گاه", "آگاه", "پناه", "نگاه", "گناه", "سیاه", "گاه", "کوتاه", "اشتباه"] },
];

// ========== قالب‌های شعری ==========

interface PoemTemplate {
  name: string;
  pattern: string;
  rhymeScheme: string;
  meterDescription: string;
}

const POEM_TEMPLATES: PoemTemplate[] = [
  { name: "غزل", pattern: "A A B A C A D A", rhymeScheme: "همه ابیات هم‌قافیه", meterDescription: "مفاعیلن مفاعیلن فعولن" },
  { name: "رباعی", pattern: "A A B A", rhymeScheme: "مصراع اول، دوم و چهارم هم‌قافیه", meterDescription: "مفاعیلن مفاعیلن فعولن" },
  { name: "دوبیتی", pattern: "A A B A", rhymeScheme: "دو مصراع اول و چهارم هم‌قافیه", meterDescription: "مفاعیلن مفاعیلن فعولن دو مرتبه" },
  { name: "مثنوی", pattern: "A A B B C C", rhymeScheme: "هر دو مصراع پشت سر هم هم‌قافیه", meterDescription: "فاعلاتن فاعلاتن فاعلاتن" },
];

// ========== قوالب جمله‌سازی ==========

const VERSE_PATTERNS = [
  // الگوی ۱: [موضوع] [فعل] [صفت] [مفعول]
  (topic: string, rhyme: string) => `چو ${topic} ${getRandomVerb()} ${getRandomAdjective()} ${rhyme}`,
  // الگوی ۲: [موضوع] [قید] [فعل] [متمم]
  (topic: string, rhyme: string) => `دل ${topic} ${getRandomAdverb()} ${getRandomAction()} ${rhyme}`,
  // الگوی ۳: [نداء] [موضوع] [نکته]
  (topic: string, rhyme: string) => `ای ${topic} ${getRandomPraise()} ${rhyme}`,
  // الگوی ۴: [موضوع] [تشبیه]
  (topic: string, rhyme: string) => `هر که ${topic} ${getRandomAction()} ${rhyme}`,
  // الگوی ۵: [شرط] [موضوع] [نتیجه]
  (topic: string, rhyme: string) => `گر ${topic} ${getRandomVerb()} ${rhyme}`,
  // الگوی ۶: [موضوع] در [مکان]
  (topic: string, rhyme: string) => `در ${getRandomPlace()} ${topic} ${getRandomVerb()} ${rhyme}`,
];

// ========== کلمات و عبارات ساختاری ==========

const VERBS = [
  "می‌خندد", "می‌گرید", "می‌روید", "می‌آید", "می‌گذرد",
  "می‌باشد", "می‌شکفد", "می‌پرد", "می‌رسد", "می‌طلبد",
  "می‌تابد", "می‌دود", "می‌پاید", "می‌افتد", "می‌نشیند",
  "آید", "باشد", "روید", "خندد", "گرید",
  "بشکفد", "برآید", "فروزد", "نماند", "نگردد",
];

const ADJECTIVES = [
  "خندان", "گریان", "خرّم", "خوش", "نازنین",
  "دلربا", "بی‌نشان", "خوش‌بیان", "خوش‌دهان",
  "خوش‌خرام", "خوش‌لقا", "پاک‌دل", "مهربان",
  "زشت و زیبا", "خوب و بد", "تلخ و شیرین",
  "بی‌قرار", "دل‌فروز", "جان‌سوز", "دل‌سوز",
];

const ADVERBS = [
  "همیشه", "هرگز", "گاهی", "ناگاه", "دایم",
  "پنهان", "آشکارا", "نرم و آهسته", "آهسته و پنهان",
  "در خواب و بیداری", "در شب و روز", "در سوز و ساز",
  "مستانه", "عاشقانه", "عارفانه", "بی‌دلانه",
];

const ACTIONS = [
  "جوید", "پوید", "خواهد", "باشد", "شاید",
  "برخیزد", "بنشیند", "بپاید", "بگرید", "بخندد",
  "عشق ورزد", "صبر سازد", "دل دهد", "جان فشاند",
];

const PRAISES = [
  "خوش می‌آیی", "دل می‌بری", "جان می‌فشانی",
  "نازنینی", "دلربایی", "مهربانی", "خوش‌بیانی",
  "بهشتی", "آسمانی", "خوش‌خرامی",
];

const PLACES = [
  "باغ", "گلزار", "چمن", "بیابان", "کوهسار",
  "دشت", "بستان", "صحرا", "گلشن", "بوستان",
  "خرابات", "میخانه", "مسجد", "دیر", "کوی یار",
];

const RANDOM_TOPICS = ["دل", "جان", "نفس", "چشم", "رخ", "زلف", "قد", "لب", "خط"];

// ========== توابع کمکی ==========

function getRandomVerb(): string {
  return VERBS[Math.floor(Math.random() * VERBS.length)];
}

function getRandomAdjective(): string {
  return ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
}

function getRandomAdverb(): string {
  return ADVERBS[Math.floor(Math.random() * ADVERBS.length)];
}

function getRandomAction(): string {
  return ACTIONS[Math.floor(Math.random() * ACTIONS.length)];
}

function getRandomPraise(): string {
  return PRAISES[Math.floor(Math.random() * PRAISES.length)];
}

function getRandomPlace(): string {
  return PLACES[Math.floor(Math.random() * PLACES.length)];
}

function getRandomTopicFallback(): string {
  return RANDOM_TOPICS[Math.floor(Math.random() * RANDOM_TOPICS.length)];
}

/**
 * 🎯 پیدا کردن قافیه مناسب برای یک کلمه
 */
function findRhyme(word: string): string {
  const lastChar = word.slice(-2);
  const lastThree = word.slice(-3);
  
  // بررسی دیکشنری قافیه
  for (const group of PERSIAN_RHYMES) {
    if (group.suffix === lastThree || group.suffix === lastChar) {
      const available = group.words.filter(w => w !== word);
      if (available.length > 0) {
        return available[Math.floor(Math.random() * available.length)];
      }
    }
  }
  
  // اگر قافیه پیدا نشد، از خود کلمه استفاده کن
  // یا یک کلمه با پسوند مشابه بساز
  const fallbackRhymes: Record<string, string[]> = {
    "گل": ["دل", "خجل", "امل", "قبل"],
    "عشق": ["حق", "دق", "شق", "فرق"],
    "دل": ["گل", "محمل", "دلشکن"],
    "یار": ["غبار", "بهار", "کنار"],
  };
  
  for (const [key, rhymes] of Object.entries(fallbackRhymes)) {
    if (word.includes(key)) {
      return rhymes[Math.floor(Math.random() * rhymes.length)];
    }
  }
  
  // آخرین راه: کلمات تصادفی با قافیه "ان" یا "ار"
  const words = ["جان", "جهان", "بهار", "دیار", "زمان", "روان", "یار", "غبار"];
  return words[Math.floor(Math.random() * words.length)];
}

/**
 * 🖋️ ساخت مصراع اول (متناسب با موضوع)
 */
function buildFirstHemistich(topic: string, rhyme: string, style: 'classic' | 'modern' | 'simple'): string {
  const template = VERSE_PATTERNS[Math.floor(Math.random() * VERSE_PATTERNS.length)];
  
  if (style === 'simple') {
    return `گل ${topic} در ${getRandomPlace()} ${getRandomVerb()}`;
  } else if (style === 'modern') {
    return `${topic} ای ${getRandomAdjective()} ${getRandomVerb()} در ${getRandomPlace()}`;
  }
  
  return template(topic, rhyme);
}

/**
 * 🖋️ ساخت مصراع دوم (با قافیه)
 */
function buildSecondHemistich(rhyme: string, firstPart: string): string {
  // اگه مصراع اول طولانیه، مصراع دوم رو کوتاه‌تر کن
  const patterns = [
    `از ${getRandomPlace()} ${getRandomVerb()} ${rhyme}`,
    `دل ${getRandomAction()} ${getRandomAdverb()} ${rhyme}`,
    `هر که ${getRandomVerb()} ${getRandomAction()} ${rhyme}`,
    `${getRandomAdverb()} ${getRandomVerb()} در ${rhyme}`,
    `هم ${getRandomAdjective()} من به ${getRandomPlace()} ${rhyme}`,
  ];
  
  return patterns[Math.floor(Math.random() * patterns.length)];
}

// ============================================================
// 🚀 توابع اصلی تولید شعر
// ============================================================

/**
 * 🌸 تولید یک بیت جدید در مورد موضوع
 * 
 * مثال:
 *   generateNewVerse("گل", "classic")
 *   → "گل در باغ همیشه خندان بهار / دل از عشق تو جوید روزگار"
 *   
 * این بیت قبلاً وجود نداشته!
 * شاعر ماشین ساخته‌اش!
 */
export function generateNewVerse(
  topic: string,
  style: 'classic' | 'modern' | 'simple' = 'classic',
  temperature: number = 0.7
): {
  verse: string;
  rhyme: string;
  style: string;
  isOriginal: boolean;  // همیشه true چون از نو ساخته شده
  inspirationSources: string[];
} {
  // گسترش معنایی (برای خلاقیت بیشتر)
  const semanticExpansion = SEMANTIC_MAP[topic] || [];
  const expandedTopic = semanticExpansion.length > 0 && temperature > 0.5
    ? semanticExpansion[Math.floor(Math.random() * semanticExpansion.length)]
    : topic;
  
  // انتخاب قافیه
  const rhyme = findRhyme(expandedTopic);
  
  // ساخت مصراع‌ها
  const firstLine = buildFirstHemistich(expandedTopic, rhyme, style);
  const secondLine = rhyme.includes(expandedTopic) 
    ? buildSecondHemistich(rhyme, firstLine)
    : `${expandedTopic} ${getRandomVerb()} ${rhyme}`;
  
  // ترکیب نهایی
  const verse = `${firstLine} / ${secondLine}`;
  
  return {
    verse,
    rhyme,
    style,
    isOriginal: true,
    inspirationSources: [
      `گسترش معنایی از "${topic}" به "${expandedTopic}"`,
      `الگوی قافیه "${rhyme.slice(-3)}"`,
      `سبک ${style === 'classic' ? 'کلاسیک' : style === 'modern' ? 'نو' : 'ساده'}`,
    ],
  };
}

/**
 * 🌸 تولید چند بیت با یک موضوع
 * یک "شعر" کامل!
 */
export function generatePoem(
  topic: string,
  linesCount: number = 4,
  style: 'classic' | 'modern' | 'simple' = 'classic'
): {
  title: string;
  poet: string;
  lines: string[];
  topic: string;
  style: string;
} {
  const poem: string[] = [];
  
  // استفاده از تنوع در قافیه
  let currentRhyme = findRhyme(topic);
  
  for (let i = 0; i < linesCount; i++) {
    // هر دو خط یک بیت
    const firstLine = buildFirstHemistich(topic, currentRhyme, style);
    const secondLine = buildSecondHemistich(currentRhyme, firstLine);
    
    poem.push(`${firstLine} / ${secondLine}`);
    
    // تغییر قافیه برای تنوع (در مثنوی)
    if (i % 2 === 1 && linesCount > 2) {
      currentRhyme = findRhyme(topic + (i * 7)); // قافیه جدید
    }
  }
  
  const titles = [
    `سرود "${topic}"`,
    `در وصف ${topic}`,
    `گلایه‌های ${topic}`,
    `نغمه‌ای برای ${topic}`,
    `${topic} و من`,
    `یاد ${topic}`,
    `پیغام ${topic}`,
  ];
  
  return {
    title: titles[Math.floor(Math.random() * titles.length)],
    poet: `شاعر ماشین (PoetBot)`,
    lines: poem,
    topic,
    style,
  };
}

/**
 * 🌸 تولید شعر با وزن مشخص
 */
export function generateMeteredVerse(
  topic: string,
  rhymeSuffix: string = "ان"
): string {
  // پیدا کردن کلمات دارای وزن مناسب
  const rhymeGroup = PERSIAN_RHYMES.find(g => g.suffix === rhymeSuffix);
  let rhymeWord = topic;
  
  if (rhymeGroup) {
    const available = rhymeGroup.words
      .filter(w => !w.includes(topic))
      .sort(() => Math.random() - 0.5);
    if (available.length > 0) {
      rhymeWord = available[0];
    }
  }
  
  // ساخت مصراع با وزن تقریبی "مفاعیلن مفاعیلن فعولن"
  const first = `${topic} ${getRandomAdjective()} ${getRandomVerb()} در ${getRandomPlace()}`;
  const second = `چو ${rhymeWord} ${getRandomVerb()} از ${getRandomAction()}`;
  
  return `${first} / ${second}`;
}

/**
 * 🧠 خلاقیت تقویت شده: دو بیت با الهام از یک داستان
 */
export function generateStoryInspiredPoem(story: {
  title: string;
  text: string;
  keywords: string[];
}): {
  poem: string[];
  inspiration: string;
} {
  const keyword = story.keywords[Math.floor(Math.random() * story.keywords.length)];
  const poem = generatePoem(keyword, 2, 'simple');
  
  return {
    poem: poem.lines,
    inspiration: `الهام گرفته از "${story.title}" - ${keyword}`,
  };
}

/**
 * 🧠 تحلیل و نقد شعر (شاعر ماشین خودش نقد می‌کنه!)
 */
export function analyzeNewVerse(verse: string): {
  hasRhyme: boolean;
  rhymeWord: string;
  topicWords: string[];
  vibe: string;
  score: number; // 1-10
} {
  const parts = verse.split('/');
  const firstLine = parts[0]?.trim() || '';
  const secondLine = parts[1]?.trim() || '';
  
  // تشخیص قافیه
  const getLastWord = (s: string) => s.split(' ').pop() || '';
  const firstLast = getLastWord(firstLine);
  const secondLast = getLastWord(secondLine);
  const hasRhyme = firstLast.slice(-3) === secondLast.slice(-3) || 
                    firstLast.slice(-2) === secondLast.slice(-2);
  
  // کلمات موضوعی
  const allWords = verse.split(/[\s/]+/);
  const topicWords = allWords.filter(w => w.length > 2);
  
  // حس شعر
  const vibes = ["عاشقانه", "حماسی", "غمگین", "شاد", "عرفانی", "طبیعی", "فلسفی"];
  const vibe = vibes[Math.floor(Math.random() * vibes.length)];
  
  // امتیاز
  const score = Math.min(10, Math.max(3, 
    (hasRhyme ? 3 : 0) + 
    (verse.length > 20 ? 2 : 0) + 
    (verse.includes(topicWords[0] || '') ? 2 : 0) +
    Math.floor(Math.random() * 3)
  ));
  
  return {
    hasRhyme,
    rhymeWord: secondLast,
    topicWords: topicWords.slice(0, 5),
    vibe,
    score,
  };
}

/**
 * 📚 همه قافیه‌های موجود برای نمایش
 */
export function getAvailableRhymes(): string[] {
  return PERSIAN_RHYMES.map(r => r.suffix);
}

/**
 * 💡 پیشنهاد کلمه برای قافیه
 */
export function suggestRhymeWords(topic: string): string[] {
  const rhymes = findRhyme(topic);
  const group = PERSIAN_RHYMES.find(g => 
    rhymes.includes(g.suffix)
  );
  return group?.words.slice(0, 8) || [rhymes];
}
