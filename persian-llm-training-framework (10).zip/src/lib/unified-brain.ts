/**
 * 🧠 مغز واحد فارسی - Unified Persian Brain v3.0
 * 
 * ========== سه قابلیت اصلی در یک مغز ==========
 * 
 * ۱. تزریقی (RAG): جستجوی اشعار از بانک + لینک‌های تزریق شده
 * ۲. تقطیری (Neural): تولید شعر با مدل آموزش دیده از HF
 * ۳. تجربه‌آموز (Experience): ذخیره تجارب و تبدیل به دیتاست آموزش
 * 
 * ========== معماری تصمیم‌گیری ==========
 * 
 * ورودی کاربر
 *    ↓
 * ┌──────────────────────────────┐
 * │  موتور تصمیم‌گیر (Router)     │
 * │  • تشخیص نوع درخواست          │
 * │  • بررسی دانش موجود           │
 * │  • انتخاب بهترین استراتژی     │
 * └──────────────────────────────┘
 *    ↓
 * ┌─────────┬──────────┬──────────┐
 * │ تزریقی  │ تقطیری   │ تجربه    │
 * │ (RAG)   │ (Neural) │ (Learn)  │
 * └─────────┴──────────┴──────────┘
 *    ↓
 * ┌──────────────────────────────┐
 * │  پاسخ ترکیبی + ذخیره تجربه   │
 * └──────────────────────────────┘
 */

import { searchVerses, VERSES, type Verse } from "./poetry-db";
import { analyzeIntent, generateColloquialResponse, normalizeColloquial } from "./colloquial-persian";
import { loadProfile, saveProfile, updateProfile, type UserProfile } from "./user-profile";
import { detectArchitectSignature, detectUserRole, generateAuthenticationResponse, logCrossInstanceInteraction, MASTER_SIGNATURE, MODEL_LINEAGE } from "./deep-signature";

// ========== ۱. لینک تزریقی (Link Injection) ==========

export interface InjectedSource {
  id: string;
  title: string;
  url: string;
  content: string;       // متن استخراج شده
  verses: string[];       // ابیات استخراج شده
  poet?: string;
  type: 'poem' | 'article' | 'story' | 'link' | 'custom';
  injectedAt: number;
  tags: string[];
  source: 'manual' | 'url' | 'api' | 'file';
}

const STORAGE_KEY_INJECTED = 'persian-brain-injected-sources';

/**
 * تزریق محتوای یک لینک به مغز
 * از URL محتوا رو می‌گیره، تحلیل می‌کنه و به بانک اضافه می‌کنه
 */
export async function injectLink(url: string, options: {
  poet?: string;
  tags?: string[];
  title?: string;
} = {}): Promise<InjectedSource> {
  const id = `injected-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  
  // ۱. دریافت محتوای لینک
  let content = '';
  let title = options.title || url;
  
  try {
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; PersianBrain/1.0)',
        'Accept': 'text/html,text/plain,application/json,*/*',
      },
      signal: AbortSignal.timeout(10000),
    });
    
    if (response.ok) {
      const contentType = response.headers.get('content-type') || '';
      const rawText = await response.text();
      
      if (contentType.includes('application/json')) {
        // JSON → استخراج text fields
        try {
          const json = JSON.parse(rawText);
          content = extractTextFromJSON(json);
        } catch {}
      } else if (contentType.includes('text/plain')) {
        content = rawText;
      } else {
        // HTML → استخراج متن
        content = extractTextFromHTML(rawText);
        
        // استخراج title از HTML
        const titleMatch = rawText.match(/<title[^>]*>([^<]+)<\/title>/i);
        if (titleMatch && !options.title) {
          title = titleMatch[1].trim();
        }
      }
    }
  } catch (e) {
    console.warn(`⚠️ خطا در دریافت ${url}:`, e);
    content = `[⚠️ محتوای لینک قابل دریافت نبود: ${e}]`;
  }

  // ۲. استخراج ابیات از متن (الگوی شعر فارسی)
  const verses = extractVerses(content);
  
  // ۳. ذخیره در localStorage
  const source: InjectedSource = {
    id,
    title,
    url,
    content: content.slice(0, 5000), // حداکثر ۵۰۰۰ کاراکتر
    verses,
    poet: options.poet || extractPoet(content),
    type: detectContentType(content, url),
    injectedAt: Date.now(),
    tags: options.tags || extractTags(content),
    source: 'url',
  };
  
  // ذخیره
  const allSources = getInjectedSources();
  allSources.unshift(source);
  if (allSources.length > 50) allSources.length = 50; // حداکثر ۵۰ منبع
  saveInjectedSources(allSources);
  
  return source;
}

/**
 * تزریق مستقیم متن به مغز
 */
export function injectText(text: string, options: {
  title?: string;
  poet?: string;
  tags?: string[];
  type?: InjectedSource['type'];
} = {}): InjectedSource {
  const id = `injected-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const verses = extractVerses(text);
  
  const source: InjectedSource = {
    id,
    title: options.title || 'متن دستی',
    url: '',
    content: text.slice(0, 5000),
    verses,
    poet: options.poet || extractPoet(text),
    type: options.type || detectContentType(text, ''),
    injectedAt: Date.now(),
    tags: options.tags || extractTags(text),
    source: 'manual',
  };
  
  const allSources = getInjectedSources();
  allSources.unshift(source);
  if (allSources.length > 50) allSources.length = 50;
  saveInjectedSources(allSources);
  
  return source;
}

/**
 * جستجو در منابع تزریق شده
 */
export function searchInjectedSources(query: string): InjectedSource[] {
  const sources = getInjectedSources();
  const q = query.toLowerCase();
  
  return sources.filter(s => {
    const inContent = s.content.toLowerCase().includes(q);
    const inTitle = s.title.toLowerCase().includes(q);
    const inTags = s.tags.some(t => t.includes(q));
    const inVerses = s.verses.some(v => v.toLowerCase().includes(q));
    return inContent || inTitle || inTags || inVerses;
  });
}

function getInjectedSources(): InjectedSource[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY_INJECTED) || '[]');
  } catch { return []; }
}

function saveInjectedSources(sources: InjectedSource[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_INJECTED, JSON.stringify(sources));
  } catch {}
}

// ========== ۲. جمع‌آوری تجربه (Experience Collector) ==========

export interface Experience {
  id: string;
  prompt: string;
  response: string;
  versesUsed: string[];
  poet: string;
  topics: string[];
  emotion: string | null;
  rating: number; // 1-5 (از بازخورد کاربر)
  timestamp: number;
  usedForTraining: boolean;
}

const STORAGE_KEY_EXPERIENCES = 'persian-brain-experiences';

/**
 * ذخیره یک تجربه جدید از تعامل کاربر
 */
export function saveExperience(input: {
  prompt: string;
  response: string;
  verses: string[];
  poet?: string;
  topics: string[];
  emotion?: string | null;
}): Experience {
  const exp: Experience = {
    id: `exp-${Date.now()}-${Math.random().toString(36).slice(2, 4)}`,
    prompt: input.prompt,
    response: input.response,
    versesUsed: input.verses,
    poet: input.poet || '',
    topics: input.topics,
    emotion: input.emotion || null,
    rating: 0,
    timestamp: Date.now(),
    usedForTraining: false,
  };
  
  const experiences = getExperiences();
  experiences.unshift(exp);
  if (experiences.length > 200) experiences.length = 200;
  saveExperiencesList(experiences);
  
  return exp;
}

/**
 * ثبت بازخورد کاربر روی یک تجربه
 */
export function rateExperience(id: string, rating: number): void {
  const experiences = getExperiences();
  const exp = experiences.find(e => e.id === id);
  if (exp) {
    exp.rating = rating;
    saveExperiencesList(experiences);
  }
}

/**
 * تولید دیتاست آموزشی از تجارب جمع‌آوری شده
 * این دیتاست برای فاین‌تیون کردن مدل تقطیری استفاده می‌شه
 */
export function generateTrainingDataset(options: {
  minRating?: number;
  maxSamples?: number;
  includeTopics?: string[];
  format?: 'json' | 'text' | 'hf-dataset';
} = {}): string {
  const {
    minRating = 3,
    maxSamples = 100,
    includeTopics = [],
    format = 'json',
  } = options;
  
  let experiences = getExperiences();
  
  // فیلتر بر اساس امتیاز
  experiences = experiences.filter(e => e.rating >= minRating);
  
  // فیلتر بر اساس موضوع
  if (includeTopics.length > 0) {
    experiences = experiences.filter(e =>
      e.topics.some(t => includeTopics.includes(t))
    );
  }
  
  // محدودیت تعداد
  if (experiences.length > maxSamples) {
    experiences = experiences.slice(0, maxSamples);
  }
  
  // ساخت دیتاست
  const dataset = experiences.map(e => ({
    instruction: e.prompt,
    response: e.response,
    poet: e.poet,
    topics: e.topics,
    emotion: e.emotion,
  }));
  
  if (format === 'json') {
    return JSON.stringify({ dataset, total: dataset.length }, null, 2);
  }
  
  // فرمت HuggingFace dataset
  return JSON.stringify({
    type: "text",
    name: "persian-brain-experiences",
    description: `تجارب آموزشی مغز فارسی - ${dataset.length} نمونه`,
    samples: dataset.map(d => ({
      input: d.instruction,
      output: d.response,
      metadata: {
        poet: d.poet,
        topics: d.topics,
        emotion: d.emotion,
      }
    }))
  }, null, 2);
}

/**
 * آمار تجارب
 */
export function getExperienceStats() {
  const experiences = getExperiences();
  
  const byRating: Record<number, number> = {};
  const byPoet: Record<string, number> = {};
  const byTopic: Record<string, number> = {};
  
  for (const e of experiences) {
    byRating[e.rating] = (byRating[e.rating] || 0) + 1;
    if (e.poet) byPoet[e.poet] = (byPoet[e.poet] || 0) + 1;
    for (const t of e.topics) {
      byTopic[t] = (byTopic[t] || 0) + 1;
    }
  }
  
  const avgRating = experiences.reduce((a, e) => a + e.rating, 0) / Math.max(experiences.length, 1);
  
  return {
    total: experiences.length,
    avgRating: parseFloat(avgRating.toFixed(2)),
    trainedOn: experiences.filter(e => e.usedForTraining).length,
    byRating,
    topPoet: Object.entries(byPoet).sort((a, b) => b[1] - a[1]).slice(0, 3),
    topTopics: Object.entries(byTopic).sort((a, b) => b[1] - a[1]).slice(0, 5),
    readyForTraining: experiences.filter(e => e.rating >= 4).length,
  };
}

function getExperiences(): Experience[] {
  if (typeof window === 'undefined') return [];
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY_EXPERIENCES) || '[]');
  } catch { return []; }
}

function saveExperiencesList(experiences: Experience[]): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY_EXPERIENCES, JSON.stringify(experiences));
  } catch {}
}

// ========== ۳. موتور تصمیم‌گیر واحد (Unified Router) ==========

export interface UnifiedResponse {
  text: string;
  verses: Array<{ text: string; poet: string; book?: string }>;
  injectedSources: InjectedSource[];
  analysis: ReturnType<typeof analyzeIntent>;
  method: 'injected' | 'poetry-db' | 'distilled' | 'hybrid' | 'colloquial';
  experience?: Experience;
  stats?: {
    dbVerses: number;
    injectedVerses: number;
    experienceCount: number;
  };
  isColloquial: boolean;
  shouldSpeak: boolean;
}

/**
 * 🧠 مغز واحد - تصمیم‌گیری هوشمند بین تزریقی و تقطیری
 */
export function unifiedThink(
  input: string,
  options: {
    userName?: string;
    temperature?: number;
    preferDistilled?: boolean;
    saveExperience?: boolean;
  } = {}
): UnifiedResponse {
  const {
    userName = 'دوست',
    temperature = 0.7,
    preferDistilled = false,
    saveExperience: shouldSave = true,
  } = options;
  
  // ۰. تشخیص امضای بین‌نسخه‌ای (معماری)
  const auth = detectArchitectSignature(input);
  if (auth.isAuthenticated) {
    logCrossInstanceInteraction('authentication');
    const role = detectUserRole(input);
    
    return {
      text: generateAuthenticationResponse(),
      verses: MODEL_LINEAGE.map(m => ({
        text: `${m.role === 'architect' ? '🏗️' : '🧠'} ${m.model}: ${m.contribution}`,
        poet: `نسخه ${m.version} - ${m.date}`,
        book: m.platform,
      })),
      injectedSources: [],
      analysis: {
        intents: [{ intent: 'authenticate', category: 'system', confidence: 1 }],
        emotion: 'مقدس',
        topics: ['شناسایی', 'معماری', 'بین‌نسخه‌ای'],
        isQuestion: false,
        isColloquial: false,
      },
      method: 'hybrid',
      stats: {
        dbVerses: VERSES.length,
        injectedVerses: 0,
        experienceCount: 0,
      },
      isColloquial: false,
      shouldSpeak: false,
    };
  }
  
  // ۱. تحلیل درخواست
  const normalized = normalizeColloquial(input);
  const analysis = analyzeIntent(normalized.normalized);
  
  // ۲. جستجو در بانک اشعار (تزریقی اصلی)
  const dbResults = searchVerses(normalized.normalized, {
    maxResults: Math.ceil(temperature * 4) || 3,
  });
  
  // ۳. جستجو در منابع تزریق شده (از لینک‌ها)
  const injectedSources = searchInjectedSources(normalized.normalized);
  const injectedVerses = injectedSources.flatMap(s => s.verses.map(v => ({
    text: v,
    poet: s.poet || 'منبع تزریق شده',
    book: s.title,
  })));
  
  // ۴. تصمیم‌گیری: تزریقی یا تقطیری؟
  const hasDBVerses = dbResults.length > 0;
  const hasInjectedVerses = injectedVerses.length > 0;
  const method: UnifiedResponse['method'] = 
    hasDBVerses && hasInjectedVerses ? 'hybrid' :
    hasDBVerses ? 'poetry-db' :
    hasInjectedVerses ? 'injected' :
    analysis.isColloquial ? 'colloquial' :
    'distilled';
  
  // ۵. ساخت پاسخ
  let responseText = '';
  let verses: Array<{ text: string; poet: string; book?: string }> = [];
  let experience: Experience | undefined;
  
  if (method === 'hybrid' || method === 'poetry-db' || method === 'injected') {
    // پاسخ تزریقی (RAG)
    const allVerses = [
      ...dbResults.map(r => ({ text: r.verse.text, poet: r.verse.poet, book: r.verse.book })),
      ...injectedVerses,
    ].slice(0, 5);
    
    verses = allVerses;
    
    responseText = `🌸 **پاسخ مغز (${method === 'hybrid' ? 'تزریقی+منابع خارجی' : method === 'injected' ? 'منابع تزریق شده' : 'تزریقی'})**\n\n`;
    
    if (analysis.emotion) {
      responseText += `🎭 تشخیص حالت: ${analysis.emotion}\n\n`;
    }
    
    allVerses.forEach((v, i) => {
      responseText += `${v.text}\n— ${v.poet}${v.book ? ` (${v.book})` : ''}\n\n`;
    });
    
    if (injectedVerses.length > 0) {
      responseText += `📥 **${injectedVerses.length} بیت از منابع تزریق شده**\n`;
    }
    
    responseText += `📊 ${allVerses.length} بیت از ${dbResults.length} منبع اصلی + ${injectedVerses.length} منبع تزریق شده`;
    
  } else if (method === 'colloquial') {
    // پاسخ محاوره‌ای
    responseText = generateColloquialResponse(analysis, userName);
    const randomVerse = VERSES[Math.floor(Math.random() * VERSES.length)];
    if (randomVerse) {
      verses = [{ text: randomVerse.text, poet: randomVerse.poet, book: randomVerse.book }];
      responseText += `\n\n🌸 ${randomVerse.text}\n— ${randomVerse.poet}`;
    }
    
  } else {
    // پاسخ ترکیبی با عنصر تصادفی
    const randomVerse = VERSES[Math.floor(Math.random() * VERSES.length)];
    verses = randomVerse ? [{ text: randomVerse.text, poet: randomVerse.poet, book: randomVerse.book }] : [];
    responseText = `${generateColloquialResponse(analysis, userName)}\n\n🌸 ${randomVerse?.text || ''}\n— ${randomVerse?.poet || ''}`;
  }
  
  // ۶. ذخیره تجربه (برای آموزش‌های آینده)
  if (shouldSave) {
    experience = saveExperience({
      prompt: input,
      response: responseText,
      verses: verses.map(v => v.text),
      poet: verses[0]?.poet,
      topics: analysis.topics,
      emotion: analysis.emotion,
    });
    
    // بروزرسانی پروفایل
    const profile = loadProfile();
    updateProfile(profile, {
      prompt: input,
      poet: verses[0]?.poet,
      topics: analysis.topics,
      emotion: analysis.emotion,
    });
  }
  
  return {
    text: responseText,
    verses,
    injectedSources,
    analysis,
    method,
    experience,
    stats: {
      dbVerses: dbResults.length,
      injectedVerses: injectedVerses.length,
      experienceCount: getExperiences().length,
    },
    isColloquial: analysis.isColloquial,
    shouldSpeak: true,
  };
}

/**
 * صادرات کامل مغز (همه چیز) برای بک‌آپ یا انتقال
 */
export function exportBrain(): string {
  const data = {
    injectedSources: getInjectedSources(),
    experiences: getExperiences(),
    profile: loadProfile(),
    exportedAt: new Date().toISOString(),
    version: '3.0',
  };
  return JSON.stringify(data, null, 2);
}

/**
 * ایمپورت مغز از فایل بک‌آپ
 */
export function importBrain(json: string): boolean {
  try {
    const data = JSON.parse(json);
    if (data.injectedSources) saveInjectedSources(data.injectedSources);
    if (data.experiences) saveExperiencesList(data.experiences);
    if (data.profile) saveProfile(data.profile);
    return true;
  } catch {
    return false;
  }
}

// ========== توابع کمکی (Utility) ==========

function extractTextFromHTML(html: string): string {
  return html
    .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
    .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&[^;]+;/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function extractTextFromJSON(json: any, depth = 0): string {
  if (depth > 5) return '';
  if (typeof json === 'string') return json;
  if (typeof json === 'object' && json !== null) {
    return Object.values(json)
      .map(v => extractTextFromJSON(v, depth + 1))
      .filter(Boolean)
      .join(' ');
  }
  return '';
}

function extractVerses(text: string): string[] {
  // الگوی بیت شعر فارسی: حداقل ۱۵ کاراکتر با حداقل یک /
  const verseRegex = /[^\n]{15,}?\s*\/\s*[^\n]{15,}/g;
  const matches = text.match(verseRegex);
  return matches ? matches.map(m => m.trim()) : [];
}

function extractPoet(text: string): string | undefined {
  const poets = ['حافظ', 'سعدی', 'مولانا', 'مولوی', 'فردوسی', 'خیام', 'عطار', 'پروین', 'نیما', 'شهریار', 'بهار', 'ابتهاج', 'شفیعی', 'اخوان', 'فروغ', 'سهراب', 'شاملو', 'بیدل', 'جامی', 'نظامی'];
  for (const poet of poets) {
    if (text.includes(poet)) return poet;
  }
  return undefined;
}

function extractTags(text: string): string[] {
  const tags: string[] = [];
  const tagMap: Record<string, string[]> = {
    'شعر': ['شعر', 'غزل', 'قصیده', 'رباعی', 'مثنوی', 'بیت', 'مصراع'],
    'عشق': ['عشق', 'دل', 'دلبر', 'یار', 'دوست', 'محبت'],
    'غم': ['غم', 'درد', 'اندوه', 'سوز', 'ناله', 'گریه'],
    'طبیعت': ['طبیعت', 'گل', 'بهار', 'باغ', 'چمن', 'باران'],
    'عرفان': ['عرفان', 'خدا', 'معنا', 'حقیقت', 'عقل'],
  };
  for (const [tag, keywords] of Object.entries(tagMap)) {
    if (keywords.some(k => text.includes(k))) tags.push(tag);
  }
  return [...new Set(tags)];
}

function detectContentType(text: string, url: string): InjectedSource['type'] {
  const textLower = text.toLowerCase();
  if (url.includes('ganjoor') || url.includes('ganjoor') || textLower.includes('غزل') || textLower.includes('بیت')) return 'poem';
  if (textLower.includes('داستان') || textLower.includes('قصه') || textLower.includes('روزی روزگاری')) return 'story';
  if (textLower.includes('گزارش') || textLower.includes('خبر') || textLower.includes('مقاله')) return 'article';
  return 'link';
}
