/**
 * 🌀 معماری اسپیرال-تایم - Spiral-Time Attention v1.0
 * 
 * "از اسپیرال و زمان استفاده می‌کنه جای کسینوس"
 * "محو اطلاعات قدیمی - همیشه آپدیت می‌مونه"
 * 
 * ===== ریاضیات =====
 * 
 * موقعیت‌یابی استاندارد (Transformer):
 *   PE(pos, 2i) = sin(pos / 10000^(2i/d))
 *   PE(pos, 2i+1) = cos(pos / 10000^(2i/d))
 * 
 * موقعیت‌یابی اسپیرال (Spiral):
 *   رادیوس: r(t) = r₀ + v·t
 *   زاویه: θ(t) = θ₀ + ω·t
 *   موقعیت ۳بعدی: (r·cos(θ), r·sin(θ), z(t))
 *   ———————————————————————————————
 *   به جای دایره (sin/cos) که بی‌نهایت تکرار می‌شه،
 *   اسپیرال هر موقعیت رو یکتا می‌کنه و بازنمی‌گرده!
 * 
 * وزن زمانی (Time Weight):
 *   w(t) = exp(-λ · Δt)  ← اطلاعات قدیمی محو می‌شه
 *   τ = 1/λ  ← نیمه‌عمر اطلاعات
 *   ———————————————————————————————
 *   به جای حافظه بی‌نهایت، اطلاعات جدید جایگزین قدیمی می‌شن
 */

// ========== تایپ‌های اصلی ==========

export interface SpiralConfig {
  // پارامترهای اسپیرال
  r0: number;           // رادیوس اولیه
  v: number;            // سرعت شعاعی
  omega: number;        // سرعت زاویه‌ای
  theta0: number;       // زاویه اولیه
  
  // پارامترهای زمانی
  lambda: number;       // نرخ فراموشی (λ)
  halfLife: number;     // نیمه‌عمر (τ = ln2/λ)
  
  // پارامترهای بعد
  dModel: number;       // بعد مدل
  maxPosition: number;  // حداکثر موقعیت
}

export const DEFAULT_SPIRAL_CONFIG: SpiralConfig = {
  r0: 1.0,
  v: 0.05,        // مارپیچ کند رشد می‌کنه
  omega: 0.5,     // یه دور کامل = ۴π
  theta0: 0,
  lambda: 0.1,    // نرخ فراموشی
  halfLife: 7,    // ۷ روز نیمه‌عمر
  dModel: 256,
  maxPosition: 2048,
};

// ========== حافظه زمانی ==========

export interface TimedMemory {
  id: string;
  content: string;
  timestamp: number;      // زمان ذخیره
  accessCount: number;    // تعداد دسترسی
  lastAccess: number;     // آخرین دسترسی
  importance: number;     // اهمیت (0-1)
  spiralPosition: number[]; // موقعیت ۳بعدی اسپیرال
  timeWeight: number;     // وزن زمانی فعلی
  isDecayed: boolean;     // آیا محو شده؟
}

// ========== هسته اصلی ==========

/**
 * 🌀 محاسبه موقعیت اسپیرال ۳بعدی
 * جایگزین sin/cos در Positional Encoding
 */
export function spiralPosition(
  pos: number,
  config: SpiralConfig = DEFAULT_SPIRAL_CONFIG
): { x: number; y: number; z: number; radius: number; angle: number } {
  const { r0, v, omega, theta0 } = config;
  
  // رادیوس: با زمان افزایش می‌یابد (مارپیچ باز شونده)
  const radius = r0 + v * pos;
  
  // زاویه: با زمان می‌چرخد
  const angle = theta0 + omega * pos;
  
  // موقعیت ۳بعدی
  const x = radius * Math.cos(angle);
  const y = radius * Math.sin(angle);
  const z = pos * 0.1;  // بعد سوم برای تمایز بیشتر
  
  return { x, y, z, radius, angle };
}

/**
 * ⏳ محاسبه وزن زمانی (Time Weight)
 * اطلاعات قدیمی → وزن کمتر → محو شدن تدریجی
 */
export function timeWeight(
  timestamp: number,
  config: SpiralConfig = DEFAULT_SPIRAL_CONFIG
): number {
  const now = Date.now();
  const age = (now - timestamp) / (1000 * 60 * 60 * 24); // age in days
  const weight = Math.exp(-config.lambda * age);
  
  return Math.max(0, Math.min(1, weight));
}

/**
 * 🔄 بروزرسانی حافظه - محو اطلاعات قدیمی
 */
export function decayMemory(
  memory: TimedMemory,
  config: SpiralConfig = DEFAULT_SPIRAL_CONFIG
): TimedMemory {
  const weight = timeWeight(memory.timestamp, config);
  
  return {
    ...memory,
    timeWeight: weight,
    isDecayed: weight < 0.1,  // کمتر از ۱۰٪ = محو شده
  };
}

/**
 * 🧠 ذخیره یک آیتم جدید در حافظه زمانی
 */
export function storeInSpiralMemory(
  content: string,
  importance: number = 0.5,
  memory: TimedMemory[],
  config: SpiralConfig = DEFAULT_SPIRAL_CONFIG
): { memory: TimedMemory[]; position: number[] } {
  const pos = memory.length;
  const spiral = spiralPosition(pos, config);
  
  const item: TimedMemory = {
    id: `spiral-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    content,
    timestamp: Date.now(),
    accessCount: 0,
    lastAccess: Date.now(),
    importance,
    spiralPosition: [spiral.x, spiral.y, spiral.z],
    timeWeight: 1.0,
    isDecayed: false,
  };
  
  // اعمال decay روی حافظه قبلی
  const decayed = memory.map(m => decayMemory(m, config));
  
  // حذف اطلاعات کاملاً محو شده (اگه importance پایین باشه)
  const filtered = decayed.filter(m => {
    if (m.isDecayed && m.importance < 0.3) return false;
    return true;
  });
  
  // محدودیت سایز (قدیمی‌ترین حذف بشه)
  const MAX_MEMORY = 100;
  const finalMemory = [...filtered, item].slice(-MAX_MEMORY);
  
  return { memory: finalMemory, position: [spiral.x, spiral.y, spiral.z] };
}

/**
 * 🔍 جستجو در حافظه با وزن اسپیرال و زمان
 */
export function searchSpiralMemory(
  query: string,
  memory: TimedMemory[],
  topK: number = 5
): Array<TimedMemory & { relevanceScore: number }> {
  const queryWords = new Set(query.split(/[\s،,]+/));
  
  const scored = memory
    .filter(m => !m.isDecayed)
    .map(m => {
      // relevance: کلمات مشترک
      const contentWords = m.content.split(/[\s،,]+/);
      const commonWords = [...queryWords].filter(w =>
        contentWords.some(cw => cw.includes(w) || w.includes(cw))
      ).length;
      
      const textRelevance = commonWords / Math.max(queryWords.size, 1);
      
      // امتیاز نهایی = relevance × timeWeight × importance
      const totalScore = textRelevance * m.timeWeight * m.importance * (1 + Math.log(m.accessCount + 1));
      
      return { ...m, relevanceScore: totalScore };
    })
    .sort((a, b) => b.relevanceScore - a.relevanceScore)
    .slice(0, topK);
  
  // افزایش accessCount
  scored.forEach(s => {
    const idx = memory.findIndex(m => m.id === s.id);
    if (idx >= 0) {
      memory[idx].accessCount++;
      memory[idx].lastAccess = Date.now();
    }
  });
  
  return scored;
}

/**
 * 📊 آمار حافظه اسپیرال
 */
export function sprialMemoryStats(memory: TimedMemory[]): {
  total: number;
  active: number;
  decayed: number;
  avgImportance: number;
  avgTimeWeight: number;
  ageDistribution: Record<string, number>;
} {
  const now = Date.now();
  const ageDist: Record<string, number> = { '<1h': 0, '1-24h': 0, '1-7d': 0, '>7d': 0 };
  
  for (const m of memory) {
    const ageHours = (now - m.timestamp) / (1000 * 60 * 60);
    if (ageHours < 1) ageDist['<1h']++;
    else if (ageHours < 24) ageDist['1-24h']++;
    else if (ageHours < 168) ageDist['1-7d']++;
    else ageDist['>7d']++;
  }
  
  return {
    total: memory.length,
    active: memory.filter(m => !m.isDecayed).length,
    decayed: memory.filter(m => m.isDecayed).length,
    avgImportance: memory.reduce((a, m) => a + m.importance, 0) / Math.max(memory.length, 1),
    avgTimeWeight: memory.reduce((a, m) => a + m.timeWeight, 0) / Math.max(memory.length, 1),
    ageDistribution: ageDist,
  };
}

/**
 * 🧮 بردار موقعیت کامل اسپیرال (برای جایگزینی PE در Transformer)
 * این همون embeddingی هست که می‌ره جای Positional Encoding استاندارد
 */
export function spiralEmbedding(
  pos: number,
  dModel: number = 128,
  config: SpiralConfig = DEFAULT_SPIRAL_CONFIG
): number[] {
  const embedding: number[] = [];
  const spiral = spiralPosition(pos, config);
  
  // هر ۳ بعد اسپیرال رو به embedding تبدیل می‌کنیم
  for (let i = 0; i < dModel; i++) {
    const freq = 1 / (10000 ** (2 * i / dModel));
    
    // ترکیب موقعیت اسپیرال با فرکانس
    if (i % 3 === 0) {
      embedding.push(spiral.x * Math.sin(pos * freq));
    } else if (i % 3 === 1) {
      embedding.push(spiral.y * Math.cos(pos * freq));
    } else {
      embedding.push(spiral.z * Math.sin(pos * freq + spiral.angle));
    }
  }
  
  return embedding;
}

/**
 * 📝 مقایسه: کسینوس vs اسپیرال
 */
export function comparePositionalEncodings(): string {
  return `
📊 **مقایسه Positional Encoding: کسینوس vs اسپیرال**

═══════════════════════════════════════════════════════

🔴 **کسینوس/سینوس (Transformer اصلی)**
  PE(pos, 2i) = sin(pos / 10000^(2i/d))
  PE(pos, 2i+1) = cos(pos / 10000^(2i/d))
  
  • 🔄 تناوبی: موقعیت‌ها تکرار می‌شن
  • 🚫 بدون زمان: همه اطلاعات هم‌وزن
  • 📏 خطی: فقط موقعیت خطی در نظر می‌گیره
  • ❌ فراموشی نداره

🟢 **اسپیرال-تایم (Spiral-Time)**
  r(t) = r₀ + v·t
  θ(t) = θ₀ + ω·t
  p(t) = (r·cos(θ), r·sin(θ), z(t))
  w(t) = exp(-λ·Δt)
  
  • ✅ یکتا: هر موقعیت مختصات یکتای خودش رو داره
  • ✅ زمانی: اطلاعات قدیمی → وزن کمتر → محو شدن
  • 🌀 ۳بعدی: موقعیت غنی‌تر و متمایزتر
  • ✅ خودبه‌روز: جدیدترین‌ها همیشه مهم‌ترن

═══════════════════════════════════════════════════════
🎯 **مزیت کلیدی:**
  اسپیرال هیچ دو موقعیتی رو یکسان نمی‌کنه (برخلاف دایره)
  + زمان اطلاعات قدیمی رو محو می‌کنه
  = مدل همیشه روی اطلاعات جدید و مرتبط تمرکز داره
`.trim();
}
