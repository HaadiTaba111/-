"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface DashboardStats {
  totalModels: number;
  trainedModels: number;
  totalInferences: number;
  totalTrainingSessions: number;
  averageLatency: number;
  averageLoss: number;
  recentActivity: Array<{
    type: "training" | "inference";
    modelName: string;
    timestamp: string;
    detail: string;
  }>;
  modelDistribution: Array<{
    status: string;
    count: number;
  }>;
  trainingProgress: Array<{
    date: string;
    sessions: number;
  }>;
}

const initialStats: DashboardStats = {
  totalModels: 0,
  trainedModels: 0,
  totalInferences: 0,
  totalTrainingSessions: 0,
  averageLatency: 0,
  averageLoss: 0,
  recentActivity: [],
  modelDistribution: [],
  trainingProgress: [],
};

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats>(initialStats);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      setLoading(true);
      const res = await fetch("/api/dashboard/stats");
      const data = await res.json();
      if (data.success) {
        setStats(data.stats);
      }
    } catch (err) {
      setError("خطا در دریافت آمار");
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    {
      title: "کل مدل‌ها",
      value: stats.totalModels,
      icon: "🤖",
      color: "from-blue-500 to-blue-700",
      desc: "مدل‌های ایجاد شده",
    },
    {
      title: "آموزش دیده",
      value: stats.trainedModels,
      icon: "🧠",
      color: "from-purple-500 to-purple-700",
      desc: "مدل‌های تکمیل آموزش",
    },
    {
      title: "تعداد تفکر",
      value: stats.totalInferences,
      icon: "💭",
      color: "from-emerald-500 to-emerald-700",
      desc: "استنتاج انجام شده",
    },
    {
      title: "جلسات آموزش",
      value: stats.totalTrainingSessions,
      icon: "📚",
      color: "from-amber-500 to-amber-700",
      desc: "دوره‌های آموزشی",
    },
  ];

  const getStatusBadge = (type: string) => {
    if (type === "training") {
      return (
        <span className="px-2 py-0.5 rounded-full text-xs bg-purple-500/20 text-purple-400 border border-purple-500/30">
          آموزش
        </span>
      );
    }
    return (
      <span className="px-2 py-0.5 rounded-full text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
        تفکر
      </span>
    );
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in">
      {/* هدر */}
      <div className="text-center space-y-3 py-6">
        <div className="inline-block animate-float text-5xl mb-2">🧠</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] via-[#a855f7] to-[#ec4899] bg-clip-text text-transparent">
          داشبورد مغز فارسی
        </h1>
        <p className="text-[#94a3b8] text-sm sm:text-base">
          مدیریت و مانیتورینگ هوش مصنوعی فارسی - Persian Brain AI Dashboard
        </p>
      </div>

      {/* کارت‌های آمار */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, i) => (
          <div
            key={i}
            className="relative group animate-slide-in"
            style={{ animationDelay: `${i * 100}ms` }}
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${card.color} rounded-2xl opacity-10 group-hover:opacity-20 transition-opacity`} />
            <div className="relative bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-5 hover:border-[#6366f1]/50 transition-all duration-300">
              <div className="flex items-center justify-between mb-3">
                <span className="text-2xl">{card.icon}</span>
                <span className="text-xs text-[#64748b]">{card.desc}</span>
              </div>
              <p className="text-3xl font-bold text-white">{card.value}</p>
              <p className="text-sm text-[#94a3b8] mt-1">{card.title}</p>
            </div>
          </div>
        ))}
      </div>

      {/* ردیف دوم - متریک‌ها و نمودار */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* میانگین‌ها */}
        <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <span>📈</span> میانگین عملکرد
          </h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-[#94a3b8]">سرعت پاسخ</span>
              <span className="text-emerald-400 font-bold">{stats.averageLatency}ms</span>
            </div>
            <div className="w-full bg-[#0f172a] rounded-full h-2">
              <div
                className="bg-emerald-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: `${Math.min(100, (stats.averageLatency / 1000) * 100)}%` }}
              />
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[#94a3b8]">میانگین Loss</span>
              <span className="text-amber-400 font-bold">{stats.averageLoss.toFixed(3)}</span>
            </div>
            <div className="w-full bg-[#0f172a] rounded-full h-2">
              <div
                className="bg-amber-500 h-2 rounded-full transition-all duration-1000"
                style={{ width: `${Math.min(100, (1 - stats.averageLoss / 3) * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {/* نمودار پیشرفت آموزش */}
        <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <span>📊</span> پیشرفت آموزش (۷ روز اخیر)
          </h3>
          <div className="flex items-end gap-2 h-32">
            {stats.trainingProgress.map((day, i) => {
              const maxVal = Math.max(...stats.trainingProgress.map(d => d.sessions), 1);
              const height = (day.sessions / maxVal) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <span className="text-xs text-[#64748b]">{day.sessions}</span>
                  <div
                    className="w-full bg-gradient-to-t from-[#6366f1] to-[#a855f7] rounded-t-md transition-all duration-500"
                    style={{ height: `${height}%`, minHeight: day.sessions > 0 ? '8px' : '2px' }}
                  />
                  <span className="text-[10px] text-[#64748b]">
                    {new Date(day.date).toLocaleDateString("fa-IR", { weekday: "short" })}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* وضعیت مدل‌ها */}
        <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
          <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <span>🎯</span> وضعیت مدل‌ها
          </h3>
          <div className="space-y-3">
            {stats.modelDistribution.map((dist, i) => {
              const total = stats.modelDistribution.reduce((a, b) => a + b.count, 0) || 1;
              const pct = (dist.count / total) * 100;
              const colors: Record<string, string> = {
                trained: "bg-emerald-500",
                training: "bg-blue-500",
                created: "bg-amber-500",
                failed: "bg-red-500",
              };
              const labels: Record<string, string> = {
                trained: "آموزش دیده",
                training: "در حال آموزش",
                created: "ایجاد شده",
                failed: "خطا",
              };
              return (
                <div key={i}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-[#94a3b8]">{labels[dist.status] || dist.status}</span>
                    <span className="text-white font-medium">{dist.count}</span>
                  </div>
                  <div className="w-full bg-[#0f172a] rounded-full h-2">
                    <div
                      className={`${colors[dist.status] || "bg-slate-500"} h-2 rounded-full transition-all duration-1000`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* فعالیت‌های اخیر */}
      <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <span>⚡</span> فعالیت‌های اخیر
        </h3>
        {stats.recentActivity.length === 0 ? (
          <div className="text-center py-8 text-[#64748b]">
            <p className="text-3xl mb-2">🌙</p>
            <p>هنوز فعالیتی ثبت نشده است</p>
            <p className="text-sm mt-1">اولین مدل خود را آموزش دهید!</p>
          </div>
        ) : (
          <div className="space-y-2">
            {stats.recentActivity.map((activity, i) => (
              <div
                key={i}
                className="flex items-center justify-between p-3 rounded-xl bg-[#0f172a]/50 hover:bg-[#0f172a] transition-colors"
              >
                <div className="flex items-center gap-3">
                  {getStatusBadge(activity.type)}
                  <div>
                    <p className="text-sm text-white font-medium">{activity.modelName}</p>
                    <p className="text-xs text-[#64748b]">{activity.detail}</p>
                  </div>
                </div>
                <span className="text-xs text-[#64748b]">
                  {new Date(activity.timestamp).toLocaleDateString("fa-IR", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* دکمه‌های اقدام سریع */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Link
          href="/train"
          className="group relative bg-gradient-to-l from-[#6366f1] to-[#4f46e5] rounded-2xl p-6 text-center hover:shadow-lg hover:shadow-[#6366f1]/25 transition-all duration-300"
        >
          <div className="text-3xl mb-2 group-hover:animate-pulse-brain">🧠</div>
          <p className="font-bold">آموزش مغز جدید</p>
          <p className="text-sm text-white/70 mt-1">شروع یک مدل فارسی جدید</p>
        </Link>

        <Link
          href="/inference"
          className="group relative bg-gradient-to-l from-[#a855f7] to-[#9333ea] rounded-2xl p-6 text-center hover:shadow-lg hover:shadow-[#a855f7]/25 transition-all duration-300"
        >
          <div className="text-3xl mb-2 group-hover:animate-pulse-brain">💭</div>
          <p className="font-bold">تفکر با مغز</p>
          <p className="text-sm text-white/70 mt-1">گفتگو با مدل آموزش دیده</p>
        </Link>

        <Link
          href="/models"
          className="group relative bg-gradient-to-l from-[#ec4899] to-[#db2777] rounded-2xl p-6 text-center hover:shadow-lg hover:shadow-[#ec4899]/25 transition-all duration-300"
        >
          <div className="text-3xl mb-2 group-hover:animate-pulse-brain">🤖</div>
          <p className="font-bold">مدیریت مدل‌ها</p>
          <p className="text-sm text-white/70 mt-1">مشاهده و ویرایش مدل‌ها</p>
        </Link>
      </div>
    </div>
  );
}
