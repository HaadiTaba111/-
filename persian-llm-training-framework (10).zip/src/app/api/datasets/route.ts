import { NextResponse } from "next/server";
import { searchPersianDatasets } from "@/lib/huggingface";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get("q") || undefined;

    const datasets = await searchPersianDatasets(query);

    return NextResponse.json({
      success: true,
      count: datasets.length,
      datasets,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در دریافت دیتاست‌ها",
      },
      { status: 500 }
    );
  }
}
