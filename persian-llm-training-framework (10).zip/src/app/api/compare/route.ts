import { NextResponse } from "next/server";
import { compareModels, getTestQuestions, getOriginalTorchScript, SpiralTimeLayer, StandardModel } from "@/lib/spiral-time-torch";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      // ===== مقایسه دو مدل روی یک سوال =====
      case "compare": {
        if (!params.question) {
          return NextResponse.json({ success: false, error: "سوال الزامی است" }, { status: 400 });
        }
        const result = compareModels(params.question, params.timeStep || 0);
        return NextResponse.json({ success: true, data: result });
      }

      // ===== اجرای دسته‌ای روی همه سوالات تست =====
      case "batch-compare": {
        const questions = getTestQuestions();
        const results = questions.map((q, i) => ({
          ...compareModels(q.question, i),
          category: q.category,
        }));
        
        const spiralWins = results.filter(r => r.spiralWon).length;
        const total = results.length;
        
        return NextResponse.json({
          success: true,
          data: {
            results,
            summary: {
              total,
              spiralWins,
              standardWins: total - spiralWins,
              spiralWinRate: `${((spiralWins / total) * 100).toFixed(1)}%`,
              averageLatencySpiral: parseFloat(
                (results.reduce((a, r) => a + r.metrics.spiral.latency, 0) / total).toFixed(2)
              ),
              averageLatencyStandard: parseFloat(
                (results.reduce((a, r) => a + r.metrics.standard.latency, 0) / total).toFixed(2)
              ),
            },
          },
        });
      }

      // ===== تست Decay اسپیرال (چقدر اطلاعات قدیمی فراموش میشه) =====
      case "test-decay": {
        const dim = 128;
        const layer = new SpiralTimeLayer(dim, 8, 5);
        const timeSteps = [0, 1, 2, 5, 10, 20, 50, 100];
        
        const decayResults = timeSteps.map(t => {
          const input = Math.tanh(t * 0.1);
          const output = layer.forward(input, t);
          const avgImportance = layer.points.reduce((a, p) => a + p.importance, 0) / layer.points.length;
          
          return {
            timeStep: t,
            input: parseFloat(input.toFixed(4)),
            output: parseFloat(output.toFixed(4)),
            avgImportance: parseFloat(avgImportance.toFixed(4)),
            decayPercent: parseFloat(((1 - avgImportance) * 100).toFixed(1)),
          };
        });
        
        return NextResponse.json({ success: true, data: decayResults });
      }

      // ===== دریافت اسکریپت PyTorch اصلی =====
      case "get-torch-script": {
        const script = getOriginalTorchScript();
        return NextResponse.json({ success: true, data: script });
      }

      // ===== اجرای مدل استاندارد تنها =====
      case "standard-only": {
        const model = new StandardModel(4);
        let hash = 0;
        const input = params.input || "test";
        for (let i = 0; i < input.length; i++) {
          hash = ((hash << 5) - hash) + input.charCodeAt(i);
          hash |= 0;
        }
        const x = Math.tanh(hash / 10000);
        const output = model.forward(x);
        
        return NextResponse.json({
          success: true,
          data: {
            input: params.input,
            output: parseFloat(output.toFixed(6)),
            layers: model.layers.map((l, i) => ({
              layer: i,
              weight: parseFloat((l as any).weight.toFixed(4)),
              bias: parseFloat((l as any).bias.toFixed(4)),
            })),
          },
        });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "🌀 مقایسه‌گر: اسپیرال-تایم vs استاندارد",
    description: "دو مدل رو کنار هم ببین و مقایسه کن",
    endpoints: [
      { action: "compare", params: { question: "...", timeStep: 0 }, desc: "مقایسه دو مدل روی یک سوال" },
      { action: "batch-compare", desc: "اجرای دسته‌ای روی ۷ سوال تست" },
      { action: "test-decay", desc: "تست محو شدن اطلاعات در طول زمان" },
      { action: "get-torch-script", desc: "دریافت اسکریپت کامل PyTorch" },
    ],
  });
}
