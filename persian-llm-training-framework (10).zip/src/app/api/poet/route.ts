import { NextResponse } from "next/server";
import {
  generateNewVerse,
  generatePoem,
  generateMeteredVerse,
  generateStoryInspiredPoem,
  analyzeNewVerse,
  getAvailableRhymes,
  suggestRhymeWords,
} from "@/lib/poetry-generator";
import {
  findStoriesByTopic,
  findStoriesByMood,
  getRandomStory,
  getStoryForConversation,
  PERSIAN_STORIES,
} from "@/lib/persian-stories";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      // ===== شعر جدید =====
      case "generate-verse": {
        const verse = generateNewVerse(
          params.topic || "گل",
          params.style || "classic",
          params.temperature || 0.7
        );
        const analysis = analyzeNewVerse(verse.verse);
        return NextResponse.json({ success: true, data: { verse, analysis } });
      }

      // ===== شعر کامل =====
      case "generate-poem": {
        const poem = generatePoem(
          params.topic || "گل",
          params.lines || 4,
          params.style || "classic"
        );
        return NextResponse.json({ success: true, data: poem });
      }

      // ===== شعر با وزن مشخص =====
      case "generate-metered": {
        const verse = generateMeteredVerse(
          params.topic || "گل",
          params.rhyme || "ان"
        );
        return NextResponse.json({ success: true, data: { verse } });
      }

      // ===== شعر از داستان =====
      case "story-poem": {
        const story = params.storyText 
          ? { title: params.storyTitle || "داستان", text: params.storyText, keywords: [params.topic || "زندگی"] }
          : getRandomStory();
        const result = generateStoryInspiredPoem(story);
        return NextResponse.json({ success: true, data: result });
      }

      // ===== تحلیل شعر =====
      case "analyze": {
        if (!params.verse) {
          return NextResponse.json({ success: false, error: "متن شعر الزامی است" }, { status: 400 });
        }
        const analysis = analyzeNewVerse(params.verse);
        return NextResponse.json({ success: true, data: analysis });
      }

      // ===== داستان‌ها =====
      case "story-random": {
        const story = getStoryForConversation();
        return NextResponse.json({ success: true, data: story });
      }

      case "story-by-topic": {
        const stories = findStoriesByTopic(params.topic || "");
        return NextResponse.json({ success: true, count: stories.length, data: stories });
      }

      case "story-by-mood": {
        const stories = findStoriesByMood(params.mood || "");
        return NextResponse.json({ success: true, count: stories.length, data: stories });
      }

      // ===== ابزارهای قافیه =====
      case "get-rhymes": {
        return NextResponse.json({ success: true, data: getAvailableRhymes() });
      }

      case "suggest-rhyme": {
        const words = suggestRhymeWords(params.topic || "");
        return NextResponse.json({ success: true, data: words });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "🖋️ شاعر ماشین + قصه‌گوی فارسی",
    description: "شعر جدید می‌سازه (پیدا نمی‌کنه!) + از داستان‌های کهن محاوره یاد می‌گیره",
    actions: [
      { action: "generate-verse", params: { topic: "گل", style: "classic" }, desc: "🌸 تولید بیت جدید" },
      { action: "generate-poem", params: { topic: "گل", lines: 4 }, desc: "📜 تولید شعر کامل" },
      { action: "story-random", desc: "📖 داستان تصادفی با محاوره روان" },
      { action: "story-by-topic", params: { topic: "عشق" }, desc: "🔍 جستجوی داستان" },
      { action: "story-poem", desc: "🖋️ شعر از داستان" },
    ],
  });
}
