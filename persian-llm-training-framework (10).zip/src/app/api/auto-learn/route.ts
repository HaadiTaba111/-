import { NextResponse } from "next/server";
import {
  learnFromAllSources,
  learnFromSource,
  getAutoLearnStats,
  addSource,
  removeSource,
  toggleSource,
  suggestSource,
  generateCronScript,
  defaultConfig,
  DEFAULT_SOURCES,
  type LearningSource,
} from "@/lib/auto-learner";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      case "learn-all": {
        const result = await learnFromAllSources();
        return NextResponse.json({
          success: true,
          message: `✅ ${result.totalNew} بیت جدید از ${result.results.length} منبع یاد گرفته شد`,
          data: result,
        });
      }

      case "learn-source": {
        if (!params.source) {
          return NextResponse.json({ success: false, error: "منبع الزامی است" }, { status: 400 });
        }
        const source: LearningSource = params.source;
        const result = await learnFromSource(source);
        return NextResponse.json({
          success: true,
          message: `✅ ${result.versesNew} بیت جدید از ${source.name}`,
          data: result,
        });
      }

      case "add-source": {
        if (!params.url) {
          return NextResponse.json({ success: false, error: "URL الزامی است" }, { status: 400 });
        }
        const suggested = suggestSource(params.url);
        if (!suggested) {
          return NextResponse.json({ success: false, error: "نمی‌توان نوع منبع را تشخیص داد" }, { status: 400 });
        }
        // اعمال تنظیمات اضافی کاربر
        if (params.name) suggested.name = params.name;
        if (params.tags) suggested.tags = params.tags;
        if (params.poet) suggested.tags = [...(suggested.tags || []), params.poet];
        
        addSource(suggested);
        return NextResponse.json({
          success: true,
          message: `✅ منبع "${suggested.name}" اضافه شد`,
          data: suggested,
        });
      }

      case "remove-source": {
        if (!params.sourceId) {
          return NextResponse.json({ success: false, error: "شناسه منبع الزامی است" }, { status: 400 });
        }
        removeSource(params.sourceId);
        return NextResponse.json({ success: true, message: "✅ منبع حذف شد" });
      }

      case "toggle-source": {
        if (!params.sourceId) {
          return NextResponse.json({ success: false, error: "شناسه منبع الزامی است" }, { status: 400 });
        }
        toggleSource(params.sourceId);
        return NextResponse.json({ success: true, message: "✅ وضعیت منبع تغییر کرد" });
      }

      case "suggest-source": {
        if (!params.url) {
          return NextResponse.json({ success: false, error: "URL الزامی است" }, { status: 400 });
        }
        const suggested = suggestSource(params.url);
        return NextResponse.json({
          success: !!suggested,
          data: suggested,
          message: suggested ? `✅ تشخیص: ${suggested.type} - ${suggested.name}` : "❌ قابل تشخیص نیست",
        });
      }

      case "get-stats": {
        const stats = getAutoLearnStats();
        return NextResponse.json({ success: true, data: stats });
      }

      case "get-cron-script": {
        return NextResponse.json({
          success: true,
          data: generateCronScript(),
          note: "این اسکریپت برای کرون جاب لینوکس است. هر روز ساعت ۳ صبح اجرا میشه",
        });
      }

      case "reset-config": {
        const config = defaultConfig();
        const { saveConfig } = require("@/lib/auto-learner");
        return NextResponse.json({ success: true, message: "✅ تنظیمات بازنشانی شد" });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  const stats = getAutoLearnStats();
  return NextResponse.json({
    success: true,
    name: "🤖 موتور یادگیری خودکار مغز فارسی",
    description: "خزنده، پردازشگر و تزریق‌کننده خودکار اشعار از منابع آنلاین",
    stats: {
      activeSources: stats.activeSources,
      totalVerses: stats.totalVerses,
      lastRun: stats.lastRun,
    },
    endpoints: [
      { action: "learn-all", method: "POST", desc: "یادگیری از همه منابع فعال" },
      { action: "learn-source", method: "POST", params: { source: "..." }, desc: "یادگیری از یک منبع خاص" },
      { action: "add-source", method: "POST", params: { url: "...", name: "..." }, desc: "افزودن منبع جدید" },
      { action: "remove-source", method: "POST", params: { sourceId: "..." }, desc: "حذف منبع" },
      { action: "toggle-source", method: "POST", params: { sourceId: "..." }, desc: "فعال/غیرفعال کردن منبع" },
      { action: "suggest-source", method: "POST", params: { url: "..." }, desc: "تشخیص خودکار نوع منبع از URL" },
      { action: "get-stats", method: "POST", desc: "آمار یادگیری" },
      { action: "get-cron-script", method: "POST", desc: "اسکریپت کرون لینوکس" },
    ],
  });
}
