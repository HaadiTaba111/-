import { NextResponse } from "next/server";
import { startDistillation, generateWithDistilledModel, TEACHER_MODELS, STUDENT_MODELS, getPythonTrainingScript, explainDistillation } from "@/lib/distilled-brain";

// POST: شروع فرآیند تقطیر
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      case "start": {
        const config = {
          teacherModel: params.teacherModel || "distilgpt2",
          studentModel: params.studentModel || "distilgpt2",
          epochs: params.epochs || 3,
          learningRate: params.learningRate || 2e-4,
          batchSize: params.batchSize || 4,
          maxLength: params.maxLength || 256,
          temperature: params.temperature || 4.0,
          alpha: params.alpha || 0.7,
          datasetName: params.datasetName || "persian_poetry",
          datasetSamples: params.datasetSamples || 50,
          quantize: params.quantize !== false,
          modelName: params.modelName || "Persian Brain Distilled",
        };

        // شبیه‌سازی فرآیند با پیشرفت
        const progressUpdates: any[] = [];
        const model = await startDistillation(config, (progress) => {
          progressUpdates.push(progress);
        });

        return NextResponse.json({
          success: true,
          message: `🧠 تقطیر "${config.modelName}" کامل شد!`,
          data: {
            model,
            progressLog: progressUpdates[progressUpdates.length - 1]?.log || [],
            summary: {
              teacherToStudent: `${config.teacherModel} → ${config.studentModel}`,
              size: `${model.sizeMB}MB`,
              accuracy: `${model.accuracy.toFixed(1)}%`,
              perplexity: model.perplexity.toFixed(2),
            },
          },
        });
      }

      case "generate": {
        const result = await generateWithDistilledModel(
          params.modelId || "distilgpt2",
          params.prompt || "",
          {
            temperature: params.temperature,
            maxLength: params.maxLength,
            topP: params.topP,
            repetitionPenalty: params.repetitionPenalty,
          }
        );

        return NextResponse.json({
          success: true,
          data: result,
        });
      }

      default:
        return NextResponse.json(
          { success: false, error: "فعالیت نامعتبر" },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در فرآیند تقطیر",
      },
      { status: 500 }
    );
  }
}

// GET: دریافت اطلاعات
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const type = searchParams.get("type") || "info";

  switch (type) {
    case "teachers":
      return NextResponse.json({ success: true, models: TEACHER_MODELS });
    case "students":
      return NextResponse.json({ success: true, models: STUDENT_MODELS });
    case "explain":
      return NextResponse.json({ success: true, explanation: explainDistillation() });
    case "python-script":
      return NextResponse.json({
        success: true,
        script: getPythonTrainingScript(),
        note: "این اسکریپت Python برای اجرا در Google Colab یا سرور GPU طراحی شده",
      });
    default:
      return NextResponse.json({
        success: true,
        available: [
          { action: "GET ?type=teachers", description: "لیست مدل‌های معلم (غول)" },
          { action: "GET ?type=students", description: "لیست مدل‌های شاگرد" },
          { action: "GET ?type=explain", description: "توضیح معماری تقطیر" },
          { action: "GET ?type=python-script", description: "دریافت اسکریپت Python" },
          { action: "POST {action:'start', ...}", description: "شروع فرآیند تقطیر" },
          { action: "POST {action:'generate', ...}", description: "تولید متن با مدل تقطیری" },
        ],
      });
  }
}
