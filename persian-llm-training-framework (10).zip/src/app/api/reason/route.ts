import { NextResponse } from "next/server";
import { reasonAndRespond, getReasoningMethodology, PITFALL_DATABASE } from "@/lib/reasoning-engine";
import { queryGemma, generateGemmaTrainingSet, GEMMA_SYSTEM_PROMPT, TRAINING_EXAMPLES } from "@/lib/gemma-connector";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      case "reason": {
        // تحلیل و پاسخ قدم‌قدم
        const result = reasonAndRespond(
          params.question || "",
          params.userName || "دوست"
        );
        return NextResponse.json({ success: true, data: result });
      }

      case "ask-gemma": {
        // سوال از Gemma (یا fallback به مغز داخلی)
        const result = await queryGemma(
          params.question || "",
          {
            systemPrompt: params.systemPrompt,
            maxTokens: params.maxTokens,
            temperature: params.temperature,
          }
        );
        return NextResponse.json({ success: result.success, data: result });
      }

      case "check-pitfall": {
        // بررسی اینکه سوال دام داره یا نه
        const result = reasonAndRespond(params.question || "");
        return NextResponse.json({
          success: true,
          data: {
            hasPitfall: result.detectedPitfalls.length > 0,
            pitfalls: result.detectedPitfalls,
            riskLevel: result.decomposition.riskLevel,
            isDistorted: result.distortionCheck.isDistorted,
          },
        });
      }

      case "get-pitfalls": {
        // دریافت همه چاه‌ها
        const category = params.category;
        const pitfalls = category
          ? PITFALL_DATABASE.filter(p => p.category === category)
          : PITFALL_DATABASE;
        return NextResponse.json({ success: true, count: pitfalls.length, data: pitfalls });
      }

      case "add-pitfall": {
        // اضافه کردن چاه جدید توسط کاربر
        if (!params.trapQuestion || !params.correctReasoning) {
          return NextResponse.json({ success: false, error: "سوال و روش درست الزامی است" }, { status: 400 });
        }
        const newPitfall = {
          id: `pitfall-${Date.now()}`,
          category: params.category || "عمومی",
          trapQuestion: params.trapQuestion,
          correctReasoning: params.correctReasoning,
          wrongAnswer: params.wrongAnswer || "",
          correctAnswer: params.correctAnswer || "",
          explanation: params.explanation || "",
          tags: params.tags || [],
          severity: params.severity || 2,
        };
        // ذخیره در localStorage (سمت کاربر)
        return NextResponse.json({
          success: true,
          message: "✅ چاه جدید ذخیره شد",
          data: newPitfall,
          note: "این چاه در session جاری ذخیره شد. برای دائمی کردن، به تیم توسعه بدهید.",
        });
      }

      case "get-methodology": {
        return NextResponse.json({
          success: true,
          data: getReasoningMethodology(),
        });
      }

      case "get-training-data": {
        // دیتاست آموزشی برای Gemma LoRA
        const dataset = generateGemmaTrainingSet();
        return NextResponse.json({ success: true, data: dataset });
      }

      case "get-system-prompt": {
        return NextResponse.json({ success: true, data: GEMMA_SYSTEM_PROMPT });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "🧠 موتور استدلال عمیق +Gemma Connector",
    description: "تجزیه سوال، تشخیص دام، قدم‌قدم جواب دادن، اتصال به Gemma Fine-tuned",
    actions: [
      { action: "reason", params: { question: "..." }, desc: "🧠 تحلیل و پاسخ قدم‌قدم" },
      { action: "ask-gemma", params: { question: "..." }, desc: "🤖 سوال از Gemma (با fallback)" },
      { action: "check-pitfall", params: { question: "..." }, desc: "🔍 بررسی دام در سوال" },
      { action: "get-pitfalls", desc: "📚 دریافت همه چاه‌ها" },
      { action: "add-pitfall", params: { trapQuestion: "...", correctReasoning: "..." }, desc: "➕ افزودن چاه جدید" },
      { action: "get-methodology", desc: "📋 متدولوژی جواب دادن" },
      { action: "get-training-data", desc: "📦 دیتاست آموزشی Gemma LoRA" },
    ],
    connectors: [
      { name: "Gemma Fine-tuned (LoRA)", status: process.env.GEMMA_API_URL ? "✅ متصل" : "🟡 fallback به مغز داخلی", env: "GEMMA_API_URL" },
      { name: "Persian Brain RAG", status: "✅ فعال" },
      { name: "Reasoning Engine", status: "✅ فعال" },
      { name: "Pitfall Database", status: `✅ ${PITFALL_DATABASE.length} چاه` },
    ],
  });
}
