import { NextResponse } from "next/server";
import { think } from "@/lib/persian-brain";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { modelId, prompt, temperature, maxLength, topP, repetitionPenalty } = body;

    if (!modelId) {
      return NextResponse.json(
        { success: false, error: "شناسه مدل الزامی است" },
        { status: 400 }
      );
    }

    if (!prompt) {
      return NextResponse.json(
        { success: false, error: "متن ورودی (prompt) الزامی است" },
        { status: 400 }
      );
    }

    const result = await think({
      modelId,
      prompt,
      temperature,
      maxLength,
      topP,
      repetitionPenalty,
    });

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در استنتاج",
      },
      { status: 500 }
    );
  }
}
