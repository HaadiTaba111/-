import { NextResponse } from "next/server";
import { db } from "@/db";
import { models, trainingSessions, inferenceLogs } from "@/db/schema";
import { eq, desc } from "drizzle-orm";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const modelId = parseInt(id, 10);

    if (isNaN(modelId)) {
      return NextResponse.json(
        { success: false, error: "شناسه مدل نامعتبر است" },
        { status: 400 }
      );
    }

    const [model] = await db
      .select()
      .from(models)
      .where(eq(models.id, modelId))
      .limit(1);

    if (!model) {
      return NextResponse.json(
        { success: false, error: "مدل یافت نشد" },
        { status: 404 }
      );
    }

    const sessions = await db
      .select()
      .from(trainingSessions)
      .where(eq(trainingSessions.modelId, modelId))
      .orderBy(desc(trainingSessions.createdAt))
      .limit(10);

    const inferences = await db
      .select()
      .from(inferenceLogs)
      .where(eq(inferenceLogs.modelId, modelId))
      .orderBy(desc(inferenceLogs.createdAt))
      .limit(20);

    return NextResponse.json({
      success: true,
      model,
      sessions,
      inferences,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در دریافت جزئیات مدل",
      },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const modelId = parseInt(id, 10);

    if (isNaN(modelId)) {
      return NextResponse.json(
        { success: false, error: "شناسه مدل نامعتبر است" },
        { status: 400 }
      );
    }

    await db.delete(models).where(eq(models.id, modelId));

    return NextResponse.json({
      success: true,
      message: "مدل با موفقیت حذف شد",
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در حذف مدل",
      },
      { status: 500 }
    );
  }
}
