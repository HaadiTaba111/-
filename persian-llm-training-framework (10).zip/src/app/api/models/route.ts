import { NextResponse } from "next/server";
import { db } from "@/db";
import { models } from "@/db/schema";
import { desc } from "drizzle-orm";

export async function GET() {
  try {
    const allModels = await db
      .select()
      .from(models)
      .orderBy(desc(models.createdAt));

    return NextResponse.json({
      success: true,
      count: allModels.length,
      models: allModels,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در دریافت مدل‌ها",
      },
      { status: 500 }
    );
  }
}
