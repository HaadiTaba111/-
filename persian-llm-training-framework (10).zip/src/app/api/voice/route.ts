import { NextResponse } from "next/server";

// ================================================================
// 🎤 Voice API برای مغز فارسی
// 
// این API پل ارتباطی بین:
// - Whisper (تشخیص گفتار فارسی)
// - مدل فاین‌تیون شده
// - VITS TTS (تولید صدای فارسی)
// 
// وقتی روی PC اجرا می‌شه، Whisper و TTS روی GPU کار می‌کنن
// ================================================================

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      // ===== تشخیص گفتار (Speech-to-Text) =====
      case "stt": {
        // این endpoint روی PC با Whisper کار می‌کنه
        // اینجا فقط شبیه‌سازی سمت مرورگر
        return NextResponse.json({
          success: true,
          data: {
            text: "این متن نمونه از تشخیص گفتار فارسی است",
            model: "Whisper tiny (local)",
            duration: "2.3s",
            note: "برای استفاده واقعی، Whisper روی PC نصب کن",
          },
          instructions: "برای نصب Whisper: pip install openai-whisper && python3 -c 'import whisper; model = whisper.load_model(\"tiny\"); result = model.transcribe(\"audio.wav\"); print(result[\"text\"])'",
        });
      }

      // ===== تولید گفتار (Text-to-Speech) =====
      case "tts": {
        if (!params.text) {
          return NextResponse.json({ success: false, error: "متن الزامی است" }, { status: 400 });
        }
        // این endpoint روی PC با VITS کار می‌کنه
        return NextResponse.json({
          success: true,
          data: {
            text: params.text,
            model: "VITS (local)",
            note: "برای خروجی صوتی واقعی: pip install TTS && tts --text '...' --model_name tts_models/fa/custom/farsi",
          },
          instructions: "برای نصب TTS: pip install TTS && tts-server --port 5002",
        });
      }

      // ===== بررسی وضعیت Voice =====
      case "status": {
        const hasWhisper = typeof process !== 'undefined';
        return NextResponse.json({
          success: true,
          data: {
            stt: {
              available: false,
              engine: "Whisper",
              description: "برای فعال‌سازی: pip install openai-whisper",
            },
            tts: {
              available: false,
              engine: "VITS (Coqui TTS)",
              description: "برای فعال‌سازی: pip install TTS",
            },
            recommendation: "روی PC با 8GB GPU هر دو به راحتی اجرا می‌شن",
          },
        });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      { success: false, error: error instanceof Error ? error.message : "خطای ناشناخته" },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "🎤 Voice Pipeline - مغز فارسی",
    description: "اتصال Whisper (STT) + VITS (TTS) به مغز فارسی",
    setup: {
      stt: "pip install openai-whisper",
      tts: "pip install TTS",
      model: "./train-pc.sh (برای فاین‌تیون)",
    },
    actions: [
      { action: "stt", desc: "🎤 تشخیص گفتار (Whisper)" },
      { action: "tts", params: { text: "..." }, desc: "🔊 تولید گفتار (VITS)" },
      { action: "status", desc: "📊 وضعیت Voice" },
    ],
  });
}
