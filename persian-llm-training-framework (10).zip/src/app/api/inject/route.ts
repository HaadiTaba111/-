import { NextResponse } from "next/server";
import { classifyMode, getModeSystemPrompt } from "@/lib/response-mode";
import { comparePositionalEncodings, DEFAULT_SPIRAL_CONFIG } from "@/lib/spiral-time";
import { extractVersesFromDocument, extractConversations, injectDocumentToBrain, searchInjectedDocuments, getDocumentStats, injectPlainText } from "@/lib/pdf-injector";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      // ===== تزریق متن =====
      case "inject-text": {
        if (!params.text) {
          return NextResponse.json({ success: false, error: "متن الزامی است" }, { status: 400 });
        }
        const doc = injectPlainText(params.text, {
          title: params.title,
          type: params.type,
          poet: params.poet,
          tags: params.tags,
        });
        return NextResponse.json({
          success: true,
          message: `✅ "${doc.title}" با ${doc.verses.length} بیت و ${doc.conversations.length} گفتگو تزریق شد`,
          data: doc,
        });
      }

      // ===== جستجو در اسناد =====
      case "search-docs": {
        const results = searchInjectedDocuments(params.query || "");
        return NextResponse.json({ success: true, count: results.length, data: results });
      }

      // ===== آمار اسناد =====
      case "doc-stats": {
        const stats = getDocumentStats();
        return NextResponse.json({ success: true, data: stats });
      }

      // ===== تشخیص حالت پاسخ =====
      case "classify-mode": {
        if (!params.text) {
          return NextResponse.json({ success: false, error: "متن الزامی است" }, { status: 400 });
        }
        const mode = classifyMode(params.text);
        const systemPrompt = getModeSystemPrompt(mode.mode);
        return NextResponse.json({ success: true, data: { mode, systemPrompt } });
      }

      // ===== معماری اسپیرال =====
      case "spiral-info": {
        return NextResponse.json({
          success: true,
          data: {
            comparison: comparePositionalEncodings(),
            config: DEFAULT_SPIRAL_CONFIG,
            note: "اسپیرال جایگزین sin/cos در Positional Encoding میشه. زمان باعث محو اطلاعات قدیمی میشه.",
          },
        });
      }

      // ===== اسپیرال position =====
      case "spiral-position": {
        const { spiralPosition } = require("@/lib/spiral-time");
        const pos = spiralPosition(params.position || 0, DEFAULT_SPIRAL_CONFIG);
        return NextResponse.json({ success: true, data: pos });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" شناخته نشد` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "📄 سامانه تزریق + تشخیص حالت + اسپیرال-تایم",
    description: "PDF/متن تزریق کن | تشخیص جدی/شعری/گفتگو | معماری اسپیرال-تایم",
    actions: [
      { action: "inject-text", params: { text: "...", title: "..." }, desc: "📄 تزریق متن به مغز" },
      { action: "search-docs", params: { query: "..." }, desc: "🔍 جستجوی اسناد تزریق شده" },
      { action: "classify-mode", params: { text: "..." }, desc: "🎭 تشخیص حالت جدی/شعری/گفتگو" },
      { action: "spiral-info", desc: "🌀 توضیحات معماری اسپیرال" },
      { action: "spiral-position", params: { position: 42 }, desc: "📍 موقعیت اسپیرال ۳بعدی" },
    ],
  });
}
