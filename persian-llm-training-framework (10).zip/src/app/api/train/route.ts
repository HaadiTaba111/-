import { NextResponse } from "next/server";
import { createModel, startTraining } from "@/lib/persian-brain";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const {
      modelName,
      description,
      baseModel = "facebook/opt-125m",
      datasetIds = ["persian_poetry"],
      learningRate = 3e-5,
      epochs = 3,
      batchSize = 8,
      maxLength = 256,
      temperature = 0.7,
      topP = 0.9,
      repetitionPenalty = 1.1,
      numSamples = 10,
    } = body;

    if (!modelName) {
      return NextResponse.json(
        { success: false, error: "نام مدل الزامی است" },
        { status: 400 }
      );
    }

    // ایجاد مدل
    const model = await createModel({
      name: modelName,
      description,
      baseModel,
      temperature,
      topP,
      maxLength,
      repetitionPenalty,
    });

    // شروع آموزش
    const result = await startTraining(model.id, {
      modelName,
      baseModel,
      datasetIds,
      learningRate,
      epochs,
      batchSize,
      maxLength,
      temperature,
      topP,
      repetitionPenalty,
      numSamples,
    });

    return NextResponse.json({
      success: true,
      message: `آموزش مدل "${modelName}" با موفقیت آغاز شد`,
      data: {
        model: result.model,
        session: result.session,
        epochLogs: result.epochLogs,
        trainingSamples: result.trainingData.length,
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در آموزش مدل",
      },
      { status: 500 }
    );
  }
}
