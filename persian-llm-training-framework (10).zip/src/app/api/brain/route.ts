import { NextResponse } from "next/server";
import {
  unifiedThink,
  injectLink,
  injectText,
  searchInjectedSources,
  generateTrainingDataset,
  getExperienceStats,
  exportBrain,
  importBrain,
} from "@/lib/unified-brain";
import { explainDistillation, getPythonTrainingScript } from "@/lib/distilled-brain";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, ...params } = body;

    switch (action) {
      // ===== مغز واحد =====
      case "think": {
        const result = unifiedThink(params.input || "", {
          userName: params.userName,
          temperature: params.temperature,
          preferDistilled: params.preferDistilled,
          saveExperience: params.saveExperience !== false,
        });
        return NextResponse.json({ success: true, data: result });
      }

      // ===== تزریق لینک =====
      case "inject-link": {
        if (!params.url) {
          return NextResponse.json({ success: false, error: "URL الزامی است" }, { status: 400 });
        }
        const source = await injectLink(params.url, {
          poet: params.poet,
          tags: params.tags,
          title: params.title,
        });
        return NextResponse.json({
          success: true,
          message: `✅ لینک "${source.title}" با ${source.verses.length} بیت تزریق شد`,
          data: source,
        });
      }

      // ===== تزریق متن =====
      case "inject-text": {
        if (!params.text) {
          return NextResponse.json({ success: false, error: "متن الزامی است" }, { status: 400 });
        }
        const source = injectText(params.text, {
          title: params.title,
          poet: params.poet,
          tags: params.tags,
          type: params.type,
        });
        return NextResponse.json({
          success: true,
          message: `✅ متن "${source.title}" با ${source.verses.length} بیت تزریق شد`,
          data: source,
        });
      }

      // ===== جستجو در منابع تزریق شده =====
      case "search-injected": {
        const results = searchInjectedSources(params.query || "");
        return NextResponse.json({ success: true, count: results.length, data: results });
      }

      // ===== تولید دیتاست آموزشی =====
      case "generate-dataset": {
        const dataset = generateTrainingDataset({
          minRating: params.minRating,
          maxSamples: params.maxSamples,
          includeTopics: params.includeTopics,
          format: params.format || "json",
        });
        return NextResponse.json({ success: true, data: dataset });
      }

      // ===== آمار تجارب =====
      case "experience-stats": {
        const stats = getExperienceStats();
        return NextResponse.json({ success: true, data: stats });
      }

      // ===== بک‌آپ گرفتن =====
      case "export": {
        const brainData = exportBrain();
        return NextResponse.json({ success: true, data: brainData });
      }

      // ===== ریستور از بک‌آپ =====
      case "import": {
        if (!params.data) {
          return NextResponse.json({ success: false, error: "دیتا الزامی است" }, { status: 400 });
        }
        const ok = importBrain(params.data);
        return NextResponse.json({
          success: ok,
          message: ok ? "✅ مغز با success بازیابی شد" : "❌ خطا در بازیابی",
        });
      }

      // ===== توضیحات تقطیر =====
      case "explain-distill": {
        return NextResponse.json({ success: true, data: explainDistillation() });
      }

      // ===== اسکریپت Python =====
      case "python-script": {
        return NextResponse.json({ success: true, data: getPythonTrainingScript() });
      }

      default:
        return NextResponse.json(
          { success: false, error: `فعالیت "${action}" ناشناخته است` },
          { status: 400 }
        );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطای ناشناخته",
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    name: "🧠 مغز واحد فارسی v3.0",
    description: "تزریقی + تقطیری + تجربه‌آموز + تزریق لینک",
    actions: [
      { post: { action: "think", input: "..." }, desc: "تفکر با مغز واحد" },
      { post: { action: "inject-link", url: "..." }, desc: "تزریق لینک به مغز" },
      { post: { action: "inject-text", text: "..." }, desc: "تزریق مستقیم متن" },
      { post: { action: "search-injected", query: "..." }, desc: "جستجو در منابع تزریق شده" },
      { post: { action: "generate-dataset" }, desc: "تولید دیتاست از تجارب" },
      { post: { action: "experience-stats" }, desc: "آمار تجارب" },
      { post: { action: "export" }, desc: "بک‌آپ کامل مغز" },
      { post: { action: "import", data: "..." }, desc: "بازیابی مغز از بک‌آپ" },
    ],
  });
}
