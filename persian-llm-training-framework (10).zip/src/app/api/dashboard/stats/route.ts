import { NextResponse } from "next/server";
import { getDashboardStats } from "@/lib/persian-brain";

export async function GET() {
  try {
    const stats = await getDashboardStats();

    return NextResponse.json({
      success: true,
      stats,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "خطا در دریافت آمار داشبورد",
      },
      { status: 500 }
    );
  }
}
