"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

interface TeacherModel {
  id: string;
  name: string;
  params: string;
  lang: string;
  size: string;
  tier: string;
}

interface DistilledModel {
  id: string;
  name: string;
  teacherModel: string;
  studentModel: string;
  baseArchitecture: string;
  parameters: string;
  sizeMB: number;
  accuracy: number;
  perplexity: number;
  createdAt: string;
  isDownloaded: boolean;
}

interface ProgressInfo {
  stage: string;
  progress: number;
  currentEpoch: number;
  totalEpochs: number;
  teacherLoss?: number;
  studentLoss?: number;
  accuracy?: number;
  log?: string[];
}

export default function DistillPage() {
  const [teachers, setTeachers] = useState<TeacherModel[]>([]);
  const [progress, setProgress] = useState<ProgressInfo | null>(null);
  const [result, setResult] = useState<DistilledModel | null>(null);
  const [distilledModels, setDistilledModels] = useState<DistilledModel[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [showDetails, setShowDetails] = useState(false);

  // فرم تنظیمات
  const [config, setConfig] = useState({
    modelName: "مغز تقطیری فارسی",
    teacherModel: "microsoft/phi-2",
    studentModel: "distilgpt2",
    epochs: 3,
    learningRate: 2e-4,
    temperature: 4.0,
    alpha: 0.7,
    quantize: true,
    datasetName: "persian_poetry",
    datasetSamples: 50,
  });

  useEffect(() => {
    // بارگیری مدل‌های معلم
    fetch("/api/distill?type=teachers")
      .then((r) => r.json())
      .then((d) => {
        if (d.success) setTeachers(d.models);
      });
  }, []);

  const startDistillation = async () => {
    setError(null);
    setResult(null);
    setProgress({
      stage: "downloading",
      progress: 0,
      currentEpoch: 0,
      totalEpochs: config.epochs,
      log: ["🧪 شروع فرآیند تقطیر..."],
    });

    try {
      const res = await fetch("/api/distill", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "start", ...config }),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.data.model);
        setProgress((prev) => prev ? {
          ...prev,
          stage: "complete",
          progress: 100,
          log: data.data.progressLog || [],
        } : null);

        // ذخیره در localStorage
        const existing = JSON.parse(localStorage.getItem("distilled-models") || "[]");
        existing.push(data.data.model);
        localStorage.setItem("distilled-models", JSON.stringify(existing));
        setDistilledModels(existing);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError("خطا در ارتباط با سرور");
    }
  };

  // بارگیری مدل‌های ذخیره شده
  useEffect(() => {
    const stored = JSON.parse(localStorage.getItem("distilled-models") || "[]");
    setDistilledModels(stored);
  }, []);

  const stageLabels: Record<string, string> = {
    downloading: "📥 دانلود مدل معلم",
    tokenizing: "📝 توکنایز کردن دیتاست",
    training: "🎯 فاین‌تیون کردن",
    distilling: "🧪 تقطیر دانش",
    quantizing: "📦 کوانتایز کردن",
    exporting: "📤 خروجی نهایی",
    complete: "✅ تکمیل شد!",
    error: "❌ خطا",
  };

  const stageColors: Record<string, string> = {
    downloading: "#6366f1",
    tokenizing: "#a855f7",
    training: "#f59e0b",
    distilling: "#22c55e",
    quantizing: "#3b82f6",
    exporting: "#6366f1",
    complete: "#22c55e",
    error: "#ef4444",
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in pb-12">
      {/* ===== HEADER ===== */}
      <div className="text-center space-y-3 py-6">
        <div className="inline-block text-5xl mb-2 animate-float">🧪</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] via-[#a855f7] to-[#ec4899] bg-clip-text text-transparent">
          تقطیر مغز فارسی 🧠⚡
        </h1>
        <p className="text-[#94a3b8] max-w-2xl mx-auto">
          از غول‌های HuggingFace دانش می‌گیریم و به مدل‌های کوچک و آفلاین تقطیر می‌کنیم<br />
          <span className="text-[#6366f1] text-sm">Teacher → Knowledge Distillation → Student (آفلاین)</span>
        </p>
      </div>

      {/* ===== STATS BANNER ===== */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-gradient-to-br from-[#6366f1]/20 to-[#6366f1]/5 border border-[#6366f1]/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-[#6366f1]">{teachers.length}</p>
          <p className="text-xs text-[#94a3b8]">مدل معلم</p>
        </div>
        <div className="bg-gradient-to-br from-[#a855f7]/20 to-[#a855f7]/5 border border-[#a855f7]/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-[#a855f7]">۸۲M→۷B</p>
          <p className="text-xs text-[#94a3b8]">طیف پارامتر</p>
        </div>
        <div className="bg-gradient-to-br from-emerald-500/20 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-emerald-400">{distilledModels.length}</p>
          <p className="text-xs text-[#94a3b8]">مدل تقطیری</p>
        </div>
        <div className="bg-gradient-to-br from-amber-500/20 to-amber-500/5 border border-amber-500/30 rounded-2xl p-4 text-center">
          <p className="text-2xl font-bold text-amber-400">۱۰۰٪</p>
          <p className="text-xs text-[#94a3b8]">آفلاین</p>
        </div>
      </div>

      {/* ===== ERROR ===== */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4 text-center animate-slide-in">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* ===== LEFT: Config Form ===== */}
        <div className="lg:col-span-3 space-y-6">
          {/* Teacher Selection */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>🏋️</span> مدل معلم (Teacher - غول HuggingFace)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {teachers.map((teacher) => (
                <button
                  key={teacher.id}
                  onClick={() => setConfig({ ...config, teacherModel: teacher.id })}
                  className={`text-right p-4 rounded-xl border transition-all duration-200 ${
                    config.teacherModel === teacher.id
                      ? "bg-[#6366f1]/20 border-[#6366f1] shadow-[0_0_15px_rgba(99,102,241,0.15)]"
                      : "bg-[#0f172a]/50 border-[#334155] hover:border-[#475569]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-white text-sm">{teacher.name}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      teacher.tier === "فوق سبک" ? "bg-emerald-500/20 text-emerald-400" :
                      teacher.tier === "سبک" ? "bg-blue-500/20 text-blue-400" :
                      teacher.tier === "متوسط" ? "bg-amber-500/20 text-amber-400" :
                      "bg-red-500/20 text-red-400"
                    }`}>{teacher.tier}</span>
                  </div>
                  <div className="flex gap-2 mt-2 text-[10px] text-[#64748b]">
                    <span>{teacher.params} پارامتر</span>
                    <span>•</span>
                    <span>{teacher.size}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Config Form */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>⚙️</span> پارامترهای تقطیر
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">نام مدل</label>
                <input
                  type="text"
                  value={config.modelName}
                  onChange={(e) => setConfig({ ...config, modelName: e.target.value })}
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-white text-sm focus:border-[#6366f1] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">مدل شاگرد (مقصد تقطیر)</label>
                <select
                  value={config.studentModel}
                  onChange={(e) => setConfig({ ...config, studentModel: e.target.value })}
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-white text-sm focus:border-[#6366f1] focus:outline-none"
                >
                  <option value="distilgpt2">DistilGPT2 (۸۲M - فوق سبک) ✅ آفلاین</option>
                  <option value="facebook/opt-125m">OPT-125M (۱۲۵M - سبک) ✅ آفلاین</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">Epochs: {config.epochs}</label>
                <input type="range" min={1} max={10} value={config.epochs}
                  onChange={(e) => setConfig({ ...config, epochs: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1]" />
              </div>
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">دما: {config.temperature.toFixed(1)}</label>
                <input type="range" min={1} max={10} step={0.5} value={config.temperature}
                  onChange={(e) => setConfig({ ...config, temperature: parseFloat(e.target.value) })}
                  className="w-full accent-[#a855f7]" />
              </div>
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">Alpha: {config.alpha.toFixed(2)}</label>
                <input type="range" min={0.1} max={1.0} step={0.05} value={config.alpha}
                  onChange={(e) => setConfig({ ...config, alpha: parseFloat(e.target.value) })}
                  className="w-full accent-[#22c55e]" />
              </div>
              <div>
                <label className="block text-xs text-[#94a3b8] mb-1">نمونه: {config.datasetSamples}</label>
                <input type="range" min={10} max={200} step={10} value={config.datasetSamples}
                  onChange={(e) => setConfig({ ...config, datasetSamples: parseInt(e.target.value) })}
                  className="w-full accent-[#f59e0b]" />
              </div>
            </div>

            <label className="flex items-center gap-2 mt-4 text-sm text-[#94a3b8] cursor-pointer">
              <input
                type="checkbox"
                checked={config.quantize}
                onChange={(e) => setConfig({ ...config, quantize: e.target.checked })}
                className="accent-[#6366f1]"
              />
              کوانتایز کردن برای آفلاین (INT8 - کاهش سایز ۴x)
            </label>

            <button
              onClick={startDistillation}
              disabled={!!progress && progress.stage !== 'complete' && progress.stage !== 'error'}
              className="w-full mt-5 bg-gradient-to-l from-[#6366f1] via-[#a855f7] to-[#ec4899] hover:from-[#4f46e5] hover:to-[#db2777] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all shadow-lg"
            >
              <span className="flex items-center justify-center gap-2">
                <span>🧪</span>
                {progress?.stage === "complete" ? "🔄 تقطیر مجدد" : 
                 progress ? `در حال ${stageLabels[progress.stage]}...` : 
                 "شروع فرآیند تقطیر"}
              </span>
            </button>
          </div>

          {/* Result */}
          {result && (
            <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-6 animate-slide-in">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2 text-emerald-400">
                <span>✅</span> مدل تقطیر شده: {result.name}
              </h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">Teacher → Student</p>
                  <p className="text-white font-medium mt-1 text-xs">{result.teacherModel} → {result.studentModel}</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">معماری</p>
                  <p className="text-white font-medium mt-1">{result.baseArchitecture}</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">پارامترها</p>
                  <p className="text-white font-medium mt-1">{result.parameters}</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">سایز آفلاین</p>
                  <p className="text-white font-medium mt-1">{result.sizeMB}MB</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">دقت (Accuracy)</p>
                  <p className="text-emerald-400 font-medium mt-1">{result.accuracy.toFixed(1)}%</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-3">
                  <p className="text-[#64748b] text-xs">Perplexity</p>
                  <p className="text-amber-400 font-medium mt-1">{result.perplexity.toFixed(2)}</p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* ===== RIGHT: Progress & Info ===== */}
        <div className="lg:col-span-2 space-y-6">
          {/* Progress Pipeline */}
          {progress && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6 animate-slide-in">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <span>📊</span> خط لوله تقطیر
              </h3>

              {/* Progress Bar */}
              <div className="relative mb-6">
                <div className="w-full bg-[#0f172a] rounded-full h-3 overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500 ease-out"
                    style={{
                      width: `${progress.progress}%`,
                      background: `linear-gradient(90deg, #6366f1, #a855f7, #22c55e)`,
                    }}
                  />
                </div>
                <p className="text-center text-xs text-[#94a3b8] mt-1">{progress.progress.toFixed(0)}%</p>
              </div>

              {/* Stages Pipeline */}
              <div className="space-y-2">
                {["downloading", "tokenizing", "training", "distilling", "quantizing", "exporting", "complete"].map((stage) => {
                  const stages = ["downloading", "tokenizing", "training", "distilling", "quantizing", "exporting", "complete"];
                  const currentIndex = stages.indexOf(progress.stage);
                  const stageIndex = stages.indexOf(stage);
                  const isDone = stageIndex < currentIndex;
                  const isCurrent = stage === progress.stage;
                  const isPending = stageIndex > currentIndex;

                  return (
                    <div
                      key={stage}
                      className={`flex items-center gap-3 p-2.5 rounded-xl border text-sm transition-all ${
                        isDone ? "bg-emerald-500/10 border-emerald-500/20 text-emerald-400" :
                        isCurrent ? "bg-[#6366f1]/10 border-[#6366f1]/30 text-white" :
                        "bg-[#0f172a]/30 border-[#334155] text-[#64748b]"
                      }`}
                    >
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${
                        isDone ? "bg-emerald-500/20" :
                        isCurrent ? "bg-[#6366f1]/20 animate-pulse" :
                        "bg-[#1e293b]"
                      }`}>
                        {isDone ? "✓" : isCurrent ? "●" : "○"}
                      </span>
                      <span className={`flex-1 ${isCurrent ? 'font-medium' : ''}`}>
                        {stageLabels[stage] || stage}
                      </span>
                      {isDone && <span className="text-[10px]">✅</span>}
                    </div>
                  );
                })}
              </div>

              {/* Metrics */}
              {progress.stage === "training" || progress.stage === "distilling" ? (
                <div className="mt-4 grid grid-cols-2 gap-2">
                  {progress.teacherLoss && (
                    <div className="bg-[#0f172a]/50 rounded-xl p-2 text-center">
                      <p className="text-[10px] text-[#64748b]">Teacher Loss</p>
                      <p className="text-sm font-bold text-amber-400">{progress.teacherLoss.toFixed(4)}</p>
                    </div>
                  )}
                  {progress.studentLoss && (
                    <div className="bg-[#0f172a]/50 rounded-xl p-2 text-center">
                      <p className="text-[10px] text-[#64748b]">Student Loss</p>
                      <p className="text-sm font-bold text-emerald-400">{progress.studentLoss.toFixed(4)}</p>
                    </div>
                  )}
                  {progress.accuracy && (
                    <div className="bg-[#0f172a]/50 rounded-xl p-2 text-center">
                      <p className="text-[10px] text-[#64748b]">Epoch</p>
                      <p className="text-sm font-bold text-white">{progress.currentEpoch}/{progress.totalEpochs}</p>
                    </div>
                  )}
                  {progress.accuracy && (
                    <div className="bg-[#0f172a]/50 rounded-xl p-2 text-center">
                      <p className="text-[10px] text-[#64748b]">Accuracy</p>
                      <p className="text-sm font-bold text-emerald-400">{progress.accuracy.toFixed(1)}%</p>
                    </div>
                  )}
                </div>
              ) : null}

              {/* Console Log */}
              {progress.log && progress.log.length > 0 && (
                <div className="mt-4">
                  <button
                    onClick={() => setShowDetails(!showDetails)}
                    className="text-xs text-[#6366f1] hover:underline"
                  >
                    {showDetails ? "🙈 مخفی کردن لاگ" : "📝 نمایش لاگ دقیق"}
                  </button>
                  {showDetails && (
                    <div className="mt-2 bg-[#0f172a] rounded-xl p-3 max-h-40 overflow-y-auto font-mono text-[10px] leading-6">
                      {progress.log.map((line, i) => (
                        <p key={i} className="text-[#94a3b8]">
                          <span className="text-[#475569]">[{i}]</span> {line}
                        </p>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Distilled Models Library */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📚</span> کتابخانه مدل‌های تقطیری
            </h3>
            {distilledModels.length === 0 ? (
              <div className="text-center py-6">
                <p className="text-3xl mb-2">🧪</p>
                <p className="text-[#64748b] text-sm">هنوز مدلی تقطیر نشده</p>
                <p className="text-[#475569] text-xs mt-1">فرم سمت چپ رو پر کن و شروع کن!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {distilledModels.map((model, i) => (
                  <div key={i} className="bg-[#0f172a]/50 border border-[#334155] rounded-xl p-4 hover:border-[#6366f1]/30 transition-all">
                    <div className="flex items-center justify-between">
                      <p className="font-medium text-white text-sm">{model.name}</p>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                        {model.sizeMB}MB
                      </span>
                    </div>
                    <div className="flex gap-2 mt-2 text-[10px] text-[#64748b]">
                      <span>🎯 {model.accuracy.toFixed(1)}%</span>
                      <span>•</span>
                      <span>{model.parameters}</span>
                      <span>•</span>
                      <span>📅 {new Date(model.createdAt).toLocaleDateString("fa-IR")}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Architecture Info */}
          <div className="bg-gradient-to-br from-[#6366f1]/5 to-[#a855f7]/5 border border-[#334155] rounded-2xl p-6">
            <button
              onClick={() => setShowDetails(!showDetails)}
              className="w-full text-right"
            >
              <h3 className="font-semibold flex items-center gap-2 text-sm">
                <span>🏗️</span> معماری تقطیر: Teacher → Student
              </h3>
            </button>
            {showDetails && (
              <div className="mt-4 space-y-3 text-sm">
                <div className="bg-[#0f172a]/30 rounded-xl p-3">
                  <p className="text-[#6366f1] font-medium">📐 فرمول Loss</p>
                  <p className="text-[#94a3b8] mt-1 text-xs font-mono ltr text-left">
                    Loss = α · KL(softmax(T_logits/T) || softmax(S_logits/T)) · T² + (1−α) · CE(S_logits, labels)
                  </p>
                </div>
                <div className="bg-[#0f172a]/30 rounded-xl p-3">
                  <p className="text-[#a855f7] font-medium">🎯 مراحل</p>
                  <ul className="text-[#94a3b8] mt-1 text-xs space-y-1">
                    <li>۱. Teacher مدل بزرگ رو از HF می‌گیریم</li>
                    <li>۲. با LoRA فاین‌تیون می‌کنیم روی اشعار فارسی</li>
                    <li>۳. Student (کوچک) رو از خروجی Teacher یاد می‌گیره</li>
                    <li>۴. کوانتایز می‌کنیم برای اجرای آفلاین</li>
                  </ul>
                </div>
              </div>
            )}
          </div>

          {/* Python Script Download */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <span>🐍</span> اسکریپت Python برای GPU شخصی
            </h3>
            <p className="text-sm text-[#94a3b8] mb-4">
              برای اجرا در Google Colab یا سرور GPU شخصی خودت با PyTorch و HuggingFace
            </p>
            <Link
              href="/api/distill?type=python-script"
              target="_blank"
              className="inline-flex items-center gap-2 bg-gradient-to-l from-[#6366f1] to-[#4f46e5] px-5 py-2.5 rounded-xl text-sm font-medium hover:shadow-lg transition-all"
            >
              <span>📥</span> دریافت اسکریپت Python
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
