"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Model {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  baseModel: string;
  temperature: number;
  topP: number;
  maxLength: number;
  repetitionPenalty: number;
  totalTrainingTokens: number;
  trainingEpochs: number;
  learningRate: number;
  status: string;
  datasetSources: string[];
  createdAt: string;
  updatedAt: string;
}

export default function ModelsPage() {
  const [models, setModels] = useState<Model[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchModels();
  }, []);

  const fetchModels = async () => {
    try {
      const res = await fetch("/api/models");
      const data = await res.json();
      if (data.success) {
        setModels(data.models);
      }
    } catch (err) {
      console.error("خطا:", err);
    } finally {
      setLoading(false);
    }
  };

  const deleteModel = async (id: number) => {
    if (!confirm("آیا از حذف این مدل اطمینان دارید؟")) return;
    try {
      const res = await fetch(`/api/models/${id}`, { method: "DELETE" });
      const data = await res.json();
      if (data.success) {
        setModels(models.filter((m) => m.id !== id));
      }
    } catch (err) {
      console.error("خطا در حذف:", err);
    }
  };

  const getStatusStyle = (status: string) => {
    const styles: Record<string, string> = {
      trained: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
      training: "bg-blue-500/20 text-blue-400 border-blue-500/30",
      created: "bg-amber-500/20 text-amber-400 border-amber-500/30",
      untrained: "bg-slate-500/20 text-slate-400 border-slate-500/30",
      failed: "bg-red-500/20 text-red-400 border-red-500/30",
    };
    const labels: Record<string, string> = {
      trained: "آموزش دیده ✅",
      training: "در حال آموزش 🔄",
      created: "ایجاد شده 📝",
      untrained: "آموزش ندیده ⏳",
      failed: "خطا ❌",
    };
    return {
      className: `px-2.5 py-1 rounded-full text-xs border ${styles[status] || styles.untrained}`,
      label: labels[status] || status,
    };
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in">
      {/* هدر */}
      <div className="flex items-center justify-between py-4">
        <div>
          <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">
            🤖 مدل‌های مغز
          </h1>
          <p className="text-[#94a3b8] mt-1">مدیریت مدل‌های آموزش دیده و ایجاد شده</p>
        </div>
        <Link
          href="/train"
          className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] px-5 py-2.5 rounded-xl text-sm font-medium hover:shadow-lg hover:shadow-[#6366f1]/25 transition-all duration-300"
        >
          + مدل جدید
        </Link>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-12 h-12 border-4 border-[#334155] border-t-[#6366f1] rounded-full animate-spin" />
        </div>
      ) : models.length === 0 ? (
        <div className="text-center py-20 bg-[#1e293b]/50 rounded-3xl border border-[#334155]">
          <div className="text-5xl mb-4">🧠</div>
          <p className="text-xl text-[#94a3b8]">هنوز مدلی ساخته نشده است</p>
          <p className="text-sm text-[#64748b] mt-2">اولین مغز فارسی خود را آموزش دهید</p>
          <Link
            href="/train"
            className="inline-block mt-6 bg-gradient-to-l from-[#6366f1] to-[#4f46e5] px-6 py-3 rounded-xl font-medium hover:shadow-lg transition-all"
          >
            شروع آموزش
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {models.map((model) => {
            const status = getStatusStyle(model.status);
            return (
              <div
                key={model.id}
                className="group bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6 hover:border-[#6366f1]/50 transition-all duration-300"
              >
                {/* هدر کارت */}
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h3 className="text-lg font-bold text-white group-hover:text-[#6366f1] transition-colors">
                      {model.name}
                    </h3>
                    {model.description && (
                      <p className="text-xs text-[#64748b] mt-0.5">{model.description}</p>
                    )}
                  </div>
                  <span className={status.className}>{status.label}</span>
                </div>

                {/* جزئیات */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-[#64748b]">مدل پایه</span>
                    <span className="text-white">{model.baseModel.split("/").pop()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#64748b]">دمای تفکر</span>
                    <span className="text-white">{model.temperature}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#64748b]">تعداد Epoch</span>
                    <span className="text-white">{model.trainingEpochs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#64748b]">توکن‌های آموزش</span>
                    <span className="text-white">{model.totalTrainingTokens.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#64748b]">تاریخ ساخت</span>
                    <span className="text-white text-xs">
                      {new Date(model.createdAt).toLocaleDateString("fa-IR")}
                    </span>
                  </div>
                </div>

                {/* دیتاست‌ها */}
                {model.datasetSources && model.datasetSources.length > 0 && (
                  <div className="mt-3 flex flex-wrap gap-1">
                    {model.datasetSources.map((ds, i) => (
                      <span key={i} className="text-[10px] px-2 py-0.5 rounded-full bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20">
                        {ds}
                      </span>
                    ))}
                  </div>
                )}

                {/* دکمه‌ها */}
                <div className="flex gap-2 mt-4 pt-4 border-t border-[#334155]">
                  <Link
                    href={`/inference?modelId=${model.id}`}
                    className="flex-1 bg-[#6366f1]/20 border border-[#6366f1]/30 rounded-xl py-2 text-center text-xs text-[#6366f1] hover:bg-[#6366f1]/30 transition-colors"
                  >
                    💭 تفکر
                  </Link>
                  <button
                    onClick={() => deleteModel(model.id)}
                    className="px-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 hover:bg-red-500/20 transition-colors"
                  >
                    🗑
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
