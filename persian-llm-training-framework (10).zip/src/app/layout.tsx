import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "🧠 مغز فارسی - Persian Brain AI",
  description: "سیستم آموزش و استنتاج هوش مصنوعی با متون و اشعار فارسی",
};

const navItems = [
  { href: "/", label: "داشبورد", icon: "📊" },
  { href: "/control-panel", label: "کنترل پنل 🎛️", icon: "🎛️" },
  { href: "/poet", label: "شاعر ماشین", icon: "🖋️" },
  { href: "/companion", label: "همراه", icon: "🗣️" },
  { href: "/brain", label: "مغز واحد", icon: "🧠" },
  { href: "/auto-learn", label: "یادگیری خودکار", icon: "🤖" },
  { href: "/distill", label: "تقطیر", icon: "🧪" },
  { href: "/inference", label: "تفکر", icon: "💭" },
];

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body className="bg-[#0f172a] text-[#f1f5f9] antialiased min-h-screen">
        {/* نویگیشن */}
        <nav className="fixed top-0 right-0 left-0 z-50 backdrop-blur-xl bg-[#0f172a]/80 border-b border-[#334155]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              {/* لوگو */}
              <Link href="/" className="flex items-center gap-2 text-lg font-bold">
                <span className="text-2xl">🧠</span>
                <span className="bg-gradient-to-l from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">
                  مغز فارسی
                </span>
                <span className="text-xs text-[#64748b] font-normal hidden sm:inline">
                  v1.0
                </span>
              </Link>

              {/* لینک‌ها */}
              <div className="flex items-center gap-1">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm text-[#94a3b8] hover:text-white hover:bg-[#1e293b] transition-all duration-200"
                  >
                    <span>{item.icon}</span>
                    <span className="hidden sm:inline">{item.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </nav>

        {/* محتوای اصلی */}
        <main className="pt-20 pb-12">
          {children}
        </main>

        {/* فوتر */}
        <footer className="border-t border-[#334155] py-6 text-center text-sm text-[#64748b]">
          <p>🧠 مغز فارسی - Persian Brain AI | ساخته شده با عشق برای ادبیات و فرهنگ ایران</p>
        </footer>
      </body>
    </html>
  );
}
