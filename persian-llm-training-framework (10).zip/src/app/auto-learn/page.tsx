"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function AutoLearnPage() {
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [learning, setLearning] = useState(false);
  const [progress, setProgress] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);
  const [linkUrl, setLinkUrl] = useState("");
  const [linkName, setLinkName] = useState("");
  const [linkResult, setLinkResult] = useState<any>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/auto-learn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "get-stats" }),
      });
      const data = await res.json();
      if (data.success) setStats(data.data);
    } catch {}
  };

  const learnAll = async () => {
    setLearning(true);
    setError(null);
    setProgress({});
    
    try {
      const res = await fetch("/api/auto-learn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "learn-all" }),
      });
      const data = await res.json();
      if (!data.success) setError(data.error);
      fetchStats();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLearning(false);
    }
  };

  const addSource = async () => {
    if (!linkUrl.trim()) return;
    setLoading(true);
    setLinkResult(null);
    setError(null);
    
    try {
      const res = await fetch("/api/auto-learn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "add-source",
          url: linkUrl.trim(),
          name: linkName.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setLinkResult(data.data);
        setLinkUrl("");
        setLinkName("");
        fetchStats();
      } else setError(data.error);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const toggleSource = async (sourceId: string) => {
    await fetch("/api/auto-learn", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "toggle-source", sourceId }),
    });
    fetchStats();
  };

  const removeSource = async (sourceId: string) => {
    await fetch("/api/auto-learn", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "remove-source", sourceId }),
    });
    fetchStats();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in pb-12">
      {/* HEADER */}
      <div className="text-center space-y-3 py-6">
        <div className="inline-block text-5xl mb-2 animate-float">🤖</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-emerald-400 via-cyan-400 to-blue-500 bg-clip-text text-transparent">
          موتور یادگیری خودکار
        </h1>
        <p className="text-[#94a3b8]">خزنده، پردازشگر و تزریق‌کننده خودکار اشعار از Ganjoor، GitHub، ویکی‌پدیا و...</p>
      </div>

      {/* STATS BANNER */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-emerald-400">{stats.activeSources}</p>
            <p className="text-xs text-[#94a3b8]">منابع فعال</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-cyan-400">{stats.totalSources}</p>
            <p className="text-xs text-[#94a3b8]">کل منابع</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-blue-400">{stats.totalVerses}</p>
            <p className="text-xs text-[#94a3b8]">بیت یاد گرفته شده</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-amber-400">{stats.totalRuns}</p>
            <p className="text-xs text-[#94a3b8]">دور یادگیری</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-purple-400">{stats.totalExtracted}</p>
            <p className="text-xs text-[#94a3b8]">کل استخراج شده</p>
          </div>
        </div>
      )}

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4">{error}</div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* LEFT: Add Source + Actions */}
        <div className="space-y-6">
          {/* دکمه یادگیری */}
          <div className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-2xl p-6">
            <h3 className="font-semibold mb-3">🚀 یادگیری از همه منابع</h3>
            <button
              onClick={learnAll}
              disabled={learning}
              className="w-full bg-gradient-to-l from-emerald-500 to-cyan-600 disabled:opacity-50 py-3 rounded-xl font-bold transition-all"
            >
              {learning ? '🤖 در حال یادگیری...' : '🤖 اجرای یادگیری'}
            </button>
          </div>

          {/* افزودن منبع جدید */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-3 flex items-center gap-2"><span>📥</span> افزودن منبع جدید</h3>
            <p className="text-xs text-[#94a3b8] mb-3">لینک Ganjoor، GitHub، ویکی‌پدیا یا هر منبع شعری</p>
            <input
              type="url"
              value={linkUrl}
              onChange={(e) => setLinkUrl(e.target.value)}
              placeholder="https://ganjoor.net/hafez/ghazal/..."
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-white text-sm mb-2 focus:border-emerald-500 focus:outline-none"
            />
            <input
              type="text"
              value={linkName}
              onChange={(e) => setLinkName(e.target.value)}
              placeholder="(اختیاری) نام منبع"
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-white text-sm mb-3 focus:border-emerald-500 focus:outline-none"
            />
            <button
              onClick={addSource}
              disabled={loading || !linkUrl.trim()}
              className="w-full bg-gradient-to-l from-blue-500 to-cyan-600 disabled:opacity-50 py-2.5 rounded-xl text-sm font-medium transition-all"
            >
              {loading ? '⏳...' : '➕ افزودن منبع'}
            </button>

            {linkResult && (
              <div className="mt-3 bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-3 text-sm animate-slide-in">
                <p className="text-emerald-400">✅ {linkResult.name}</p>
                <p className="text-[#94a3b8] text-xs">نوع: {linkResult.type} | {linkResult.tags?.join(', ')}</p>
              </div>
            )}
          </div>
        </div>

        {/* MIDDLE + RIGHT: Sources */}
        <div className="lg:col-span-2 space-y-6">
          {/* منابع پیش‌فرض */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <span>📚</span> منابع یادگیری ({stats?.totalSources || 0})
            </h3>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {stats?.sourceStats?.map((source: any, i: number) => (
                <div key={source.id} className="bg-[#0f172a]/50 rounded-xl p-3 border border-[#334155] hover:border-emerald-500/30 transition-all">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleSource(source.id)}
                        className={`w-4 h-4 rounded-full border-2 flex items-center justify-center text-[8px] ${
                          source.enabled
                            ? 'bg-emerald-500 border-emerald-500 text-white'
                            : 'border-[#64748b] text-[#64748b]'
                        }`}
                      >
                        {source.enabled ? '✓' : ''}
                      </button>
                      <div>
                        <p className={`text-sm font-medium ${source.enabled ? 'text-white' : 'text-[#64748b]'}`}>
                          {source.name}
                        </p>
                        <p className="text-[10px] text-[#64748b] font-mono truncate max-w-[250px]">{source.url}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-[10px]">
                      <span className={`px-1.5 py-0.5 rounded ${
                        source.type === 'ganjoor' ? 'bg-emerald-500/20 text-emerald-400' :
                        source.type === 'github' ? 'bg-purple-500/20 text-purple-400' :
                        'bg-blue-500/20 text-blue-400'
                      }`}>{source.type}</span>
                      <span className="text-[#94a3b8]">{source.totalVerses || 0} بیت</span>
                      <button onClick={() => removeSource(source.id)} className="text-red-400 hover:text-red-300">✕</button>
                    </div>
                  </div>
                  {source.runs > 0 && (
                    <div className="flex gap-2 mt-1.5 text-[9px] text-[#475569]">
                      <span>🔄 {source.runs} بار</span>
                      <span>⏱️ {source.lastRun ? new Date(source.lastRun).toLocaleDateString('fa-IR') : '-'}</span>
                    </div>
                  )}
                  {source.tags?.length > 0 && (
                    <div className="flex gap-1 mt-1.5 flex-wrap">
                      {source.tags.map((t: string, ti: number) => (
                        <span key={ti} className="text-[8px] px-1.5 py-0.5 rounded bg-[#6366f1]/10 text-[#6366f1]">{t}</span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* آخرین نتایج */}
          {stats?.recentResults?.length > 0 && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2"><span>📋</span> آخرین نتایج یادگیری</h3>
              <div className="space-y-2">
                {stats.recentResults.map((r: any, i: number) => (
                  <div key={i} className="bg-[#0f172a]/50 rounded-xl p-3 border border-[#334155]">
                    <div className="flex justify-between text-sm">
                      <span className="text-white">{r.sourceName}</span>
                      <span className={`font-medium ${r.versesNew > 0 ? 'text-emerald-400' : 'text-[#64748b]'}`}>
                        +{r.versesNew} بیت
                      </span>
                    </div>
                    <div className="flex gap-3 text-[10px] text-[#64748b] mt-1">
                      <span>📊 {r.versesExtracted} کل | {r.versesDuplicates} تکراری</span>
                      <span>⏱️ {(r.duration / 1000).toFixed(1)}s</span>
                      <span>📅 {new Date(r.timestamp).toLocaleDateString('fa-IR')}</span>
                    </div>
                    {r.samples?.length > 0 && (
                      <div className="mt-1 text-[10px] text-[#94a3b8] italic truncate">
                        نمونه: "{r.samples[0]?.slice(0, 60)}..."
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* CRON Script + Links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><span>🐚</span> اسکریپت کرون لینوکس</h3>
          <p className="text-sm text-[#94a3b8] mb-3">برای اجرای خودکار روزانه روی سرور لینوکس</p>
          <Link
            href="/api/auto-learn"
            target="_blank"
            className="inline-block bg-[#6366f1]/20 border border-[#6366f1]/30 px-4 py-2 rounded-xl text-sm hover:bg-[#6366f1]/30 transition-all"
          >
            📥 دریافت اسکریپت
          </Link>
        </div>
        <div className="bg-gradient-to-br from-amber-500/10 to-orange-500/10 border border-amber-500/30 rounded-2xl p-6">
          <h3 className="font-semibold mb-3 flex items-center gap-2"><span>💡</span> پیشنهادات منبع</h3>
          <div className="flex flex-wrap gap-2">
            {[
              { url: 'https://ganjoor.net/hafez/ghazal/', label: '📖 حافظ' },
              { url: 'https://ganjoor.net/saadi/golestan/', label: '🌹 سعدی' },
              { url: 'https://ganjoor.net/moulavi/masnavi/', label: '📕 مولانا' },
              { url: 'https://raw.githubusercontent.com/nikiede/ganjoor-json/main/hafez.json', label: '📦 JSON حافظ' },
            ].map((link, i) => (
              <button
                key={i}
                onClick={() => { setLinkUrl(link.url); }}
                className="text-xs px-3 py-1.5 rounded-full bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-emerald-500/50 hover:text-white transition-all"
              >
                {link.label}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
