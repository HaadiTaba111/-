"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

interface Dataset {
  id: string;
  name: string;
  description: string;
  hfId: string;
}

interface EpochLog {
  epoch: number;
  loss: number;
  accuracy: number;
  samplesProcessed: number;
  timestamp: string;
}

export default function TrainPage() {
  const [datasets, setDatasets] = useState<Dataset[]>([]);
  const [loading, setLoading] = useState(true);
  const [training, setTraining] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [epochLogs, setEpochLogs] = useState<EpochLog[]>([]);
  const [error, setError] = useState<string | null>(null);

  // فرم
  const [formData, setFormData] = useState({
    modelName: "",
    description: "",
    baseModel: "facebook/opt-125m",
    datasetIds: [] as string[],
    epochs: 3,
    learningRate: 3e-5,
    batchSize: 8,
    maxLength: 256,
    temperature: 0.7,
    topP: 0.9,
    repetitionPenalty: 1.1,
    numSamples: 10,
  });

  useEffect(() => {
    fetchDatasets();
  }, []);

  const fetchDatasets = async () => {
    try {
      const res = await fetch("/api/datasets");
      const data = await res.json();
      if (data.success) {
        setDatasets(data.datasets);
      }
    } catch (err) {
      console.error("خطا در دریافت دیتاست‌ها:", err);
    } finally {
      setLoading(false);
    }
  };

  const toggleDataset = (id: string) => {
    setFormData((prev) => ({
      ...prev,
      datasetIds: prev.datasetIds.includes(id)
        ? prev.datasetIds.filter((d) => d !== id)
        : [...prev.datasetIds, id],
    }));
  };

  const startTraining = async () => {
    if (!formData.modelName.trim()) {
      setError("لطفاً نام مدل را وارد کنید");
      return;
    }
    if (formData.datasetIds.length === 0) {
      setError("حداقل یک دیتاست انتخاب کنید");
      return;
    }

    setError(null);
    setTraining(true);
    setResult(null);
    setEpochLogs([]);

    try {
      const res = await fetch("/api/train", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.data);
        setEpochLogs(data.data.epochLogs || []);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError("خطا در ارتباط با سرور");
    } finally {
      setTraining(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in">
      {/* هدر */}
      <div className="text-center space-y-3 py-4">
        <div className="inline-block animate-float text-4xl mb-2">🧠</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">
          آموزش مغز فارسی
        </h1>
        <p className="text-[#94a3b8]">پارامترهای آموزش را تنظیم کرده و یک مدل هوش مصنوعی فارسی جدید بسازید</p>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4 text-center">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* فرم تنظیمات */}
        <div className="lg:col-span-2 space-y-6">
          {/* اطلاعات پایه */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📋</span> اطلاعات پایه
            </h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">نام مدل *</label>
                <input
                  type="text"
                  value={formData.modelName}
                  onChange={(e) => setFormData({ ...formData, modelName: e.target.value })}
                  placeholder="مثال: حافظ‌یار"
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-2.5 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">توضیحات</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="هدف این مدل چیست؟"
                  rows={2}
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-2.5 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none transition-colors resize-none"
                />
              </div>
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">مدل پایه</label>
                <select
                  value={formData.baseModel}
                  onChange={(e) => setFormData({ ...formData, baseModel: e.target.value })}
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-2.5 text-white focus:border-[#6366f1] focus:outline-none transition-colors"
                >
                  <option value="facebook/opt-125m">OPT-125M (سبک - 125 میلیون پارامتر)</option>
                  <option value="facebook/opt-350m">OPT-350M (متوسط - 350 میلیون پارامتر)</option>
                  <option value="distilgpt2">DistilGPT2 (فوق سبک - 82 میلیون پارامتر)</option>
                </select>
              </div>
            </div>
          </div>

          {/* انتخاب دیتاست‌ها */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📚</span> دیتاست‌های آموزشی - متون و اشعار فارسی
            </h3>
            <p className="text-sm text-[#64748b] mb-4">
              از Hugging Face - منابع ادبیات و متون کهن فارسی
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {datasets.map((ds) => (
                <button
                  key={ds.id}
                  onClick={() => toggleDataset(ds.id)}
                  className={`text-right p-4 rounded-xl border transition-all duration-200 ${
                    formData.datasetIds.includes(ds.id)
                      ? "bg-[#6366f1]/20 border-[#6366f1] shadow-[0_0_15px_rgba(99,102,241,0.15)]"
                      : "bg-[#0f172a]/50 border-[#334155] hover:border-[#475569]"
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <p className="font-medium text-white">{ds.name}</p>
                    {formData.datasetIds.includes(ds.id) && (
                      <span className="text-[#6366f1]">✓</span>
                    )}
                  </div>
                  <p className="text-xs text-[#64748b] mt-1">{ds.description}</p>
                  <p className="text-[10px] text-[#475569] mt-1">HF: {ds.hfId}</p>
                </button>
              ))}
            </div>
          </div>

          {/* پارامترهای آموزش */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>⚙️</span> پارامترهای آموزش (قابل تنظیم)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">
                  تعداد Epoch: <span className="text-[#6366f1]">{formData.epochs}</span>
                </label>
                <input
                  type="range"
                  min={1}
                  max={10}
                  value={formData.epochs}
                  onChange={(e) => setFormData({ ...formData, epochs: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1]"
                />
              </div>
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">
                  Learning Rate: <span className="text-[#6366f1]">{formData.learningRate.toExponential()}</span>
                </label>
                <input
                  type="range"
                  min={1}
                  max={50}
                  value={formData.learningRate * 100000}
                  onChange={(e) => setFormData({ ...formData, learningRate: parseInt(e.target.value) / 100000 })}
                  className="w-full accent-[#6366f1]"
                />
              </div>
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">
                  Batch Size: <span className="text-[#6366f1]">{formData.batchSize}</span>
                </label>
                <input
                  type="range"
                  min={2}
                  max={32}
                  step={2}
                  value={formData.batchSize}
                  onChange={(e) => setFormData({ ...formData, batchSize: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1]"
                />
              </div>
              <div>
                <label className="block text-sm text-[#94a3b8] mb-1">
                  Max Length: <span className="text-[#6366f1]">{formData.maxLength}</span>
                </label>
                <input
                  type="range"
                  min={64}
                  max={512}
                  step={32}
                  value={formData.maxLength}
                  onChange={(e) => setFormData({ ...formData, maxLength: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1]"
                />
              </div>
            </div>
          </div>

          {/* دکمه آموزش */}
          <button
            onClick={startTraining}
            disabled={training}
            className="w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] hover:from-[#4f46e5] hover:to-[#4338ca] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-2xl transition-all duration-300 shadow-lg shadow-[#6366f1]/20 hover:shadow-[#6366f1]/40"
          >
            {training ? (
              <span className="flex items-center justify-center gap-2">
                <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                در حال آموزش مغز...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                <span>🧠</span>
                شروع آموزش مغز
              </span>
            )}
          </button>
        </div>

        {/* سایدبار - نتایج و لاگ */}
        <div className="space-y-6">
          {/* وضعیت آموزش */}
          {training && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6 animate-pulse">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <span>⏳</span> وضعیت آموزش
              </h3>
              <div className="flex items-center justify-center py-8">
                <div className="w-16 h-16 border-4 border-[#334155] border-t-[#6366f1] rounded-full animate-spin" />
              </div>
              <p className="text-center text-[#94a3b8] text-sm">مغز در حال یادگیری است...</p>
            </div>
          )}

          {/* لاگ Epochها */}
          {epochLogs.length > 0 && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <span>📊</span> گزارش آموزش
              </h3>
              <div className="space-y-2">
                {epochLogs.map((log, i) => (
                  <div key={i} className="p-3 rounded-xl bg-[#0f172a]/50 border border-[#334155]">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-white">Epoch {log.epoch}</span>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        log.loss < 0.5 ? 'bg-emerald-500/20 text-emerald-400' :
                        log.loss < 1.5 ? 'bg-amber-500/20 text-amber-400' :
                        'bg-red-500/20 text-red-400'
                      }`}>
                        Loss: {log.loss.toFixed(4)}
                      </span>
                    </div>
                    <div className="mt-2">
                      <div className="flex justify-between text-xs text-[#64748b]">
                        <span>دقت: {log.accuracy.toFixed(1)}%</span>
                        <span>{log.samplesProcessed} نمونه</span>
                      </div>
                      <div className="w-full bg-[#0f172a] rounded-full h-1.5 mt-1">
                        <div
                          className="bg-gradient-to-l from-[#6366f1] to-[#a855f7] h-1.5 rounded-full transition-all"
                          style={{ width: `${log.accuracy}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* نتیجه نهایی */}
          {result && (
            <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-6">
              <h3 className="text-lg font-semibold mb-3 flex items-center gap-2 text-emerald-400">
                <span>✅</span> آموزش تکمیل شد!
              </h3>
              <div className="space-y-2 text-sm">
                <p className="flex justify-between">
                  <span className="text-[#94a3b8]">مدل:</span>
                  <span className="text-white">{result.model.name}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-[#94a3b8]">وضعیت:</span>
                  <span className="text-emerald-400">{result.model.status}</span>
                </p>
                <p className="flex justify-between">
                  <span className="text-[#94a3b8]">نمونه‌های آموزش:</span>
                  <span className="text-white">{result.trainingSamples}</span>
                </p>
              </div>
              <div className="mt-4 flex gap-2">
                <Link
                  href={`/models`}
                  className="flex-1 bg-[#1e293b] border border-[#334155] rounded-xl py-2 text-center text-sm hover:bg-[#334155] transition-colors"
                >
                  مشاهده مدل‌ها
                </Link>
                <Link
                  href="/inference"
                  className="flex-1 bg-emerald-600/20 border border-emerald-500/30 rounded-xl py-2 text-center text-sm text-emerald-400 hover:bg-emerald-600/30 transition-colors"
                >
                  تست مغز
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
