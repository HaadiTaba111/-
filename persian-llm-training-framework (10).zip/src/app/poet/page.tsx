"use client";

import { useState } from "react";

export default function PoetPage() {
  const [topic, setTopic] = useState("گل");
  const [style, setStyle] = useState<"classic" | "modern" | "simple">("classic");
  const [lines, setLines] = useState(4);
  const [poem, setPoem] = useState<any>(null);
  const [verses, setVerses] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showStories, setShowStories] = useState(false);
  const [story, setStory] = useState<any>(null);

  const generatePoem = async () => {
    setLoading(true);
    setError(null);
    setPoem(null);
    try {
      const res = await fetch("/api/poet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "generate-poem", topic, lines, style }),
      });
      const data = await res.json();
      if (data.success) setPoem(data.data);
      else setError(data.error);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  };

  const generateVerse = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/poet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "generate-verse", topic, style, temperature: 0.8 }),
      });
      const data = await res.json();
      if (data.success) setVerses(prev => [data.data.verse, ...prev].slice(0, 8));
    } catch {}
    finally { setLoading(false); }
  };

  const fetchStory = async () => {
    const res = await fetch("/api/poet", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "story-random" }),
    });
    const data = await res.json();
    if (data.success) setStory(data.data);
  };

  const topics = ["گل", "عشق", "بهار", "دوستی", "غم", "زندگی", "خدا", "وطن", "شادی", "دل"];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in pb-12">
      {/* HEADER */}
      <div className="text-center space-y-3 py-6">
        <div className="inline-block text-5xl mb-2 animate-float">🖋️</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-pink-500 via-rose-500 to-amber-500 bg-clip-text text-transparent">
          شاعر ماشین
        </h1>
        <p className="text-[#94a3b8]">
          شعر جدید می‌سازه، پیدا نمی‌کنه! با الهام از حافظ، سعدی و مولانا
        </p>
      </div>

      {error && <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4">{error}</div>}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* سایدبار: تنظیمات */}
        <div className="space-y-6">
          {/* تنظیمات شعر */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-4">🎛️ تنظیمات شعر</h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs text-[#94a3b8] block mb-1">موضوع</label>
                <div className="flex flex-wrap gap-1.5">
                  {topics.map(t => (
                    <button key={t} onClick={() => setTopic(t)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                        topic === t ? 'bg-rose-500/20 border-rose-500 text-rose-400' : 'bg-[#0f172a] border-[#334155] text-[#94a3b8]'
                      }`}>{t}</button>
                  ))}
                </div>
                <input type="text" value={topic} onChange={e => setTopic(e.target.value)}
                  className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-white text-sm mt-2 focus:border-rose-500 outline-none"
                  placeholder="هر موضوعی..."
                />
              </div>
              <div>
                <label className="text-xs text-[#94a3b8] block mb-1">سبک</label>
                <div className="flex gap-2">
                  {(["classic", "modern", "simple"] as const).map(s => (
                    <button key={s} onClick={() => setStyle(s)}
                      className={`flex-1 text-xs py-2 rounded-xl border transition-all ${
                        style === s ? 'bg-rose-500/20 border-rose-500 text-rose-400' : 'bg-[#0f172a] border-[#334155] text-[#94a3b8]'
                      }`}>
                      {s === "classic" ? "🏛️ کلاسیک" : s === "modern" ? "✨ مدرن" : "📝 ساده"}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-xs text-[#94a3b8] block mb-1">تعداد بیت: {lines}</label>
                <input type="range" min={2} max={8} value={lines} onChange={e => setLines(parseInt(e.target.value))}
                  className="w-full accent-rose-500" />
              </div>
              <button onClick={generatePoem} disabled={loading}
                className="w-full bg-gradient-to-l from-rose-500 to-amber-600 disabled:opacity-50 py-3 rounded-xl font-bold transition-all">
                {loading ? '🖋️ در حال سرودن...' : '🖋️ بسرا شاعر!'}
              </button>
            </div>
          </div>

          {/* تک‌بیت */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-3">🌸 تک‌بیت جدید</h3>
            <button onClick={generateVerse} disabled={loading}
              className="w-full bg-[#0f172a] border border-[#334155] py-2 rounded-xl text-sm hover:border-rose-500/50 transition-all">
              ✨ بساز
            </button>
            {verses.length > 0 && (
              <div className="mt-3 space-y-2 max-h-40 overflow-y-auto">
                {verses.map((v: any, i: number) => (
                  <div key={i} className="bg-[#0f172a]/50 rounded-xl p-3 border border-[#334155] text-sm text-white" dir="rtl">
                    {v.verse?.length > 60 ? v.verse.slice(0, 60) + '...' : v.verse}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* وسط: شعر تولید شده */}
        <div className="lg:col-span-2 space-y-6">
          {poem && (
            <div className="bg-gradient-to-br from-rose-500/10 to-amber-500/5 border border-rose-500/30 rounded-2xl p-8 animate-slide-in">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold bg-gradient-to-l from-rose-400 to-amber-400 bg-clip-text text-transparent">
                  {poem.title}
                </h2>
                <p className="text-[#94a3b8] text-sm mt-1">{poem.poet} | موضوع: {poem.topic} | سبک: {poem.style === 'classic' ? 'کلاسیک' : poem.style === 'modern' ? 'مدرن' : 'ساده'}</p>
              </div>
              <div className="space-y-4">
                {poem.lines.map((line: string, i: number) => (
                  <div key={i} className="bg-[#0f172a]/50 rounded-2xl p-5 border border-[#334155] hover:border-rose-500/20 transition-all">
                    <p className="text-white text-lg leading-9 text-center" dir="rtl">
                      {line.split('/')[0]}
                    </p>
                    <p className="text-rose-300 text-lg leading-9 text-center mt-2" dir="rtl">
                      / {line.split('/')[1] || ''}
                    </p>
                    <p className="text-[10px] text-[#475569] text-center mt-2">بیت {i + 1}</p>
                  </div>
                ))}
              </div>
              <div className="mt-6 pt-4 border-t border-[#334155] text-center">
                <p className="text-xs text-[#64748b]">
                  🧠 این شعر کاملاً جدید است و توسط شاعر ماشین سروده شده
                  <br />با الهام از قالب‌های کلاسیک شعر فارسی
                </p>
              </div>
            </div>
          )}

          {!poem && !story && (
            <div className="bg-[#1e293b]/50 border border-[#334155] rounded-2xl p-12 text-center">
              <div className="text-6xl mb-4">🖋️</div>
              <p className="text-[#94a3b8]">موضوع رو انتخاب کن و بزن <strong>بسرا شاعر!</strong></p>
              <p className="text-[#64748b] text-sm mt-2">شاعر ماشین شعر جدید می‌سازه، پیدا نمی‌کنه!</p>
            </div>
          )}

          {/* داستان */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold flex items-center gap-2"><span>📖</span> قصه‌گوی فارسی</h3>
              <button onClick={fetchStory} className="text-xs bg-[#0f172a] border border-[#334155] px-3 py-1.5 rounded-xl hover:border-emerald-500/50 transition-all">
                🎲 داستان تصادفی
              </button>
            </div>
            {story ? (
              <div className="animate-slide-in">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">{story.source}</span>
                  <span className="text-xs text-[#64748b]">{story.author}</span>
                  {story.conversationLines && (
                    <span className="text-xs text-amber-400">🗣️ {story.conversationLines.length} گفتگو</span>
                  )}
                </div>
                <h4 className="font-medium text-white mb-2">{story.title}</h4>
                <p className="text-sm text-[#94a3b8] leading-7" dir="rtl">{story.text.slice(0, 300)}...</p>
                <div className="mt-3 bg-[#0f172a]/50 rounded-xl p-3 border border-[#334155]">
                  <p className="text-xs text-emerald-400 mb-1">💡 نکته:</p>
                  <p className="text-sm text-white">{story.moral}</p>
                </div>
                {story.conversationLines && story.conversationLines.length > 0 && (
                  <details className="mt-3">
                    <summary className="text-xs text-[#6366f1] cursor-pointer hover:underline">
                      🗣️ نمایش گفتگوهای داستان
                    </summary>
                    <div className="mt-2 space-y-1">
                      {story.conversationLines.map((line: string, i: number) => (
                        <p key={i} className="text-xs text-[#94a3b8] bg-[#0f172a]/30 rounded-lg p-2 border border-[#334155]/50" dir="rtl">
                          💬 {line}
                        </p>
                      ))}
                    </div>
                  </details>
                )}
              </div>
            ) : (
              <p className="text-[#64748b] text-sm text-center py-4">دکمه رو بزن تا یه داستان کهن با محاوره روان ببینیم 📖</p>
            )}
          </div>
        </div>
      </div>

      {/* توضیحات فنی */}
      <div className="bg-gradient-to-br from-rose-500/5 to-amber-500/5 border border-[#334155] rounded-2xl p-6">
        <h3 className="font-semibold mb-3 flex items-center gap-2"><span>🧠</span> مکانیزم شاعر ماشین</h3>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
          <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
            <p className="text-rose-400 font-medium">۱. گسترش معنایی</p>
            <p className="text-[#94a3b8] text-xs mt-1">"گل" → گلزار، گلستان، بنفشه، نرگس، لاله، سنبل، بهار...</p>
          </div>
          <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
            <p className="text-amber-400 font-medium">۲. انتخاب قافیه</p>
            <p className="text-[#94a3b8] text-xs mt-1">دیکشنری هم‌قافیه با ۸ گروه و ۸۰+ کلمه</p>
          </div>
          <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
            <p className="text-emerald-400 font-medium">۳. ترکیب خلاقانه</p>
            <p className="text-[#94a3b8] text-xs mt-1">۳۱ فعل + ۱۸ صفت + ۱۴ قید + ۱۰ مکان + ۱۲ ستایش</p>
          </div>
        </div>
      </div>
    </div>
  );
}
