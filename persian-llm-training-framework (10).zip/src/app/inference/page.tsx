"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

interface Model {
  id: number;
  name: string;
  status: string;
  temperature: number;
  topP: number;
  maxLength: number;
  repetitionPenalty: number;
}

interface DetectedVerse {
  verse: {
    id: number;
    text: string;
    poet: string;
    book?: string;
    keywords: string[];
    topics: string[];
    themes: string[];
    mood?: string;
  };
  score: number;
  matchedKeywords: string[];
}

interface AnalysisData {
  keywords: string[];
  detectedPoets: string[];
  mood?: string;
  hasQuestion: boolean;
}

interface InferenceResult {
  text: string;
  tokenCount: number;
  modelUsed: string;
  latencyMs: number;
  logId: number;
  modelName: string;
  verses: DetectedVerse[];
  analysis: AnalysisData;
  parameters: {
    temperature: number;
    maxLength: number;
    topP: number;
    repetitionPenalty: number;
  };
}

function InferenceContent() {
  const searchParams = useSearchParams();
  const [models, setModels] = useState<Model[]>([]);
  const [selectedModelId, setSelectedModelId] = useState<number | null>(null);
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<InferenceResult | null>(null);
  const [history, setHistory] = useState<Array<{ prompt: string; time: string }>>([]);
  const [error, setError] = useState<string | null>(null);

  // پارامترهای پیشرفته
  const [params, setParams] = useState({
    temperature: 0.7,
    maxLength: 256,
    topP: 0.9,
    repetitionPenalty: 1.1,
  });

  useEffect(() => {
    fetchModels();
  }, []);

  useEffect(() => {
    const modelId = searchParams.get("modelId");
    if (modelId) {
      setSelectedModelId(parseInt(modelId));
    }
  }, [searchParams]);

  const fetchModels = async () => {
    try {
      const res = await fetch("/api/models");
      const data = await res.json();
      if (data.success) {
        const trainedModels = data.models.filter((m: Model) => m.status === "trained" || m.status === "created");
        setModels(trainedModels);
      }
    } catch (err) {
      console.error("خطا:", err);
    }
  };

  const think = async () => {
    if (!selectedModelId) {
      setError("لطفاً یک مدل انتخاب کنید");
      return;
    }
    if (!prompt.trim()) {
      setError("لطفاً متن ورودی را وارد کنید");
      return;
    }

    setError(null);
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("/api/inference", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          modelId: selectedModelId,
          prompt: prompt.trim(),
          ...params,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setResult(data.data);
        setHistory((prev) => [
          { prompt: prompt.trim(), time: new Date().toLocaleTimeString("fa-IR") },
          ...prev,
        ]);
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError("خطا در ارتباط با سرور");
    } finally {
      setLoading(false);
    }
  };

  const selectedModel = models.find((m) => m.id === selectedModelId);

  // پیشنهادات با موضوعات متنوع
  const suggestions = [
    { text: "گل و بهار", icon: "🌸", prompt: "در مورد گل و بهار شعر بگو" },
    { text: "عشق حافظ", icon: "💖", prompt: "از عشق و دلدادگی بگو با شعر حافظ" },
    { text: "غم و فراق", icon: "💔", prompt: "شعر درباره غم دوری و فراق" },
    { text: "دوستی سعدی", icon: "🤝", prompt: "درباره دوستی و انسانیت از سعدی بگو" },
    { text: "حماسه فردوسی", icon: "⚔️", prompt: "شعر حماسی از شاهنامه فردوسی" },
    { text: "خدا و عرفان", icon: "🙏", prompt: "شعر عرفانی درباره خدا و حقیقت" },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in">
      {/* هدر */}
      <div className="text-center space-y-3 py-4">
        <div className="inline-block animate-float text-4xl mb-2">💭</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">
          تفکر با مغز فارسی
        </h1>
        <p className="text-[#94a3b8]">مغز با درک عمیق مفاهیم، دقیق‌ترین اشعار مرتبط با درخواست شما را می‌یابد</p>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4 text-center animate-slide-in">
          {error}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* سایدبار - انتخاب مدل و پارامترها */}
        <div className="lg:col-span-1 space-y-6">
          {/* انتخاب مدل */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-5">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <span>🤖</span> انتخاب مدل
            </h3>
            {models.length === 0 ? (
              <div className="text-center py-4">
                <p className="text-[#64748b] text-sm">مدلی وجود ندارد</p>
                <a href="/train" className="text-[#6366f1] text-xs mt-1 block hover:underline">
                  آموزش مدل جدید
                </a>
              </div>
            ) : (
              <div className="space-y-2">
                {models.map((model) => (
                  <button
                    key={model.id}
                    onClick={() => {
                      setSelectedModelId(model.id);
                      setParams({
                        temperature: model.temperature,
                        maxLength: model.maxLength,
                        topP: model.topP,
                        repetitionPenalty: model.repetitionPenalty,
                      });
                    }}
                    className={`w-full text-right p-3 rounded-xl border transition-all text-sm ${
                      selectedModelId === model.id
                        ? "bg-[#6366f1]/20 border-[#6366f1]"
                        : "bg-[#0f172a]/50 border-[#334155] hover:border-[#475569]"
                    }`}
                  >
                    <p className="font-medium text-white">{model.name}</p>
                    <p className="text-[10px] text-[#64748b] mt-0.5">
                      {model.status === "trained" ? "✅ آموزش دیده" : "📝 ایجاد شده"}
                    </p>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* پارامترهای تفکر */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-5">
            <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
              <span>🎛️</span> تنظیم دقت تفکر
            </h3>
            <div className="space-y-4">
              <div>
                <label className="flex justify-between text-xs text-[#94a3b8] mb-1">
                  <span>خلاقیت (Temperature)</span>
                  <span className={`font-bold ${params.temperature > 1.2 ? 'text-yellow-400' : params.temperature < 0.4 ? 'text-blue-400' : 'text-[#6366f1]'}`}>
                    {params.temperature.toFixed(1)}
                  </span>
                </label>
                <input
                  type="range"
                  min={0.1}
                  max={2.0}
                  step={0.1}
                  value={params.temperature}
                  onChange={(e) => setParams({ ...params, temperature: parseFloat(e.target.value) })}
                  className="w-full accent-[#6366f1]"
                />
                <div className="flex justify-between text-[10px] text-[#475569]">
                  <span>🎯 دقیق</span>
                  <span>🌈 خلاق</span>
                </div>
              </div>

              <div>
                <label className="flex justify-between text-xs text-[#94a3b8] mb-1">
                  <span>تعداد ابیات</span>
                  <span className="text-[#6366f1]">{params.maxLength}</span>
                </label>
                <input
                  type="range"
                  min={32}
                  max={512}
                  step={16}
                  value={params.maxLength}
                  onChange={(e) => setParams({ ...params, maxLength: parseInt(e.target.value) })}
                  className="w-full accent-[#6366f1]"
                />
              </div>

              {/* نمایش حالت فعلی */}
              <div className="pt-2 border-t border-[#334155] text-[10px] text-[#64748b]">
                {params.temperature < 0.4 && <p>🎯 حالت دقیق: فقط مرتبط‌ترین نتایج</p>}
                {params.temperature >= 0.4 && params.temperature <= 1.2 && <p>⚖️ حالت متعادل: دقیق + متنوع</p>}
                {params.temperature > 1.2 && <p>🌈 حالت خلاق: نتایج متنوع و غیرمنتظره</p>}
              </div>
            </div>
          </div>

          {/* تحلیل لحظه‌ای */}
          {result && result.analysis && (
            <div className="bg-gradient-to-br from-[#6366f1]/10 to-[#a855f7]/10 border border-[#6366f1]/20 rounded-2xl p-5">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <span>🔍</span> تحلیل مغز
              </h3>
              <div className="space-y-2 text-xs">
                {result.analysis.detectedPoets.length > 0 && (
                  <div className="flex items-center gap-1">
                    <span className="text-[#94a3b8]">شاعر:</span>
                    {result.analysis.detectedPoets.map((p, i) => (
                      <span key={i} className="px-1.5 py-0.5 rounded bg-[#6366f1]/20 text-[#6366f1] text-[10px]">{p}</span>
                    ))}
                  </div>
                )}
                {result.analysis.mood && (
                  <div className="flex items-center gap-1">
                    <span className="text-[#94a3b8]">حال و هوا:</span>
                    <span className="px-1.5 py-0.5 rounded bg-[#a855f7]/20 text-[#a855f7] text-[10px]">{result.analysis.mood}</span>
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <span className="text-[#94a3b8]">تعداد ابیات:</span>
                  <span className="font-bold text-white">{result.verses?.length || 0}</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-[#94a3b8]">سرعت:</span>
                  <span className="font-bold text-emerald-400">{result.latencyMs}ms</span>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* بخش اصلی */}
        <div className="lg:col-span-3 space-y-6">
          {/* نوار وضعیت مدل */}
          {selectedModel && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-4 animate-slide-in">
              <div className="flex items-center gap-3 text-sm">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-[#6366f1] font-bold">{selectedModel.name}</span>
                <span className="text-[#64748b]">|</span>
                <span className="text-[#94a3b8]">
                  خلاقیت {selectedModel.temperature} | درک معنایی عمیق
                </span>
              </div>
            </div>
          )}

          {/* ورودی و دکمه تفکر */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="هر چی بگی مغز می‌فهمه... مثال: «با گل شعر بگو»، «شعر عاشقانه از حافظ»، «درباره دوستی از سعدی بگو»"
              rows={3}
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none transition-colors resize-none"
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  think();
                }
              }}
            />
            <button
              onClick={think}
              disabled={loading || !selectedModelId}
              className="mt-3 w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] hover:from-[#4f46e5] hover:to-[#4338ca] disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3 rounded-xl transition-all duration-300 shadow-lg shadow-[#6366f1]/20 hover:shadow-[#6366f1]/40"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  مغز در حال جستجوی معنایی...
                </span>
              ) : (
                <span className="flex items-center justify-center gap-2">
                  <span>🧠</span>
                  بفرمایید مغز تفکر کند
                </span>
              )}
            </button>
          </div>

          {/* پیشنهادات */}
          <div className="flex flex-wrap gap-2">
            {suggestions.map((s, i) => (
              <button
                key={i}
                onClick={() => {
                  setPrompt(s.prompt);
                }}
                className="text-xs px-3 py-1.5 rounded-full bg-[#1e293b] border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 hover:text-white hover:bg-[#6366f1]/10 transition-all"
              >
                {s.icon} {s.text}
              </button>
            ))}
          </div>

          {/* نتیجه تفکر */}
          {loading && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-8">
              <div className="flex flex-col items-center justify-center space-y-4">
                <div className="flex gap-2">
                  {[0, 0.2, 0.4].map((d, i) => (
                    <div
                      key={i}
                      className="w-3 h-3 rounded-full bg-[#6366f1] animate-bounce"
                      style={{ animationDelay: `${d}s` }}
                    />
                  ))}
                </div>
                <p className="text-[#94a3b8] animate-pulse">
                  🔍 در حال تحلیل معنایی درخواست شما...
                </p>
                <div className="flex gap-4 text-xs text-[#64748b]">
                  <span>📖 جستجو در بانک اشعار</span>
                  <span>⚖️ امتیازدهی</span>
                  <span>🎯 انتخاب دقیق‌ترین‌ها</span>
                </div>
              </div>
            </div>
          )}

          {result && (
            <div className="space-y-4 animate-slide-in">
              {/* تحلیل درخواست */}
              <div className="bg-gradient-to-br from-[#6366f1]/5 to-[#a855f7]/5 border border-[#334155] rounded-2xl p-6">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold flex items-center gap-2">
                    <span>🧠</span>
                    پاسخ مغز
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-[#64748b]">
                    <span>⚡ {result.latencyMs}ms</span>
                    <span>📝 {result.tokenCount} کلمه</span>
                    {result.verses && <span>📚 {result.verses.length} بیت</span>}
                  </div>
                </div>

                {/* توضیح مغز */}
                <div className="bg-[#0f172a]/50 rounded-xl p-5 border border-[#334155] mb-4">
                  <p className="text-white leading-8 whitespace-pre-line text-base" dir="rtl">
                    {result.text.split("🌸")[0]}
                  </p>
                </div>

                {/* ابیات یافت شده */}
                {result.verses && result.verses.length > 0 && (
                  <div className="space-y-3">
                    <h4 className="text-sm font-medium text-[#94a3b8] flex items-center gap-2">
                      <span>🌸</span> اشعار یافت شده با تطبیق معنایی:
                    </h4>
                    {result.verses.map((v, i) => (
                      <div
                        key={i}
                        className="bg-[#0f172a]/30 rounded-xl p-4 border border-[#334155] hover:border-[#6366f1]/30 transition-all group"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="text-white text-lg leading-8" dir="rtl">
                              {v.verse.text}
                            </p>
                            <p className="text-xs text-[#64748b] mt-2">
                              — {v.verse.poet}
                              {v.verse.book ? ` (${v.verse.book})` : ""}
                            </p>
                          </div>
                          {/* امتیاز relevance */}
                          <div className="flex flex-col items-center mr-3">
                            <div className="w-10 h-10 rounded-full bg-[#6366f1]/20 border border-[#6366f1]/30 flex items-center justify-center">
                              <span className="text-xs font-bold text-[#6366f1]">
                                {Math.round(v.score * 10)}
                              </span>
                            </div>
                            <span className="text-[8px] text-[#64748b] mt-1">امتیاز</span>
                          </div>
                        </div>

                        {/* تگ‌های تطبیق */}
                        {v.matchedKeywords.length > 0 && (
                          <div className="flex flex-wrap gap-1 mt-3 pt-2 border-t border-[#334155]/50">
                            {v.matchedKeywords.map((kw, ki) => (
                              <span
                                key={ki}
                                className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                              >
                                ✓ {kw}
                              </span>
                            ))}
                            {v.verse.themes.map((th, ti) => (
                              <span
                                key={ti}
                                className="text-[10px] px-1.5 py-0.5 rounded bg-[#6366f1]/10 text-[#6366f1] border border-[#6366f1]/20"
                              >
                                🏷️ {th}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {/* خلاصه آماری */}
                <div className="mt-4 p-3 bg-[#0f172a]/50 rounded-xl border border-[#334155]">
                  <div className="flex flex-wrap gap-3 text-[11px] text-[#64748b] items-center">
                    <span>🔍 درخواست: "{result.analysis?.hasQuestion ? 'سوال' : 'درخواست'}"</span>
                    {result.analysis?.detectedPoets?.length > 0 && (
                      <span>👤 شاعر تشخیص: {result.analysis.detectedPoets.join("، ")}</span>
                    )}
                    {result.analysis?.mood && (
                      <span>🎭 حال و هوا: {result.analysis.mood}</span>
                    )}
                    <span>🎛️ خلاقیت: {result.parameters.temperature.toFixed(1)}</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* تاریخچه */}
          {history.length > 1 && (
            <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
              <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
                <span>📜</span> تاریخچه تفکر
              </h3>
              <div className="space-y-2 max-h-40 overflow-y-auto">
                {history.slice(1).map((item, i) => (
                  <div key={i} className="p-2 rounded-lg bg-[#0f172a]/50 border border-[#334155] flex justify-between text-xs">
                    <span className="text-[#94a3b8] truncate max-w-[80%]">{item.prompt}</span>
                    <span className="text-[#64748b]">{item.time}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function InferencePage() {
  return (
    <Suspense fallback={
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex flex-col items-center justify-center text-center space-y-4">
          <div className="w-12 h-12 border-4 border-[#334155] border-t-[#6366f1] rounded-full animate-spin" />
          <p className="text-[#94a3b8]">در حال بارگذاری مغز...</p>
        </div>
      </div>
    }>
      <InferenceContent />
    </Suspense>
  );
}
