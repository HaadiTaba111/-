"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function BrainPage() {
  const [activeTab, setActiveTab] = useState<'unified' | 'inject' | 'experiences' | 'dataset'>('unified');
  const [input, setInput] = useState("");
  const [response, setResponse] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<any>(null);
  const [injectedSources, setInjectedSources] = useState<any[]>([]);
  const [showStats, setShowStats] = useState(false);

  // لینک تزریق
  const [linkUrl, setLinkUrl] = useState("");
  const [linkPoet, setLinkPoet] = useState("");
  const [injectResult, setInjectResult] = useState<any>(null);
  const [injectLoading, setInjectLoading] = useState(false);

  useEffect(() => {
    fetchStats();
    loadInjected();
  }, []);

  const fetchStats = async () => {
    try {
      const res = await fetch("/api/brain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "experience-stats" }),
      });
      const data = await res.json();
      if (data.success) setStats(data.data);
    } catch {}
  };

  const loadInjected = () => {
    const stored = JSON.parse(localStorage.getItem("persian-brain-injected-sources") || "[]");
    setInjectedSources(stored);
  };

  const think = async () => {
    if (!input.trim()) return;
    setLoading(true);
    setError(null);
    setResponse(null);

    try {
      const res = await fetch("/api/brain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "think", input: input.trim(), saveExperience: true }),
      });
      const data = await res.json();
      if (data.success) {
        setResponse(data.data);
        fetchStats();
      } else setError(data.error);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const injectLink = async () => {
    if (!linkUrl.trim()) return;
    setInjectLoading(true);
    setInjectResult(null);
    setError(null);

    try {
      const res = await fetch("/api/brain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "inject-link",
          url: linkUrl.trim(),
          poet: linkPoet.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setInjectResult(data.data);
        loadInjected();
        setLinkUrl("");
        setLinkPoet("");
      } else setError(data.error);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setInjectLoading(false);
    }
  };

  const exportBrain = async () => {
    try {
      const res = await fetch("/api/brain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "export" }),
      });
      const data = await res.json();
      if (data.success) {
        const blob = new Blob([data.data], { type: "application/json" });
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `persian-brain-backup-${new Date().toISOString().split('T')[0]}.json`;
        a.click();
      }
    } catch {}
  };

  const tabs = [
    { id: 'unified' as const, label: '🧠 مغز واحد', desc: 'تفکر ترکیبی' },
    { id: 'inject' as const, label: '📥 تزریق لینک', desc: 'غنی‌سازی مغز' },
    { id: 'experiences' as const, label: '📊 تجارب', desc: 'داده‌های آموزشی' },
    { id: 'dataset' as const, label: '📦 دیتاست', desc: 'خروجی آموزش' },
  ];

  const methodLabels: Record<string, string> = {
    'poetry-db': '📚 تزریقی (بانک اصلی)',
    'injected': '📥 تزریقی (منابع خارجی)',
    'hybrid': '🔄 ترکیبی (اصلی+خارجی)',
    'distilled': '🧪 تقطیری (تولیدی)',
    'colloquial': '🗣️ محاوره‌ای',
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8 animate-fade-in pb-12">
      {/* HEADER */}
      <div className="text-center space-y-3 py-6">
        <div className="inline-block text-5xl mb-2 animate-float">🧠</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] via-[#a855f7] to-[#ec4899] bg-clip-text text-transparent">
          مغز واحد فارسی v3.0
        </h1>
        <p className="text-[#94a3b8]">تزریقی + تقطیری + تجربه‌آموز + تزریق لینک - هر سه در یک مغز</p>
      </div>

      {/* تَب‌ها */}
      <div className="flex flex-wrap gap-2 justify-center">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-5 py-3 rounded-2xl text-sm border transition-all ${
              activeTab === tab.id
                ? 'bg-[#6366f1]/20 border-[#6366f1] text-white shadow-[0_0_15px_rgba(99,102,241,0.15)]'
                : 'bg-[#1e293b]/50 border-[#334155] text-[#94a3b8] hover:text-white'
            }`}
          >
            <p className="font-medium">{tab.label}</p>
            <p className="text-[10px] opacity-70">{tab.desc}</p>
          </button>
        ))}
      </div>

      {/* Error */}
      {error && (
        <div className="bg-red-500/10 border border-red-500/30 text-red-400 rounded-2xl p-4 text-center animate-slide-in">{error}</div>
      )}

      {/* Stats Bar */}
      {stats && (
        <div className={`grid grid-cols-2 sm:grid-cols-4 gap-3 ${showStats ? 'animate-slide-in' : 'hidden'}`}>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-[#6366f1]">{stats.total}</p>
            <p className="text-xs text-[#94a3b8]">تجارب ذخیره شده</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-emerald-400">{stats.readyForTraining}</p>
            <p className="text-xs text-[#94a3b8]">آماده آموزش</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-amber-400">{stats.avgRating}</p>
            <p className="text-xs text-[#94a3b8]">میانگین امتیاز</p>
          </div>
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 text-center">
            <p className="text-2xl font-bold text-[#a855f7]">{injectedSources.length}</p>
            <p className="text-xs text-[#94a3b8]">منابع تزریق شده</p>
          </div>
        </div>
      )}
      <button onClick={() => setShowStats(!showStats)} className="text-xs text-[#6366f1] hover:underline text-center block mx-auto">
        {showStats ? '🙈 مخفی کردن آمار' : '📊 نمایش آمار'}
      </button>

      {/* ===== TAB 1: مغز واحد ===== */}
      {activeTab === 'unified' && (
        <div className="space-y-6">
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2"><span>💬</span> با مغز حرف بزن</h3>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="هر چی دوست داری بگو - مغز تصمیم می‌گیره از تزریقی، تقطیری یا محاوره استفاده کنه..."
              rows={3}
              className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none resize-none"
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); think(); } }}
            />
            <button
              onClick={think}
              disabled={loading || !input.trim()}
              className="mt-3 w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] disabled:opacity-50 py-3 rounded-xl font-bold transition-all"
            >
              {loading ? '🧠 مغز در حال تفکر...' : '🧠 بفرمایید مغز تفکر کند'}
            </button>
          </div>

          {response && (
            <div className="bg-gradient-to-br from-[#6366f1]/5 to-[#a855f7]/5 border border-[#334155] rounded-2xl p-6 animate-slide-in">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <span>🧠</span> پاسخ مغز
                </h3>
                <span className="text-xs px-2 py-1 rounded-full bg-[#6366f1]/20 text-[#6366f1] border border-[#6366f1]/30">
                  {methodLabels[response.method] || response.method}
                </span>
              </div>

              <div className="bg-[#0f172a]/50 rounded-xl p-5 border border-[#334155] mb-4">
                <p className="text-white leading-8 whitespace-pre-line" dir="rtl">{response.text}</p>
              </div>

              {response.verses?.length > 0 && (
                <div className="space-y-2">
                  <p className="text-sm text-[#94a3b8]">🌸 ابیات:</p>
                  {response.verses.map((v: any, i: number) => (
                    <div key={i} className="bg-[#0f172a]/30 rounded-xl p-3 border border-[#334155]">
                      <p className="text-white" dir="rtl">{v.text}</p>
                      <p className="text-xs text-[#64748b] mt-1">— {v.poet}{v.book ? ` (${v.book})` : ''}</p>
                    </div>
                  ))}
                </div>
              )}

              {response.stats && (
                <div className="mt-4 flex flex-wrap gap-2 text-[10px] text-[#64748b] pt-3 border-t border-[#334155]">
                  <span>📚 {response.stats.dbVerses} بیت بانک</span>
                  <span>📥 {response.stats.injectedVerses} بیت تزریقی</span>
                  <span>💾 {response.stats.experienceCount} تجربه</span>
                  <span>{response.isColloquial ? '🗣️ محاوره' : '📝 رسمی'}</span>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ===== TAB 2: تزریق لینک ===== */}
      {activeTab === 'inject' && (
        <div className="space-y-6">
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📥</span> تزریق لینک به مغز
            </h3>
            <p className="text-sm text-[#94a3b8] mb-4">
              لینک Ganjoor، ویکی‌پدیا، بلاگ یا هر صفحه‌ای که شعر فارسی داره رو بده<br />
              مغز محتوا رو می‌خونه، ابیات رو استخراج می‌کنه و به بانکش اضافه می‌کنه
            </p>
            <div className="space-y-3">
              <input
                type="url"
                value={linkUrl}
                onChange={(e) => setLinkUrl(e.target.value)}
                placeholder="https://ganjoor.net/hafez/ghazal/..."
                className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none"
              />
              <input
                type="text"
                value={linkPoet}
                onChange={(e) => setLinkPoet(e.target.value)}
                placeholder="(اختیاری) نام شاعر مثل: حافظ"
                className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none"
              />
              <button
                onClick={injectLink}
                disabled={injectLoading || !linkUrl.trim()}
                className="w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] disabled:opacity-50 py-3 rounded-xl font-bold transition-all flex items-center justify-center gap-2"
              >
                {injectLoading ? '🔄 در حال تزریق...' : '📥 تزریق به مغز'}
              </button>
            </div>

            {injectResult && (
              <div className="mt-4 bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 animate-slide-in">
                <p className="text-emerald-400 font-medium">✅ تزریق شد!</p>
                <p className="text-sm text-[#94a3b8] mt-1">{injectResult.title}</p>
                <p className="text-xs text-[#64748b] mt-1">
                  {injectResult.verses.length} بیت استخراج شد • {injectResult.content.length} کاراکتر
                </p>
              </div>
            )}

            {/* لینک‌های پیشنهادی */}
            <div className="mt-6">
              <p className="text-sm text-[#94a3b8] mb-3">📌 لینک‌های پیشنهادی برای تزریق:</p>
              <div className="flex flex-wrap gap-2">
                {[
                  { url: 'https://fa.wikisource.org/wiki/دیوان_حافظ', label: '📖 دیوان حافظ (ویکی‌نبشته)' },
                  { url: 'https://ganjoor.net/hafez/ghazal/sh1', label: '🌸 غزل ۱ حافظ (گنجور)' },
                  { url: 'https://ganjoor.net/saadi/golestan', label: '🌹 گلستان سعدی (گنجور)' },
                  { url: 'https://ganjoor.net/moulavi/masnavi', label: '📕 مثنوی مولانا (گنجور)' },
                  { url: 'https://ganjoor.net/ferdowsi/shahnameh', label: '⚔️ شاهنامه فردوسی (گنجور)' },
                  { url: 'https://ganjoor.net/khayyam/robaee', label: '🍷 رباعیات خیام (گنجور)' },
                ].map((link, i) => (
                  <button
                    key={i}
                    onClick={() => setLinkUrl(link.url)}
                    className="text-xs px-3 py-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 hover:text-white transition-all text-right"
                  >
                    {link.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* منابع تزریق شده */}
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📚</span> منابع تزریق شده ({injectedSources.length})
            </h3>
            {injectedSources.length === 0 ? (
              <p className="text-[#64748b] text-sm text-center py-6">هنوز منبعی تزریق نکردی! لینک بده تا مغز تغذیه بشه 😋</p>
            ) : (
              <div className="space-y-2 max-h-60 overflow-y-auto">
                {injectedSources.map((src, i) => (
                  <div key={i} className="bg-[#0f172a]/50 rounded-xl p-3 border border-[#334155]">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-sm text-white font-medium truncate max-w-[250px]">{src.title}</p>
                        {src.poet && <p className="text-xs text-[#6366f1]">{src.poet}</p>}
                      </div>
                      <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#6366f1]/20 text-[#6366f1]">{src.verses.length} بیت</span>
                    </div>
                    <div className="flex gap-1 mt-1">
                      {src.tags?.map((t: string, ti: number) => (
                        <span key={ti} className="text-[9px] px-1.5 py-0.5 rounded bg-[#a855f7]/10 text-[#a855f7]">{t}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ===== TAB 3: تجارب ===== */}
      {activeTab === 'experiences' && (
        <div className="space-y-6">
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2"><span>💾</span> تجارب ثبت شده</h3>
            <div className="flex gap-3">
              <button
                onClick={exportBrain}
                className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] px-5 py-2.5 rounded-xl text-sm font-medium"
              >
                📥 بک‌آپ کامل مغز
              </button>
              <button
                onClick={async () => {
                  const res = await fetch("/api/brain", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ action: "generate-dataset", format: "json", minRating: 3 }),
                  });
                  const d = await res.json();
                  if (d.success) {
                    const blob = new Blob([d.data], { type: "application/json" });
                    const a = document.createElement("a");
                    a.href = URL.createObjectURL(blob);
                    a.download = "persian-brain-dataset.json";
                    a.click();
                  }
                }}
                className="bg-[#1e293b] border border-[#334155] px-5 py-2.5 rounded-xl text-sm hover:bg-[#334155] transition-all"
              >
                📊 خروجی دیتاست
              </button>
            </div>
          </div>

          {stats && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {stats.topTopics?.length > 0 && (
                <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                  <h4 className="text-sm font-medium text-[#94a3b8] mb-3">🏷️ موضوعات پرتکرار</h4>
                  <div className="space-y-2">
                    {stats.topTopics.map(([topic, count]: [string, number], i: number) => (
                      <div key={i} className="flex justify-between text-sm">
                        <span>{topic}</span>
                        <span className="text-[#6366f1]">{count} بار</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
              {stats.byRating && (
                <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                  <h4 className="text-sm font-medium text-[#94a3b8] mb-3">⭐ توزیع امتیاز</h4>
                  <div className="space-y-2">
                    {[5, 4, 3, 2, 1].map(r => (
                      <div key={r} className="flex items-center gap-2 text-sm">
                        <span className="w-8">{'⭐'.repeat(r)}</span>
                        <div className="flex-1 bg-[#0f172a] rounded-full h-2">
                          <div className="bg-amber-500 h-2 rounded-full" style={{
                            width: `${((stats.byRating[r] || 0) / Math.max(stats.total, 1)) * 100}%`
                          }} />
                        </div>
                        <span className="text-[#64748b] w-6 text-left">{stats.byRating[r] || 0}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ===== TAB 4: دیتاست ===== */}
      {activeTab === 'dataset' && (
        <div className="space-y-6">
          <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6">
            <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
              <span>📦</span> تولید دیتاست برای فاین‌تیون
            </h3>
            <div className="space-y-4">
              <p className="text-sm text-[#94a3b8]">
                از تجارب ثبت شده دیتاست آموزشی بساز و با اسکریپت Python روی GPU فاین‌تیون کن!
              </p>

              <div className="bg-gradient-to-br from-[#6366f1]/10 to-[#a855f7]/10 border border-[#6366f1]/20 rounded-2xl p-5">
                <h4 className="font-medium mb-3 flex items-center gap-2"><span>📋</span> خلاصه مسیر:</h4>
                <div className="space-y-2 text-sm text-[#94a3b8]">
                  <p className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#6366f1]/20 flex items-center justify-center text-[10px]">1</span>
                    با مغز حرف بزن ← تجارب ثبت می‌شن
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#a855f7]/20 flex items-center justify-center text-[10px]">2</span>
                    به تعاملات امتیاز بده (با 👍/👎)
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#22c55e]/20 flex items-center justify-center text-[10px]">3</span>
                    اینجا دیتاست رو خروجی بگیر
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-[#f59e0b]/20 flex items-center justify-center text-[10px]">4</span>
                    اسکریپت Python رو روی Colab اجرا کن
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-[10px]">5</span>
                    مدل تقطیری جدید = مغز شخصی‌سازی شده 🎉
                  </p>
                </div>
              </div>

              <Link
                href="/distill"
                className="block bg-gradient-to-l from-[#6366f1] to-[#4f46e5] text-center py-3 rounded-xl font-bold hover:shadow-lg transition-all"
              >
                🧪 برو به صفحه تقطیر
              </Link>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
