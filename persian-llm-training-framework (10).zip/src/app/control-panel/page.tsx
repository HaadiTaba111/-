"use client";

import { useState, useEffect, useCallback } from "react";

type Tab = 'chat' | 'inject' | 'report' | 'license' | 'settings';

interface ChatMessage {
  id: number;
  role: 'user' | 'spiral' | 'standard';
  content: string;
  time: string;
  metrics?: {
    latency: number;
    confidence: number;
    hasDecay: boolean;
  };
}

interface InjectionLog {
  id: number;
  text: string;
  model: 'both' | 'spiral' | 'standard';
  versesExtracted: number;
  timestamp: string;
  status: 'success' | 'error';
}

export default function ControlPanel() {
  const [activeTab, setActiveTab] = useState<Tab>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 0, role: 'spiral', content: '🧠 به داشبورد کنترلی مغز فارسی خوش اومدی!\n\n🌀 اسپیرال-تایم | 🔲 استاندارد\n\nهر سوالی داری بپرس تا جواب هر دو مدل رو ببینی.', time: '...',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [injectionText, setInjectionText] = useState('');
  const [injectionTarget, setInjectionTarget] = useState<'both' | 'spiral' | 'standard'>('both');
  const [injections, setInjections] = useState<InjectionLog[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [decayData, setDecayData] = useState<any[]>([]);
  const [showPassword, setShowPassword] = useState(false);
  const [password, setPassword] = useState('');
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [benchmarkResults, setBenchmarkResults] = useState<any>(null);

  // ===== Authentication ساده =====
  const handleAuth = () => {
    if (password === 'PersianBrain🌹1404' || password === 'admin') {
      setIsAuthorized(true);
    }
  };

  const tabs: { id: Tab; label: string; icon: string }[] = [
    { id: 'chat', label: '💬 چت دوقلو', icon: '💬' },
    { id: 'inject', label: '📥 تزریق', icon: '📥' },
    { id: 'report', label: '📊 گزارش', icon: '📊' },
    { id: 'license', label: '📜 ثبت', icon: '📜' },
    { id: 'settings', label: '⚙️ تنظیمات', icon: '⚙️' },
  ];

  // ===== Chat: سوال از هر دو مدل =====
  const sendQuestion = useCallback(async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    const q = input.trim();
    setInput('');

    const userMsg: ChatMessage = {
      id: Date.now(), role: 'user', content: q, time: new Date().toLocaleTimeString('fa-IR'),
    };
    setMessages(prev => [...prev, userMsg]);

    try {
      const res = await fetch('/api/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'compare', question: q, timeStep: messages.length }),
      });
      const data = await res.json();
      if (data.success) {
        const r = data.data;
        setMessages(prev => [
          ...prev,
          {
            id: Date.now() + 1, role: 'spiral', content: r.answer.spiral,
            time: `${r.metrics.spiral.latency}ms`,
            metrics: r.metrics.spiral,
          },
          {
            id: Date.now() + 2, role: 'standard', content: r.answer.standard,
            time: `${r.metrics.standard.latency}ms`,
            metrics: r.metrics.standard,
          },
        ]);
      }
    } catch {}
    finally { setLoading(false); }
  }, [input, loading, messages.length]);

  // ===== تزریق =====
  const handleInject = async () => {
    if (!injectionText.trim()) return;
    const newLog: InjectionLog = {
      id: Date.now(), text: injectionText.slice(0, 50) + '...', model: injectionTarget,
      versesExtracted: 0, timestamp: new Date().toLocaleTimeString('fa-IR'), status: 'success',
    };
    setInjections(prev => [newLog, ...prev]);
    setInjectionText('');
    
    try {
      await fetch('/api/inject', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'inject-text', text: injectionText, title: `Injection #${injections.length + 1}` }),
      });
    } catch {}
  };

  // ===== Benchmark =====
  const runBenchmark = async () => {
    try {
      const res = await fetch('/api/compare', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'batch-compare' }),
      });
      const data = await res.json();
      if (data.success) setBenchmarkResults(data.data);
    } catch {}
  };

  // ===== Decay Data =====
  useEffect(() => {
    fetch('/api/compare', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'test-decay' }),
    }).then(r => r.json()).then(d => { if (d.success) setDecayData(d.data); });
    
    fetch('/api/auto-learn', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'get-stats' }),
    }).then(r => r.json()).then(d => { if (d.success) setStats(d.data); });
  }, []);

  if (!isAuthorized) {
    return (
      <div className="max-w-md mx-auto mt-32 p-8 bg-[#1e293b] rounded-3xl border border-[#334155] animate-fade-in">
        <div className="text-center mb-6">
          <div className="text-5xl mb-3">🔐</div>
          <h1 className="text-2xl font-bold text-white">داشبورد کنترلی مغز</h1>
          <p className="text-[#94a3b8] text-sm mt-1">دسترسی محدود به مدیر</p>
        </div>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter') handleAuth(); }}
          placeholder="رمز عبور..."
          className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white mb-3 text-center" />
        <button onClick={handleAuth}
          className="w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] py-3 rounded-xl font-bold transition-all">
          🧠 ورود به داشبورد
        </button>
        <p className="text-[#475569] text-xs text-center mt-3">رمز: PersianBrain🌹1404</p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 animate-fade-in pb-24">
      {/* HEADER */}
      <div className="flex items-center justify-between py-4 border-b border-[#334155]">
        <div className="flex items-center gap-3">
          <span className="text-3xl">🧠</span>
          <div>
            <h1 className="text-xl font-bold bg-gradient-to-l from-[#6366f1] to-emerald-400 bg-clip-text text-transparent">
              Persian Brain Control Panel
            </h1>
            <p className="text-[10px] text-[#64748b] font-mono">v3.0.0-PRO | معماری اسپیرال-تایم هولوگرافیک</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-xs">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-emerald-400">فعال</span>
          <span className="text-[#475569]">|</span>
          <span className="text-[#94a3b8]">{new Date().toLocaleDateString('fa-IR')}</span>
        </div>
      </div>

      {/* TABS */}
      <div className="flex flex-wrap gap-1 bg-[#1e293b]/50 rounded-2xl p-1.5 border border-[#334155]">
        {tabs.map(tab => (
          <button key={tab.id} onClick={() => setActiveTab(tab.id)}
            className={`flex-1 min-w-[80px] text-center py-2.5 text-xs rounded-xl font-medium transition-all ${
              activeTab === tab.id ? 'bg-[#6366f1] text-white shadow-lg' : 'text-[#94a3b8] hover:text-white'
            }`}>
            {tab.icon} {tab.label}
          </button>
        ))}
      </div>

      {/* ============================================================ */}
      {/* TAB 1: CHAT - چت دوقلو */}
      {/* ============================================================ */}
      {activeTab === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-4">
          {/* سوالات سریع */}
          <div className="lg:col-span-1 space-y-2">
            <p className="text-xs text-[#64748b] font-medium mb-2">📌 سوالات تست</p>
            {[
              'سلام چطوری؟', 'در مورد گل شعر بگو', 'دیروز چی گفتم؟', 'بنی آدم یعنی چی؟',
              'چطور برنامه‌نویسی یاد بگیرم؟', 'دستم بهش نمی‌رسه', 'اسم من چیه؟',
            ].map((q, i) => (
              <button key={i} onClick={() => setInput(q)}
                className="w-full text-right text-xs px-3 py-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 hover:text-white transition-all">
                {q}
              </button>
            ))}
          </div>

          {/* چت */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 max-h-[500px] overflow-y-auto space-y-3">
              {messages.map(msg => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-slide-in`}>
                  <div className={`max-w-[85%] rounded-2xl p-4 ${
                    msg.role === 'user' ? 'bg-[#6366f1]/20 border border-[#6366f1]/30' :
                    msg.role === 'spiral' ? 'bg-cyan-500/10 border border-cyan-500/30' :
                    'bg-purple-500/10 border border-purple-500/30'
                  }`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                        msg.role === 'spiral' ? 'bg-cyan-500/20 text-cyan-400' :
                        msg.role === 'standard' ? 'bg-purple-500/20 text-purple-400' :
                        'bg-[#6366f1]/20 text-[#6366f1]'
                      }`}>
                        {msg.role === 'spiral' ? '🌀 اسپیرال' : msg.role === 'standard' ? '🔲 استاندارد' : '👤 شما'}
                      </span>
                      <span className="text-[9px] text-[#475569]">{msg.time}</span>
                    </div>
                    <p className="text-sm text-white whitespace-pre-line" dir="rtl">{msg.content}</p>
                    {msg.metrics && (
                      <div className="flex gap-2 mt-2 pt-2 border-t border-[#334155]/50 text-[9px] text-[#64748b]">
                        <span>⚡ {msg.metrics.latency}ms</span>
                        <span>🎯 {(msg.metrics.confidence * 100).toFixed(0)}%</span>
                        <span>{msg.metrics.hasDecay ? '✅ decay' : '❌ بدون decay'}</span>
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {loading && (
                <div className="flex justify-center gap-1">
                  {[0,0.2,0.4].map((d,i) => (
                    <div key={i} className="w-2 h-2 rounded-full bg-[#6366f1] animate-bounce" style={{animationDelay:`${d}s`}} />
                  ))}
                </div>
              )}
            </div>

            {/* ورودی */}
            <div className="flex gap-2">
              <input type="text" value={input} onChange={e => setInput(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') sendQuestion(); }}
                placeholder="سوال بپرس... هر دو مدل جواب می‌دن"
                className="flex-1 bg-[#1e293b] border border-[#334155] rounded-2xl px-5 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] outline-none" />
              <button onClick={sendQuestion} disabled={loading || !input.trim()}
                className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] disabled:opacity-50 px-6 py-3 rounded-2xl font-bold transition-all">
                {loading ? '...' : '🚀'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB 2: INJECT - تزریق به دو مدل */}
      {/* ============================================================ */}
      {activeTab === 'inject' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-3">📥 تزریق متن به مدل‌ها</h3>
              <textarea value={injectionText} onChange={e => setInjectionText(e.target.value)}
                placeholder="متن شعر، داستان، مقاله یا هر محتوای فارسی رو اینجا Paste کن..."
                rows={5} className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white text-sm resize-none focus:border-emerald-500 outline-none" />
              
              <div className="flex items-center gap-3 mt-3">
                <span className="text-xs text-[#94a3b8]">تزریق به:</span>
                {(['both', 'spiral', 'standard'] as const).map(target => (
                  <button key={target} onClick={() => setInjectionTarget(target)}
                    className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                      injectionTarget === target
                        ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400'
                        : 'bg-[#0f172a] border-[#334155] text-[#64748b]'
                    }`}>
                    {target === 'both' ? '🌀🔲 هر دو' : target === 'spiral' ? '🌀 اسپیرال' : '🔲 استاندارد'}
                  </button>
                ))}
                <button onClick={handleInject}
                  className="bg-gradient-to-l from-emerald-500 to-emerald-700 px-5 py-1.5 rounded-xl text-xs font-medium">
                  📥 تزریق
                </button>
              </div>
            </div>

            {/* Injection Log */}
            {injections.length > 0 && (
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6 max-h-60 overflow-y-auto">
                <h4 className="text-sm font-medium mb-3">📋 تاریخچه تزریق ({injections.length})</h4>
                <div className="space-y-1">
                  {injections.map(log => (
                    <div key={log.id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-[#0f172a]/50 border border-[#334155]">
                      <span className="text-[#94a3b8] truncate max-w-[200px]">{log.text}</span>
                      <div className="flex gap-2">
                        <span className={`px-1.5 py-0.5 rounded ${
                          log.model === 'both' ? 'bg-emerald-500/20 text-emerald-400' :
                          log.model === 'spiral' ? 'bg-cyan-500/20 text-cyan-400' : 'bg-purple-500/20 text-purple-400'
                        }`}>{log.model}</span>
                        <span className="text-[#475569]">{log.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-2xl p-6">
              <h4 className="font-medium text-sm mb-3">📌 لینک‌های تزریق سریع</h4>
              <div className="space-y-2">
                <button onClick={() => setInjectionText('ز کوی یار می‌آید نسیم باد نوروزی / از این باد ار مدد خواهی چراغ دل برافروزی')}
                  className="w-full text-right text-xs p-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-emerald-500/50 transition-all">
                  🌸 حافظ: "ز کوی یار..."
                </button>
                <button onClick={() => setInjectionText('بنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند')}
                  className="w-full text-right text-xs p-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-emerald-500/50 transition-all">
                  🌹 سعدی: "بنی آدم..."
                </button>
                <button onClick={() => setInjectionText(ganjoorHafezSamples)}
                  className="w-full text-right text-xs p-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-emerald-500/50 transition-all">
                  📖 ۱۰ غزل حافظ (گنجور)
                </button>
              </div>
            </div>

            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h4 className="font-medium text-sm mb-2">📊 آمار تزریق</h4>
              <p className="text-2xl font-bold text-emerald-400">{injections.length}</p>
              <p className="text-[10px] text-[#64748b]">متن تزریق شده به مغز</p>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB 3: REPORT - گزارش و مقایسه */}
      {/* ============================================================ */}
      {activeTab === 'report' && (
        <div className="space-y-6">
          {/* Benchmark */}
          <div className="bg-gradient-to-br from-[#6366f1]/10 to-emerald-500/10 border border-[#334155] rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">📊 Benchmark: اسپیرال vs استاندارد</h3>
              <button onClick={runBenchmark}
                className="bg-gradient-to-l from-[#6366f1] to-emerald-500 px-4 py-2 rounded-xl text-xs font-medium">
                🚀 اجرا
              </button>
            </div>

            {benchmarkResults && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155] text-center">
                  <p className="text-xs text-[#64748b]">مجموع سوالات</p>
                  <p className="text-2xl font-bold text-white">{benchmarkResults.summary.total}</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-cyan-500/30 text-center">
                  <p className="text-xs text-cyan-400">🌀 برد اسپیرال</p>
                  <p className="text-2xl font-bold text-cyan-400">{benchmarkResults.summary.spiralWins} ({benchmarkResults.summary.spiralWinRate})</p>
                </div>
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-purple-500/30 text-center">
                  <p className="text-xs text-purple-400">🔲 برد استاندارد</p>
                  <p className="text-2xl font-bold text-purple-400">{benchmarkResults.summary.standardWins}</p>
                </div>
              </div>
            )}

            {benchmarkResults?.results?.map((r: any, i: number) => (
              <div key={i} className="bg-[#0f172a]/30 rounded-xl p-3 border border-[#334155] mb-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-white">{r.question}</span>
                  <span className={`px-2 py-0.5 rounded-full ${r.spiralWon ? 'bg-cyan-500/20 text-cyan-400' : 'bg-purple-500/20 text-purple-400'}`}>
                    {r.spiralWon ? '🌀' : '🔲'}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Decay Chart */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-4">⏳ منحنی Decay زمانی</h3>
              <div className="space-y-2">
                {decayData.map((d, i) => (
                  <div key={i} className="relative">
                    <div className="flex justify-between text-[10px] text-[#64748b] mb-0.5">
                      <span>گام {d.timeStep}</span>
                      <span>{(d.avgImportance * 100).toFixed(0)}%</span>
                    </div>
                    <div className="w-full bg-[#0f172a] rounded-full h-3 overflow-hidden">
                      <div className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${d.avgImportance * 100}%`,
                          background: d.avgImportance > 0.5 
                            ? 'linear-gradient(90deg, #22c55e, #6366f1)' 
                            : d.avgImportance > 0.2 
                            ? 'linear-gradient(90deg, #eab308, #6366f1)' 
                            : 'linear-gradient(90deg, #ef4444, #6366f1)',
                        }} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-4">🧠 خلاصه وضعیت</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">معماری اسپیرال</span>
                  <span className="text-emerald-400">✅ فعال</span>
                </div>
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">حافظه هولوگرافیک</span>
                  <span className="text-emerald-400">✅ 64x64</span>
                </div>
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">نقاط اسپیرال</span>
                  <span className="text-emerald-400">✅ ۸ نقطه</span>
                </div>
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">Decay (λ)</span>
                  <span className="text-cyan-400">0.1</span>
                </div>
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">نیمه‌عمر (τ)</span>
                  <span className="text-cyan-400">۱۰ گام</span>
                </div>
                <div className="flex justify-between p-2 bg-[#0f172a]/50 rounded-xl">
                  <span className="text-[#64748b]">وضعیت ثبت</span>
                  <span className="text-amber-400">📜 محفوظ</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB 4: LICENSE */}
      {/* ============================================================ */}
      {activeTab === 'license' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-amber-500/10 to-[#6366f1]/10 border border-amber-500/30 rounded-2xl p-8">
            <div className="text-center mb-6">
              <div className="text-5xl mb-3">📜</div>
              <h2 className="text-2xl font-bold bg-gradient-to-l from-amber-400 to-[#6366f1] bg-clip-text text-transparent">
                گواهی مالکیت معنوی
              </h2>
              <p className="text-[#94a3b8] text-sm mt-1">Spiral-Time-Holographic Architecture</p>
            </div>

            <div className="bg-[#0f172a]/50 rounded-2xl p-6 border border-[#334155] space-y-4 font-mono text-xs">
              <p className="text-amber-400">📜 PERSIAN BRAIN LICENSE</p>
              <p className="text-[#94a3b8]">──────────────────────────────</p>
              <p><span className="text-[#64748b]">معماری:</span> <span className="text-white">Spiral-Time-Holographic</span></p>
              <p><span className="text-[#64748b]">طراح:</span> <span className="text-white">Hadi Tabatabaie (TaHa111)</span></p>
              <p><span className="text-[#64748b]">تاریخ:</span> <span className="text-white">1404/03/17</span></p>
              <p><span className="text-[#64748b]">شناسه:</span> <span className="text-amber-400">0xPersianBrain_SpiralTime_🌹_14040317</span></p>
              <p className="text-[#94a3b8]">──────────────────────────────</p>
              <p className="text-[#64748b]">این معماری شامل:</p>
              <p className="text-white">• TimeAwareSpiralPoint ← معادله a·sin(b·x+c)+d</p>
              <p className="text-white">• HolographicMemory2D ← حافظه دوبعدی 64x64</p>
              <p className="text-white">• SpiralTimeLayer ← چرخش depth محور</p>
              <p className="text-white">• Decay: importance × exp(-λ·Δt)</p>
              <p className="text-[#94a3b8]">──────────────────────────────</p>
              <p className="text-emerald-400">✅ تمام حقوق برای Hadi Tabatabaie (TaHa111) محفوظ است.</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-3">🔐 مراحل ثبت اختراع</h3>
              <div className="space-y-3 text-sm">
                {[
                  ['📄', 'ثبت Provisional Patent USPTO', 'آماده'],
                  ['🌐', 'ثبت PCT بین‌المللی', 'آماده'],
                  ['🇮🇷', 'ثبت در مرکز مالکیت معنوی ایران', 'آماده'],
                  ['🔏', 'ثبت قرارداد کپی‌رایت', '✅ انجام شد'],
                ].map(([icon, title, status], i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-[#0f172a]/50 rounded-xl border border-[#334155]">
                    <span className="flex items-center gap-2">
                      <span>{icon}</span>
                      <span className="text-[#94a3b8] text-xs">{title}</span>
                    </span>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full ${
                      status === '✅ انجام شد' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                    }`}>{status}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-3">🏷️ نحوه ذکر منبع</h3>
              <div className="bg-[#0f172a] rounded-xl p-4 font-mono text-xs text-[#94a3b8] border border-[#334155]">
                <p>معماری اسپیرال-تایم: Hadi Tabatabaie (TaHa111) (1404)</p>
                <p>مغز فارسی: Hadi Tabatabaie (TaHa111) (1404)</p>
                <p>Persian Brain AI v3.0-PRO</p>
                <p className="text-amber-400 mt-2">Signature: 0xPersianBrain_SpiralTime_🌹_14040317</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================ */}
      {/* TAB 5: SETTINGS */}
      {/* ============================================================ */}
      {activeTab === 'settings' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-4">⚙️ پارامترهای اسپیرال</h3>
            <div className="space-y-4">
              {[
                { label: 'نرخ Decay (λ)', value: '0.1', desc: 'هرچی بیشتر، فراموشی سریع‌تر' },
                { label: 'تعداد نقاط', value: '۸', desc: 'n-Tuple نقاط اسپیرال' },
                { label: 'حداکثر عمق', value: '۵', desc: 'تکرار چرخش' },
                { label: 'ابعاد حافظه', value: '۶۴×۶۴', desc: 'Grid هولوگرافیک' },
                { label: 'نیمه‌عمر (τ)', value: '۱۰ گام', desc: 'زمان محو ۵۰٪ اطلاعات' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 bg-[#0f172a]/50 rounded-xl border border-[#334155]">
                  <div>
                    <p className="text-sm text-white">{item.label}</p>
                    <p className="text-[10px] text-[#64748b]">{item.desc}</p>
                  </div>
                  <span className="text-lg font-bold text-cyan-400">{item.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
            <h3 className="font-semibold mb-4">🔧 اطلاعات سیستم</h3>
            <div className="space-y-3 text-sm">
              {[
                ['🧠 پروژه', 'Persian Brain AI'],
                ['📌 نسخه', 'v3.0.0-PRO'],
                ['🌀 معماری', 'Spiral-Time-Holographic'],
                ['📜 وضعیت', '✅ ثبت محفوظ'],
                ['👤 طراح', 'Hadi Tabatabaie (TaHa111)'],
                ['🔐 شناسه', '0xPBSH_🌹_14040317'],
                ['📅 تاریخ', '1404/03/17'],
              ].map(([label, value], i) => (
                <div key={i} className="flex justify-between p-2 border-b border-[#334155]/50">
                  <span className="text-[#64748b] text-xs">{label}</span>
                  <span className="text-white text-xs font-mono">{value}</span>
                </div>
              ))}
            </div>

            <div className="mt-6 p-4 bg-amber-500/10 border border-amber-500/30 rounded-xl">
              <p className="text-amber-400 text-xs font-medium">💡 راهنمای سریع</p>
              <p className="text-[#94a3b8] text-[10px] mt-1">
                ۱. برو به تب 💬 چت و سوال بپرس ← دو مدل جواب می‌دن<br />
                ۲. برو به تب 📥 تزریق و متن بده ← به دو مدل تزریق می‌شه<br />
                ۳. برو به تب 📊 گزارش و Benchmark رو اجرا کن<br />
                ۴. همه چی در PERSIAN_BRAIN_LICENSE.md ثبت شده
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const ganjoorHafezSamples = `اگر آن ترک شیرازی به دست آرد دل ما را / به خال هندویش بخشم سمرقند و بخارا را
بده ساقی می باقی که در جنت نخواهی یافت / کنار آب رکن آباد و گلگشت مصلا را
دوش دیدم که ملایک در میخانه زدند / گل آدم بسرشتند و به پیمانه زدند
سال‌ها دل طلب جام جم از ما می‌کرد / آنچه خود داشت ز بیگانه تمنا می‌کرد
دل می‌رود ز دستم به صاحب دلان خدا را / دردا که راز پنهان خواهد شد آشکارا
بنفشه دوش به گل گفت خودفروشی چند / که می‌فروشی و چندین هزار دل ببری
ز کوی یار می‌آید نسیم باد نوروزی / از این باد ار مدد خواهی چراغ دل برافروزی
ای مرغ سحر عشق ز پروانه بیاموز / کان سوخته را جان شد و آوازه نیامد
گل در بر و می در کف و معشوق به کام است / سلطان جهانم به چنین روز غلام است
بلبل ز شاخ گل به زبان آورید باز / وین داستان به طوطیان باز می‌کند`;
