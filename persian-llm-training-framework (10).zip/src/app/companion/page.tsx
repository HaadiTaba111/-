"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { companionThink } from "@/lib/offline-brain";
import { loadProfile, analyzePreferences } from "@/lib/user-profile";
import { COLLOQUIAL_EXAMPLES } from "@/lib/colloquial-persian";
import Link from "next/link";

interface Message {
  id: number;
  role: "user" | "assistant";
  text: string;
  verses?: Array<{ text: string; poet: string; book?: string }>;
  analysis?: any;
  timestamp: number;
}

export default function CompanionPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "assistant",
      text: "سلام دوست من! 🧠 من مغز فارسی‌ام، همراه همیشگی تو.\n\nمی‌تونم باهات حرف بزنم، شعر بگم، حالت رو بفهمم و همیشه در کنارتم.\nهر طور راحت‌تی باهات حرف بزن! 😎",
      timestamp: Date.now(),
    },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [userName, setUserName] = useState("دوست");
  const [showProfile, setShowProfile] = useState(false);
  const [profileInsight, setProfileInsight] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [mode, setMode] = useState<"free" | "poetry" | "conversation">("free");

  // بارگذاری پروفایل
  useEffect(() => {
    const profile = loadProfile();
    setUserName(profile.name);
  }, []);

  // auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Voice
  const speak = useCallback(
    (text: string) => {
      if (!voiceEnabled || typeof window === "undefined") return;
      try {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "fa-IR";
        utterance.rate = 0.9;
        utterance.pitch = 1.1;
        window.speechSynthesis.speak(utterance);
      } catch (e) {
        console.warn("Voice error:", e);
      }
    },
    [voiceEnabled]
  );

  const sendMessage = useCallback(() => {
    const text = input.trim();
    if (!text || loading) return;

    setInput("");
    setLoading(true);

    // اضافه کردن پیام کاربر
    const userMsg: Message = {
      id: Date.now(),
      role: "user",
      text,
      timestamp: Date.now(),
    };
    setMessages((prev) => [...prev, userMsg]);

    // شبیه‌سازی تأخیر طبیعی
    setTimeout(() => {
      try {
        const response = companionThink(text, {
          userName,
          temperature: 0.7,
          mode: mode === "poetry" ? "poetry" : "free",
        });

        // insight پروفایل
        if (response.profileInsight) {
          setProfileInsight(response.profileInsight);
        }

        const assistantMsg: Message = {
          id: Date.now() + 1,
          role: "assistant",
          text: response.text,
          verses: response.verses,
          analysis: response.analysis,
          timestamp: Date.now(),
        };

        setMessages((prev) => [...prev, assistantMsg]);

        // Voice
        if (response.shouldSpeak) {
          speak(response.text);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }, 500 + Math.random() * 500);
  }, [input, loading, userName, mode, speak]);

  const toggleVoice = () => {
    const newVal = !voiceEnabled;
    setVoiceEnabled(newVal);

    if (!newVal && typeof window !== "undefined") {
      window.speechSynthesis.cancel();
    }

    if (newVal) {
      const msg = "سلام! حالت صوتی فعال شد 😊";
      const utterance = new SpeechSynthesisUtterance(msg);
      utterance.lang = "fa-IR";
      window.speechSynthesis.speak(utterance);
    }
  };

  const quickActions = [
    { icon: "🌸", text: "شعر گل", action: "در مورد گل و بهار شعر بگو" },
    { icon: "💖", text: "شعر عشق", action: "شعر عاشقانه از حافظ" },
    { icon: "😢", text: "دلم گرفته", action: "دلم گرفته یه شعر بگو" },
    { icon: "🤝", text: "دوستی", action: "درباره دوستی از سعدی بگو" },
    { icon: "🧠", text: "کی هستی", action: "تو کی هستی؟" },
    { icon: "😎", text: "چطوری", action: "سلام داداش چطوری؟" },
  ];

  const profile = loadProfile();
  const prefs = profile.totalInteractions > 3 ? analyzePreferences(profile) : null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 animate-fade-in pb-24">
      {/* هدر */}
      <div className="text-center space-y-3 py-4">
        <div className="inline-block animate-float text-4xl mb-2">🧠</div>
        <h1 className="text-3xl sm:text-4xl font-bold bg-gradient-to-l from-[#6366f1] to-[#a855f7] bg-clip-text text-transparent">
          {userName} جان! 🤗
        </h1>
        <p className="text-[#94a3b8]">همراه هوشمند آفلاین - محاوره رو می‌فهمم، حالت رو تشخیص می‌دم</p>
      </div>

      {/* ابزارها */}
      <div className="flex flex-wrap items-center justify-center gap-2">
        {/* Voice Toggle */}
        <button
          onClick={toggleVoice}
          className={`px-4 py-2 rounded-xl text-sm border transition-all flex items-center gap-1.5 ${
            voiceEnabled
              ? "bg-emerald-500/20 border-emerald-500/50 text-emerald-400"
              : "bg-[#1e293b] border-[#334155] text-[#94a3b8]"
          }`}
        >
          <span>🔊</span>
          {voiceEnabled ? "صوت فعال" : "صوت غیرفعال"}
        </button>

        {/* Mode */}
        <div className="flex bg-[#1e293b] rounded-xl border border-[#334155] p-1">
          {(["free", "poetry", "conversation"] as const).map((m) => (
            <button
              key={m}
              onClick={() => setMode(m)}
              className={`px-3 py-1.5 text-xs rounded-lg transition-all ${
                mode === m
                  ? "bg-[#6366f1] text-white"
                  : "text-[#94a3b8] hover:text-white"
              }`}
            >
              {m === "free" && "🎯 آزاد"}
              {m === "poetry" && "🌸 شعر"}
              {m === "conversation" && "💬 گفتگو"}
            </button>
          ))}
        </div>

        {/* Profile */}
        <button
          onClick={() => setShowProfile(!showProfile)}
          className="px-4 py-2 rounded-xl text-sm bg-[#1e293b] border border-[#334155] text-[#94a3b8] hover:text-white transition-all"
        >
          📊 پروفایل من
        </button>
      </div>

      {/* Profile Panel */}
      {showProfile && (
        <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-6 animate-slide-in">
          <h3 className="font-semibold mb-4 flex items-center gap-2">
            <span>📊</span> پروفایل و الگوی رفتاری {userName}
          </h3>
          {profile.totalInteractions === 0 ? (
            <p className="text-[#94a3b8] text-sm">هنوز اطلاعات کافی نیست. باهات حرف بزنم تا بشناسمت! 😊</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-sm">
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">تعداد تعاملات</p>
                <p className="text-2xl font-bold text-white">{profile.totalInteractions}</p>
              </div>
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">روزهای متوالی</p>
                <p className="text-2xl font-bold text-emerald-400">{profile.streaks.currentStreak} 🔥</p>
              </div>
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">شاعر محبوب</p>
                <p className="text-lg font-bold text-[#6366f1]">{prefs?.bestPoet || "در حال کشف..."}</p>
              </div>
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">موضوع محبوب</p>
                <p className="text-lg font-bold text-[#a855f7]">{prefs?.bestTopic || "در حال کشف..."}</p>
              </div>
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">حال و هوای غالب</p>
                <p className="text-lg font-bold text-amber-400">{prefs?.dominantEmotion || "خنثی"}</p>
              </div>
              <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]">
                <p className="text-[#64748b] text-xs mb-1">ساعت اوج مراجعه</p>
                <p className="text-lg font-bold text-emerald-400">{prefs?.peakHour || "نامشخص"}:00</p>
              </div>
              {prefs?.recommendation && (
                <div className="sm:col-span-2 lg:col-span-3 bg-gradient-to-r from-[#6366f1]/10 to-[#a855f7]/10 rounded-xl p-4 border border-[#6366f1]/20">
                  <p className="text-[#6366f1] text-xs mb-1">🧠 تحلیل مغز از تو:</p>
                  <p className="text-white">{prefs.recommendation}</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Insight Alert */}
      {profileInsight && (
        <div className="bg-gradient-to-r from-amber-500/10 to-orange-500/10 border border-amber-500/20 rounded-2xl p-4 animate-slide-in">
          <div className="flex items-center justify-between">
            <p className="text-amber-400 text-sm">{profileInsight}</p>
            <button
              onClick={() => setProfileInsight(null)}
              className="text-[#64748b] hover:text-white text-xs"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Chat Box */}
      <div className="bg-[#1e293b]/80 backdrop-blur-sm border border-[#334155] rounded-2xl p-4 max-h-[500px] overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-slide-in`}
          >
            <div
              className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 ${
                msg.role === "user"
                  ? "bg-[#6366f1]/20 border border-[#6366f1]/30 rounded-bl-none"
                  : "bg-[#0f172a]/80 border border-[#334155] rounded-tr-none"
              }`}
            >
              <p className={`text-sm whitespace-pre-line leading-7 ${msg.role === "user" ? "text-white" : "text-[#e2e8f0]"}`} dir="rtl">
                {msg.text}
              </p>

              {/* ابیات در پاسخ */}
              {msg.verses && msg.verses.length > 0 && (
                <div className="mt-3 pt-3 border-t border-[#334155]/50 space-y-2">
                  {msg.verses.map((v, i) => (
                    <div key={i} className="bg-[#6366f1]/5 rounded-xl p-3 border border-[#6366f1]/10">
                      <p className="text-white text-sm leading-8" dir="rtl">{v.text}</p>
                      <p className="text-[#64748b] text-xs mt-1">— {v.poet}{v.book ? ` (${v.book})` : ""}</p>
                    </div>
                  ))}
                </div>
              )}

              <p className="text-[10px] text-[#475569] mt-2">
                {new Date(msg.timestamp).toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" })}
              </p>
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex justify-start animate-slide-in">
            <div className="bg-[#0f172a]/80 border border-[#334155] rounded-2xl rounded-tr-none p-4">
              <div className="flex gap-1.5">
                {[0, 0.2, 0.4].map((d, i) => (
                  <div
                    key={i}
                    className="w-2 h-2 rounded-full bg-[#6366f1] animate-bounce"
                    style={{ animationDelay: `${d}s` }}
                  />
                ))}
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Quick Actions */}
      <div className="flex flex-wrap gap-2">
        {quickActions.map((action, i) => (
          <button
            key={i}
            onClick={() => {
              setInput(action.action);
            }}
            className="text-xs px-3 py-1.5 rounded-full bg-[#1e293b] border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 hover:text-white transition-all"
          >
            {action.icon} {action.text}
          </button>
        ))}
      </div>

      {/* Input */}
      <div className="fixed bottom-0 right-0 left-0 bg-[#0f172a]/95 backdrop-blur-xl border-t border-[#334155] p-4">
        <div className="max-w-7xl mx-auto flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                sendMessage();
              }
            }}
            placeholder="به فارسی محاوره‌ای بگو... مثلاً: داداش چطوری؟ یا یه شعر بگو"
            className="flex-1 bg-[#1e293b] border border-[#334155] rounded-2xl px-5 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] focus:outline-none transition-colors"
          />
          <button
            onClick={sendMessage}
            disabled={loading || !input.trim()}
            className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] disabled:opacity-50 disabled:cursor-not-allowed px-6 py-3 rounded-2xl font-bold hover:shadow-lg hover:shadow-[#6366f1]/25 transition-all"
          >
            {loading ? "..." : "🗣️"}
          </button>
        </div>
        <p className="text-[10px] text-[#475569] text-center mt-2">
          🧠 مغز فارسی - کاملاً آفلاین | فارسی محاوره‌ای + انگلیسی | Voice {voiceEnabled ? "🔊" : "🔇"}
        </p>
      </div>
    </div>
  );
}
