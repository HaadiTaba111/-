import {
  pgTable,
  serial,
  text,
  varchar,
  jsonb,
  integer,
  real,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";

// ========== مدل‌های مغز ==========
export const models = pgTable("models", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  description: text("description"),
  // پارامترهای مغز
  baseModel: varchar("base_model", { length: 255 }).notNull().default("facebook/opt-125m"),
  temperature: real("temperature").notNull().default(0.7),
  topP: real("top_p").notNull().default(0.9),
  maxLength: integer("max_length").notNull().default(256),
  repetitionPenalty: real("repetition_penalty").notNull().default(1.1),
  // آمار
  totalTrainingTokens: integer("total_training_tokens").notNull().default(0),
  trainingEpochs: integer("training_epochs").notNull().default(3),
  learningRate: real("learning_rate").notNull().default(3e-5),
  // وضعیت
  status: varchar("status", { length: 50 }).notNull().default("untrained"),
  // متادیتا
  datasetSources: jsonb("dataset_sources").default([]),
  tags: text("tags").array().default([]),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// ========== جلسات آموزش ==========
export const trainingSessions = pgTable("training_sessions", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id")
    .references(() => models.id, { onDelete: "cascade" })
    .notNull(),
  status: varchar("status", { length: 50 }).notNull().default("pending"),
  progress: real("progress").notNull().default(0),
  epochsCompleted: integer("epochs_completed").notNull().default(0),
  totalEpochs: integer("total_epochs").notNull().default(3),
  loss: real("loss"),
  accuracy: real("accuracy"),
  // داده‌های آموزشی استفاده شده
  datasetName: varchar("dataset_name", { length: 255 }),
  numSamples: integer("num_samples").notNull().default(0),
  batchSize: integer("batch_size").notNull().default(8),
  // لاگ
  logs: jsonb("logs").default([]),
  startedAt: timestamp("started_at"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ========== لاگ‌های استنتاج ==========
export const inferenceLogs = pgTable("inference_logs", {
  id: serial("id").primaryKey(),
  modelId: integer("model_id")
    .references(() => models.id, { onDelete: "cascade" })
    .notNull(),
  prompt: text("prompt").notNull(),
  response: text("response").notNull(),
  // پارامترهای لحظه‌ای
  temperature: real("temperature").notNull().default(0.7),
  topP: real("top_p").notNull().default(0.9),
  maxLength: integer("max_length").notNull().default(256),
  // متریک‌ها
  latencyMs: integer("latency_ms"),
  tokenCount: integer("token_count"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// ========== بازخورد ==========
export const feedback = pgTable("feedback", {
  id: serial("id").primaryKey(),
  inferenceId: integer("inference_id")
    .references(() => inferenceLogs.id, { onDelete: "cascade" }),
  rating: integer("rating").notNull().default(3),
  comment: text("comment"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type Model = typeof models.$inferSelect;
export type NewModel = typeof models.$inferInsert;
export type TrainingSession = typeof trainingSessions.$inferSelect;
export type InferenceLog = typeof inferenceLogs.$inferSelect;
