#!/usr/bin/env bash
# ================================================================
# 🚀 مغز فارسی - آموزش روی PC با 8GB GPU
# Persian Brain - Local GPU Training Pipeline
#
# این اسکریپت مدل رو واقعاً آموزش میده (نه تزریق!)
# با QLoRA (4-bit) روی 8GB VRAM اجرا می‌شه
#
# ===== مدل‌های پیشنهادی =====
# Qwen/Qwen2.5-1.5B-Instruct  ← 🏆 بهترین برای فارسی (1.5B)
# google/gemma-2-2b-it         ← 🥈 عالی (2B)
# microsoft/Phi-3-mini-4k-instruct ← 🥉 قوی (3.8B)
# ================================================================

set -euo pipefail

# 🎨 رنگ‌ها
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; PURPLE='\033[0;35m'; CYAN='\033[0;36m'
WHITE='\033[1;37m'; NC='\033[0m'; BOLD='\033[1m'

# ═══════════════════════════════════════════════
# ⚙️ تنظیمات (اینجا رو تغییر بده)
# ═══════════════════════════════════════════════

# مدل پایه
BASE_MODEL="${1:-Qwen/Qwen2.5-1.5B-Instruct}"
OUTPUT_DIR="./persian-brain-trained"
DATASET_FILE="./persian-training-data.json"

# تنظیمات QLoRA
LORA_R=16
LORA_ALPHA=32
LORA_DROPOUT=0.05

# تنظیمات آموزش
EPOCHS=3
BATCH_SIZE=2       # برای 8GB VRAM
GRADIENT_ACC=4     # batch size مجازی = 2*4 = 8
LEARNING_RATE=2e-4
MAX_LENGTH=512
USE_4BIT=true      # QLoRA 4-bit

# ═══════════════════════════════════════════════
# 🏗️ توابع
# ═══════════════════════════════════════════════

log() { echo -e "${GREEN}[$(date +'%H:%M:%S')]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; }

check_gpu() {
    log "🔍 بررسی GPU..."
    
    if command -v nvidia-smi &>/dev/null; then
        local gpu_info=$(nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader 2>/dev/null)
        local vram=$(nvidia-smi --query-gpu=memory.total --format=csv,noheader 2>/dev/null | grep -oP '\d+' || echo "0")
        log "  🎮 GPU: $gpu_info"
        
        if [[ $vram -lt 6000 ]]; then
            warn "  ⚠️ VRAM کمتر از 6GB! ممکنه کند باشه"
            BATCH_SIZE=1
            GRADIENT_ACC=2
        elif [[ $vram -lt 10000 ]]; then
            log "  ✅ 8GB VRAM - مناسب برای QLoRA"
        else
            log "  🚀 VRAM بالا - می‌تونیم batch size رو ببریم بالا"
            BATCH_SIZE=4
        fi
    else
        error "❌ GPU پیدا نشد! این اسکریپت نیاز به NVIDIA GPU داره."
        exit 1
    fi
}

# ═══════════════════════════════════════════════
# 📦 مرحله ۱: تولید دیتاست آموزشی
# ═══════════════════════════════════════════════

generate_dataset() {
    log "📦 مرحله ۱: تولید دیتاست آموزشی از مغز فارسی"
    
    # دیتاست JSON با فرمت Chat (sharegpt-like)
    cat > "$DATASET_FILE" << 'JSONEOF'
[
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی. به سوالات به فارسی روان جواب بده."},
            {"role": "user", "content": "در مورد گل و بهار شعر بگو"},
            {"role": "assistant", "content": "🌸 گل در بهار می‌خندد و بلبل به عشقش نغمه می‌خواند.\n\nچو گل در باغ خندان شود بهار / دل از عشقش شود پروردگار\n\n— برگرفته از اشعار حافظ و سعدی"}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی."},
            {"role": "user", "content": "سلام چطوری؟"},
            {"role": "assistant", "content": "سلام داداش! خوبم، ممنون که پرسیدی. تو چطوری؟ چه خبرا؟ 🌹"}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی."},
            {"role": "user", "content": "بنی آدم اعضای یکدیگرند یعنی چی؟"},
            {"role": "assistant", "content": "این بیت معروف سعدی از گلستان هست:\n\nبنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند\nچو عضوی به درد آورد روزگار / دگر عضوها را نماند قرار\n\nیعنی همه انسان‌ها مثل اعضای یک بدن هستیم. اگه یکی درد بکشه، بقیه هم بی‌قرار می‌شن. این شعر دعوت به همدلی و مهربانیه."}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی."},
            {"role": "user", "content": "چطور می‌تونم برنامه‌نویسی یاد بگیرم؟"},
            {"role": "assistant", "content": "قدم‌قدم بهت می‌گم:\n\n۱. با یه زبان ساده مثل Python شروع کن\n۲. هر روز حداقل ۳۰ دقیقه کد بزن\n۳. پروژه کوچیک بزن (مثلاً ماشین حساب)\n۴. از منابع رایگان مثل freeCodeCamp استفاده کن\n۵. توی گیت‌هاب پروژه‌هات رو بذار\n\nسعدی می‌گه: «توانا بود هر که دانا بود» - هر کی یاد بگیره، می‌تونه!"}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی."},
            {"role": "user", "content": "دلم گرفته یه شعر بگو"},
            {"role": "assistant", "content": "🌙 داداش جان ناراحت نباش! این شعر از حافظ حالت رو خوب می‌کنه:\n\nز کوی یار می‌آید نسیم باد نوروزی / از این باد ار مدد خواهی چراغ دل برافروزی\n\nهمیشه یادت باشه: بعد از هر غمی، بهاری هست. ☀️"}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی. به سوالات فنی دقیق و مستند جواب بده."},
            {"role": "user", "content": "تفاوت بین REST و GraphQL چیه؟"},
            {"role": "assistant", "content": "تفاوت‌های اصلی:\n\n1️⃣ REST: \n   • هر endpoint یک منبع رو نمایش می‌ده\n   • داده اضافی (over-fetching) ممکنه\n   • کش کردن راحت‌تر\n   • با HTTP verbs کار می‌کنه (GET, POST, PUT, DELETE)\n\n2️⃣ GraphQL:\n   • یک endpoint برای همه چیز\n   • دقیقاً همون داده‌ای که نیاز داری برمی‌گردونه\n   • query language مخصوص خودش\n   • پیچیدگی سمت کلاینت بیشتر\n\nانتخاب بستگی به پروژه‌ات داره. برای API ساده REST کافیه، برای سیستم پیچیده با کلاینت‌های مختلف GraphQL بهتره."}
        ]
    },
    {
        "conversations": [
            {"role": "system", "content": "تو یک دستیار فارسی‌دان هستی."},
            {"role": "user", "content": "عشق چیه؟"},
            {"role": "assistant", "content": "عشق... سوال سختی پرسیدی!\n\nمولانا می‌گه:\n«عقل در شرحش چو خر در گل بخفت / شرح عشق و عاشقی هم عشق گفت»\n\nیعنی عقل از توضیح عشق عاجزه. فقط خود عشقه که می‌تونه عشق رو توضیح بده.\n\nبه نظر من، عشق یعنی:\n• وقتی برات مهمتر از خودتی\n• وقتی بدون چشم‌داشت می‌دی\n• وقتی حتی توی سختی‌ها هم می‌مونی\n\nعشق می‌تونه الهی باشه، زمینی، به خانواده، به دوست، به هنر... هر شکلیش قشنگه."}
        ]
    }
]
JSONEOF

    log "  ✅ دیتاست با ۷ نمونه آموزشی ساخته شد: $DATASET_FILE"
}

# ═══════════════════════════════════════════════
# 🧠 مرحله ۲: فاین‌تیون با QLoRA
# ═══════════════════════════════════════════════

run_training() {
    log "🧠 مرحله ۲: شروع فاین‌تیون $BASE_MODEL"
    log "  📊 تنظیمات: LoRA(r=$LORA_R) | Epochs=$EPOCHS | Batch=$BATCH_SIZE | 4bit=$USE_4BIT"
    
    # تولید و اجرای اسکریپت Python
    python3 << PYEOF
import json
import torch
from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    TrainingArguments,
    Trainer,
    DataCollatorForSeq2Seq,
    BitsAndBytesConfig,
)
from peft import LoraConfig, get_peft_model, TaskType, prepare_model_for_kbit_training
from datasets import Dataset
import os

print("📥 بارگذاری مدل و توکنایزر...")

# QLoRA 4-bit config
quant_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_compute_dtype=torch.float16,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
)

tokenizer = AutoTokenizer.from_pretrained("$BASE_MODEL")
tokenizer.pad_token = tokenizer.eos_token
tokenizer.chat_template = "{% for msg in messages %}{{ msg['role'] + ': ' + msg['content'] + '\\n' }}{% endfor %}"

model = AutoModelForCausalLM.from_pretrained(
    "$BASE_MODEL",
    quantization_config=quant_config,
    device_map="auto",
    torch_dtype=torch.float16,
    trust_remote_code=True,
)

# LoRA
lora_config = LoraConfig(
    r=$LORA_R,
    lora_alpha=$LORA_ALPHA,
    lora_dropout=$LORA_DROPOUT,
    task_type=TaskType.CAUSAL_LM,
    target_modules=["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"],
)

model = prepare_model_for_kbit_training(model)
model = get_peft_model(model, lora_config)
model.print_trainable_parameters()

# بارگذاری دیتاست
with open("$DATASET_FILE", "r") as f:
    data = json.load(f)

def format_chat(conv):
    messages = conv["conversations"]
    system = messages[0]["content"]
    user = messages[1]["content"]
    assistant = messages[2]["content"]
    return f"### سیستم: {system}\n### کاربر: {user}\n### دستیار: {assistant}"

texts = [format_chat(item) for item in data]
dataset = Dataset.from_dict({"text": texts})

def tokenize_fn(examples):
    return tokenizer(
        examples["text"],
        truncation=True,
        padding="max_length",
        max_length=$MAX_LENGTH,
    )

tokenized = dataset.map(tokenize_fn, batched=True)

# Training
training_args = TrainingArguments(
    output_dir="$OUTPUT_DIR",
    num_train_epochs=$EPOCHS,
    per_device_train_batch_size=$BATCH_SIZE,
    gradient_accumulation_steps=$GRADIENT_ACC,
    learning_rate=$LEARNING_RATE,
    fp16=True,
    save_steps=50,
    logging_steps=10,
    report_to="none",
    save_total_limit=2,
    remove_unused_columns=False,
    optim="adamw_8bit",
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=tokenized,
    data_collator=DataCollatorForSeq2Seq(tokenizer=tokenizer, pad_to_multiple_of=8),
)

print("🎯 شروع آموزش...")
trainer.train()

print(f"✅ مدل فاین‌تیون شده در: $OUTPUT_DIR")
print(f"📦 سایز LoRA weights: ~{model.peft_config['default'].r * $LORA_ALPHA * 2}MB")

# ذخیره
model.save_pretrained("$OUTPUT_DIR/lora")
tokenizer.save_pretrained("$OUTPUT_DIR")
with open("$OUTPUT_DIR/training_config.json", "w") as f:
    json.dump({
        "base_model": "$BASE_MODEL",
        "lora_r": $LORA_R,
        "lora_alpha": $LORA_ALPHA,
        "epochs": $EPOCHS,
        "batch_size": $BATCH_SIZE,
        "gradient_accumulation": $GRADIENT_ACC,
        "learning_rate": $LEARNING_RATE,
    }, f)

print("✅ آموزش کامل شد!")
PYEOF
}

# ═══════════════════════════════════════════════
# 🎤 مرحله ۳: نصب Voice Pipeline
# ═══════════════════════════════════════════════

setup_voice() {
    log "🎤 مرحله ۳: نصب Voice Pipeline"
    
    # Whisper برای تشخیص گفتار فارسی
    if ! python3 -c "import whisper" 2>/dev/null; then
        log "  📥 نصب Whisper (تشخیص گفتار فارسی)..."
        pip install openai-whisper 2>/dev/null || warn "  ⚠️ Whisper نصب نشد، ادامه می‌دم"
    fi
    
    # VITS برای تولید صدا
    if ! python3 -c "import TTS" 2>/dev/null; then
        log "  📥 نصب VITS/TTS (تولید صدای فارسی)..."
        pip install TTS 2>/dev/null || warn "  ⚠️ TTS نصب نشد، ادامه می‌دم"
    fi
    
    log "  ✅ Voice: Whisper + VITS آماده‌اند"
}

# ═══════════════════════════════════════════════
# 🚀 اجرای اصلی
# ═══════════════════════════════════════════════

main() {
    clear
    echo -e "${PURPLE}"
    echo "    ╔═══════════════════════════════════════════╗"
    echo "    ║    🚀  مغز فارسی - آموزش روی PC          ║"
    echo "    ║    Persian Brain Local GPU Training        ║"
    echo "    ╚═══════════════════════════════════════════╝"
    echo -e "${NC}"
    
    echo -e "  ${BLUE}🎮${NC} GPU: 8GB VRAM"
    echo -e "  ${BLUE}🧠${NC} مدل: $BASE_MODEL"
    echo -e "  ${BLUE}📊${NC} روش: QLoRA 4-bit"
    echo ""
    
    # بررسی GPU
    check_gpu
    
    echo ""
    
    # منو
    echo -e "${BOLD}${CYAN}===== منوی آموزش =====${NC}"
    echo "  1) 🚀 آموزش کامل (تولید دیتاست + فاین‌تیون)"
    echo "  2) 📦 فقط تولید دیتاست"
    echo "  3) 🧠 فقط فاین‌تیون (اگه دیتاست داری)"
    echo "  4) 🎤 نصب Voice Pipeline"
    echo "  5) 🎯 همه رو یکجا انجام بده!"
    echo "  0) خروج"
    echo ""
    echo -ne "${GREEN}انتخاب: ${NC}"
    read -r choice
    
    case "$choice" in
        1)
            generate_dataset
            echo ""
            run_training
            ;;
        2)
            generate_dataset
            ;;
        3)
            run_training
            ;;
        4)
            setup_voice
            ;;
        5)
            generate_dataset
            echo ""
            run_training
            echo ""
            setup_voice
            ;;
        0)
            echo -e "\n${PURPLE}🧠 خدا نگهدار!${NC}\n"
            exit 0
            ;;
        *)
            warn "❌ گزینه نامعتبر!"
            sleep 1
            main
            ;;
    esac
    
    echo ""
    log "${GREEN}✅${NC} ${BOLD}کار Done!${NC}"
    echo ""
    echo -e "${CYAN}🧠 مدل آموزش دیده:${NC} $OUTPUT_DIR"
    echo -e "${CYAN}📦 وزن‌های LoRA:${NC} $OUTPUT_DIR/lora"
    echo -e "${CYAN}📄 دیتاست:${NC} $DATASET_FILE"
    echo ""
    echo -e "${YELLOW}💡 حالا می‌تونی:${NC}"
    echo "  1. مغز فارسی رو اجرا کنی (npm run dev)"
    echo "  2. مدل فاین‌تیون شده بهش وصل بشه"
    echo "  3. Voice هم فعاله! 🎤🔊"
    echo ""
    echo -e "${BOLD}${GREEN}🔥 مغز فارسی واقعاً فارسی یاد گرفته! 🧠${NC}"
}

# اجرا
main "$@"
