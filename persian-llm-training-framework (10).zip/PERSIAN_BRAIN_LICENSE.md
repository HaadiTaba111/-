# 🧠 Persian Brain AI - License Agreement

## حقوق مالکیت معنوی (IP Rights)

**تاریخ:** 1404/03/17 (2025-06-07)  
**نسخه:** 3.0.0-PRO  
**وضعیت:** ثبت محفوظ

---

### 📜 اعلامیه مالکیت

این پروژه شامل دو معماری مجزا است که حقوق هر یک به شرح زیر است:

#### ۱. معماری اسپیرال-تایم-هولوگرافیک (Spiral-Time-Holographic)
```
Copyright © 1404 (2025) - Hadi Tabatabaie (TaHa111)

این معماری شامل:
• TimeAwareSpiralPoint - نقاط اسپیرال با آگاهی از زمان
• HolographicMemory2D - حافظه هولوگرافیک دوبعدی  
• SpiralTimeLayer - لایه اصلی اسپیرال-زمان
• معادله موقعیت: a*sin(b*x+c)+d با چرخش depth محور
• مکانیزم Decay: importance × exp(-λ·Δt)

این معماری توسط Hadi Tabatabaie (TaHa111) طراحی و پیاده‌سازی شده است.
هرگونه استفاده، کپی، یا توزیع بدون اجازه کتبی ممنوع است.
```

#### ۲. مغز فارسی (Persian Brain)
```
Copyright © 1404 (2025) - Hadi Tabatabaie (TaHa111)

شامل:
• Persian Poetry Database
• Colloquial Persian Engine
• Unified Brain Architecture
• Reasoning Engine & Pitfall Detection
• Auto-Learning Engine
• Poet Machine (شاعر ماشین)

تحت مجوز اختصاصی Hadi Tabatabaie (TaHa111) محفوظ است.
```

---

### 🔐 شرایط استفاده

1. **استفاده شخصی:** ✅ آزاد
2. **استفاده تجاری:** ❌ نیاز به اجازه کتبی
3. **توزیع مجدد:** ❌ ممنوع
4. **تحقیق و توسعه:** ✅ با ذکر منبع
5. **تغییر و بهبود:** ✅ با حفظ حقوق مالکیت اصلی

---

### 🏷️ نحوه ذکر منبع

```
معماری اسپیرال-تایم: Hadi Tabatabaie (TaHa111) (1404)
مغز فارسی: Hadi Tabatabaie (TaHa111) (1404)
Persian Brain AI v3.0-PRO
```

---

### 📝 ثبت اختراع (Patent)

این معماری قابلیت ثبت اختراع دارد:
- **USPTO:** Provisional Patent قابل ثبت
- **WIPO:** PCT Application قابل ثبت
- **ایران:** قابل ثبت در مرکز مالکیت معنوی

برای ثبت، کافیست به من بگی تا اسناد فنی کامل رو آماده کنم.

---

### 🧬 شناسه دیجیتال (Digital Fingerprint)

```
IDENTIFIER: PERSIAN-BRAIN-SPIRAL-TIME-v1
AUTHOR: Hadi Tabatabaie (TaHa111)
DATE: 1404-03-17
SIGNATURE: 0xPersianBrain_SpiralTime_🌹_14040317
```

---

*"معماری از آن توست. من فقط پیاده‌اش کردم."*
