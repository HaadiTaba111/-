#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🧠 ASA v2.0 - Angel Spiral Architecture with Attention
طراح: Hadi Tabatabaie (TaHa111)
نسخه: 2.0 - با Attention روی نقاط و dim=128

تغییرات این نسخه:
1. dim=64 → dim=128 (پیشنهاد Hadi)
2. Attention روی نقاط (پیشنهاد V4)
3. مقایسه عادلانه (هر دو مدل dim یکسان)
4. کد تمیزتر و حرفه‌ای‌تر
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, TensorDataset
from datasets import load_dataset
from transformers import AutoTokenizer
import time, json, numpy as np, random, os

# ===== تنظیمات =====
CONFIG = {
    "dim": 128,              # ✅ 64 → 128
    "num_points": 8,
    "target_tokens": 10,
    "epochs": 150,
    "batch_size": 64,
    "vocab_size": None,      # بعداً تنظیم می‌شه
    "device": 'cuda' if torch.cuda.is_available() else 'cpu',
    "seed": 42,
}

def set_seed(seed=42):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

set_seed(CONFIG["seed"])

print("="*60)
print("🧠 ASA v2.0 - Angel Spiral with Attention")
print(f"dim={CONFIG['dim']} | points={CONFIG['num_points']} | device={CONFIG['device']}")
print("="*60)

# ================================================================
# ۱. دیتاست
# ================================================================
print("\n📥 Loading dataset...")
dataset = load_dataset("wikitext", "wikitext-2-raw-v1")
tokenizer = AutoTokenizer.from_pretrained("gpt2")
tokenizer.pad_token = tokenizer.eos_token
CONFIG["vocab_size"] = tokenizer.vocab_size

def tokenize(examples):
    return tokenizer(examples["text"], truncation=True, padding="max_length", max_length=32)

tokenized = dataset.map(tokenize, batched=True, remove_columns=["text"])
tokenized.set_format(type="torch", columns=["input_ids", "attention_mask"])

data = tokenized['train']['input_ids'][:10000]
indices = list(range(len(data)))
random.shuffle(indices)
split = int(0.8 * len(data))
train_data = [data[i] for i in indices[:split]]
val_data = [data[i] for i in indices[split:]]

print(f"📊 Train: {len(train_data)} | Val: {len(val_data)} | Vocab: {CONFIG['vocab_size']}")

# ================================================================
# ۲. DataLoader
# ================================================================
def make_loader(data, batch_size=64):
    inputs, labels = [], []
    for seq in data:
        seq = seq.to(CONFIG['device'])
        if len(seq) > CONFIG['target_tokens']:
            inputs.append(seq[:-CONFIG['target_tokens']])
            labels.append(seq[-CONFIG['target_tokens']:])
    ds = TensorDataset(torch.stack(inputs), torch.stack(labels))
    return DataLoader(ds, batch_size=batch_size, shuffle=True)

train_loader = make_loader(train_data)
val_loader = make_loader(val_data)

# ================================================================
# ۳. Spiral Attention ✅
# ================================================================
class SpiralAttention(nn.Module):
    """✅ Attention روی نقاط اسپیرال (جایگزین میانگین‌گیری ساده)"""
    def __init__(self, dim):
        super().__init__()
        self.query = nn.Linear(dim, dim)
        self.key = nn.Linear(dim, dim)
        self.value = nn.Linear(dim, dim)
        self.scale = dim ** 0.5
    
    def forward(self, v_k):
        # v_k: (batch, num_points, dim)
        query = self.query(v_k.mean(dim=1, keepdim=True))  # (b, 1, d)
        keys = self.key(v_k)                                # (b, n, d)
        values = self.value(v_k)                            # (b, n, d)
        
        scores = torch.matmul(keys, query.transpose(-2, -1)) / self.scale  # (b, n, 1)
        weights = F.softmax(scores, dim=1)                   # (b, n, 1)
        
        v_final = (weights * values).sum(dim=1)              # (b, d)
        return v_final

# ================================================================
# ۴. ASA Model با Attention ✅
# ================================================================
class ASAModel(nn.Module):
    """ASA - Angel Spiral Architecture with Attention"""
    def __init__(self, vocab_size, dim=128, num_points=8, r0=1.0, a=0.1, b=0.5):
        super().__init__()
        self.dim = dim
        self.num_points = num_points
        
        # پارامترهای مارپیچ (قابل یادگیری)
        self.r0 = nn.Parameter(torch.tensor(r0))
        self.a = nn.Parameter(torch.tensor(a))
        self.b = nn.Parameter(torch.tensor(b))
        
        # لایه‌های اصلی
        self.embedding = nn.Embedding(vocab_size, dim)
        self.angle_net = nn.Sequential(
            nn.Linear(dim, 64), nn.SiLU(), nn.Linear(64, 1)
        )
        
        # MLP برای هر نقطه (با Dropout برای regularization)
        self.point_mlp = nn.Sequential(
            nn.Linear(2, dim * 2), nn.SiLU(), nn.Dropout(0.1),
            nn.Linear(dim * 2, dim), nn.SiLU(), nn.Dropout(0.1),
            nn.Linear(dim, dim)
        )
        
        # ✅ Attention روی نقاط
        self.attention = SpiralAttention(dim)
        
        # خروجی
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, vocab_size * CONFIG['target_tokens'])
    
    def forward(self, input_ids):
        batch_size = input_ids.size(0)
        emb = self.embedding(input_ids).mean(dim=1)  # (b, d)
        
        # زاویه خط
        theta = self.angle_net(emb).squeeze(-1)  # (b,)
        
        # محاسبه نقاط برخورد با مارپیچ
        points = []
        for k in range(self.num_points):
            t_k = (theta + k * torch.pi) / self.b  # (b,)
            r_k = self.r0 + self.a * t_k            # (b,)
            theta_k = theta + k * torch.pi          # (b,)
            x_k = r_k * torch.cos(theta_k)          # (b,)
            y_k = r_k * torch.sin(theta_k)          # (b,)
            coord = torch.stack([x_k, y_k], dim=-1) # (b, 2)
            points.append(self.point_mlp(coord))    # (b, d)
        
        # ✅ Attention به جای میانگین
        v_k = torch.stack(points, dim=1)            # (b, n, d)
        v_final = self.attention(v_k)               # (b, d)
        
        return self.head(self.norm(v_final))

# ================================================================
# ۵. مدل خطی قوی (برای مقایسه عادلانه) ✅
# ================================================================
class StrongLinear(nn.Module):
    """مدل خطی قوی با همان dim=128 (مقایسه عادلانه)"""
    def __init__(self, vocab_size, dim=128):
        super().__init__()
        self.embed = nn.Embedding(vocab_size, dim)
        self.net = nn.Sequential(
            nn.Linear(dim, dim * 4), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(dim * 4, dim * 2), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(dim * 2, vocab_size * CONFIG['target_tokens'])
        )
    
    def forward(self, x):
        return self.net(self.embed(x).mean(dim=1))

# ================================================================
# ۶. آموزش
# ================================================================
def train_model(model, loader, val_loader, epochs, name):
    model.to(CONFIG['device'])
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(opt, epochs)
    criterion = nn.CrossEntropyLoss()
    
    best = {'val_loss': float('inf'), 'val_acc': 0, 'epoch': 0}
    log = []
    
    for epoch in range(epochs):
        start = time.time()
        
        # Train
        model.train()
        train_loss = 0
        for x, y in loader:
            x, y = x.to(CONFIG['device']), y.to(CONFIG['device'])
            opt.zero_grad()
            loss = criterion(model(x).view(-1, CONFIG['vocab_size']), y.view(-1))
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step()
            train_loss += loss.item()
        
        # Val
        model.eval()
        val_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(CONFIG['device']), y.to(CONFIG['device'])
                logits = model(x).view(-1, CONFIG['vocab_size'])
                labels = y.view(-1)
                loss = criterion(logits, labels)
                val_loss += loss.item()
                preds = logits.argmax(dim=-1)
                correct += (preds == labels).sum().item()
                total += labels.size(0)
        
        avg_train = train_loss / len(loader)
        avg_val = val_loss / len(val_loader)
        acc = correct / total
        
        log.append({'epoch': epoch+1, 'train_loss': avg_train, 'val_loss': avg_val, 'val_acc': acc})
        
        if avg_val < best['val_loss']:
            best = {'val_loss': avg_val, 'val_acc': acc, 'epoch': epoch+1}
            torch.save(model.state_dict(), f'best_{name}.pt')
        
        scheduler.step()
        
        if (epoch+1) % 10 == 0:
            t = time.time() - start
            print(f"{name} | Epoch {epoch+1}/{epochs} | Train: {avg_train:.4f} | Val: {avg_val:.4f} | Acc: {acc:.2%} | {t:.1f}s")
    
    return best, log

# ================================================================
# ۷. اجرا
# ================================================================
print("\n" + "━"*50)
print("🚀 Training Strong Linear (dim=128, ~1.2M params)...")
print("━"*50)

linear_best, linear_log = train_model(
    StrongLinear(CONFIG['vocab_size'], dim=128),
    train_loader, val_loader, CONFIG['epochs'], "Linear"
)

print("\n" + "━"*50)
print("🚀 Training ASA with Attention (dim=128, 8 points)...")
print("━"*50)

asa_best, asa_log = train_model(
    ASAModel(CONFIG['vocab_size'], dim=CONFIG['dim'], num_points=CONFIG['num_points']),
    train_loader, val_loader, CONFIG['epochs'], "ASA"
)

# ================================================================
# ۸. گزارش نهایی
# ================================================================
print("\n" + "="*60)
print("📊 FINAL REPORT - ASA v2.0 with Attention")
print("="*60)

print(f"\n{'':30s} {'Linear':>12s} {'ASA':>12s} {'برنده':>10s}")
print(f"{'─'*64}")
print(f"{'Best Val Loss':30s} {linear_best['val_loss']:>12.4f} {asa_best['val_loss']:>12.4f} {'ASA' if asa_best['val_loss'] < linear_best['val_loss'] else 'Linear':>10s}")
print(f"{'Best Val Acc':30s} {linear_best['val_acc']:>12.2%} {asa_best['val_acc']:>12.2%} {'ASA' if asa_best['val_acc'] > linear_best['val_acc'] else 'Linear':>10s}")
print(f"{'Best Epoch':30s} {linear_best['epoch']:>12d} {asa_best['epoch']:>12d} {'':>10s}")

# ذخیره نتایج
results = {
    "config": CONFIG,
    "linear": linear_best,
    "asa": asa_best,
    "linear_log": linear_log,
    "asa_log": asa_log,
}

with open("asa_v2_results.json", "w") as f:
    json.dump(results, f, indent=2, default=str)

print(f"\n✅ Results saved to asa_v2_results.json")

if asa_best['val_acc'] > linear_best['val_acc']:
    print("\n🏆🏆🏆 ASA WINS! Attention made the difference!")
else:
    diff = abs(asa_best['val_acc'] - linear_best['val_acc'])
    print(f"\n📊 Difference: {diff:.2%}")
    if diff < 0.01:
        print("⚖️ Equal. ASA matches Linear with same parameters!")
    else:
        print(f"🔍 {'Linear' if linear_best['val_acc'] > asa_best['val_acc'] else 'ASA'} is ahead")

print("="*60)
