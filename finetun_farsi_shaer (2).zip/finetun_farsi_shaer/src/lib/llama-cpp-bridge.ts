/**
 * 🖥️ پل اتصال به llama.cpp برای چت آفلاین
 * 
 * این ماژول به مغز فارسی اجازه میده با llama.cpp حرف بزنه
 * llama.cpp روی PC اجرا میشه و API روی localhost:8080 بالا میاد
 * 
 * نصب llama.cpp:
 *   git clone https://github.com/ggerganov/llama.cpp
 *   cd llama.cpp
 *   make -j
 *   ./server -m models/qwen2.5-1.5b-instruct-q4_k_m.gguf --host 0.0.0.0 --port 8080
 */

export interface LlamaConfig {
  enabled: boolean;
  apiUrl: string;
  modelName: string;
  temperature: number;
  topP: number;
  maxTokens: number;
  repeatPenalty: number;
  contextLength: number;
  systemPrompt: string;
  useGPU: boolean;
  nGpuLayers: number;
}

export interface LlamaChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LlamaCompletionRequest {
  messages: LlamaChatMessage[];
  temperature?: number;
  top_p?: number;
  max_tokens?: number;
  repeat_penalty?: number;
  stream?: boolean;
}

export interface LlamaCompletionResponse {
  content: string;
  tokensPerSecond: number;
  totalTokens: number;
  finishReason: string;
}

export const DEFAULT_LLAMA_CONFIG: LlamaConfig = {
  enabled: false,
  apiUrl: 'http://localhost:8080',
  modelName: 'Qwen 2.5 1.5B (Q4)',
  temperature: 0.7,
  topP: 0.9,
  maxTokens: 512,
  repeatPenalty: 1.1,
  contextLength: 4096,
  systemPrompt: `شما یک دستیار فارسی زبان هستید که بسیار مهربان و خوش‌برخورد صحبت می‌کنید.
  به زبان فارسی محاوره‌ای و روان پاسخ دهید.
  با کاربر مانند یک دوست صمیمی رفتار کنید.
  اگر سوال فنی پرسید، دقیق و مستند پاسخ دهید.
  اگر درخواست شعر کرد، با شعر و تمثیل پاسخ دهید.
  همیشه با احترام و گرمی صحبت کنید.`,
  useGPU: true,
  nGpuLayers: 35,
};

/**
 * چک کردن اینکه llama.cpp سرویس بالا هست یا نه
 */
export async function checkLlamaStatus(config: LlamaConfig): Promise<{
  running: boolean;
  modelName?: string;
  error?: string;
}> {
  try {
    const res = await fetch(`${config.apiUrl}/health`, {
      signal: AbortSignal.timeout(3000),
    });
    if (res.ok) {
      return { running: true, modelName: config.modelName };
    }
    return { running: false, error: 'سرویس پاسخ نمی‌دهد' };
  } catch (e: any) {
    return { running: false, error: `خطا در اتصال: ${e.message}` };
  }
}

/**
 * ارسال پیام به llama.cpp و دریافت پاسخ
 */
export async function chatWithLlama(
  messages: LlamaChatMessage[],
  config: LlamaConfig = DEFAULT_LLAMA_CONFIG,
): Promise<LlamaCompletionResponse> {
  const startTime = performance.now();

  const body: LlamaCompletionRequest = {
    messages,
    temperature: config.temperature,
    top_p: config.topP,
    max_tokens: config.maxTokens,
    repeat_penalty: config.repeatPenalty,
    stream: false,
  };

  try {
    const res = await fetch(`${config.apiUrl}/v1/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(30000),
    });

    if (!res.ok) {
      throw new Error(`llama.cpp خطا: ${res.status}`);
    }

    const data = await res.json();
    const elapsed = (performance.now() - startTime) / 1000;

    return {
      content: data.choices?.[0]?.message?.content || '',
      tokensPerSecond: data.usage?.tokens_per_second || 0,
      totalTokens: data.usage?.total_tokens || 0,
      finishReason: data.choices?.[0]?.finish_reason || 'stop',
    };
  } catch (e: any) {
    // Fallback: اگر llama.cpp وصل نبود از مغز داخلی استفاده کن
    const { unifiedThink } = await import('./unified-brain');
    const lastMsg = messages[messages.length - 1]?.content || '';
    const brainResponse = unifiedThink(lastMsg, {
      userName: 'کاربر',
      temperature: config.temperature,
    });

    return {
      content: brainResponse.text,
      tokensPerSecond: 0,
      totalTokens: brainResponse.text.split(' ').length,
      finishReason: 'fallback_to_persian_brain',
    };
  }
}

/**
 * گرفتن آمار از llama.cpp
 */
export async function getLlamaStats(config: LlamaConfig): Promise<{
  running: boolean;
  modelInfo?: string;
  gpuLayers?: number;
  contextSize?: number;
  error?: string;
}> {
  try {
    const res = await fetch(`${config.apiUrl}/api/info`, {
      signal: AbortSignal.timeout(3000),
    });
    if (res.ok) {
      const data = await res.json();
      return {
        running: true,
        modelInfo: data.model_path?.split('/').pop() || config.modelName,
        gpuLayers: data.n_gpu_layers || 0,
        contextSize: data.n_ctx || 0,
      };
    }
    return { running: false, error: 'خطا در دریافت اطلاعات' };
  } catch {
    return { running: false, error: 'اتصال برقرار نشد' };
  }
}

/**
 * پرامپت سیستمی فارسی برای llama.cpp
 */
export function getSystemPromptForMode(mode: 'general' | 'poet' | 'teacher' | 'friend'): string {
  const prompts: Record<string, string> = {
    general: `شما یک دستیار فارسی زبان صمیمی و مهربان هستید.
    - به فارسی محاوره‌ای و روان صحبت کنید
    - با کاربر مانند دوست رفتار کنید
    - سوالات فنی را دقیق جواب دهید
    - درخواست شعر را با شعر پاسخ دهید`,
    
    poet: `شما یک شاعر و ادیب فارسی هستید.
    - بیشتر با شعر و تمثیل صحبت کنید
    - از اشعار حافظ، سعدی و مولانا استفاده کنید
    - زبان ادبی و شیوا داشته باشید`,
    
    teacher: `شما یک معلم و استاد دانشگاه هستید.
    - دقیق و مستند پاسخ دهید
    - با مثال و دلیل توضیح دهید
    - صبور و خوش‌برخورد باشید`,
    
    friend: `شما یک دوست صمیمی برای کاربر هستید.
    - مثل یک رفیق قدیمی صحبت کنید
    - از اصطلاحات محاوره‌ای استفاده کنید
    - گرم و خودمانی باشید
    - اگر کاربر ناراحت است، دلداری دهید`,
  };

  return prompts[mode] || prompts.general;
}
