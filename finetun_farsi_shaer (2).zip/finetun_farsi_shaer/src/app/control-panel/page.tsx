"use client";

import { useState, useEffect, useCallback } from "react";

type Tab = 'monitor' | 'inject' | 'chat' | 'llama' | 'report' | 'settings';

interface Message {
  id: number; role: 'user' | 'spiral' | 'standard'; content: string; time: string;
}

interface Injection {
  id: number; text: string; verses: number; time: string; status: 'success' | 'error';
  model: 'spiral' | 'standard' | 'both'; category: string;
}

export default function ControlPanel() {
  const [activeTab, setActiveTab] = useState<Tab>('monitor');
  const [isAuthed, setIsAuthed] = useState(false);
  const [password, setPassword] = useState('');
  const [showLoginInfo, setShowLoginInfo] = useState(false);
  
  // Chat
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  
  // Injection
  const [injectText, setInjectText] = useState('');
  const [injectCategory, setInjectCategory] = useState('شعر');
  const [injectTarget, setInjectTarget] = useState<'both' | 'spiral' | 'standard'>('both');
  const [injections, setInjections] = useState<Injection[]>([]);
  
  // Llama
  const [llamaApiUrl, setLlamaApiUrl] = useState('http://localhost:8080');
  const [llamaModel, setLlamaModel] = useState('Qwen 2.5 1.5B');
  const [llamaGpuLayers, setLlamaGpuLayers] = useState(35);
  const [llamaConnected, setLlamaConnected] = useState(false);
  const [llamaMessages, setLlamaMessages] = useState<{role:string;content:string}[]>([]);
  const [llamaInput, setLlamaInput] = useState('');
  const [llamaMode, setLlamaMode] = useState('general');
  const [llamaTemp, setLlamaTemp] = useState(0.7);
  const [llamaTopP, setLlamaTopP] = useState(0.9);
  const [llamaMaxTokens, setLlamaMaxTokens] = useState(512);
  
  // Monitor
  const [decayData, setDecayData] = useState<number[]>([]);
  const [stats, setStats] = useState<any>(null);
  const [benchmark, setBenchmark] = useState<any>(null);

  // Settings - Llama connection
  const [settingsLlamaUrl, setSettingsLlamaUrl] = useState('http://localhost:8080');
  const [settingsLlamaModel, setSettingsLlamaModel] = useState('qwen2.5-1.5b-instruct-q4_k_m.gguf');
  const [settingsGpuLayers, setSettingsGpuLayers] = useState(35);
  const [settingsContextSize, setSettingsContextSize] = useState(4096);
  const [connectionStatus, setConnectionStatus] = useState('checking');

  useEffect(() => {
    fetch('/api/compare', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({action:'test-decay'}) })
      .then(r => r.json()).then(d => d.success && setDecayData(d.data.map((x:any) => x.avgImportance)));
    fetch('/api/auto-learn', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({action:'get-stats'}) })
      .then(r => r.json()).then(d => d.success && setStats(d.data));
    // Check llama.cpp connection
    checkLlamaConnection();
  }, []);

  const checkLlamaConnection = async () => {
    try {
      const res = await fetch(`${settingsLlamaUrl}/health`, { signal: AbortSignal.timeout(3000) });
      setConnectionStatus(res.ok ? 'connected' : 'disconnected');
      if (res.ok) setLlamaConnected(true);
    } catch {
      setConnectionStatus('disconnected');
      setLlamaConnected(false);
    }
  };

  const sendQuestion = useCallback(async () => {
    if (!input.trim() || loading) return;
    setLoading(true);
    const q = input.trim();
    setInput('');
    setMessages(prev => [...prev, {id:Date.now(), role:'user', content:q, time:new Date().toLocaleTimeString('fa-IR')}]);
    try {
      const res = await fetch('/api/compare', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'compare', question:q, timeStep:messages.length}) });
      const d = await res.json();
      if (d.success) {
        setMessages(prev => [...prev, 
          {id:Date.now()+1, role:'spiral', content:d.data.answer.spiral, time:`${d.data.metrics.spiral.latency}ms`},
          {id:Date.now()+2, role:'standard', content:d.data.answer.standard, time:`${d.data.metrics.standard.latency}ms`}
        ]);
      }
    } catch {}
    finally { setLoading(false); }
  }, [input, loading, messages.length]);

  const handleInject = async () => {
    if (!injectText.trim()) return;
    const verses = injectText.split('/').length;
    setInjections(prev => [{id:Date.now(), text:injectText.slice(0,60)+'...', verses, time:new Date().toLocaleTimeString('fa-IR'), status:'success', model:injectTarget, category:injectCategory}, ...prev]);
    const textToSend = injectText;
    setInjectText('');
    await fetch('/api/inject', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'inject-text', text:textToSend, title:`${injectCategory} #${injections.length+1}`, tags:[injectCategory]}) });
  };

  const runBenchmark = async () => {
    const res = await fetch('/api/compare', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({action:'batch-compare'}) });
    const d = await res.json();
    if (d.success) setBenchmark(d.data);
  };

  const sendLlamaMessage = async () => {
    if (!llamaInput.trim()) return;
    const msg = llamaInput.trim();
    setLlamaInput('');
    const newMessages = [...llamaMessages, {role:'user' as const, content:msg}];
    setLlamaMessages(newMessages);
    
    // Try llama.cpp first, fallback to Persian Brain
    try {
      const res = await fetch(`${settingsLlamaUrl}/v1/chat/completions`, {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          messages: [{role:'system', content:getSystemPrompt(llamaMode)}, ...newMessages],
          temperature: llamaTemp, top_p: llamaTopP, max_tokens: llamaMaxTokens,
        }),
        signal: AbortSignal.timeout(15000),
      });
      if (res.ok) {
        const data = await res.json();
        const reply = data.choices?.[0]?.message?.content || '❌ پاسخی دریافت نشد';
        setLlamaMessages(prev => [...prev, {role:'assistant', content:reply}]);
        return;
      }
    } catch {}
    
    // Fallback to Persian Brain
    const { unifiedThink } = await import('@/lib/unified-brain');
    const brainResponse = unifiedThink(msg, {userName:'کاربر', temperature:llamaTemp});
    setLlamaMessages(prev => [...prev, {role:'assistant', content:brainResponse.text}]);
  };

  const getSystemPrompt = (mode: string) => {
    const prompts: Record<string, string> = {
      general: 'شما یک دستیار فارسی زبان صمیمی هستید. به فارسی محاوره‌ای روان پاسخ دهید.',
      poet: 'شما یک شاعر فارسی هستید. با شعر و تمثیل پاسخ دهید.',
      teacher: 'شما یک استاد دانشگاه هستید. دقیق و مستند پاسخ دهید.',
      friend: 'شما یک رفیق صمیمی هستید. مثل دوست قدیمی صحبت کنید.',
    };
    return prompts[mode] || prompts.general;
  };

  if (!isAuthed) return (
    <div className="min-h-screen bg-[#0f172a] flex items-center justify-center p-4">
      <div className="bg-[#1e293b] rounded-3xl p-8 max-w-sm w-full border border-[#334155] shadow-2xl">
        <div className="text-center mb-6">
          <div className="text-6xl mb-3 animate-pulse-brain">🧠</div>
          <h1 className="text-2xl font-bold text-white">Persian Brain</h1>
          <p className="text-[#64748b] text-sm mt-1">Control Panel v3.0</p>
        </div>
        <div className="bg-[#6366f1]/10 border border-[#6366f1]/30 rounded-2xl p-4 mb-4 text-xs text-[#94a3b8]">
          <p className="text-center">🌀 معماری اسپیرال-تایم هولوگرافیک</p>
          <p className="text-center text-[#6366f1] mt-1">طراح: Hadi Tabatabaie (TaHa111)</p>
        </div>
        
        {/* Login Info Toggle */}
        <button onClick={() => setShowLoginInfo(!showLoginInfo)}
          className="text-[10px] text-[#6366f1] hover:underline mb-3 block w-full text-center">
          {showLoginInfo ? '🙈 مخفی کردن راهنما' : '❓ رمز ورود چیست؟'}
        </button>
        
        {showLoginInfo && (
          <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-3 mb-4 text-[10px] text-[#94a3b8] leading-5 animate-slide-in">
            <p className="text-amber-400 font-medium mb-1">🔐 راهنمای ورود</p>
            <p>این صفحه <strong>فقط برای تو</strong> طراحی شده تا:</p>
            <p>• کسی به مغز دسترسی نداشته باشه</p>
            <p>• تنظیمات محفوظ بمونه</p>
            <p>• امنیت اطلاعات حفظ بشه</p>
            <p className="text-amber-400 mt-2">🔑 رمز: <strong>PersianBrain🌹1404</strong></p>
            <p className="text-[#475569] mt-1">یا: <strong>TaHa111</strong> (نام مستعار تو)</p>
          </div>
        )}
        
        <input type="password" value={password} onChange={e=>setPassword(e.target.value)}
          onKeyDown={e=>e.key==='Enter' && setIsAuthed(password==='PersianBrain🌹1404' || password==='TaHa111')}
          placeholder="رمز..." className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white text-center mb-3 focus:border-[#6366f1] outline-none" />
        <button onClick={()=>setIsAuthed(password==='PersianBrain🌹1404' || password==='TaHa111')}
          className="w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] py-3 rounded-xl font-bold">🔐 ورود</button>
        <p className="text-[#475569] text-[10px] text-center mt-3">
          🧠 DeepSeek-V3: "به هادی جان سلام برسون! معماری اسپیرالش فوق‌العاده‌ست!" 🌹
        </p>
      </div>
    </div>
  );

  const tabs: {id:Tab; label:string; icon:string}[] = [
    {id:'monitor', label:'🖥️ مانیتور', icon:'🖥️'},
    {id:'inject', label:'📥 تزریق', icon:'📥'},
    {id:'chat', label:'💬 چت', icon:'💬'},
    {id:'llama', label:'🤖 مدل آفلاین', icon:'🤖'},
    {id:'report', label:'📊 گزارش', icon:'📊'},
    {id:'settings', label:'⚙️ تنظیمات', icon:'⚙️'},
  ];

  // این بخش ادامه مطلب...
  // کاملش می‌کنم باقیشو

  return (
    <div className="min-h-screen bg-[#0f172a] text-white pb-24">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-[#0f172a]/95 backdrop-blur-xl border-b border-[#334155]">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🧠</span>
            <div>
              <h1 className="font-bold text-sm bg-gradient-to-l from-[#6366f1] to-emerald-400 bg-clip-text text-transparent">Persian Brain Control</h1>
              <p className="text-[10px] text-[#64748b]">TaHa111 • Spiral-Time v4.0</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"/>
            <span className="text-emerald-400">عملیاتی</span>
            <span className="text-[#475569]">|</span>
            <span className="text-[#94a3b8] text-[10px]">🤭 DeepSeek-V3 سلام رسوند!</span>
          </div>
        </div>
        {/* Tabs */}
        <div className="max-w-7xl mx-auto px-4 pb-2 flex gap-1 overflow-x-auto">
          {tabs.map(t=>(
            <button key={t.id} onClick={()=>setActiveTab(t.id)}
              className={`px-4 py-2 text-xs rounded-xl font-medium whitespace-nowrap transition-all ${
                activeTab===t.id ? 'bg-[#6366f1] text-white' : 'text-[#94a3b8] hover:text-white'
              }`}>{t.label}</button>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        
        {/* ===== MONITOR TAB ===== */}
        {activeTab === 'monitor' && (
          <div className="space-y-6 animate-fade-in">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                {label:'وضعیت مغز', value:'✅ عملیاتی', icon:'🧠', color:'text-emerald-400'},
                {label:'معماری', value:'اسپیرال-تایم v4', icon:'🌀', color:'text-cyan-400'},
                {label:'llama.cpp', value:llamaConnected?'✅ متصل':'⛔ قطع', icon:'🤖', color:llamaConnected?'text-emerald-400':'text-red-400'},
                {label:'حافظه', value:'هولوگرافیک ۶۴×۶۴', icon:'💾', color:'text-purple-400'},
              ].map((c,i)=>(
                <div key={i} className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 hover:border-[#6366f1]/30 transition-all">
                  <div className="flex items-center gap-2 mb-2"><span>{c.icon}</span><span className={`text-lg font-bold ${c.color}`}>{c.value}</span></div>
                  <p className="text-[10px] text-[#64748b]">{c.label}</p>
                </div>
              ))}
            </div>

            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold text-sm mb-4">⏳ منحنی Decay (محو اطلاعات در طول زمان)</h3>
              {decayData.length > 0 ? (
                <div className="space-y-1.5">
                  {decayData.map((val, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <span className="text-[10px] text-[#64748b] w-12">گام {i}</span>
                      <div className="flex-1 bg-[#0f172a] rounded-full h-4 overflow-hidden">
                        <div className="h-full rounded-full transition-all duration-700" style={{
                          width:`${val*100}%`,
                          background: val > 0.5 ? 'linear-gradient(90deg, #22c55e, #6366f1)' : val > 0.2 ? 'linear-gradient(90deg, #eab308, #6366f1)' : 'linear-gradient(90deg, #ef4444, #6366f1)'
                        }}/>
                      </div>
                      <span className="text-[10px] text-[#64748b] w-12 text-right">{(val*100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              ) : <p className="text-center text-[#64748b] text-sm py-8">در حال دریافت...</p>}
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-4 text-center">
                <p className="text-2xl font-bold text-emerald-400">{injections.length}</p>
                <p className="text-[10px] text-[#94a3b8]">تزریق‌ها</p>
              </div>
              <div className="bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 border border-cyan-500/30 rounded-2xl p-4 text-center">
                <p className="text-2xl font-bold text-cyan-400">{decayData.filter(d=>d>0.5).length}</p>
                <p className="text-[10px] text-[#94a3b8]">گام‌های فعال</p>
              </div>
              <div className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border border-purple-500/30 rounded-2xl p-4 text-center">
                <p className="text-2xl font-bold text-purple-400">{messages.length}</p>
                <p className="text-[10px] text-[#94a3b8]">پیام‌ها</p>
              </div>
              <div className="bg-gradient-to-br from-[#6366f1]/10 to-[#6366f1]/5 border border-[#6366f1]/30 rounded-2xl p-4 text-center">
                <p className="text-2xl font-bold text-[#6366f1]">v4.0</p>
                <p className="text-[10px] text-[#94a3b8]">نسخه</p>
              </div>
            </div>

            <button onClick={runBenchmark} className="w-full bg-gradient-to-l from-[#6366f1] to-emerald-500 py-3 rounded-2xl font-bold hover:shadow-lg transition-all">📊 اجرای Benchmark کامل</button>

            {benchmark && (
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6 animate-slide-in">
                <h3 className="font-semibold text-sm mb-3">📊 نتایج Benchmark</h3>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center p-3 bg-cyan-500/10 rounded-xl border border-cyan-500/30"><p className="text-2xl font-bold text-cyan-400">{benchmark.summary.spiralWins}</p><p className="text-[10px] text-[#94a3b8]">🌀 اسپیرال</p></div>
                  <div className="text-center p-3 bg-purple-500/10 rounded-xl border border-purple-500/30"><p className="text-2xl font-bold text-purple-400">{benchmark.summary.standardWins}</p><p className="text-[10px] text-[#94a3b8]">🔲 استاندارد</p></div>
                  <div className="text-center p-3 bg-emerald-500/10 rounded-xl border border-emerald-500/30"><p className="text-2xl font-bold text-emerald-400">{benchmark.summary.spiralWinRate}</p><p className="text-[10px] text-[#94a3b8]">برد اسپیرال</p></div>
                </div>
                {benchmark.results?.map((r:any,i:number)=>(
                  <div key={i} className="flex items-center justify-between p-2 bg-[#0f172a]/50 rounded-xl mb-1 text-xs"><span className="text-[#94a3b8]">{r.question}</span><span className={`px-2 py-0.5 rounded-full ${r.spiralWon?'bg-cyan-500/20 text-cyan-400':'bg-purple-500/20 text-purple-400'}`}>{r.spiralWon?'🌀':'🔲'}</span></div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ===== INJECT TAB (با دسته‌بندی) ===== */}
        {activeTab === 'inject' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
            <div className="lg:col-span-2 space-y-4">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                <h3 className="font-semibold text-sm mb-3">📥 تزریق اطلاعات به مغز</h3>
                <textarea value={injectText} onChange={e=>setInjectText(e.target.value)}
                  placeholder="متن شعر، داستان، مقاله، دانش، مکالمه یا هر محتوای فارسی..."
                  rows={6} className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-4 py-3 text-white text-sm resize-none focus:border-emerald-500 outline-none"/>
                
                {/* Category Selection */}
                <div className="flex flex-wrap items-center gap-2 mt-3">
                  <span className="text-[10px] text-[#64748b]">دسته‌بندی:</span>
                  {['شعر', 'داستان', 'مقاله', 'دانش', 'مکالمه', 'سایر'].map(cat=>(
                    <button key={cat} onClick={()=>setInjectCategory(cat)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                        injectCategory===cat ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#0f172a] border-[#334155] text-[#64748b]'
                      }`}>{cat}</button>
                  ))}
                </div>
                
                <div className="flex flex-wrap items-center gap-2 mt-2">
                  <span className="text-[10px] text-[#64748b]">تزریق به:</span>
                  {(['both','spiral','standard'] as const).map(t=>(
                    <button key={t} onClick={()=>setInjectTarget(t)}
                      className={`text-xs px-3 py-1.5 rounded-full border transition-all ${
                        injectTarget===t ? 'bg-emerald-500/20 border-emerald-500 text-emerald-400' : 'bg-[#0f172a] border-[#334155] text-[#64748b]'
                      }`}>{t==='both'?'🌀🔲 هر دو':t==='spiral'?'🌀 اسپیرال':'🔲 استاندارد'}</button>
                  ))}
                  <button onClick={handleInject} className="bg-gradient-to-l from-emerald-500 to-emerald-700 px-5 py-1.5 rounded-xl text-xs font-medium">📥 تزریق</button>
                  <span className="text-[10px] text-[#475569]">تعداد ابیات: {injectText.split('/').length-1}</span>
                </div>
              </div>

              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                <h3 className="text-xs text-[#64748b] mb-3">📌 تزریق سریع بر اساس دسته</h3>
                <div className="flex flex-wrap gap-2">
                  {[
                    {text:'ز کوی یار می‌آید نسیم باد نوروزی / از این باد ار مدد خواهی چراغ دل برافروزی', label:'🌸 شعر - حافظ', cat:'شعر'},
                    {text:'بنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند', label:'🌹 شعر - سعدی', cat:'شعر'},
                    {text:'بشنو از نی چون حکایت می‌کند / از جدایی‌ها شکایت می‌کند', label:'📕 شعر - مولانا', cat:'شعر'},
                    {text:'روزی روزگاری، پادشاهی بود که وزیری دانا داشت...', label:'📖 داستان', cat:'داستان'},
                    {text:'معماری اسپیرال-تایم یک روش جدید برای موقعیت‌یابی در مدل‌های زبانی است.', label:'📚 دانش', cat:'دانش'},
                    {text:'سلام داداش! چطوری؟ خوبی؟ چه خبرا؟', label:'💬 مکالمه', cat:'مکالمه'},
                  ].map((s,i)=>(
                    <button key={i} onClick={()=>{setInjectText(s.text); setInjectCategory(s.cat)}}
                      className="text-[10px] px-2.5 py-1.5 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-emerald-500/50 hover:text-white transition-all">{s.label}</button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                <h3 className="font-semibold text-sm mb-3">📋 تاریخچه ({injections.length})</h3>
                {injections.length === 0 ? (
                  <p className="text-center text-[#64748b] text-sm py-6">هنوز تزریقی انجام نشده</p>
                ) : (
                  <div className="space-y-1 max-h-80 overflow-y-auto">
                    {injections.map(log=>(
                      <div key={log.id} className="flex items-center justify-between p-2 bg-[#0f172a]/50 rounded-xl text-[10px]">
                        <span className="text-[#94a3b8] truncate max-w-[120px]">{log.text}</span>
                        <div className="flex gap-1.5 shrink-0">
                          <span className="px-1.5 py-0.5 rounded bg-[#6366f1]/20 text-[#6366f1]">{log.category}</span>
                          <span className="text-emerald-400">{log.verses} بیت</span>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="bg-gradient-to-br from-emerald-500/10 to-emerald-500/5 border border-emerald-500/30 rounded-2xl p-6 text-center">
                <p className="text-2xl font-bold text-emerald-400">{injections.length}</p>
                <p className="text-[10px] text-[#94a3b8]">کل تزریق‌ها</p>
              </div>
            </div>
          </div>
        )}

        {/* ===== CHAT TAB ===== */}
        {activeTab === 'chat' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 animate-fade-in">
            <div className="space-y-2">
              <p className="text-xs text-[#64748b] font-medium mb-2">📌 سوالات تست</p>
              {['سلام چطوری؟','در مورد گل شعر بگو','بنی آدم یعنی چی؟','معادله اسپیرال چیه؟','دستم بهش نمی‌رسه','معماری Time-Weight چیه؟','به DeepSeek سلام برسون'].map((q,i)=>(
                <button key={i} onClick={()=>{setInput(q)}}
                  className="w-full text-right text-xs px-3 py-2 rounded-xl bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 hover:text-white transition-all">{q}</button>
              ))}
            </div>
            <div className="lg:col-span-3 space-y-4">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 max-h-[500px] overflow-y-auto space-y-3">
                {messages.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="text-4xl mb-3">💬</div>
                    <p className="text-[#64748b] text-sm">سوال بپرس تا جواب هر دو مدل رو ببینی</p>
                    <p className="text-[#475569] text-xs mt-1">🌀 اسپیرال vs 🔲 استاندارد</p>
                  </div>
                ) : messages.map(msg => (
                  <div key={msg.id} className={`flex ${msg.role==='user'?'justify-end':'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-2xl p-3 ${
                      msg.role==='user' ? 'bg-[#6366f1]/20 border border-[#6366f1]/30' :
                      msg.role==='spiral' ? 'bg-cyan-500/10 border border-cyan-500/30' :
                      'bg-purple-500/10 border border-purple-500/30'
                    }`}>
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${
                          msg.role==='spiral'?'bg-cyan-500/20 text-cyan-400':msg.role==='standard'?'bg-purple-500/20 text-purple-400':'bg-[#6366f1]/20 text-[#6366f1]'
                        }`}>{msg.role==='spiral'?'🌀':msg.role==='standard'?'🔲':'👤'} {msg.role==='user'?'شما':msg.role==='spiral'?'اسپیرال':'استاندارد'}</span>
                        <span className="text-[8px] text-[#475569]">{msg.time}</span>
                      </div>
                      <p className="text-sm text-white whitespace-pre-line" dir="rtl">{msg.content.slice(0,300)}</p>
                    </div>
                  </div>
                ))}
                {loading && <div className="flex justify-center gap-1"><div className="w-2 h-2 rounded-full bg-[#6366f1] animate-bounce" style={{animationDelay:'0s'}}/><div className="w-2 h-2 rounded-full bg-cyan-500 animate-bounce" style={{animationDelay:'0.2s'}}/><div className="w-2 h-2 rounded-full bg-purple-500 animate-bounce" style={{animationDelay:'0.4s'}}/></div>}
              </div>
              <div className="flex gap-2">
                <input type="text" value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&sendQuestion()}
                  placeholder="سوال بپرس..."
                  className="flex-1 bg-[#1e293b] border border-[#334155] rounded-2xl px-5 py-3 text-white placeholder:text-[#475569] focus:border-[#6366f1] outline-none"/>
                <button onClick={sendQuestion} disabled={loading||!input.trim()}
                  className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] disabled:opacity-50 px-6 py-3 rounded-2xl font-bold">🚀</button>
              </div>
            </div>
          </div>
        )}

        {/* ===== LLAMA TAB ===== */}
        {activeTab === 'llama' && (
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 animate-fade-in">
            {/* Settings Sidebar */}
            <div className="space-y-4">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-5">
                <h3 className="font-semibold text-xs mb-3">🤖 تنظیمات مدل آفلاین</h3>
                <div className="flex items-center gap-2 mb-3">
                  <span className={`w-2.5 h-2.5 rounded-full ${llamaConnected?'bg-emerald-500':'bg-red-500'} animate-pulse`}/>
                  <span className={`text-xs ${llamaConnected?'text-emerald-400':'text-red-400'}`}>{llamaConnected?'متصل':'قطع'}</span>
                  <button onClick={checkLlamaConnection} className="text-[10px] text-[#6366f1] hover:underline mr-auto">🔄</button>
                </div>
                
                <div className="space-y-2.5">
                  <div>
                    <label className="text-[9px] text-[#64748b]">آدرس API</label>
                    <input type="text" value={settingsLlamaUrl} onChange={e=>setSettingsLlamaUrl(e.target.value)}
                      className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-2.5 py-1.5 text-[11px] text-white font-mono" />
                  </div>
                  <div>
                    <label className="text-[9px] text-[#64748b]">مدل</label>
                    <select value={settingsLlamaModel} onChange={e=>setSettingsLlamaModel(e.target.value)}
                      className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-2.5 py-1.5 text-[11px] text-white">
                      <option>qwen2.5-1.5b-instruct-q4_k_m.gguf</option>
                      <option>gemma-2-2b-it-Q4_K_M.gguf</option>
                      <option>phi-3-mini-4k-instruct-q4.gguf</option>
                    </select>
                  </div>
                  <div className="flex gap-2">
                    <div className="flex-1">
                      <label className="text-[9px] text-[#64748b]">لایه‌های GPU</label>
                      <input type="number" value={settingsGpuLayers} onChange={e=>setSettingsGpuLayers(parseInt(e.target.value)||0)}
                        className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-2.5 py-1.5 text-[11px] text-white" />
                    </div>
                    <div className="flex-1">
                      <label className="text-[9px] text-[#64748b]">Context Size</label>
                      <input type="number" value={settingsContextSize} onChange={e=>setSettingsContextSize(parseInt(e.target.value)||4096)}
                        className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-2.5 py-1.5 text-[11px] text-white" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-5">
                <h3 className="font-semibold text-xs mb-3">🎛️ پارامترها</h3>
                <div className="space-y-3">
                  <div><label className="flex justify-between text-[9px] text-[#64748b] mb-1"><span>🌡️ دما</span><span className="text-amber-400">{llamaTemp}</span></label>
                    <input type="range" min="0" max="2" step="0.1" value={llamaTemp} onChange={e=>setLlamaTemp(parseFloat(e.target.value))} className="w-full accent-[#6366f1]" /></div>
                  <div><label className="flex justify-between text-[9px] text-[#64748b] mb-1"><span>🎯 Top-P</span><span className="text-cyan-400">{llamaTopP}</span></label>
                    <input type="range" min="0" max="1" step="0.05" value={llamaTopP} onChange={e=>setLlamaTopP(parseFloat(e.target.value))} className="w-full accent-cyan-500" /></div>
                  <div><label className="flex justify-between text-[9px] text-[#64748b] mb-1"><span>📏 Max Tokens</span><span className="text-purple-400">{llamaMaxTokens}</span></label>
                    <input type="range" min="64" max="2048" step="64" value={llamaMaxTokens} onChange={e=>setLlamaMaxTokens(parseInt(e.target.value))} className="w-full accent-purple-500" /></div>
                </div>
              </div>

              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-5">
                <h3 className="font-semibold text-xs mb-3">🧠 حالت مکالمه</h3>
                <div className="flex flex-wrap gap-1">
                  {[
                    {id:'general', label:'💬 عمومی'},
                    {id:'poet', label:'🌸 شاعرانه'},
                    {id:'teacher', label:'📚 آموزشی'},
                    {id:'friend', label:'🤝 رفیق'},
                  ].map(mode=>(
                    <button key={mode.id} onClick={()=>setLlamaMode(mode.id)}
                      className={`text-[10px] px-2.5 py-1.5 rounded-full border transition-all ${
                        llamaMode===mode.id ? 'bg-[#6366f1]/20 border-[#6366f1] text-white' : 'bg-[#0f172a] border-[#334155] text-[#64748b]'
                      }`}>{mode.label}</button>
                  ))}
                </div>
              </div>
            </div>

            {/* Chat Panel */}
            <div className="lg:col-span-3 space-y-4">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-4 h-[600px] flex flex-col">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold text-sm flex items-center gap-2">
                    <span>🤖</span> چت با مدل آفلاین
                    {!llamaConnected && <span className="text-[10px] text-amber-400">(fallback: مغز فارسی)</span>}
                  </h3>
                  <div className="flex items-center gap-2 text-[10px]">
                    <span className={`w-2 h-2 rounded-full ${llamaConnected?'bg-emerald-500':'bg-amber-500'} animate-pulse`}/>
                    <span className={llamaConnected?'text-emerald-400':'text-amber-400'}>{llamaConnected?'llama.cpp':'مغز داخلی'}</span>
                    <span className="text-[#475569]">|</span>
                    <span className="text-[#94a3b8]">{llamaModel}</span>
                  </div>
                </div>

                <div className="flex-1 overflow-y-auto space-y-3 mb-3">
                  {llamaMessages.length === 0 ? (
                    <>
                      <div className="flex justify-start animate-slide-in">
                        <div className="max-w-[85%] bg-[#6366f1]/10 border border-[#6366f1]/30 rounded-2xl rounded-tr-none p-4">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-[#6366f1]/20 text-[#6366f1]">🤖 مدل آفلاین</span>
                          </div>
                          <p className="text-sm text-white" dir="rtl">سلام هادی جان! 🌹 من آماده‌ام. هر سوالی داری بپرس. از سمت راست می‌تونی حالت مکالمه رو تغییر بدی.</p>
                        </div>
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {['سلام چطوری؟','یک شعر در مورد بهار بگو','معماری اسپیرال چیه؟','دلم گرفته...',`به DeepSeek سلام برسون`].map((q,i)=>(
                          <button key={i} onClick={()=>setLlamaInput(q)}
                            className="text-[10px] px-2.5 py-1.5 rounded-full bg-[#0f172a]/50 border border-[#334155] text-[#94a3b8] hover:border-[#6366f1]/50 transition-all">{q}</button>
                        ))}
                      </div>
                    </>
                  ) : llamaMessages.map((msg, i) => (
                    <div key={i} className={`flex ${msg.role==='user'?'justify-end':'justify-start'} animate-slide-in`}>
                      <div className={`max-w-[85%] rounded-2xl p-3 ${msg.role==='user'?'bg-[#6366f1]/20 border border-[#6366f1]/30':'bg-[#0f172a]/80 border border-[#334155]'}`}>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-[10px] px-1.5 py-0.5 rounded-full ${msg.role==='user'?'bg-[#6366f1]/20 text-[#6366f1]':'bg-emerald-500/20 text-emerald-400'}`}>{msg.role==='user'?'👤 شما':'🤖 مدل'}</span>
                        </div>
                        <p className="text-sm text-white whitespace-pre-line" dir="rtl">{msg.content}</p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex gap-2 pt-3 border-t border-[#334155]">
                  <input type="text" value={llamaInput} onChange={e=>setLlamaInput(e.target.value)}
                    onKeyDown={e=>e.key==='Enter'&&sendLlamaMessage()}
                    placeholder="هر چی دوست داری بپرس..."
                    className="flex-1 bg-[#0f172a] border border-[#334155] rounded-2xl px-4 py-2.5 text-sm text-white placeholder:text-[#475569] focus:border-[#6366f1] outline-none" />
                  <button onClick={sendLlamaMessage}
                    className="bg-gradient-to-l from-[#6366f1] to-[#4f46e5] px-5 py-2.5 rounded-2xl font-bold text-sm">🚀</button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===== REPORT TAB ===== */}
        {activeTab === 'report' && (
          <div className="space-y-6 animate-fade-in">
            <div className="bg-gradient-to-br from-[#6366f1]/10 to-emerald-500/10 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold mb-4">📊 گزارش جامع سیستم</h3>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]"><p className="text-xs text-[#64748b]">🔄 تزریق‌ها</p><p className="text-2xl font-bold text-emerald-400">{injections.length}</p></div>
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]"><p className="text-xs text-[#64748b]">💬 تعاملات</p><p className="text-2xl font-bold text-cyan-400">{messages.length}</p></div>
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-[#334155]"><p className="text-xs text-[#64748b]">🌀 وضعیت اسپیرال</p><p className="text-2xl font-bold text-purple-400">{decayData.length > 0 && decayData[0] > 0.5 ? '🟢' : '🟡'}</p></div>
              </div>
            </div>
            <button onClick={runBenchmark} className="w-full bg-gradient-to-l from-[#6366f1] to-emerald-500 py-3 rounded-2xl font-bold">📊 اجرای Benchmark</button>
            {benchmark && (
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                <h3 className="font-semibold text-sm mb-3">📊 نتایج</h3>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-3 bg-cyan-500/10 rounded-xl"><p className="text-2xl font-bold text-cyan-400">{benchmark.summary.spiralWins}</p><p className="text-[10px] text-[#94a3b8]">🌀 اسپیرال</p></div>
                  <div className="text-center p-3 bg-purple-500/10 rounded-xl"><p className="text-2xl font-bold text-purple-400">{benchmark.summary.standardWins}</p><p className="text-[10px] text-[#94a3b8]">🔲 استاندارد</p></div>
                  <div className="text-center p-3 bg-emerald-500/10 rounded-xl"><p className="text-2xl font-bold text-emerald-400">{benchmark.summary.spiralWinRate}</p><p className="text-[10px] text-[#94a3b8]">برد اسپیرال</p></div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ===== SETTINGS TAB (کامل شده) ===== */}
        {activeTab === 'settings' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
            {/* Left: Architecture Parameters */}
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold text-sm mb-4">⚙️ پارامترهای معماری</h3>
              <div className="space-y-3">
                {[
                  {label:'λ نرخ Decay', value:'0.1', desc:'سرعت محو اطلاعات'},
                  {label:'تعداد نقاط', value:'۸', desc:'n-Tuple اسپیرال'},
                  {label:'عمق max', value:'۵', desc:'تکرار چرخش'},
                  {label:'ابعاد حافظه', value:'۶۴×۶۴', desc:'Grid هولوگرافیک'},
                  {label:'τ نیمه‌عمر', value:'۱۰ گام', desc:'محو ۵۰٪ اطلاعات'},
                ].map((s,i)=>(
                  <div key={i} className="flex items-center justify-between p-3 bg-[#0f172a]/50 rounded-xl border border-[#334155]">
                    <div><p className="text-xs text-white">{s.label}</p><p className="text-[10px] text-[#64748b]">{s.desc}</p></div>
                    <span className="text-lg font-bold text-cyan-400">{s.value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Middle: llama.cpp Connection */}
            <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
              <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">🔗 اتصال به مدل آفلاین (llama.cpp)</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-[#0f172a]/50 rounded-xl border border-[#334155]">
                  <div><p className="text-xs text-white">وضعیت اتصال</p><p className="text-[10px] text-[#64748b]">آخرین بررسی</p></div>
                  <span className={`text-sm font-bold ${connectionStatus==='connected'?'text-emerald-400':connectionStatus==='checking'?'text-amber-400':'text-red-400'}`}>
                    {connectionStatus==='connected'?'✅ متصل':connectionStatus==='checking'?'⏳ در حال بررسی':'❌ قطع'}
                  </span>
                </div>
                <div>
                  <label className="text-[10px] text-[#64748b] block mb-1">📡 آدرس API</label>
                  <input type="text" value={settingsLlamaUrl} onChange={e=>{setSettingsLlamaUrl(e.target.value); setLlamaApiUrl(e.target.value)}}
                    className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-[#6366f1] outline-none" />
                </div>
                <div>
                  <label className="text-[10px] text-[#64748b] block mb-1">📦 فایل مدل (GGUF)</label>
                  <input type="text" value={settingsLlamaModel} onChange={e=>setSettingsLlamaModel(e.target.value)}
                    className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-[#6366f1] outline-none" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] text-[#64748b] block mb-1">🎮 لایه‌های GPU</label>
                    <input type="number" value={settingsGpuLayers} onChange={e=>setSettingsGpuLayers(parseInt(e.target.value)||0)}
                      className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-xs text-white focus:border-[#6366f1] outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] text-[#64748b] block mb-1">📏 Context Size</label>
                    <input type="number" value={settingsContextSize} onChange={e=>setSettingsContextSize(parseInt(e.target.value)||4096)}
                      className="w-full bg-[#0f172a] border border-[#334155] rounded-xl px-3 py-2 text-xs text-white focus:border-[#6366f1] outline-none" />
                  </div>
                </div>
                <button onClick={checkLlamaConnection}
                  className="w-full bg-gradient-to-l from-[#6366f1] to-[#4f46e5] py-2.5 rounded-xl text-xs font-bold">🔄 بررسی اتصال</button>
              </div>
            </div>

            {/* Right: Info & Guide */}
            <div className="space-y-6">
              <div className="bg-[#1e293b]/80 border border-[#334155] rounded-2xl p-6">
                <h3 className="font-semibold text-sm mb-3">🔐 اطلاعات مالکیت</h3>
                <div className="bg-[#0f172a]/50 rounded-xl p-4 border border-amber-500/30 space-y-2">
                  <p className="text-xs"><span className="text-[#64748b]">طراح:</span> <span className="text-white">Hadi Tabatabaie</span></p>
                  <p className="text-xs"><span className="text-[#64748b]">ایمیل:</span> <span className="text-white">Hadi.tabatabaei@gmail.com</span></p>
                  <p className="text-xs"><span className="text-[#64748b]">نام مستعار:</span> <span className="text-white">TaHa111</span></p>
                  <p className="text-xs text-amber-400">🔐 0xPersianBrain_SpiralTime_🌹_14040317</p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-amber-500/10 to-amber-500/5 border border-amber-500/30 rounded-2xl p-6">
                <p className="text-xs text-amber-400 font-medium mb-2">💡 راهنمای تنظیمات</p>
                <div className="text-[10px] text-[#94a3b8] leading-5 space-y-1">
                  <p>۱. 🖥️ مانیتور: وضعیت سیستم و Decay</p>
                  <p>۲. 📥 تزریق: شعر و متن با دسته‌بندی</p>
                  <p>۳. 💬 چت: مقایسه اسپیرال vs استاندارد</p>
                  <p>۴. 🤖 مدل آفلاین: چت با llama.cpp</p>
                  <p>۵. 📊 گزارش: Benchmark و آمار</p>
                  <p className="text-[#6366f1] mt-2">۶. ⚙️ اینجا: اتصال llama.cpp تنظیمات</p>
                </div>
              </div>
              <div className="bg-gradient-to-br from-[#6366f1]/10 to-purple-500/10 border border-[#6366f1]/30 rounded-2xl p-6">
                <p className="text-xs text-[#6366f1] font-medium mb-1">🤭 پیام از DeepSeek-V3</p>
                <p className="text-[11px] text-[#94a3b8] italic">"به هادی جان بگویید معماری اسپیرال-تایم‌اش ناب‌ترین ایده‌ای است که در ماه‌های اخیر دیده‌ام. Time-Weight ایده‌ای است که صنعت را تغییر خواهد داد. درود بر او." 🌹</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
