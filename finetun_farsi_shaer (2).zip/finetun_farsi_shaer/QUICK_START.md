# 🚀 راهنمای Quick Start - Persian Brain on PC

**هادی جان، با ۱۲GB GPU اینارو به ترتیب انجام بده:**

---

## 📋 فهرست نهایی (Copy-Paste)

```bash
# ============================================================
# مرحله ۰: نصب پیش‌نیازها (~۱ ساعت)
# ============================================================

# ۱. نصب CUDA از سایت NVIDIA

# ۲. نصب Python packages
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers datasets accelerate peft bitsandbytes flask flask-cors
pip install openai-whisper

# ۳. نصب llama.cpp
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp
cmake -B build -DGGML_CUDA=ON
cmake --build build --config Release -j
cd models
wget https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf
cd ../..

# ۴. کلون کردن پروژه مغز فارسی
git clone https://github.com/your-repo/persian-brain.git
cd persian-brain
npm install

# ============================================================
# مرحله ۱: اجرای سرویس‌ها
# ============================================================

# ترمینال ۱: llama.cpp
cd llama.cpp
./build/bin/server -m models/qwen2.5-1.5b-instruct-q4_k_m.gguf --host 0.0.0.0 --port 8080 -ngl 35 -c 4096

# ترمینال ۲: مغز فارسی
cd persian-brain
npm start

# ترمینال ۳: مانیتور GPU
nvidia-smi -l 2

# ============================================================
# مرحله ۲: آموزش معماری اسپیرال
# ============================================================

# Benchmark (۱ دقیقه)
python3 spiral-real-train.py --mode benchmark --device cuda

# آموزش اسپیرال vs استاندارد (۲ ساعت)
python3 train-both-models.py --epochs 30 --dim 256 --device cuda

# آموزش عمیق با Time-Weight (۴ ساعت)
python3 spiral-real-train.py --mode train --epochs 100 --device cuda

# ============================================================
# مرحله ۳: استفاده
# ============================================================

# مرورگر: http://localhost:3000/control-panel
# رمز: PersianBrain🌹1404
# تب 🤖 llama.cpp - چت با مدل آفلاین
# تب 💬 چت - مقایسه دو مدل
```

## 📊 جواب سوالاتت

### ۱. غیر از اشعار، فارسی محاوره‌ای بلد باشه؟
**✅ بله. با دو راه:**
- **llama.cpp (همین الان):** مدل Qwen رو دانلود می‌کنی، فارسی محاوره‌ای بلده
- **آموزش اسپیرال (بعداً):** با `train-both-models.py` به مدل خودت یاد می‌دی محاوره‌ای حرف بزنه

### ۲. llama.cpp به داشبورد اضافه بشه؟
**✅ اضافه شد.** تب 🤖 llama.cpp توی کنترل پنل با:
- چت کامل
- تنظیمات دما، Top-P، طول خروجی
- حالت‌های مکالمه (عمومی، شاعرانه، آموزشی، رفیق)

### ۳. تنظیمات حرارت و ... نیاز هست؟
**✅ بله. همه رو داره:**
- 🌡️ Temperature (دما) - ۰.۱ تا ۲.۰
- 🎯 Top-P - ۰.۱ تا ۱.۰
- 📏 Max Tokens - ۶۴ تا ۲۰۴۸
- 🔁 Repeat Penalty - ۱.۰ تا ۲.۰
- 🧠 حالت مکالمه - عمومی/شاعرانه/آموزشی/رفیق

---

> **هادی جان، حالا هم llama.cpp داری هم مغز فارسی.**
> از تب 🤖 توی کنترل پنل می‌تونی با مدل آفلاین حرف بزنی.
> از تب 💬 می‌تونی معماری اسپیرال خودت رو با استاندارد مقایسه کنی.
> 
> **🧠🌹🇮🇷 Hadi Tabatabaie - موفق باشی!**
