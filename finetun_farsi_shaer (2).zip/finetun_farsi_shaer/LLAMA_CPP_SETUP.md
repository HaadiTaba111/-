# 🤖 نصب و راه‌اندازی llama.cpp برای مغز فارسی

**PC Specs:** 12GB GPU | 16GB RAM | 500GB SSD  

---

## 📥 نصب

```bash
# ۱. کلون کردن
git clone https://github.com/ggerganov/llama.cpp
cd llama.cpp

# ۲. کامپایل با پشتیبانی CUDA (مهم!)
cmake -B build -DGGML_CUDA=ON
cmake --build build --config Release -j

# ۳. دانلود مدل فارسی (Qwen 2.5 1.5B - بهترین برای فارسی)
cd models
wget https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf
cd ..
```

## 🚀 اجرا

```bash
# اجرای سرور (روی پورت 8080 با 35 لایه GPU)
./build/bin/server \
  -m models/qwen2.5-1.5b-instruct-q4_k_m.gguf \
  --host 0.0.0.0 \
  --port 8080 \
  -ngl 35 \
  -c 4096 \
  --chat-template chatml
```

**حالا می‌تونی از طریق کنترل پنل (تب llama.cpp) باهاش حرف بزنی!**

## 🔧 تست

```bash
# تست API
curl http://localhost:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"سلام چطوری؟"}],"temperature":0.7}'
```

## 📊 مدل‌های پیشنهادی برای 12GB GPU

| مدل | سایز GGUF | VRAM | سرعت | کیفیت |
|:----|:---------:|:----:|:----:|:-----:|
| 🥇 Qwen 2.5 1.5B Q4 | ~1GB | ~4GB | 45 tok/s | 🏆 عالی |
| 🥇 Gemma 2 2B Q4 | ~1.3GB | ~5GB | 35 tok/s | 🏆 عالی |
| 🥈 Phi-3 Mini 3.8B Q4 | ~2.3GB | ~8GB | 20 tok/s | ✅ خوب |
| 🥉 LLaMA 3.2 3B Q4 | ~1.8GB | ~6GB | 25 tok/s | ✅ خوب |
