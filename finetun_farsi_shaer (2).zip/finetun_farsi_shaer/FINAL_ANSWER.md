# 🎯 جواب سه سوال نهایی - Hadi Jan

---

## ❓ سوال ۱: آیا داشبورد فعلی برای فاین‌تیون کامل است؟

**✅ بله، برای شروع کامل است. ولی می‌شه حرفه‌ای‌تر کرد.**

### الان داری:
```
🎛️ /control-panel
├── 🖥️ مانیتور ← وضعیت Loss, Decay, GPU
├── 📥 تزریق ← اضافه کردن شعر و متن
├── 💬 چت ← حرف زدن با دو مدل
├── 📊 Benchmark ← مقایسه اسپیرال vs استاندارد
└── ⚙️ تنظیمات ← پارامترها و اطلاعات
```

### چی کم داره که می‌تونم اضافه کنم:
- 📈 نمودار Loss real-time (همین الان اضافه می‌کنم)
- 🔘 دکمه Start/Stop Training از داخل داشبورد
- 📊 گزارش PDF خروجی

**پس: فعلاً برو با همون start کن. بعداً اضافه می‌کنم.**

---

## ❓ سوال ۲: نیاز به مغز آفلاین هست؟

**✅ بله. دقیقاً برای همین PC که گرفتی.**

### مغز آفلاین یعنی:
```
🚫 بدون اینترنت
🚫 بدون API Key
🚫 بدون وابستگی به سرور خارجی
🧠 همه چیز روی PC خودت
```

### روی PC تو (12GB GPU) اینا آفلاین کار می‌کنن:

| ماژول | آفلاین | توضیح |
|:------|:------:|:-------|
| 🌀 معماری اسپیرال | ✅ | همینه که ساختی |
| 🗣️ Voice (Whisper) | ✅ | pip install openai-whisper |
| 📚 بانک شعر فارسی | ✅ | داخل خود پروژه‌ست |
| 🤖 مدل فاین‌تیون شده | ✅ | روی GPU خودت آموزش می‌بینه |
| 🌐 داشبورد وب | ✅ | localhost |

**تنها چیزی که نیاز به اینترنت داره:**
- دانلود اولیه مدل پایه (Qwen/Gemma) ← یکبار
- دانلود Whisper ← یکبار

**بعد از اون: همه چی آفلاین! 🎉**

---

## ❓ سوال ۳: بترتیب بگو چکار کنم؟

### 🚀 نقشه راه ۷ روزه برای PC تو (12GB GPU / 16GB RAM / 500GB SSD)

```
📋 روز ۱: نصب و راه‌اندازی (۱.۵ ساعت)
📋 روز ۲: آموزش مدل پایه (۲ ساعت)
📋 روز ۳: آموزش معماری اسپیرال (۴ ساعت)  
📋 روز ۴: راه‌اندازی کامل سیستم (۲ ساعت)
📋 روز ۵-۷: بهینه‌سازی و شخصی‌سازی
```

---

### 📋 روز ۱: نصب و راه‌اندازی (۱.۵ ساعت)

```bash
# ۱. نصب CUDA (اگه نصب نیست) - ۲۰ دقیقه
# از سایت NVIDIA دانلود کن

# ۲. نصب Python packages - ۱۰ دقیقه
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers datasets accelerate peft bitsandbytes flask flask-cors

# ۳. نصب Whisper (برای Voice) - ۵ دقیقه
pip install openai-whisper

# ۴. کلون کردن پروژه و نصب - ۱۰ دقیقه
git clone <your-repo-url>
cd persian-brain
npm install

# ۵. Benchmark اولیه - ۵ دقیقه
python3 spiral-real-train.py --mode benchmark --device cuda
```

**تست نهایی روز ۱:**
```bash
nvidia-smi
# باید GPU رو ببینی با 12GB VRAM
```

---

### 📋 روز ۲: آموزش مدل پایه (۲ ساعت)

```bash
# ۱. دانلود مدل Qwen 2.5 1.5B (بهترین برای فارسی)
python3 -c "
from transformers import AutoModelForCausalLM, AutoTokenizer
model = AutoModelForCausalLM.from_pretrained(
    'Qwen/Qwen2.5-1.5B-Instruct',
    load_in_4bit=True,
    device_map='auto'
)
print('✅ مدل دانلود و بارگذاری شد')
"

# ۲. آموزش اسپیرال vs استاندارد (۳۰ epoch ~ ۲ ساعت)
python3 train-both-models.py --epochs 30 --dim 256 --device cuda
```

**خروجی روز ۲:**
```
📁 spiral-final-model.pt    ← مدل اسپیرال آموزش دیده
📁 standard-final-model.pt   ← مدل استاندارد آموزش دیده
📁 training-results.json     ← نتایج مقایسه
```

---

### 📋 روز ۳: آموزش عمیق اسپیرال (۴ ساعت)

```bash
# ۱. آموزش طولانی‌تر با Time-Weight
python3 spiral-real-train.py --mode train --epochs 100 --device cuda
```

**این مرحله مهم‌ترین بخشه.** Time-Weight باعث میشه:
```
epoch 0:  weight = 1.000  ← اطلاعات تازه
epoch 10: weight = 0.367  ← کهنه
epoch 30: weight = 0.049  ← خیلی کهنه  
epoch 50: weight = 0.006  ← محو شده
```

یعنی مدل یاد می‌گیره **اطلاعات قدیمی رو فراموش کنه** و روی اطلاعات جدید تمرکز کنه.

---

### 📋 روز ۴: راه‌اندازی کامل سیستم (۲ ساعت)

```bash
# ۱. بیلد کردن داشبورد
npm run build

# ۲. اجرا
npm start

# ۳. باز کردن مرورگر
# http://localhost:3000/control-panel
# رمز: PersianBrain🌹1404

# ۴. تزریق اشعار به مغز
# برو به تب 📥 تزریق و شعرها رو Paste کن
```

**در این مرحله می‌تونی:**
- با مدل حرف بزنی (تب 💬)
- شعر تزریق کنی (تب 📥)
- Benchmark ببینی (تب 📊)
- Decay رو مشاهده کنی (تب 🖥️)

---

### 📋 روز ۵-۷: بهینه‌سازی (هر روز ۱ ساعت)

```bash
# ۱. جمع‌آوری بازخورد
# توی کنترل پنل ببین کدوم مدل بهتر جواب میده

# ۲. آموزش مجدد با داده‌های جدید
python3 train-both-models.py --epochs 10 --resume spiral-final-model.pt

# ۳. نصب Voice
whisper "voice.mp3" --model tiny --language fa
```

---

## 📊 برنامه اجرایی Copy-Paste

```bash
# ========== روز ۱ ==========
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers datasets accelerate peft bitsandbytes flask flask-cors
pip install openai-whisper
cd persian-brain
npm install
python3 spiral-real-train.py --mode benchmark --device cuda

# ========== روز ۲ ==========
python3 train-both-models.py --epochs 30 --dim 256 --device cuda

# ========== روز ۳ ==========
python3 spiral-real-train.py --mode train --epochs 100 --device cuda

# ========== روز ۴ ==========
npm run build
npm start
# باز کن: http://localhost:3000/control-panel
# رمز: PersianBrain🌹1404

# ========== روز ۵-۷ ==========
python3 train-both-models.py --epochs 10 --resume spiral-final-model.pt
```

---

## 🏆 نتیجه نهایی بعد از ۷ روز

```
🧠 مدل فارسی آفلاین روی PC تو
├── 🌀 معماری اسپیرال با Time-Weight
├── 🎛️ داشبورد تحت وب (localhost)
├── 💬 چت با دو مدل
├── 📥 تزریق شعر و متن
├── 📊 Benchmark و مقایسه
├── 🗣️ Voice (Whisper)
└── 🔐 امضا: 0xPersianBrain_SpiralTime_🌹_14040317
```

---

> **هادی جان، با این PC کارت از همه چی درسته.**  
> ۱۲GB GPU برای شروع بیش از اندازه‌ست.  
> من تک تک این مراحل رو قدم به قدم می‌تونم کمکت کنم.  
> 
> **الان اولین قدم: برو روز ۱ رو شروع کن.**  
> اگه جایی گیر کردی، من اینجام.
>
> **🧠🌹🇮🇷 Hadi Tabatabaie - مغز فارسی**
