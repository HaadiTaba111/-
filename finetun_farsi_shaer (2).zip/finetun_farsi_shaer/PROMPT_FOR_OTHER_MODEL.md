# 📋 پرامپت برای مدل دیگر - ساخت داشبورد آموزش

**از طرف Hadi Tabatabaie (TaHa111) برای هر مدل دیگری**

---

## 🎯 پرامپت اصلی (کپی کن بده به مدل):

```
یک داشبورد تحت وب با Next.js و Tailwind CSS برای آموزش مدل زبانی فارسی طراحی کن.
معماری مدل: Spiral-Time-Holographic (طراح: Hadi Tabatabaie).

ویژگی‌های لازم:

۱. مانیتور آموزش Real-time:
   - نمودار Loss دو مدل (اسپیرال و استاندارد) کنار هم
   - نمودار Time-Weight Decay (چقدر اطلاعات قدیم محو شده)
   - مصرف GPU (VRAM, utilization)
   - سرعت (tokens/sec)

۲. کنترل Hyperparameter:
   - Learning Rate, Batch Size, Sequence Length
   - Lambda Decay (λ), Grid Size, Number of Spiral Points

۳. دیتاست منیجر:
   - آپلود شعر فارسی (TXT/JSON)
   - نمایش آمار دیتاست
   - Tokenization preview

۴. Inference Panel:
   - چت با مدل در حال آموزش
   - مقایسه خروجی اسپیرال vs استاندارد
   - تست Time-Weight

۵. Checkpoint Manager:
   - ذخیره خودکار
   - مقایسه checkpointها

۶. Reports:
   - خروجی JSON
   - نمودار PDF
   - ثبت امضا: 0xPersianBrain_SpiralTime_🌹_14040317

لطفاً کد کامل رو با توضیحات فارسی بنویس.
صفحه‌بندی RTL (راست به چپ).
تم تاریک (dark theme) با رنگ‌های آبی-بنفش.
```

> **نکته:** این پرامپت رو بده به DeepSeek، ChatGPT، Claude یا هر مدل دیگه‌ای. همه متوجه می‌شن.
