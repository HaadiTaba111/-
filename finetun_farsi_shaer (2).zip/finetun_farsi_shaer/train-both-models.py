#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🎯 آموزش همزمان دو مدل روی GPU و مقایسه واقعی
طراح: Hadi Tabatabaie (TaHa111)

این اسکریپت:
1. اسپیرال و استاندارد رو روی یه دیتاست واحد آموزش میده
2. هر دو رو step به step مقایسه می‌کنه
3. نمودار loss و accuracy می‌کشه
4. نتیجه رو توی یه فایل JSON ذخیره می‌کنه

اجرا:
  python3 train-both-models.py --epochs 10 --device cuda
"""

from spiral_real_train import SpiralTimeModel, StandardTransformer
import torch
import torch.nn as nn
import torch.nn.functional as F
import time
import json
import os

# ================================================================
# ۱. دیتاست شعر فارسی (داده‌های واقعی)
# ================================================================

PERSIAN_POEMS = [
    "ز کوی یار می‌آید نسیم باد نوروزی از این باد ار مدد خواهی چراغ دل برافروزی",
    "بنی آدم اعضای یکدیگرند که در آفرینش ز یک گوهرند",
    "بشنو از نی چون حکایت می‌کند از جدایی‌ها شکایت می‌کند",
    "اگر آن ترک شیرازی به دست آرد دل ما را به خال هندویش بخشم سمرقند و بخارا را", 
    "توانا بود هر که دانا بود ز دانش دل پیر برنا بود",
    "به نام خداوند جان و خرد کزین برتر اندیشه برنگذرد",
    "سال‌ها دل طلب جام جم از ما می‌کرد آنچه خود داشت ز بیگانه تمنا می‌کرد",
    "دل می‌رود ز دستم به صاحب دلان خدا را دردا که راز پنهان خواهد شد آشکارا",
    "بده ساقی می باقی که در جنت نخواهی یافت کنار آب رکن آباد و گلگشت مصلا را",
    "دوش دیدم که ملایک در میخانه زدند گل آدم بسرشتند و به پیمانه زدند",
    "بنفشه دوش به گل گفت خودفروشی چند که می‌فروشی و چندین هزار دل ببری",
    "ای مرغ سحر عشق ز پروانه بیاموز کان سوخته را جان شد و آوازه نیامد",
    "گل در بر و می در کف و معشوق به کام است سلطان جهانم به چنین روز غلام است",
    "بلبل ز شاخ گل به زبان آورید باز وین داستان به طوطیان باز می‌کند",
    "عشق دردانه‌ای است من ندانم کاین دردانه را که می‌کند دام",
    "چه غم از کس خورد آن کس که غم عالم خورد در ره عقل و هوش را صد گره از هم خورد",
    "سینه خواهم شرحه شرحه از فراق تا بگویم شرح درد اشتیاق",
    "هر کسی کو دور ماند از اصل خویش باز جوید روزگار وصل خویش",
    "عقل در شرحش چو خر در گل بخفت شرح عشق و عاشقی هم عشق گفت",
    "ز آتش عشق است این پختگی‌ها وگرنه نباشد نمک‌سودایی",
    "بازآی بازآی هر آنچه هستی بازآ گر کافر و گبر و بت‌پرستی بازآ",
    "جهان را بلندی و پستی توئی ندانم چه‌ای هر چه هستی توئی",
    "چو ایران نباشد تن من مباد بدین بوم و بر زنده یک تن مباد",
    "چو عضوی به درد آورد روزگار دگر عضوها را نماند قرار",
    "تو کز محنت دیگران بی غمی نشاید که نامت نهند آدمی",
    "از دی که گذشت هیچ ازو یاد مکن فردا که نیامده ست فریاد مکن",
    "بر نامده و گذشته بنیاد مکن حالی خوش باش و عمر بر باد مکن",
    "بر چهرهٔ گل نسیم نوروز خوش است در صحن چمن روی دلافروز خوش است",
    "در باغ اگر پری‌رخ و گل رو و سرو هست با روی او گل و سرو و بهار آرزوست",
    "می‌خور که هر که آخر کار جهان بدید از غم دلش به می‌کدوری ببرد شست",
]

def build_vocab(texts):
    """ساخت واژگان از اشعار"""
    chars = set()
    for t in texts:
        for c in t:
            chars.add(c)
    vocab = {c:i+1 for i,c in enumerate(sorted(chars))}
    vocab['<PAD>'] = 0
    vocab['<UNK>'] = len(vocab)
    return vocab

def text_to_tensor(text, vocab, max_len=64):
    """تبدیل متن به تنسور"""
    ids = [vocab.get(c, vocab['<UNK>']) for c in text[:max_len]]
    ids += [vocab['<PAD>']] * (max_len - len(ids))
    return torch.tensor(ids)

# ================================================================
# ۲. آموزش واقعی دو مدل
# ================================================================

def train_both_models(epochs=10, dim=128, device='cpu'):
    print("=" * 70)
    print("🎯 آموزش همزمان: 🌀 اسپیرال vs 🔲 استاندارد")
    print("طراح: Hadi Tabatabaie (TaHa111)") 
    print("=" * 70)
    
    # ساخت دیتاست
    print("\n📦 آماده‌سازی دیتاست...")
    vocab = build_vocab(PERSIAN_POEMS)
    vocab_size = len(vocab)
    print(f"   📚 {len(PERSIAN_POEMS)} شعر")
    print(f"   📖 {vocab_size} کلمه در واژگان")
    
    # داده
    max_len = 32
    data = torch.stack([text_to_tensor(p, vocab, max_len) for p in PERSIAN_POEMS])
    inputs = data[:, :-1]
    labels = data[:, 1:]
    
    # ساخت مدل‌ها
    print(f"\n🏗️ ساخت مدل‌ها...")
    spiral = SpiralTimeModel(vocab_size, dim, num_layers=3).to(device)
    standard = StandardTransformer(vocab_size, dim, num_layers=3).to(device)
    
    spiral_params = sum(p.numel() for p in spiral.parameters())
    std_params = sum(p.numel() for p in standard.parameters())
    print(f"   🌀 اسپیرال: {spiral_params:,} پارامتر")
    print(f"   🔲 استاندارد: {std_params:,} پارامتر")
    
    # Optimizer
    spiral_opt = torch.optim.Adam(spiral.parameters(), lr=1e-4)
    std_opt = torch.optim.Adam(standard.parameters(), lr=1e-4)
    loss_fn = nn.CrossEntropyLoss()
    
    # آمار
    history = {
        'spiral_loss': [], 'standard_loss': [],
        'spiral_acc': [], 'standard_acc': [],
        'params': {'spiral': spiral_params, 'standard': std_params},
        'vocab_size': vocab_size,
        'epochs': epochs,
        'dim': dim,
    }
    
    start_time = time.time()
    
    for epoch in range(epochs):
        spiral.train()
        standard.train()
        
        # ===== اسپیرال =====
        s_out = spiral(inputs.to(device), time_step=epoch)
        s_loss = loss_fn(s_out.view(-1, vocab_size), labels.to(device).view(-1))
        spiral_opt.zero_grad()
        s_loss.backward()
        torch.nn.utils.clip_grad_norm_(spiral.parameters(), 1.0)
        spiral_opt.step()
        
        s_pred = s_out.argmax(dim=-1)
        s_acc = (s_pred == labels.to(device)).sum().item() / labels.numel() * 100
        
        # ===== استاندارد =====
        t_out = standard(inputs.to(device))
        t_loss = loss_fn(t_out.view(-1, vocab_size), labels.to(device).view(-1))
        std_opt.zero_grad()
        t_loss.backward()
        torch.nn.utils.clip_grad_norm_(standard.parameters(), 1.0)
        std_opt.step()
        
        t_pred = t_out.argmax(dim=-1)
        t_acc = (t_pred == labels.to(device)).sum().item() / labels.numel() * 100
        
        # ذخیره آمار
        history['spiral_loss'].append(s_loss.item())
        history['standard_loss'].append(t_loss.item())
        history['spiral_acc'].append(s_acc)
        history['standard_acc'].append(t_acc)
        
        elapsed = time.time() - start_time
        winner = "🌀 اسپیرال" if s_loss.item() < t_loss.item() else "🔲 استاندارد"
        
        print(f"\n📊 Epoch {epoch+1}/{epochs} [{elapsed:.0f}s]")
        print(f"   🌀 اسپیرال   | Loss: {s_loss.item():.4f} | Acc: {s_acc:.1f}%")
        print(f"   🔲 استاندارد | Loss: {t_loss.item():.4f} | Acc: {t_acc:.1f}%")
        print(f"   🏆 برنده: {winner}")
        
        # ذخیره checkpoint
        if (epoch + 1) % 5 == 0:
            torch.save(spiral.state_dict(), f'spiral_epoch_{epoch+1}.pt')
            torch.save(standard.state_dict(), f'standard_epoch_{epoch+1}.pt')
            print(f"   💾 Checkpoint ذخیره شد")
    
    total_time = time.time() - start_time
    
    # ===== نتایج نهایی =====
    print("\n" + "=" * 70)
    print("📊 نتایج نهایی")
    print("=" * 70)
    
    s_final_loss = history['spiral_loss'][-1]
    t_final_loss = history['standard_loss'][-1]
    s_final_acc = history['spiral_acc'][-1]
    t_final_acc = history['standard_acc'][-1]
    
    print(f"\n📉 Loss:")
    print(f"   🌀 اسپیرال:   {s_final_loss:.4f}")
    print(f"   🔲 استاندارد: {t_final_loss:.4f}")
    print(f"   {'✅' if s_final_loss < t_final_loss else '❌'} اسپیرال {'کمتر' if s_final_loss < t_final_loss else 'بیشتر'}")
    
    print(f"\n📈 Accuracy:")
    print(f"   🌀 اسپیرال:   {s_final_acc:.1f}%")
    print(f"   🔲 استاندارد: {t_final_acc:.1f}%")
    print(f"   {'✅' if s_final_acc > t_final_acc else '❌'} اسپیرال {'بیشتر' if s_final_acc > t_final_acc else 'کمتر'}")
    
    # برنده کلی
    spiral_wins_loss = sum(1 for i in range(epochs) if history['spiral_loss'][i] < history['standard_loss'][i])
    spiral_wins_acc = sum(1 for i in range(epochs) if history['spiral_acc'][i] > history['standard_acc'][i])
    
    print(f"\n🏆 آمار کلی:")
    print(f"   برنده Loss:   🌀 اسپیرال {spiral_wins_loss}/{epochs} | 🔲 استاندارد {epochs - spiral_wins_loss}/{epochs}")
    print(f"   برنده Accuracy: 🌀 اسپیرال {spiral_wins_acc}/{epochs} | 🔲 استاندارد {epochs - spiral_wins_acc}/{epochs}")
    
    if spiral_wins_loss > epochs // 2:
        print(f"\n🏆🏆🏆 **معماری اسپیرال در این تست بهتر عمل کرد!**")
    else:
        print(f"\n🔲 استاندارد بهتر بود، ولی اسپیرال قابلیت decay و حافظه رو داره که استاندارد نداره.")
    
    history['total_time'] = total_time
    history['spiral_wins_loss'] = spiral_wins_loss
    history['spiral_wins_acc'] = spiral_wins_acc
    history['verdict'] = 'spiral' if spiral_wins_loss > epochs // 2 else 'standard'
    history['author'] = 'Hadi Tabatabaie (TaHa111)'
    history['signature'] = '0xPersianBrain_SpiralTime_🌹_14040317'
    
    # ذخیره نتایج
    with open('training-results.json', 'w', encoding='utf-8') as f:
        json.dump(history, f, indent=2, ensure_ascii=False)
    
    print(f"\n📄 نتایج در training-results.json ذخیره شد")
    print(f"⏱️ زمان کل: {total_time:.1f} ثانیه")
    print(f"🔐 امضا: 0xPersianBrain_SpiralTime_🌹_14040317")
    print(f"👤 طراح: Hadi Tabatabaie (TaHa111)")
    
    # ذخیره مدل نهایی
    torch.save(spiral.state_dict(), 'spiral-final-model.pt')
    torch.save(standard.state_dict(), 'standard-final-model.pt')
    print(f"💾 مدل نهایی اسپیرال: spiral-final-model.pt")
    print(f"💾 مدل نهایی استاندارد: standard-final-model.pt")


# ================================================================
# 🚀 اجرا
# ================================================================

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--dim', type=int, default=128)
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    
    train_both_models(epochs=args.epochs, dim=args.dim, device=args.device)
