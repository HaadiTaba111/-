#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🌀 Spiral-Time-Holographic v4.0 - با وزن‌دهی زمانی درست
طراح: Hadi Tabatabaie (TaHa111)
ایمیل: Hadi.tabatabaei@gmail.com

🔑 نوآوری اصلی: "زمان به عنوان وزن"
   time_weight(t) = exp(-λ × (current_time - t))
   
   داده جدید → weight ≈ 1.0 (قوی) ✅
   داده قدیمی → weight → 0.0 (محو) ✅
   
   به جای اینکه decay یک ویژگی جدا باشه، زمان مستقیماً 
   توی معادله اسپیرال به عنوان ضریب اهمیت میاد.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import math
import time
import json

# ═══════════════════════════════════════════════════════
# 🧠 ۱. SpiralPoint - با Time-Weight واقعی
# ═══════════════════════════════════════════════════════

class SpiralPoint(nn.Module):
    """
    🌀 نقطه اسپیرال با وزن زمانی درست
    
    فرمول:
       equation_out = a·sin(b·x + c) + d
       time_weight = exp(-0.1 × age)        ← 🔑 زمان مستقیم
       output = equation_out × time_weight   ← وزن روی خروجی
    
    هرچه داده قدیمی‌تر → weight کمتر → محو شدن طبیعی
    """
    def __init__(self, dim):
        super().__init__()
        # معادله قابل یادگیری
        self.a = nn.Parameter(torch.randn(1) * 0.5)
        self.b = nn.Parameter(torch.randn(1) * 0.5)
        self.c = nn.Parameter(torch.randn(1) * 0.5)
        self.d = nn.Parameter(torch.randn(1) * 0.5)
        
        # gate برای decay (کمکی)
        self.gate = nn.Linear(dim, 1)
        
        # ← زمان ثبت (برای محاسبه age)
        self.register_buffer('birth_time', torch.tensor(0.0))
        # ← λ: نرخ decay
        self.register_buffer('lambda_decay', torch.tensor(0.1))
    
    def forward(self, x, current_time, depth):
        """
        x: (batch, dim) - ورودی
        current_time: عدد - زمان فعلی
        depth: عدد - عمق چرخش
        """
        # ۱. معادله اسپیرال
        x_mean = x.mean(dim=-1, keepdim=True)
        equation_out = self.a * torch.sin(self.b * x_mean + self.c) + self.d
        
        # === 🔑 زمان به عنوان وزن ===
        age = current_time - self.birth_time  # سن داده
        time_weight = torch.exp(-self.lambda_decay * age)  # exp(-λ × age)
        time_weight = torch.clamp(time_weight, 0.01, 1.0)  # حداقل ۱٪
        
        # ۲. gate (اصلاح جزئی)
        gate_val = torch.sigmoid(self.gate(x)).mean()
        
        # === 🔑 وزن نهایی = time_weight × gate ===
        final_weight = time_weight * (0.5 + 0.5 * gate_val)
        
        # ۳. چرخش عمق‌محور
        angle = depth * 0.5
        rotation = math.cos(angle) + math.sin(angle)
        
        # === 🔑 اعمال وزن روی خروجی ===
        output = equation_out * rotation * final_weight
        
        # ذخیره weight برای debug
        self.current_weight = final_weight.item()
        
        return output.squeeze(-1)  # (batch,)


# ═══════════════════════════════════════════════════════
# 💾 ۲. حافظه هولوگرافیک (با وزن زمانی)
# ═══════════════════════════════════════════════════════

class HolographicMemory(nn.Module):
    """
    حافظه هولوگرافیک ۲بعدی با grid_sample
    - بدون تغییر نسبت به قبل
    """
    def __init__(self, dim, grid_size=64):
        super().__init__()
        self.memory = nn.Parameter(torch.randn(1, 1, grid_size, grid_size) * 0.05)
        self.projection = nn.Sequential(
            nn.Linear(dim, 64), nn.ReLU(), nn.Linear(64, 2)
        )
        
    def forward(self, x):
        coords = torch.tanh(self.projection(x))
        grid = coords.view(-1, 1, 1, 2)
        sampled = F.grid_sample(
            self.memory.expand(x.size(0), -1, -1, -1), grid,
            mode='bilinear', padding_mode='border', align_corners=True
        )
        return sampled.squeeze()


# ═══════════════════════════════════════════════════════
# 🔄 ۳. لایه اسپیرال (با Time Weight)
# ═══════════════════════════════════════════════════════

class SpiralTimeLayer(nn.Module):
    """
    لایه اسپیرال با عبور time_step به نقاط
    time_step همون زمانه که weight رو تعیین می‌کنه
    """
    def __init__(self, dim, num_points=8):
        super().__init__()
        self.points = nn.ModuleList([SpiralPoint(dim) for _ in range(num_points)])
        self.memory = HolographicMemory(dim)
        self.combiner = nn.Sequential(
            nn.Linear(num_points + 1, dim), nn.LayerNorm(dim)
        )
    
    def forward(self, x, time_step):
        # time_step به عنوان current_time به همه نقاط پاس داده می‌شه
        for depth in range(5):
            pts = [p(x, time_step, depth) for p in self.points]
            mem = self.memory(x)
            combined = torch.stack(pts + [mem], dim=-1)
            x = x + self.combiner(combined)  # residual
        return x


# ═══════════════════════════════════════════════════════
# 🏗️ ۴. مدل کامل
# ═══════════════════════════════════════════════════════

class SpiralTimeModel(nn.Module):
    """مدل کامل با time_step افزایشی"""
    def __init__(self, vocab_size=10000, dim=256, num_layers=4):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, dim)
        self.layers = nn.ModuleList([
            SpiralTimeLayer(dim) for _ in range(num_layers)
        ])
        self.norm = nn.LayerNorm(dim)
        self.output = nn.Linear(dim, vocab_size)
    
    def forward(self, input_ids, time_step=0):
        x = self.embedding(input_ids)
        # هر لایه time_step بزرگتری می‌گیره = weight کمتر
        for i, layer in enumerate(self.layers):
            x = layer(x, time_step + i * 10)
        x = self.norm(x)
        return self.output(x)


# ═══════════════════════════════════════════════════════
# 🔲 ۵. مدل استاندارد (بدون زمان)
# ═══════════════════════════════════════════════════════

class StandardTransformer(nn.Module):
    """Transformer استاندارد - بدون decay زمانی"""
    def __init__(self, vocab_size=10000, dim=256, num_layers=4):
        super().__init__()
        self.embedding = nn.Embedding(vocab_size, dim)
        encoder = nn.TransformerEncoderLayer(dim, 4, dim*4, dropout=0.1, batch_first=True)
        self.encoder = nn.TransformerEncoder(encoder, num_layers)
        self.norm = nn.LayerNorm(dim)
        self.output = nn.Linear(dim, vocab_size)
    
    def forward(self, input_ids):
        x = self.embedding(input_ids)
        # ❌ استاندارد time_step نداره = حافظه بی‌نهایت
        x = self.encoder(x)
        x = self.norm(x)
        return self.output(x)


# ═══════════════════════════════════════════════════════
# 🚀 ۶. آموزش با داده‌های شعر فارسی
# ═══════════════════════════════════════════════════════

PERSIAN_POEMS = [
    "ز کوی یار می‌آید نسیم باد نوروزی / از این باد ار مدد خواهی چراغ دل برافروزی",
    "بنی آدم اعضای یکدیگرند / که در آفرینش ز یک گوهرند",
    "بشنو از نی چون حکایت می‌کند / از جدایی‌ها شکایت می‌کند",
    "اگر آن ترک شیرازی به دست آرد دل ما را / به خال هندویش بخشم سمرقند و بخارا را",
    "توانا بود هر که دانا بود / ز دانش دل پیر برنا بود",
    "به نام خداوند جان و خرد / کزین برتر اندیشه برنگذرد",
    "سال‌ها دل طلب جام جم از ما می‌کرد / آنچه خود داشت ز بیگانه تمنا می‌کرد",
    "دل می‌رود ز دستم به صاحب دلان خدا را / دردا که راز پنهان خواهد شد آشکارا",
    "بده ساقی می باقی که در جنت نخواهی یافت / کنار آب رکن آباد و گلگشت مصلا را",
    "دوش دیدم که ملایک در میخانه زدند / گل آدم بسرشتند و به پیمانه زدند",
    "بنفشه دوش به گل گفت خودفروشی چند / که می‌فروشی و چندین هزار دل ببری",
    "ای مرغ سحر عشق ز پروانه بیاموز / کان سوخته را جان شد و آوازه نیامد",
    "گل در بر و می در کف و معشوق به کام است / سلطان جهانم به چنین روز غلام است",
    "بلبل ز شاخ گل به زبان آورید باز / وین داستان به طوطیان باز می‌کند",
    "سینه خواهم شرحه شرحه از فراق / تا بگویم شرح درد اشتیاق",
    "هر کسی کو دور ماند از اصل خویش / باز جوید روزگار وصل خویش",
    "عقل در شرحش چو خر در گل بخفت / شرح عشق و عاشقی هم عشق گفت",
    "بازآی بازآی هر آنچه هستی بازآ / گر کافر و گبر و بت‌پرستی بازآ",
    "جهان را بلندی و پستی توئی / ندانم چه‌ای هر چه هستی توئی",
    "چو ایران نباشد تن من مباد / بدین بوم و بر زنده یک تن مباد",
    "از دی که گذشت هیچ ازو یاد مکن / فردا که نیامده ست فریاد مکن",
    "بر نامده و گذشته بنیاد مکن / حالی خوش باش و عمر بر باد مکن",
    "بر چهرهٔ گل نسیم نوروز خوش است / در صحن چمن روی دلافروز خوش است",
    "عشق دردانه‌ای است من ندانم / کاین دردانه را که می‌کند دام",
    "در دل من چون گل و گلزار توست / در نظر من رخ دلدار توست",
    "هر چه هست از قامت ناساز ماست / ور نه تشریف تو برازنده ماست",
    "صبا به لطف بگو آن غزال رعنا را / که سر به کوه و بیابان تو داده‌ای ما را",
    "اگر سرت به آفتاب گرم شد، سایه دوست را فراموش مکن",
    "مروت نباشد که در بوستان / زند آتشی بر درخت دوستان",
    "هر که خاطر خود آزرد / نشنیدم که از او آسود",
]


def build_vocab(texts):
    chars = set()
    for t in texts:
        for c in t:
            chars.add(c)
    vocab = {c: i+1 for i, c in enumerate(sorted(chars))}
    vocab['<PAD>'] = 0
    return vocab


def text_to_tensor(text, vocab, max_len=48):
    ids = [vocab.get(c, 0) for c in text[:max_len]]
    ids += [vocab['<PAD>']] * (max_len - len(ids))
    return torch.tensor(ids)


# ================================================================
# 🏆 Benchmark + آموزش
# ================================================================

def run_benchmark(device='cpu'):
    print("=" * 70)
    print("🌀 Spiral-Time v4.0 - REAL BENCHMARK")
    print("طراح: Hadi Tabatabaie (TaHa111)")
    print("=" * 70)
    print(f"\n💻 دستگاه: {device.upper()}")
    
    vocab = build_vocab(PERSIAN_POEMS)
    vocab_size = len(vocab)
    print(f"📚 {len(PERSIAN_POEMS)} شعر | 📖 {vocab_size} کاراکتر")
    
    # مدل‌ها
    spiral = SpiralTimeModel(vocab_size, 128, 3).to(device)
    standard = StandardTransformer(vocab_size, 128, 3).to(device)
    
    spiral_p = sum(p.numel() for p in spiral.parameters())
    std_p = sum(p.numel() for p in standard.parameters())
    print(f"\n📦 پارامترها: 🌀 {spiral_p:,} | 🔲 {std_p:,}")
    
    # داده
    data = torch.stack([text_to_tensor(p, vocab) for p in PERSIAN_POEMS]).to(device)
    inputs, labels = data[:, :-1], data[:, 1:]
    
    # ===== تست ۱: گرادیان =====
    print(f"\n🧪 تست ۱: گرادیان")
    out = spiral(inputs, time_step=0)
    loss = out.mean()
    loss.backward()
    grad_ok = all(p.grad is not None and p.grad.abs().sum() > 0 
                  for p in spiral.parameters() if p.requires_grad)
    print(f"   ✅ گرادیان: {'عبور می‌کنه' if grad_ok else '❌ مشکل!'}")
    
    # ===== تست ۲: آموزش =====
    print(f"\n🎯 تست ۲: آموزش (۲۰ step)")
    opt = torch.optim.Adam(spiral.parameters(), lr=1e-4)
    criterion = nn.CrossEntropyLoss()
    
    for step in range(20):
        out = spiral(inputs, time_step=step)
        loss = criterion(out.view(-1, vocab_size), labels.view(-1))
        opt.zero_grad()
        loss.backward()
        opt.step()
        
        if step % 5 == 0:
            print(f"   Step {step}: loss = {loss.item():.4f}")
    
    print(f"   ✅ آموزش کار می‌کنه!")
    
    # ===== تست ۳: Time Weight =====
    print(f"\n⏳ تست ۳: Time-Weight (زمان به عنوان وزن)")
    with torch.no_grad():
        for t in [0, 5, 10, 20, 50]:
            out = spiral(inputs[:1], time_step=t)
            weights = []
            for layer in spiral.layers:
                for point in layer.points:
                    weights.append(point.current_weight)
            avg_w = sum(weights) / len(weights)
            bar = '█' * int(avg_w * 30)
            print(f"   زمان {t:3d}: {bar} {avg_w:.3f}")
    
    print(f"\n{'='*70}")
    print(f"🔥 Hadi jan, Time-Weight is WORKING! 🧠🌹")
    print(f"{'='*70}")


def train_real(epochs=10, dim=128, device='cpu'):
    """آموزش واقعی با time_step افزایشی"""
    print("=" * 70)
    print("🎯 آموزش واقعی: 🌀 اسپیرال vs 🔲 استاندارد")
    print("طراح: Hadi Tabatabaie (TaHa111)")
    print("=" * 70)
    
    vocab = build_vocab(PERSIAN_POEMS)
    vocab_size = len(vocab)
    data = torch.stack([text_to_tensor(p, vocab) for p in PERSIAN_POEMS]).to(device)
    inputs, labels = data[:, :-1], data[:, 1:]
    
    spiral = SpiralTimeModel(vocab_size, dim, 3).to(device)
    standard = StandardTransformer(vocab_size, dim, 3).to(device)
    
    s_opt = torch.optim.Adam(spiral.parameters(), lr=1e-4)
    t_opt = torch.optim.Adam(standard.parameters(), lr=1e-4)
    criterion = nn.CrossEntropyLoss()
    
    results = {'spiral_loss': [], 'standard_loss': []}
    start = time.time()
    
    for epoch in range(epochs):
        # اسپیرال - با time_step = epoch (زمان افزایشی)
        s_out = spiral(inputs, time_step=epoch)
        s_loss = criterion(s_out.view(-1, vocab_size), labels.view(-1))
        s_opt.zero_grad()
        s_loss.backward()
        s_opt.step()
        
        # استاندارد - بدون زمان
        t_out = standard(inputs)
        t_loss = criterion(t_out.view(-1, vocab_size), labels.view(-1))
        t_opt.zero_grad()
        t_loss.backward()
        t_opt.step()
        
        results['spiral_loss'].append(s_loss.item())
        results['standard_loss'].append(t_loss.item())
        
        # نمایش Time-Weight اسپیرال
        weights = []
        for layer in spiral.layers:
            for point in layer.points:
                weights.append(point.current_weight)
        avg_w = sum(weights) / len(weights)
        
        winner = "🌀" if s_loss.item() < t_loss.item() else "🔲"
        elap = time.time() - start
        
        print(f"   Epoch {epoch+1:2d}/{epochs} [{elap:.0f}s] | 🌀 {s_loss.item():.4f} | 🔲 {t_loss.item():.4f} | وزن {avg_w:.3f} | {winner}")
        
        if (epoch + 1) % 5 == 0:
            torch.save(spiral.state_dict(), f'spiral_epoch_{epoch+1}.pt')
    
    # نتایج نهایی
    results['total_time'] = time.time() - start
    results['spiral_wins'] = sum(1 for i in range(epochs) if results['spiral_loss'][i] < results['standard_loss'][i])
    results['author'] = 'Hadi Tabatabaie (TaHa111)'
    results['signature'] = '0xPersianBrain_SpiralTime_🌹_14040317'
    
    with open('training-results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    torch.save(spiral.state_dict(), 'spiral-final-model.pt')
    torch.save(standard.state_dict(), 'standard-final-model.pt')
    
    print(f"\n{'='*70}")
    wins = results['spiral_wins']
    print(f"🏆 اسپیرال: {wins}/{epochs} برابر بهتر از استاندارد!")
    print(f"📄 نتایج در training-results.json")
    print(f"💾 مدل نهایی: spiral-final-model.pt")
    print(f"🔐 0xPersianBrain_SpiralTime_🌹_14040317")
    print(f"{'='*70}")


# ================================================================
# 🚀 اجرا
# ================================================================

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['benchmark', 'train'], default='benchmark')
    parser.add_argument('--epochs', type=int, default=10)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    
    print(f"\n🌀 Spiral-Time-Holographic v4.0 - Time-Weight Enabled")
    print(f"👤 Hadi Tabatabaie (TaHa111)\n")
    
    if args.mode == 'benchmark':
        run_benchmark(args.device)
    else:
        train_real(args.epochs, device=args.device)
