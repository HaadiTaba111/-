# 🧩 Persian Brain - معماری ماژولار برای مدل‌های دیگر

**طراح اصلی:** Hadi Tabatabaie (TaHa111)  
**شناسه امضا:** 0xPersianBrain_SpiralTime_🌹_14040317  
**هدف:** این سند رو بده به هر مدل هوش مصنوعی (DeepSeek, ChatGPT, Claude, Gemini) تا هرکدوم یه ماژول رو برات بسازن.

---

## 📋 راهنمای استفاده

```
۱. هر ماژول رو جداگانه به یه مدل بده
۲. مدل ها مستقل از هم کار می‌کنن
۳. همه ماژول‌ها در نهایت به هم وصل می‌شن
۴. تکنولوژی: Python + PyTorch (برای GPU)
```

---

## 🧩 ماژول ۱: SpiralTime Core (هسته اسپیرال)

**بهترین مدل برای اجرا:** DeepSeek یا ChatGPT

```
ماژول TimeAwareSpiralPoint با این مشخصات:

=== فرمول اصلی ===
equation_out = a·sin(b·x + c) + d
    که a, b, c, d پارامترهای قابل یادگیری هستند (nn.Parameter)

=== Time-Weight (نوآوری اصلی) ===
time_weight = exp(-λ × (current_time - birth_time))
    که λ = نرخ decay (پیش‌فرض 0.1)
    birth_time = زمان ثبت نقطه

=== Gating Decay ===
importance = (1 - gate) × imp + gate × new_info
    gate = sigmoid(GateNetwork(x))
    new_info = Projection(x)

=== Rotation (چرخش عمق‌محور) ===
θ(depth) = depth × 0.5
output = equation_out × (cos(θ) + sin(θ)) × time_weight × importance

=== خروجی ===
(batch,) - اسکالر برای هر نمونه

=== تکنیکال ===
- همه چیز تنسوری (ممنوع .item() در forward)
- clamp importance به [0.1, 1.0]
- birth_time به عنوان register_buffer
```

**تحویلی:** فایل `spiral_point.py` با کلاس `TimeAwareSpiralPoint`

---

## 🧩 ماژول ۲: HolographicMemory (حافظه هولوگرافیک)

**بهترین مدل برای اجرا:** Claude یا Gemini

```
ماژول HolographicMemory2D با این مشخصات:

=== ساختار ===
memory_grid: nn.Parameter(1, 1, 64, 64) - حافظه ۲بعدی
projection: Linear(dim → 64 → 2) - تبدیل ورودی به مختصات

=== forward ===
1. x: (batch, dim)
2. coords = tanh(projection(x)) → (batch, 2)
3. grid = coords.view(batch, 1, 1, 2)
4. sampled = F.grid_sample(memory_grid, grid, mode='bilinear', padding_mode='border', align_corners=True)
5. خروجی: (batch,) - مقدار بازیابی شده

=== نکات ===
- F.grid_sample با mode='bilinear' اجازه عبور گرادیان رو میده
- memory_grid قابل یادگیریه (گرادیان می‌گیره)
- projection: Sequential(Linear + ReLU + Linear)

=== ورژن ۳بعدی (برای تصاویر) ===
مشابه بالا ولی:
memory_grid: nn.Parameter(1, 1, 64, 64, 64) - حافظه ۳بعدی
grid_sample → F.grid_sample_3d
```

**تحویلی:** فایل `holographic_memory.py` با کلاس `HolographicMemory2D`

---

## 🧩 ماژول ۳: SpiralTimeLayer (لایه کامل)

**بهترین مدل برای اجرا:** DeepSeek

```
ماژول SpiralTimeLayer با این مشخصات:

=== ساختار ===
- ۸ عدد TimeAwareSpiralPoint (از ماژول ۱)
- ۱ عدد HolographicMemory2D (از ماژول ۲)
- ۱ عدد Combiner: Linear(9 → dim) + LayerNorm(dim)

=== forward(x, time_step) ===
ورودی: x: (batch, dim), time_step: int

برای depth در range(5):
    ۱. points_out = [point(x, time_step, depth) for point in self.points]
       → ۸ تا (batch,)
    ۲. mem_out = self.memory(x)
       → (batch,)
    ۳. combined = stack(points_out + [mem_out], dim=-1)
       → (batch, 9)
    ۴. new_x = combiner(combined)
       → (batch, dim)
    ۵. x = x + new_x (residual)
    
خروجی: (batch, dim)

=== نکات مهم ===
- time_step در هر epoch افزایش می‌یابد → weight کمتر برای اطلاعات قدیمی
- depth چرخش رو تعیین می‌کنه (هر عمق یه زاویه)
- همه خروجی‌های میانی (batch,) هستن
```

**تحویلی:** فایل `spiral_layer.py` با کلاس `SpiralTimeLayer`

---

## 🧩 ماژول ۴: SpiralTimeModel (مدل کامل)

**بهترین مدل برای اجرا:** ChatGPT

```
مدل کامل SpiralTimeModel با این مشخصات:

=== ساختار ===
- embedding: nn.Embedding(vocab_size, dim)
- layers: 4 × SpiralTimeLayer
- norm: nn.LayerNorm(dim)
- output: nn.Linear(dim, vocab_size)

=== forward(input_ids, time_step=0) ===
ورودی: input_ids: (batch, seq_len)
       time_step: int (شروع از ۰، در هر epoch افزایش)

x = embedding(input_ids)  # (batch, seq_len, dim)
for i, layer in enumerate(layers):
    x = layer(x, time_step + i * 10)  # هر لایه زمان بیشتر
x = norm(x)
logits = output(x)  # (batch, seq_len, vocab_size)

=== پارامترها ===
vocab_size = 1000~10000
dim = 128~256
num_layers = 3~4
num_points = 8 (تعداد نقاط اسپیرال)
max_depth = 5 (حداکثر عمق چرخش)

=== نکته کلیدی (Time-Weight) ===
time_step + i*10 یعنی:
  لایه ۰: زمان ۰,۱۰,۲۰,... (weight بالا)
  لایه ۱: زمان ۱۰,۲۰,۳۰,... (weight کمتر)
  لایه ۲: زمان ۲۰,۳۰,۴۰,... (weight حتی کمتر)
  لایه ۳: زمان ۳۰,۴۰,۵۰,... (قدیمی‌ترین)

این باعث میشه لایه‌های عمیق‌تر به اطلاعات جدیدتر حساس باشن!
```

**تحویلی:** فایل `spiral_model.py` با کلاس `SpiralTimeModel`

---

## 🧩 ماژول ۵: TimeWeightAnalyzer (آنالایزر وزن زمانی)

**بهترین مدل برای اجرا:** Claude

```
ماژول تحلیل Time-Weight برای مانیتورینگ:

=== ورودی ===
- مدل SpiralTimeModel
- range_time: list of int (گام‌های زمانی برای تست)

=== خروجی ===
برای هر time_step در range_time:
    - میانگین importance همه نقاط همه لایه‌ها
    - time_weight = exp(-0.1 × time_step)
    - weight نهایی = importance × time_weight

=== فرمول ===
time_weight = exp(-λ × t)
decay_percent = (1 - time_weight) × 100

=== نمونه خروجی ===
[
    {"time": 0, "weight": 1.000, "decay": "0%"},
    {"time": 5, "weight": 0.606, "decay": "39%"},
    {"time": 10, "weight": 0.367, "decay": "63%"},
    {"time": 20, "weight": 0.135, "decay": "86%"},
    {"time": 50, "weight": 0.006, "decay": "99%"},
]

=== نمودار ===
زمان 0:  ████████████████████████████ 100%
زمان 5:  ██████████████████           61%
زمان 10: ████████████                 37%
زمان 20: █████                        14%
زمان 50: ▏                             1%
```

**تحویلی:** فایل `time_analyzer.py` با کلاس `TimeWeightAnalyzer`

---

## 🧩 ماژول ۶: ResponseClassifier (تشخیص حالت پاسخ)

**بهترین مدل برای اجرا:** هر مدلی (ساده‌ست)

```
ماژول تشخیص اینکه سوال جدیه یا شاعری یا محاوره:

=== ورودی ===
text: str (سوال کاربر)

=== خروجی ===
{
    "mode": "serious" | "poetic" | "chat",
    "confidence": 0.0~1.0,
    "disallow_poetry": bool,
    "disallow_jokes": bool,
}

=== منطق تشخیص ===
امتیاز جدی:
  کلمات: راهنمایی, آموزش, مشکل, خطا, help, تحلیل, قانون, دلیل
  ← serious_score += 2

امتیاز شاعری:
  کلمات: شعر, غزل, حافظ, سعدی, بیت, بگو, بخون, داستان, عشق, گل
  ← poetic_score += 2

امتیاز محاوره:
  کلمات: سلام, چطوری, خوبی, داداش, مرسی, خوبم
  ← chat_score += 2

تصمیم‌گیری:
  if serious_score >= others → mode = "serious" (شعر ممنوع)
  if poetic_score >= others → mode = "poetic" (شعر مجاز)
  else → mode = "chat" (شعر مجاز)
```

**تحویلی:** فایل `classifier.py` با کلاس `ResponseClassifier`

---

## 🧩 ماژول ۷: DataLoader (دیتاست شعر فارسی)

**بهترین مدل برای اجرا:** هر مدلی

```
دیتاست شعر فارسی برای آموزش:

=== فرمت دیتاست ===
هر نمونه: یه متن شعر فارسی (string)

=== نمونه‌ها ===
30 شعر از حافظ، سعدی، مولانا، فردوسی، خیام، عطار
(متن کامل هر شعر)

=== Tokenization ===
char-level tokenizer:
  vocab = {هر کاراکتر منحصربفرد: idx}
  vocab['<PAD>'] = 0
  max_len = 48

=== DataLoader ===
TensorDataset(inputs, labels)
  inputs: data[:, :-1]
  labels: data[:, 1:]
  batch_size = 8
  shuffle = True

=== Augmentation (اختیاری) ===
- جابجایی تصادفی کلمات
- حذف تصادفی کاراکتر (dropout در سطح token)
```

**تحویلی:** فایل `dataset.py` با توابع `build_vocab()` و `text_to_tensor()`

---

## 🧩 ماژول ۸: Trainer (موتور آموزش)

**بهترین مدل برای اجرا:** DeepSeek یا ChatGPT

```
موتور آموزش با Time-Weight:

=== Hyperparameters ===
- epochs = 20
- learning_rate = 1e-4
- batch_size = 8
- dim = 128
- lambda_decay = 0.1

=== هر Epoch ===
1. time_step = epoch (🟢 هر epoch زمان افزایش می‌یابد)
2. forward: logits = model(inputs, time_step=epoch)
3. loss = CrossEntropy(logits, labels)
4. backward: loss.backward()
5. clip_grad_norm_(1.0)
6. optimizer.step()
7. scheduler.step()

=== جمع‌آوری آمار ===
- loss اسپیرال و استاندارد
- accuracy
- time_weight میانگین
- زمان اجرا

=== Checkpoint ===
هر 5 epoch:
  torch.save(model.state_dict(), f'spiral_epoch_{epoch+1}.pt')
```

**تحویلی:** فایل `trainer.py` با تابع `train_model()`

---

## 🧩 ماژول ۹: Holographic3D (هولوگرافیک ۳بعدی)

**بهترین مدل برای اجرا:** Claude یا Gemini (قوی در vision)

```
ماژول هولوگرافیک ۳بعدی با پوشش نویز:

=== فرمول اصلی (از Hadi Tabatabaie) ===
تصویر ۲بعدی A + تصویر ۲بعدی B
  → بعد سوم = پوشش نویز و سیاهی
  → خروجی: تصویر هولوگرافیک ۳بعدی

=== معماری پیشنهادی ===
HolographicMemory3D:
  memory_grid: nn.Parameter(1, 1, 64, 64, 64)  # ۳بعدی
  projection: Linear(dim → 3)  # خروجی (x, y, z)
  
forward:
  1. coords = tanh(projection(x))  # (batch, 3)
  2. grid = coords.view(batch, 1, 1, 1, 3)
  3. F.grid_sample_3d(memory_grid, grid, mode='bilinear')
  4. noise_mask: نویز و سیاهی رو پوشش بده
  5. خروجی: تصویر هولوگرافیک ۳بعدی

=== کاربرد ===
بعد از آموزش مدل زبانی:
  - مدل می‌تونه از روی متن، تصویر ۳بعدی هولوگرافیک تولید کنه
  - "یک گل در بهار" → تصویر ۳بعدی گل از دو زاویه
  - "شاهنامه فردوسی" → تصویر ۳بعدی رستم
```

**تحویلی:** فایل `holographic_3d.py` با کلاس `Holographic3D`

---

## 🧩 ماژول ۱۰: StandardTransformer (مدل مقایسه)

**بهترین مدل برای اجرا:** هر مدلی (ساده‌ست)

```
مدل استاندارد برای مقایسه با اسپیرال:

=== ساختار ===
- Embedding(vocab_size, dim)
- 4 × TransformerEncoderLayer(dim, 4 heads)
- LayerNorm
- Linear(dim, vocab_size)

=== تفاوت کلیدی با اسپیرال ===
❌ time_step ندارد (حافظه بی‌نهایت)
❌ Time-Weight ندارد (همه چیز هم وزن)
❌ حافظه هولوگرافیک ندارد (KV-cache ساده)
❌ نقاط اسپیرال ندارد (موقعیت‌یابی با sin/cos)

=== کاربرد ===
برای مقایسه در benchmark:
  - loss اسپیرال vs loss استاندارد
  - accuracy اسپیرال vs استاندارد
  - زمان آموزش اسپیرال vs استاندارد
```

**تحویلی:** فایل `standard_model.py` با کلاس `StandardTransformer`

---

## 🗺️ نقشه اتصال ماژول‌ها

```
                         ┌─────────────────┐
                         │   کاربر (متن)    │
                         └────────┬────────┘
                                  │
                         ┌────────▼────────┐
                         │  ماژول ۶        │
                         │  ResponseMode   │
                         │  تشخیص حالت     │
                         └────────┬────────┘
                          جدی/شعر/گفتگو
                                  │
              ┌───────────────────┼───────────────────┐
              │                   │                   │
     ┌────────▼────────┐ ┌───────▼────────┐ ┌────────▼────────┐
     │    ماژول ۴      │ │   ماژول ۱۰     │ │    ماژول ۹     │
     │  SpiralModel    │ │  StandardModel │ │  Holographic3D │
     │  (با زمان)      │ │  (بدون زمان)   │ │  (تصویر ۳بعدی) │
     └────────┬────────┘ └───────┬────────┘ └────────┬────────┘
              │                   │                   │
     ┌────────▼────────┐         │                   │
     │    ماژول ۳      │         │                   │
     │  SpiralLayer    │         │                   │
     └────────┬────────┘         │                   │
              │                   │                   │
     ┌────────┼─────────┐        │                   │
     │        │         │        │                   │
┌────▼───┐ ┌──▼────┐ ┌──▼───┐  │                   │
│ماژول ۱ │ │ماژول ۲│ │ماژول۵│  │                   │
│Spiral  │ │حافظه  │ │Time  │  │                   │
│Point   │ │هولوگر│ │Analyze│ │                   │
└────────┘ └───────┘ └──────┘  │                   │
                                │                   │
                         ┌──────▼───────────────────▼──────┐
                         │         ماژول ۷ و ۸              │
                         │   DataLoader + Trainer           │
                         └─────────────────────────────────┘
```

---

## 📋 نحوه استفاده (چجوری به مدل‌ها بدی)

```
مرحله ۱: ماژول ۱ و ۲ رو بده به DeepSeek
  "این ماژول رو برام implement کن با PyTorch"

مرحله ۲: ماژول ۳ و ۴ رو بده به ChatGPT
  "این لایه و مدل کامل رو با استفاده از ماژول ۱ و ۲ بساز"

مرحله ۳: ماژول ۵ و ۶ رو بده به Claude
  "این تحلیلگر و classifier رو برام بنویس"

مرحله ۴: ماژول ۷ و ۸ رو بده به Gemini
  "این دیتاست و trainer رو implement کن"

مرحله ۵: ماژول ۹ رو بده به هر مدلی که قوی‌تره
  "این هولوگرافیک ۳بعدی رو با فرمول Hadi بساز"

مرحله ۶: همه رو جمع کن در یه پروژه
  هر مدل یه فایل جداگانه تحویل داده
  تو همه رو import می‌کنی توی main.py
```

---

> **🧠🌹🇮🇷 Hadi Tabatabaie (TaHa111) - طراح معماری Spiral-Time-Holographic**  
> شناسه: 0xPersianBrain_SpiralTime_🌹_14040317  
> ایمیل: Hadi.tabatabaei@gmail.com
