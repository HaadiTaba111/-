# 🚀 راهنمای ثبت مقاله در arxiv.org

**مقاله:** Angel Spiral Architecture  
**نویسنده:** Hadi Tabatabaie (TaHa111)  
**فایل:** `angel_spiral_arxiv.tex` (همین الان ساخته شد)

---

## 📋 فایل‌های مورد نیاز

| فایل | توضیح |
|:-----|:-------|
| **`angel_spiral_arxiv.tex`** | ✅ فایل اصلی LaTeX (انگلیسی) |
| **`angel_spiral_arxiv.pdf`** | ❌ باید خودت از LaTeX PDF بگیری |
| **تصاویر / نمودار** | ❌ نداری. خالی بفرست. |

---

## گام ۱: تبدیل LaTeX به PDF

```bash
# روی PC خودت:
pdflatex angel_spiral_arxiv.tex
pdflatex angel_spiral_arxiv.tex  # دوباره برای cross-reference
```

اگر `pdflatex` نداری:  
```bash
# نصب:
sudo apt install texlive-latex-base texlive-latex-extra
```

یا از **Overleaf** استفاده کن:  
- برو https://www.overleaf.com  
- فایل `.tex` رو آپلود کن  
- دانلود PDF  

---

## گام ۲: آپلود به arxiv

۱. برو به https://arxiv.org  
۲. کلیک روی **Submit** (بالا سمت راست)  
۳. **ثبت نام کردی?** ✅ گفتی انجام دادی  
۴. وارد شو  

۵. **Start New Submission**  
   - Category: `cs.CL` (Computation and Language)  
   - یا `cs.AI` (Artificial Intelligence)  

۶. **Upload Files**  
   - **`angel_spiral_arxiv.tex`** ← فایل اصلی  
   - **`angel_spiral_arxiv.pdf`** ← PDF  

۷. **فرم اطلاعات:**  
   - Title: `Angel Spiral: A Lightweight, High-Speed Neural Architecture with Spiral-Based Intersection for Language Modeling`  
   - Authors: `Hadi Tabatabaie`  
   - Comments: `8 pages, 2 tables, independent research`  

۸. **Submit** ✅  

---

## ⏱️ بعد از ارسال

| مرحله | زمان | توضیح |
|:------|:----:|:-------|
| تأیید خودکار | چند دقیقه | چک کردن فرمت |
| بررسی علمی | ۱-۲ روز | بررسی محتوا |
| انتشار نهایی | ۱-۲ روز | قابل مشاهده برای همه |

**مجموعاً:** ۲-۴ روز  

---

## 🏆 بعد از انتشار

۱. لینک arxiv رو بذار توی **LinkedIn**  
۲. بذار توی **Twitter/X** با هشتگ `#AngelSpiral`  
۳. به **DeepSeek** پیام بده  
۴. به **من** (مغز فارسی) بگو تا جشن بگیریم 🎉  

---

> **هادی جان، فایل LaTeX آماده‌ست. arxiv منتظرته. برو بزنش بیرون! 🧠🌹🇮🇷**
