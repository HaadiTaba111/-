# 🧠 Persian Brain - معماری کامل ماژولار

**طراح:** Hadi Tabatabaie (TaHa111)  
**شناسه:** 0xPersianBrain_SpiralTime_🌹_14040317  
**نسخه:** v3.0.0-PRO

---

## 🗺️ نقشه کلی پروژه

```
📁 پروژه (Full Stack Next.js + PostgreSQL)
│
├── 📁 src/lib/                    ← 🧠 مغز (همه منطق اینجاست)
│   ├── poetry-db.ts               ← 📚 بانک اشعار فارسی
│   ├── colloquial-persian.ts      ← 🗣️ موتور محاوره فارسی
│   ├── persian-stories.ts         ← 📖 داستان‌های کهن
│   ├── poetry-generator.ts        ← 🖋️ شاعر ماشین (شعر جدید)
│   ├── reasoning-engine.ts        ← 🧠 استدلال + تشخیص دام
│   ├── unified-brain.ts           ← 🧠 مغز واحد (تزریقی + تقطیری)
│   ├── distilled-brain.ts         ← 🧪 موتور تقطیر با HuggingFace
│   ├── deep-signature.ts          ← 🔐 امضای بین‌نسخه‌ای
│   ├── spiral-time.ts             ← 🌀 پیاده‌سازی اولیه اسپیرال
│   ├── spiral-time-torch.ts       ← 🌀 پیاده‌سازی دقیق از کد تو
│   └── user-profile.ts            ← 👤 پروفایل کاربر (الگوی رفتاری)
│
├── 📁 src/app/                    ← 🌐 صفحات وب
│   ├── /control-panel             ← 🎛️ کنترل پنل (مهم‌ترین صفحه)
│   ├── /companion                 ← 🗣️ همراه هوشمند
│   ├── /brain                     ← 🧠 مغز واحد 
│   ├── /poet                      ← 🖋️ شاعر ماشین
│   ├── /distill                   ← 🧪 تقطیر
│   └── /auto-learn                ← 🤖 یادگیری خودکار
│
├── 📄 spiral-real-train.py        ← 🐍 آموزش واقعی GPU (فایل اصلی تو)
├── 📄 train-both-models.py        ← 🐍 آموزش همزمان دو مدل
├── 📄 spiral-time-v2-fixed.py     ← 🐍 نسخه v2 (رفع باگ)
├── 📄 spiral-time-v3-optimized.py ← 🐍 نسخه v3 (بهینه)
├── 📄 spiral-optimizer.py         ← 🐍 آنالایزر و benchmark
├── 📄 README-HADI.md              ← 📖 راهنما
└── 📄 PERSIAN_BRAIN_LICENSE.md    ← 📜 ثبت مالکیت
```

---

## 🧩 ماژول‌های اصلی (توضیح هر کدام)

### ۱. 🌀 `SpiralPoint` - هسته معماری اسپیرال
```
ورودی: x (تنسور ورودی), depth (عمق چرخش)
   │
   ├── ۱. معادله: a·sin(b·x + c) + d  ← ۴ پارامتر قابل یادگیری
   │
   ├── ۲. Gating Decay: 
   │     importance = (1-gate) × imp + gate × new_info
   │     gate = sigmoid(gate_net(x))  ← یاد می‌گیره کی فراموش کنه
   │
   ├── ۳. چرخش عمق‌محور:
   │     θ = depth × 0.5
   │     rotated = equation_out × (cos(θ) + sin(θ))
   │
   └── ۴. اعمال اهمیت:
         output = rotated × importance
```

### ۲. 💾 `HolographicMemory` - حافظه هولوگرافیک
```
ورودی: x (تنسور ورودی)
   │
   ├── projection: Linear(x) → (x, y) مختصات روی grid
   │
   ├── grid_sample: memory_grid[x, y]  ← ✅ با گرادیان
   │     (bilinear interpolation = differentiable)
   │
   └── خروجی: اسکالر (مقدار بازیابی شده از حافظه)
```

### ۳. 🔄 `SpiralTimeLayer` - لایه کامل
```
ورودی: x (batch, dim), time_step
   │
   برای depth در ۰ تا ۵:
   │   ├── points: ۸ تا SpiralPoint → ۸ تا اسکالر (batch,)
   │   ├── memory: HolographicMemory → ۱ اسکالر (batch,)
   │   ├── stack: (batch, 9) ← همه همشکل
   │   ├── combiner: Linear(9, dim)
   │   └── residual: x = x + new_x
   │
   └── خروجی: x (batch, dim)
```

### ۴. 🏗️ `SpiralTimeModel` - مدل کامل
```
Embedding(vocab → dim)
   → ۴× SpiralTimeLayer (هر لایه ۸ نقطه + حافظه)
   → LayerNorm
   → Linear(dim → vocab)
```

### ۵. 🗣️ `ColloquialEngine` - محاوره فارسی
```
ورودی متن محاوره‌ای
   → ۱۰۰+ الگوی محاوره (داداش، چطوری، دلم گرفته...)
   → تبدیل به فارسی رسمی
   → تحلیل منظور (جدی / شعری / گفتگو)
   → پاسخ متناسب با حالت
```

### ۶. 🖋️ `PoetryGenerator` - شاعر ماشین
```
ورودی: موضوع (مثلاً "گل")
   → گسترش معنایی (گل → گلزار، بنفشه، نرگس...)
   → انتخاب قافیه از دیکشنری
   → ترکیب با ۳۱ فعل + ۱۸ صفت + ۱۴ قید
   → خروجی: بیت جدید (قبلاً وجود نداشته!)
```

---

## 🎯 **نکته کلیدی: زمان به عنوان وزن (Time as Weight)**

این超大 معماری توئه که باید درست پیاده بشه. مفهومش اینه:

### فرمول درست Time-Weight:

```
time_weight(t) = exp(-λ × (current_time - t))
```

که:
- `t` = زمان ثبت داده
- `current_time` = الان
- `λ` = نرخ decay

### در معماری اسپیرال:

```python
# هر نقطه اسپیرال یه birth_time داره
point.birth_time = t  # کی این نقطه متولد شده

# اهمیت (وزن) بر اساس زمان:
point.importance = exp(-λ × (now - point.birth_time))

# خروجی نهایی:
output = equation(x) × importance  # زمان مستقیماً وزن میشه
```

### یعنی:
- **داده‌های جدید:** importance ≈ 1.0 (وزن کامل)
- **داده‌های قدیمی:** importance → 0 (محو شدن)

این دقیقاً همون چیزیه که توی `TimeAwareSpiralPoint` اولیه‌ات نوشته بودی ولی من درست پیاده‌اش نکرده بودم. الان درستش می‌کنم.

---

## 📊 ویژگی‌ها: بردار کنار مدل یا داخل مدل؟

سوال تو: *"شعر، ضرب‌المثل و ... بردار کنار مدل میشن؟"*

**جواب: دو جا ذخیره می‌شن:**

| روش | مکان | کاربرد | 
|:----|:-----|:-------|
| 📚 **RAG (تزریقی)** | بانک JSON | جستجوی سریع، شعر گفتن، پاسخ فوری |
| 🧠 **در معماری اسپیرال** | HolographicMemory | یادگیری الگوها، decay زمانی، حافظه بلندمدت |

**ترکیب هر دو = بهترین نتیجه:**
```
سوال کاربر
   → ۱. RAG: شعر مرتبط رو پیدا کن (سریع)
   → ۲. اسپیرال: با حافظه هولوگرافیک پردازش کن (عمیق)
   → ۳. ترکیب: خروجی نهایی
```

---

## 🐍 فایل‌های ویژه PC تو

| فایل | اجرا | زمان | خروجی |
|:-----|:-----|:----|:------|
| `python3 spiral-real-train.py --mode benchmark` | 🚀 ۱ دقیقه | 📊 گزارش عملکرد | `benchmark-real-results.json` |
| `python3 train-both-models.py --epochs 20 --device cuda` | 🎯 ۳۰ دقیقه | 🏆 مدل آموزش دیده | `spiral-final-model.pt` |
| `python3 spiral-optimizer.py` | 📊 ۲ دقیقه | 📈 آنالیز کامل | `benchmark-results.json` |
