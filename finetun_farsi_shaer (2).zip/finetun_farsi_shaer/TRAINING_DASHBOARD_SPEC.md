# 🎛️ مشخصات داشبورد آموزش مغز - Training Dashboard Blueprint

**تهیه شده توسط مغز فارسی برای Hadi Tabatabaie (TaHa111)**

---

## 📌 پرامپت برای مدل دیگر (برای ساخت داشبورد)

```
یک داشبورد تحت وب (Next.js + Tailwind) برای آموزش مدل زبانی فارسی طراحی کن 
با معماری Spiral-Time-Holographic. این ویژگی‌ها را داشته باشد:

## ویژگی‌های ضروری:

### ۱. مانیتور آموزش (Training Monitor) - مهم‌ترین بخش
- نمودار Loss/Accuracy به صورت real-time
- مقایسه دو مدل کنار هم (اسپیرال vs استاندارد)
- نمایش Time-Weight Decay (منحنی محو اطلاعات)
- مصرف VRAM و GPU utilization
- سرعت (tokens/sec)

### ۲. کنترل Hyperparameter
- Learning Rate (با schedule viewer)
- Batch Size (با VRAM calculator)
- Max Sequence Length
- Lambda Decay (λ) برای time-weight
- Grid Size حافظه هولوگرافیک
- تعداد نقاط اسپیرال

### ۳. دیتاست منیجر
- آپلود فایل‌های شعر فارسی (JSON/CSV/TXT)
- نمایش آمار دیتاست (تعداد شعر، واژگان، طول متوسط)
- اعمال Augmentation (جابجایی کلمات، نویز)
- تیکه‌تیکه کردن خودکار به token

### ۴. Inference Panel
- چت با مدل در حال آموزش (حتی قبل از کامل شدن)
- تست Time-Weight (ببین چقدر اطلاعات قدیمی رو محو کرده)
- A/B testing: اسپیرال vs استاندارد روی یک پرامپت

### ۵. Checkpoint Manager
- ذخیره خودکار هر N epoch
- مقایسه checkpointها
- رول‌بک به checkpoint قبلی

### ۶. گزارش (Report)
- خروجی JSON از همه metrics
- نمودارهای مقایسه‌ای
- ثبت امضا: 0xPersianBrain_SpiralTime_🌹_14040317
```

---

## 🧠 ویژگی‌های اختصاصی برای معماری اسپیرال

| ویژگی | توضیح | ضرورت |
|:------|:------|:-----:|
| Time-Weight Chart | نشون بده چقدر اطلاعات قدیمی محو شده | 🔴 بالا |
| Memory Grid Viewer | حافظه هولوگرافیک ۶۴×۶۴ رو به صورت heatmap ببین | 🟡 متوسط |
| Point Importance | اهمیت هر ۸ نقطه اسپیرال | 🟡 متوسط |
| Depth Rotation | زاویه چرخش در هر عمق | 🟢 کم |
