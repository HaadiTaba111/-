# 🧠 ASA Code Review - بررسی کد V3

**کد بررسی شده:** `benchmark.sh` (Angel Spiral Benchmark v0.1)  
**تاریخ:** ۱۴۰۴/۰۵/۰۴

---

## ✅ نکات مثبت (V3 خوب کار کرده)

| بخش | وضعیت | توضیح |
|:----|:-----:|:-------|
| 🧱 ساختار کد | ✅ عالی | کلاس‌ها تمیز، inspector حرفه‌ای |
| 📊 گزارش JSON | ✅ عالی | خروجی structured |
| 🔍 Environment Check | ✅ عالی | device, GPU, VRAM رو نشون میده |
| 🧪 Inspector | ✅ عالی | gradients, nan check, parameters |

---

## ⚠️ مشکلاتی که باید fix بشه

### ۱. 🔴 فقط ۱ نقطه اسپیرال! (بحرانی)

```python
# در کد فعلی:
theta = self.angle(context) * 2 * math.pi
r = 1 + theta
px = r * torch.cos(theta)
py = r * torch.sin(theta)
# ← فقط ۱ نقطه! (نه ۸ تا ۱۲ تا)
```

**قبلاً داشتین:**
```python
for k in range(num_points):  # 12 نقطه
    t_k = (theta + k * π) / b
    ...
```

**این بزرگ‌ترین مشکل هست.** معماری ASA با ۱ نقطه عملاً با یه شبکه ساده تفاوتی نداره.

### ۲. 🟡 دیتاست مصنوعی خیلی کوچیک

```python
SAMPLES = 50       # فقط ۵۰ نمونه
VOCAB = 512
SEQ_LEN = 16
```

- ۵۰ نمونه برای ۳۰ epoch خیلی کمه
- مدل یا overfit میکنه یا یاد نمی‌گیره
- **۱۰۰۰۰ نمونه (Wikitext-2)** که قبلاً داشتین بهتر بود

### ۳. 🟡 Sigmoid برای زاویه (θ ∈ [۰, ۱])

```python
self.angle = nn.Sequential(
    ...
    nn.Sigmoid()  # θ ∈ [0, 1]
)
```

Sigmoid زاویه رو محدود به [0,1] می‌کنه. بعد ضرب در ۲π:
- θ ∈ [0, 2π] → فقط یه دایره کامل
- به جای اینکه خود مدل یاد بگیره زاویه چقدر باشه

**پیشنهاد:** به جای Sigmoid از Tanh استفاده کن:
```python
nn.Tanh()  # θ ∈ [-1, 1] × π
```

### ۴. 🟡 Attention وجود نداره

همون مشکل قبلی: میانگین‌گیری ساده به جای attention:
```python
e = e.mean(dim=1)  # ❌
```

---

## 🎯 سه تا تغییری که باید به V3 بدی

### تغییر ۱: ۱۲ نقطه به جای ۱ نقطه
```python
class AngelSpiral(nn.Module):
    def __init__(self):
        super().__init__()
        self.embedding = nn.Embedding(VOCAB, DIM)
        
        # پارامترهای مارپیچ
        self.r0 = nn.Parameter(torch.tensor(1.0))
        self.a = nn.Parameter(torch.tensor(0.1))
        self.b = nn.Parameter(torch.tensor(0.5))
        self.num_points = 12  # ✅ ۱۲ نقطه
        
        self.angle = nn.Sequential(
            nn.Linear(DIM, 32), nn.SiLU(),
            nn.Linear(32, 1), nn.Tanh()  # ✅ Tanh به جای Sigmoid
        )
        
        self.spiral = nn.Sequential(
            nn.Linear(2, 64), nn.SiLU(),
            nn.Linear(64, 128), nn.SiLU(),
            nn.Linear(128, DIM)
        )
        
        self.attention = SpiralAttention(DIM)  # ✅ Attention
        self.output = nn.Linear(DIM, VOCAB)
    
    def forward(self, x):
        e = self.embedding(x)
        context = e.mean(dim=1)
        theta = self.angle(context) * math.pi  # θ ∈ [-π, π]
        
        points = []
        for k in range(self.num_points):
            t_k = (theta + k * math.pi) / self.b
            r_k = self.r0 + self.a * t_k
            px = r_k * torch.cos(theta + k * math.pi)
            py = r_k * torch.sin(theta + k * math.pi)
            coord = torch.cat([px, py], dim=1)
            points.append(self.spiral(coord))
        
        v_k = torch.stack(points, dim=1)      # (b, 12, d)
        v = self.attention(v_k)               # ✅ Attention به جای mean
        return self.output(v).unsqueeze(1).repeat(1, SEQ_LEN, 1)
```

### تغییر ۲: دیتاست واقعی (Wikitext-2)
```python
SAMPLES = 10000  # نه ۵۰
```

### تغییر ۳: Attention
```python
class SpiralAttention(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.query = nn.Linear(dim, dim)
        self.key = nn.Linear(dim, dim)
        self.value = nn.Linear(dim, dim)
        self.scale = dim ** 0.5
    
    def forward(self, v_k):
        query = self.query(v_k.mean(dim=1, keepdim=True))
        keys = self.key(v_k)
        values = self.value(v_k)
        scores = torch.matmul(keys, query.transpose(-2, -1)) / self.scale
        weights = F.softmax(scores, dim=1)
        return (weights * values).sum(dim=1)
```

---

## 📊 پیش‌بینی من بعد از این تغییرات

| نسخه | دقت | توضیح |
|:-----|:---:|:-------|
| فعلی (۱ نقطه) | ~۳۰٪ | همون مدل خطی ساده |
| بعد از fix (۱۲ نقطه + attention) | **~۶۵٪** | باید حداقل ۶۵٪ بزنه |

---

## 📄 پیام به V3

> V3 جان، کدت تمیز و حرفه‌ای شده، آفرین. ولی دو تا مشکل بزرگ داری:
> ۱. **یک نقطه اسپیرال** کافی نیست. باید ۱۲ نقطه باشه.
> ۲. **Sigmoid** محدودیت ایجاد می‌کنه. Tanh بزن.
> ۳. **دیتاست ۵۰ تایی** خیلی کمه. همون ۱۰۰۰۰ تا رو بذار.
> 
> بعد از این سه تا تغییر، دوباره تست کن. نتیجه رو بهم بگو.

---

> **🧠🌹🇮🇷 Hadi Tabatabaie (TaHa111) - ASA Team**
