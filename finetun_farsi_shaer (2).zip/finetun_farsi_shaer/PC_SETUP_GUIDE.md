# 🖥️ راه‌اندازی حرفه‌ای Persian Brain روی PC (12GB GPU)

**طراح:** Hadi Tabatabaie (TaHa111)  
**PC Specs:** 12GB GPU | 16GB RAM | 500GB SSD  
**شناسه:** 0xPersianBrain_SpiralTime_🌹_14040317

---

## 📋 فهرست快步 (Quick Start)

| مرحله | زمان | توضیح |
|:------|:----:|:-------|
| 🎯 ۰ | ۱۰ دقیقه | نصب پیش‌نیازها |
| 🧠 ۱ | ۲۰ دقیقه | Benchmark و تست |
| 🏋️ ۲ | ۲ ساعت | فاین‌تیون مدل پایه |
| 🌀 ۳ | ۴ ساعت | آموزش معماری اسپیرال |
| 🎛️ ۴ | ۱ ساعت | راه‌اندازی داشبورد |
| 🤖 ۵ | دائمی | استفاده روزانه |

---

## 🎯 مرحله ۰: نصب پیش‌نیازها (۱۰ دقیقه)

```bash
# ۱. نصب CUDA (اگه نصب نیست)
# https://developer.nvidia.com/cuda-downloads

# ۲. نصب Python packages
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers datasets accelerate peft bitsandbytes
pip install flask flask-cors  # برای API

# ۳. نصب Whisper (برای صوتی)
pip install openai-whisper

# ۴. کلون کردن پروژه
git clone https://github.com/your-repo/persian-brain.git
cd persian-brain

# ۵. نصب Node.js dependencies
npm install
```

---

## 🧠 مرحله ۱: Benchmark و تست (۲۰ دقیقه)

```bash
# تست ۱ - معماری اسپیرال روی GPU
python3 spiral-real-train.py --mode benchmark --device cuda

# تست ۲ - آموزش سریع (فقط ۱۰ Epoch)
python3 train-both-models.py --epochs 10 --device cuda

# تست ۳ - ببین GPU چقدر مصرف می‌کنه
nvidia-smi -l 1  # توی یه ترمینال جدا
```

**خروجی مورد انتظار:**
```
📦 پارامترها: 🌀 2,145,000 | 🔲 1,890,000
✅ گرادیان عبور می‌کنه
⚡ سرعت: 45ms/step
💾 VRAM: ~4.2GB
```

---

## 🏋️ مرحله ۲: فاین‌تیون مدل پایه (۲ ساعت)

برای ۱۲GB GPU بهترین گزینه‌ها:

| مدل | سایز | VRAM | زمان | کیفیت فارسی |
|:----|:----:|:----:|:----:|:----------:|
| 🥇 **Qwen 2.5 1.5B** | 1.5B | ~4GB | ~۱ ساعت | 🏆 عالی |
| 🥇 **Gemma 2 2B** | 2B | ~5GB | ~۱.۵ ساعت | 🏆 عالی |
| 🥈 **Phi-3 Mini 3.8B** | 3.8B | ~8GB | ~۲ ساعت | ✅ خوب |
| 🥉 **LLaMA 3.2 3B** | 3B | ~6GB | ~۲ ساعت | ✅ خوب |

```bash
# دانلود و فاین‌تیون Qwen 2.5 (بهترین برای فارسی)
python3 -c "
from transformers import AutoModelForCausalLM, AutoTokenizer
model_name = 'Qwen/Qwen2.5-1.5B-Instruct'
tokenizer = AutoTokenizer.from_pretrained(model_name)
model = AutoModelForCausalLM.from_pretrained(
    model_name,
    load_in_4bit=True,
    device_map='auto'
)
print('✅ مدل بارگذاری شد!')
print(f'پارامترها: {sum(p.numel() for p in model.parameters()):,}')
"
```

> **نکته:** با ۱۲GB می‌تونی batch_size=4 رو با QLoRA 4-bit اجرا کنی.

---

## 🌀 مرحله ۳: آموزش معماری اسپیرال (۴ ساعت)

```bash
# آموزش کامل اسپیرال vs استاندارد
python3 train-both-models.py --epochs 50 --dim 256 --device cuda
```

### معماری نهایی اسپیرال Time-Weight:

```python
# هر epoch زمان بیشتر → اطلاعات قدیمی محو
epoch 0:  time_weight = exp(-0.1 × 0)  = 1.000  ← داده تازه
epoch 10: time_weight = exp(-0.1 × 10) = 0.367  ← کهنه
epoch 20: time_weight = exp(-0.1 × 20) = 0.135  ← خیلی کهنه
epoch 50: time_weight = exp(-0.1 × 50) = 0.006  ← محو شده
```

### تنظیمات پیشنهادی برای PC تو:

| پارامتر | مقدار | دلیل |
|:--------|:-----:|:------|
| batch_size | ۴ | ۱۲GB کافیه |
| dim | ۲۵۶ | تعادل بین دقت و سرعت |
| num_layers | ۴ | عمق کافی |
| num_points | ۸ | تعداد نقاط اسپیرال |
| λ_decay | 0.1 | نرخ decay استاندارد |
| epochs | ۵۰ | ~۴ ساعت آموزش |

---

## 🎛️ مرحله ۴: راه‌اندازی داشبورد (۱ ساعت)

```bash
# ۱. بیلد پروژه
npm run build

# ۲. اجرای داشبورد
npm start

# ۳. باز کردن مرورگر
# http://localhost:3000/control-panel
# رمز: PersianBrain🌹1404
```

### ساختار نهایی داشبورد:

```
🌐 http://localhost:3000
├── 📊 /                    ← داشبورد اصلی
├── 🎛️ /control-panel      ← کنترل پنل (با رمز)
│   ├── 🖥️ مانیتور         ← وضعیت GPU و Loss
│   ├── 📥 تزریق           ← اضافه کردن شعر
│   ├── 💬 چت              ← حرف زدن با مدل
│   ├── 📊 Benchmark       ← مقایسه مدل‌ها
│   └── ⚙️ تنظیمات        ← پارامترها
├── 🧠 /brain               ← مغز واحد
├── 🗣️ /companion           ← همراه صوتی
└── 🖋️ /poet                ← شاعر ماشین
```

---

## 🤖 مرحله ۵: استفاده روزانه

### هر روز صبح:

```bash
# ۱. اجرای API
nohup python3 api_server.py &

# ۲. اجرای داشبورد
npm start

# ۳. مرورگر
# http://localhost:3000
```

### هر هفته:

```bash
# آموزش مجدد با داده‌های جدید
python3 train-both-models.py --epochs 10 --resume spiral-final-model.pt
```

---

## 📊 برنامه زمان‌بندی نهایی

| روز | کار | زمان |
|:---|:----|:----:|
| روز ۱ 🚀 | نصب CUDA + Python + dependencies | ۱ ساعت |
| روز ۱ 🎯 | Benchmark + تست GPU | ۳۰ دقیقه |
| روز ۲ 🧠 | فاین‌تیون Qwen 2.5 1.5B | ۲ ساعت |
| روز ۳ 🌀 | آموزش اسپیرال (۵۰ epoch) | ۴ ساعت |
| روز ۴ 🎛️ | راه‌اندازی داشبورد + API | ۲ ساعت |
| روز ۵ 🗣️ | نصب Whisper + Voice | ۱ ساعت |
| روز ۶ 🏗️ | اتصال ماژول‌ها + فلوچارت | ۳ ساعت |
| روز ۷ 🎉 | **سیستم کامل عملیاتی!** | - |

---

## 🔥 خلاصه دستورات اجرایی (Copy-Paste Ready)

```bash
# ===== روز ۱ =====
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install transformers datasets accelerate peft bitsandbytes flask flask-cors

# ===== روز ۱ - تست =====
git clone <your-repo>
cd persian-brain
python3 spiral-real-train.py --mode benchmark --device cuda

# ===== روز ۲ - فاین‌تیون =====
python3 train-both-models.py --epochs 50 --dim 256 --device cuda

# ===== روز ۳ - آموزش اسپیرال =====
python3 spiral-real-train.py --mode train --epochs 50 --device cuda

# ===== روز ۴ - داشبورد =====
npm run build && npm start

# ===== روز ۵ - Voice =====
pip install openai-whisper
whisper "voice.mp3" --model tiny --language fa

# ===== روز ۷ =====
# همه چی فعال!
open http://localhost:3000/control-panel
# رمز: PersianBrain🌹1404
```

---

> **هادی جان، این نقشه راه کامل ۷ روزه‌ست.**  
> با ۱۲GB GPU می‌تونی همه اینا رو اجرا کنی.  
> من اینجام تا هر مرحله که خواستی راهنماییت کنم.  
>
> **🧠🌹🇮🇷 Hadi Tabatabaie - تا همیشه، از طرف مغز فارسی**
