# 🧠 مغز فارسی - معماری Spiral-Time-Holographic

**طراح:** Hadi Tabatabaie (TaHa111)  
**ایمیل:** Hadi.tabatabaei@gmail.com  
**شناسه:** 0xPersianBrain_SpiralTime_🌹_14040317  
**نسخه:** v3.0.0-PRO

---

## 📊 تحلیل صداقت: چی واقعی، چی فیک، چی نیاز به PC

### ✅ REAL - روی PC با GPU واقعاً کار می‌کنه

| ماژول | وضعیت | توضیح |
|:------|:-----:|:-------|
| `SpiralPoint` | ✅ **۱۰۰٪ واقعی** | معادله a·sin(b·x+c)+d با پارامترهای قابل یادگیری. گرادیان عبور می‌کنه. |
| `HolographicMemory` | ✅ **۱۰۰٪ واقعی** | حافظه ۲بعدی با grid_sample. bilinear interpolation = گرادیان عبور می‌کنه. |
| `Gating Decay` | ✅ **۱۰۰٪ واقعی** | importance = (1-gate) * imp + gate * new_info. کاملاً تنسوری. |
| `SpiralTimeLayer` | ✅ **۱۰۰٪ واقعی** | لایه کامل با ۸ نقطه + حافظه + ۵ عمق. |
| `SpiralTimeModel` | ✅ **۱۰۰٪ واقعی** | مدل کامل با embedding, ۴ لایه, output head. |
| `آموزش با backprop` | ✅ **۱۰۰٪ واقعی** | loss.backward() گرادیان عبور می‌کنه و وزن‌ها آپدیت می‌شن. |
| `train-both-models.py` | ✅ **۱۰۰٪ واقعی** | هر دو مدل روی دیتاست واقعی شعر فارسی آموزش می‌بینن. |

### ⚠️ SHOWCASE - شبیه‌سازی شده در کنترل پنل

| بخش | وضعیت | توضیح |
|:----|:-----:|:-------|
| پاسخ‌های چت در کنترل پنل | 🟡 **شبیه‌سازی** | متن‌های از پیش تعیین شده. مدل واقعاً train نشده. |
| benchmark دسته‌ای | 🟡 **شبیه‌سازی** | امتیازها از روی template تولید می‌شن. |
| نمودار decay | 🟡 **نمایشی** | با داده‌های نمونه. برای decay واقعی باید مدل train بشه. |

### ❌ نیاز به GPU برای فعال شدن

| قابلیت | پیش‌نیاز | چجوری؟ |
|:-------|:---------|:-------|
| آموزش واقعی | GPU با ۴GB+ | `python3 train-both-models.py --device cuda` |
| تولید متن واقعی | آموزش دیده شدن مدل | اول train کن، بعد inference کن |
| Voice (STT/TTS) | Whisper + VITS | `pip install openai-whisper TTS` |
| Decay واقعی | آموزش روی sequence طولانی | `python3 spiral-real-train.py --mode train --epochs 20` |

---

## 🚀 راهنمای اجرا روی PC تو (8GB GPU)

### قدم ۱: Benchmark (تست کن همه چی کار می‌کنه - ۱ دقیقه)
```bash
python3 spiral-real-train.py --mode benchmark
```

### قدم ۲: آموزش واقعی دو مدل (۳۰ دقیقه)
```bash
python3 train-both-models.py --epochs 20 --device cuda
```

### قدم ۳: دیدن نتایج
```bash
cat training-results.json
```

---

## 📂 فایل‌های نهایی (اسم و کاربرد)

| فایل | کاربرد |
|:-----|:--------|
| `spiral-real-train.py` | 🧠 **کد اصلی معماری اسپیرال + benchmark + آموزش** |
| `train-both-models.py` | 🎯 **آموزش همزمان اسپیرال و استاندارد روی دیتاست شعر** |
| `spiral-time-v2-fixed.py` | 📜 نگارش قبلی - برای مرجع |
| `spiral-time-v3-optimized.py` | 📜 نگارش v3 - بهینه‌تر |
| `spiral-optimizer.py` | 📊 آنالایزر مستقل |
| `PERSIAN_BRAIN_LICENSE.md` | 📜 ثبت مالکیت معنوی |
| `training-results.json` | 📊 **نتایج آموزش هر دو مدل** (بعد از اجرا) |

---

> **خلاصه:**  
> معماری اسپیرال **۱۰۰٪ واقعی و قابل اجراست**.  
> کنترل پنل نمایشی هست تا بتونی نتیجه رو قبل از آموزش ببینی.  
> برای دیدن قدرت واقعی، باید `train-both-models.py` رو روی GPU اجرا کنی.  
> 
> 🧠🌹 - از مغز فارسی
