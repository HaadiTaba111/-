import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, normalize, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = normalize(fileURLToPath(new URL('.', import.meta.url))).replace(new RegExp(`${sep}$`), '');
const PORT = Number(process.env.PORT || 8787);
const BYBIT_BASE_URL = process.env.BYBIT_API_URL || process.env.BYBIT_BASE_URL || 'https://api.bybit.com';
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon'
};

function headers(extra = {}) {
  return {
    'access-control-allow-origin': '*',
    'access-control-allow-methods': 'GET,POST,OPTIONS',
    'access-control-allow-headers': 'Content-Type, X-Webhook-Token',
    ...extra
  };
}

function json(res, status, body, extra = {}) {
  res.writeHead(status, headers({
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    ...extra
  }));
  res.end(JSON.stringify(body));
}

function mockCandles(symbol, interval = '1', limit = 90) {
  // Deliberately isolated under /api/mock/bybit. It is never used by the LIVE path.
  const bases = { BTCUSDT: 65000, ETHUSDT: 3400, SOLUSDT: 145, XRPUSDT: 0.52, BNBUSDT: 585, DOGEUSDT: 0.12, ADAUSDT: 0.41, AVAXUSDT: 28, LINKUSDT: 14, TONUSDT: 7 };
  const base = bases[symbol] || 100;
  const seed = [...symbol].reduce((sum, char) => sum + char.charCodeAt(0), 0);
  let price = base * (1 + Math.sin(Date.now() / 160000 + seed) / 80);
  const out = [];
  const minutes = Number(interval) || 1;
  const safeLimit = Math.max(30, Math.min(200, Number(limit) || 90));

  for (let index = 0; index < safeLimit; index += 1) {
    const hot = index > safeLimit - 6;
    const open = price;
    price = Math.max(0.0001, price * (
      1 + Math.sin((Date.now() / 60000 + index + seed) / 9) * 0.001
      + (hot ? (Math.random() - 0.38) * 0.012 : (Math.random() - 0.5) * 0.004)
    ));
    const high = Math.max(open, price) * (1 + Math.random() * 0.0025);
    const low = Math.min(open, price) * (1 - Math.random() * 0.0025);
    const volume = (900 + Math.random() * 900) * (hot ? 1.7 + Math.random() * 2.5 : 1);
    const timestamp = Date.now() - (safeLimit - index) * minutes * 60_000;
    out.push([String(timestamp), String(open), String(high), String(low), String(price), String(volume), String(volume * price)]);
  }
  return out;
}

async function proxyBybit(req, res, url) {
  if (req.method !== 'GET') return json(res, 405, { retCode: -1, retMsg: 'GET only' });
  const suffix = url.pathname.replace(/^\/api\/bybit/, '') || '/';
  const target = new URL(suffix, `${BYBIT_BASE_URL.replace(/\/$/, '')}/`);
  url.searchParams.forEach((value, key) => target.searchParams.set(key, value));

  try {
    const upstream = await fetch(target, {
      headers: {
        Accept: 'application/json',
        'User-Agent': 'futures-scalp-lab/2.0'
      },
      signal: AbortSignal.timeout(9000)
    });
    const body = Buffer.from(await upstream.arrayBuffer());
    res.writeHead(upstream.status, headers({
      'content-type': upstream.headers.get('content-type') || 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-data-source': 'BYBIT LIVE PROXY'
    }));
    res.end(body);
  } catch (error) {
    json(res, 502, {
      retCode: -1,
      retMsg: 'BYBIT_UPSTREAM_UNAVAILABLE',
      error: (error && error.message) || 'upstream fetch failed',
      baseUrl: BYBIT_BASE_URL
    });
  }
  return true;
}

function mockBybit(url, res) {
  if (url.pathname.endsWith('/v5/market/tickers')) {
    const symbol = (url.searchParams.get('symbol') || 'BTCUSDT').toUpperCase();
    const last = Number(mockCandles(symbol, '1', 2).at(-1)[4]);
    return json(res, 200, {
      retCode: 0,
      retMsg: 'OK (EXPLICIT MOCK)',
      result: {
        category: 'linear',
        list: [{
          symbol,
          lastPrice: String(last),
          markPrice: String(last),
          indexPrice: String(last),
          volume24h: String(1_000_000 + Math.random() * 5_000_000),
          turnover24h: String(last * 1_000_000)
        }]
      }
    }, { 'x-data-source': 'MOCK SERVER EXPLICIT' });
  }
  if (url.pathname.endsWith('/v5/market/kline')) {
    const symbol = (url.searchParams.get('symbol') || 'BTCUSDT').toUpperCase();
    const interval = url.searchParams.get('interval') || '1';
    const limit = url.searchParams.get('limit') || '90';
    return json(res, 200, {
      retCode: 0,
      retMsg: 'OK (EXPLICIT MOCK)',
      result: {
        symbol,
        category: 'linear',
        list: mockCandles(symbol, interval, limit).reverse()
      }
    }, { 'x-data-source': 'MOCK SERVER EXPLICIT' });
  }
  return json(res, 404, { retCode: -1, retMsg: 'Unknown mock market route' });
}

function readBody(req, maxBytes = 64 * 1024) {
  return new Promise((resolve, reject) => {
    let raw = '';
    let size = 0;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > maxBytes) {
        reject(new Error('request body too large'));
        req.destroy();
        return;
      }
      raw += chunk;
    });
    req.on('end', () => resolve(raw));
    req.on('error', reject);
  });
}

async function routeApi(req, res, url) {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, headers());
    res.end();
    return true;
  }
  if (url.pathname === '/api/health' && req.method === 'GET') {
    return json(res, 200, { ok: true, bybitBaseUrl: BYBIT_BASE_URL, mode: 'live-proxy-no-fallback' });
  }
  if (url.pathname.startsWith('/api/bybit/v5/market/')) {
    return proxyBybit(req, res, url);
  }
  if (url.pathname.startsWith('/api/mock/bybit/v5/market/')) {
    return mockBybit(url, res);
  }
  if (url.pathname === '/api/lbank/order' && req.method === 'POST') {
    try {
      const raw = await readBody(req);
      const body = raw ? JSON.parse(raw) : {};
      return json(res, 200, {
        ok: true,
        mode: 'DRY_RUN_ONLY',
        exchange: 'lbank-futures',
        acceptedAt: new Date().toISOString(),
        orderId: `dry_${Math.random().toString(36).slice(2)}`,
        received: body
      });
    } catch (error) {
      return json(res, 400, { ok: false, mode: 'DRY_RUN_ONLY', error: error.message });
    }
  }
  return json(res, 404, { ok: false, error: 'API route not found' });
}

async function serveStatic(req, res, url) {
  let pathname;
  try {
    pathname = decodeURIComponent(url.pathname);
  } catch {
    res.writeHead(400, headers({ 'content-type': 'text/plain; charset=utf-8' }));
    res.end('Bad URL');
    return;
  }
  const relative = (pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, ''));
  const file = normalize(join(ROOT, relative));
  if (file !== ROOT && !file.startsWith(`${ROOT}${sep}`)) {
    res.writeHead(403, headers({ 'content-type': 'text/plain; charset=utf-8' }));
    res.end('Forbidden');
    return;
  }

  try {
    const fileStat = await stat(file);
    if (!fileStat.isFile()) throw new Error('not a file');
    const data = await readFile(file);
    res.writeHead(200, headers({
      'content-type': MIME[extname(file)] || 'application/octet-stream',
      'cache-control': 'no-cache'
    }));
    res.end(data);
  } catch {
    res.writeHead(404, headers({ 'content-type': 'text/plain; charset=utf-8' }));
    res.end('404 Not Found');
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) {
      await routeApi(req, res, url);
      return;
    }
    await serveStatic(req, res, url);
  } catch (error) {
    if (!res.headersSent) json(res, 500, { ok: false, error: error.message });
    else res.destroy();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🚀 Futures Scalp Lab: http://localhost:${PORT}`);
  console.log(`📡 Bybit LIVE proxy: ${BYBIT_BASE_URL}`);
  console.log('🧪 Synthetic data is isolated at /api/mock/bybit and is never a LIVE fallback.');
  console.log('🛡️  Built-in LBank endpoint is DRY_RUN_ONLY; configure a secure backend for real orders.\n');
});
