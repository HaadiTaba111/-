# 🤖 Agent Factory - کارخانه ساخت Agent هوشمند

یک سیستم کامل برای ساخت Agent‌های هوشمند با قابلیت یادگیری، ابزارهای متنوع، و سیستم اینتررپت.

## ✨ ویژگی‌ها

- 🧠 **مغز آفلاین** - با Qwen2.5 و Ollama
- 🔧 **ابزارهای متنوع** - فایل، شبکه، محاسبات
- ⚡ **سیستم اینتررپت** - مانند DOS
- 🗄️ **حافظه برداری** - ذخیره و جستجوی تجربیات
- 🌐 **دوزبانه** - فارسی و انگلیسی
- 📦 **کارخانه Agent** - ساخت Agent‌های سفارشی

## 📁 ساختار پروژه

```
agent_factory/
├── core/
│   ├── agent.py         # هسته اصلی Agent
│   ├── llm_client.py    # اتصال به Ollama
│   ├── tool_registry.py # ثبت ابزارها
│   ├── vector_memory.py # حافظه برداری
│   └── interrupts.py    # سیستم اینتررپت
├── factory.py           # کارخانه ساخت Agent
├── cli.py               # رابط خط فرمان
└── __init__.py
```

## 🚀 شروع سریع

### 1. نصب Ollama

```bash
# نصب Ollama
curl -fsSL https://ollama.com/install.sh | sh

# دانلود مدل Qwen2.5
ollama pull qwen2.5

# اجرای سرور
ollama serve
```

### 2. نصب Agent Factory

```bash
cd agent_factory
pip install -r requirements.txt
```

### 3. اجرا

```bash
# رابط خط فرمان
python -m agent_factory.cli

# یا مستقیم
python agent_factory/cli.py

# با تنظیمات سفارشی
python -m agent_factory.cli --model qwen2.5:latest --lang both
```

## 📖 استفاده

### رابط خط فرمان

```
AgentOS:~> سلام، چطوری؟
AgentOS:~> /help
AgentOS:~> /status
AgentOS:~> /tools
AgentOS:~> /learn یادگیری جدید نتیجه خوب
```

### ساخت Agent سفارشی

```python
from agent_factory import AgentFactory, AgentConfig

factory = AgentFactory()

# از قالب
agent = factory.create(template="coder")

# با تنظیمات سفارشی
agent = factory.create(
    config=AgentConfig(
        name="MyAgent",
        model="qwen2.5",
        temperature=0.5
    )
)

# استفاده
response = agent.think("سلام")
```

### استفاده از ابزارها

```python
# مستقیم
agent.tools.execute("file_read", "/path/to/file")

# در متن با فرمت خاص
agent.think("[TOOL:file_read:/path/to/file]")
```

### یادگیری

```python
# ذخیره تجربه
agent.memory.add_experience(
    content="چطوری فلان کار رو بکنیم",
    context="موقعیت",
    result="جواب درست"
)

# جستجو
results = agent.memory.search("موضوع مورد نظر")
```

## ⚡ سیستم اینتررپت

| کد | نام | توضیح |
|----|-----|-------|
| INT_00 | System | کنترل سیستم |
| INT_01 | Memory | دسترسی حافظه |
| INT_02 | Tool | اجرای ابزار |
| INT_03 | Learning | یادگیری |
| INT_04 | Communication | ارتباط |
| INT_05 | File | عملیات فایل |
| INT_06 | Search | جستجو |
| INT_07 | Decision | تصمیم‌گیری |

## 🔧 ابزارهای موجود

- `sys_info` - اطلاعات سیستم
- `sys_exec` - اجرای دستور
- `file_read` - خواندن فایل
- `file_write` - نوشتن فایل
- `file_list` - لیست پوشه
- `web_search` - جستجوی اینترنت
- `web_fetch` - دریافت صفحه وب
- `calc` - محاسبه
- `code_run` - اجرای کد
- `llm_chat` - گفتگو با LLM
- `memory_save` - ذخیره در حافظه
- `memory_recall` - بازیابی از حافظه

## 📦 ساخت Agent سفارشی

```python
from agent_factory.factory import AgentFactory, ToolBuilder, InterruptBuilder, ToolCategory

factory = AgentFactory()

# ساخت ابزار سفارشی
my_tool = (ToolBuilder("my_tool")
    .description("My custom tool", "ابزار سفارشی من")
    .category(ToolCategory.CUSTOM)
    .param("arg1", "string", True, "آرگومان اول")
    .function(lambda arg1: {"result": f"Processed: {arg1}"})
    .example("my_tool:test")
    .build())

# ساخت اینتررپت سفارشی
my_interrupt = (InterruptBuilder("INT_08")
    .name("عملیات خاص", "Special Operation")
    .description("یک عملیات خاص")
    .params("param1", "param2")
    .handler(lambda p1, p2: {"done": True})
    .example("INT_08:value1:value2")
    .build())

# ساخت Agent
agent = factory.create(
    config=AgentConfig(
        name="SpecialAgent",
        custom_tools=[my_tool],
        custom_interrupts=[my_interrupt]
    )
)
```

## 🎯 نقشه راه

- [x] سیستم اینتررپت پایه
- [x] حافظه برداری
- [x] ابزارهای پایه
- [x] رابط خط فرمان
- [x] کارخانه Agent
- [ ] پشتیبانی ChromaDB
- [ ] Web UI
- [ ] Multi-agent coordination
- [ ] API Server

## 📝 لایسنس

MIT License

## 🤝 مشارکت

Pull requests are welcome!

---

ساخته شده با ❤️ برای جامعه هوش مصنوعی ایران