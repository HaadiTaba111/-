#!/bin/bash
# ╔═══════════════════════════════════════════════════════════════════════╗
# ║                    Agent Factory Launcher                             ║
║                    اجرای سریع سیستم                                     ║
# ╚═══════════════════════════════════════════════════════════════════════╝

echo "╔═══════════════════════════════════════════════════════════════╗"
echo "║               🤖 Agent Factory Launcher                        ║"
echo "╚═══════════════════════════════════════════════════════════════╝"
echo ""

show_menu() {
    echo "لطفاً انتخاب کنید:"
    echo ""
    echo "  1. 🚀 رابط خط فرمان (CLI)"
    echo "  2. 🌐 داشبورد وب (Web Dashboard)"
    echo "  3. 🔌 سرور API"
    echo "  4. 🧪 اجرای تست‌ها"
    echo "  5. 📖 راهنما"
    echo "  0. ❌ خروج"
    echo ""
}

install_deps() {
    echo "📦 نصب وابستگی‌ها..."
    pip install -r requirements.txt
    echo "✅ نصب complete"
}

# Main menu
while true; do
    show_menu
    read -p "انتخاب (0-5): " choice
    
    case $choice in
        1)
            echo "🚀 راه‌اندازی CLI..."
            python -m agent_factory.cli
            ;;
        2)
            echo "🌐 راه‌اندازی Dashboard..."
            pip install flask flask-cors -q 2>/dev/null
            python agent_factory/web_dashboard.py
            ;;
        3)
            echo "🔌 راه‌اندازی API Server..."
            pip install flask flask-cors -q 2>/dev/null
            python agent_factory/api_server.py
            ;;
        4)
            echo "🧪 اجرای تست‌ها..."
            python agent_factory/test_basic.py
            ;;
        5)
            echo "📖 راهنما:"
            echo ""
            echo "  • CLI: رابط خط فرمان برای تعامل مستقیم"
            echo "  • Dashboard: رابط وب با گرافیک"
            echo "  • API: سرور REST برای برنامه‌نویسی"
            echo ""
            read -p "Enter to continue..."
            ;;
        0)
            echo "👋 خداحافظ!"
            exit 0
            ;;
        *)
            echo "❌ انتخاب نامعتبر"
            ;;
    esac
    echo ""
done