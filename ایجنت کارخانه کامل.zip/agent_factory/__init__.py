"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    AGENT FACTORY - کارخانه ساخت Agent                   ║
║                                                                       ║
║  یک سیستم Agent هوشمند با قابلیت یادگیری و ابزارهای متنوع              ║
╚═══════════════════════════════════════════════════════════════════════╝

Modules:
  ├── core/
  │   ├── agent.py         - هسته اصلی Agent
  │   ├── llm_client.py    - اتصال به Ollama
  │   ├── tool_registry.py - ثبت ابزارها
  │   ├── vector_memory.py - حافظه برداری
  │   └── interrupts.py    - سیستم اینتررپت
  ├── cli.py               - رابط خط فرمان
  ├── web_dashboard.py     - داشبورد وب
  ├── api_server.py        - سرور API
  └── factory.py           - کارخانه ساخت Agent سفارشی
"""

__version__ = "1.0.0"
__author__ = "Agent Factory Team"

from .core.agent import Agent
from .core.llm_client import OllamaClient, LLMConfig
from .core.tool_registry import ToolRegistry, Tool, ToolCategory
from .core.vector_memory import VectorMemory, Experience
from .core.interrupts import InterruptManager, Interrupt, InterruptType

# Factory components
from .factory import AgentFactory, AgentConfig, AgentTemplate
from .factory import ToolBuilder, InterruptBuilder

__all__ = [
    # Core
    "Agent",
    "OllamaClient", 
    "LLMConfig",
    "ToolRegistry",
    "Tool",
    "ToolCategory", 
    "VectorMemory",
    "Experience",
    "InterruptManager",
    "Interrupt",
    "InterruptType",
    # Factory
    "AgentFactory",
    "AgentConfig",
    "AgentTemplate",
    "ToolBuilder",
    "InterruptBuilder"
]