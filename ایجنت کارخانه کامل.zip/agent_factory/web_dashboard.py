"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    WEB DASHBOARD - داشبورد وب                          ║
║                                                                       ║
║  داشبورد مدیریت Agent با API و رابط وب                                ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

from flask import Flask, request, jsonify, render_template_string
from flask_cors import CORS
import threading
import json
from datetime import datetime

app = Flask(__name__)
CORS(app)

# ═══════════════════════════════════════════════════════════════════════
# GLOBAL STATE
# ═══════════════════════════════════════════════════════════════════════

global_agent = None
server_config = {
    "host": "0.0.0.0",
    "port": 5000,
    "debug": False
}


def set_agent(agent):
    """تنظیم Agent برای استفاده در API"""
    global global_agent
    global_agent = agent


# ═══════════════════════════════════════════════════════════════════════
# HTML TEMPLATE - رابط وب
# ═══════════════════════════════════════════════════════════════════════

DASHBOARD_HTML = """
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>🤖 Agent Factory - Dashboard</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --bg-dark: #0f0f1a;
            --bg-card: #1a1a2e;
            --accent: #00d4ff;
            --accent2: #7b2cbf;
            --text: #e0e0e0;
            --success: #00ff88;
            --warning: #ffaa00;
            --danger: #ff4444;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, sans-serif;
            background: var(--bg-dark);
            color: var(--text);
            min-height: 100vh;
        }
        
        /* Header */
        .header {
            background: linear-gradient(135deg, var(--accent2), var(--accent));
            padding: 20px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .header h1 {
            font-size: 1.8rem;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .status-badge {
            background: var(--success);
            color: #000;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: bold;
        }
        
        /* Main Layout */
        .main {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 20px;
            padding: 20px;
            height: calc(100vh - 80px);
        }
        
        /* Chat Section */
        .chat-section {
            display: flex;
            flex-direction: column;
            background: var(--bg-card);
            border-radius: 15px;
            overflow: hidden;
        }
        
        .chat-header {
            background: rgba(255,255,255,0.05);
            padding: 15px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            font-weight: bold;
        }
        
        .chat-messages {
            flex: 1;
            overflow-y: auto;
            padding: 20px;
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .message {
            max-width: 80%;
            padding: 12px 18px;
            border-radius: 15px;
            line-height: 1.6;
        }
        
        .message.user {
            background: var(--accent);
            color: #000;
            align-self: flex-start;
            border-bottom-right-radius: 3px;
        }
        
        .message.agent {
            background: var(--bg-card);
            border: 1px solid rgba(255,255,255,0.1);
            align-self: flex-end;
            border-bottom-left-radius: 3px;
        }
        
        .chat-input-area {
            padding: 15px;
            background: rgba(255,255,255,0.05);
            display: flex;
            gap: 10px;
        }
        
        .chat-input {
            flex: 1;
            background: rgba(0,0,0,0.3);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            padding: 12px 18px;
            color: #fff;
            font-size: 1rem;
            outline: none;
        }
        
        .chat-input:focus {
            border-color: var(--accent);
        }
        
        .send-btn {
            background: var(--accent);
            border: none;
            border-radius: 10px;
            padding: 12px 25px;
            color: #000;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .send-btn:hover {
            transform: scale(1.05);
            box-shadow: 0 0 20px rgba(0,212,255,0.5);
        }
        
        /* Sidebar */
        .sidebar {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .card {
            background: var(--bg-card);
            border-radius: 15px;
            padding: 20px;
        }
        
        .card h3 {
            color: var(--accent);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .stat-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .stat-item {
            background: rgba(0,0,0,0.3);
            padding: 15px;
            border-radius: 10px;
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--accent);
        }
        
        .stat-label {
            font-size: 0.8rem;
            color: #888;
            margin-top: 5px;
        }
        
        /* Tools List */
        .tools-list {
            max-height: 200px;
            overflow-y: auto;
        }
        
        .tool-item {
            background: rgba(0,0,0,0.3);
            padding: 10px 15px;
            border-radius: 8px;
            margin-bottom: 8px;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .tool-icon {
            width: 25px;
            height: 25px;
            background: var(--accent);
            border-radius: 5px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
        }
        
        /* Memory Preview */
        .memory-item {
            background: rgba(0,0,0,0.3);
            padding: 10px;
            border-radius: 8px;
            margin-bottom: 8px;
            font-size: 0.85rem;
            border-right: 3px solid var(--accent);
        }
        
        /* API Section */
        .api-code {
            background: #000;
            padding: 15px;
            border-radius: 8px;
            font-family: monospace;
            font-size: 0.8rem;
            direction: ltr;
            text-align: left;
            overflow-x: auto;
        }
        
        .copy-btn {
            background: var(--accent2);
            border: none;
            border-radius: 5px;
            padding: 8px 15px;
            color: #fff;
            cursor: pointer;
            margin-top: 10px;
            font-size: 0.85rem;
        }
        
        /* Interrupts */
        .interrupt-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 8px;
        }
        
        .interrupt-item {
            background: rgba(0,0,0,0.3);
            padding: 8px;
            border-radius: 5px;
            text-align: center;
            font-size: 0.75rem;
        }
        
        .interrupt-code {
            color: var(--accent);
            font-weight: bold;
        }
        
        /* Loading */
        .loading {
            display: none;
            text-align: center;
            padding: 20px;
        }
        
        .spinner {
            width: 40px;
            height: 40px;
            border: 3px solid rgba(255,255,255,0.1);
            border-top-color: var(--accent);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 0 auto;
        }
        
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>🤖 Agent Factory Dashboard</h1>
        <span class="status-badge" id="status">🟢 Online</span>
    </div>
    
    <div class="main">
        <!-- Chat Section -->
        <div class="chat-section">
            <div class="chat-header">💬 گفتگو با Agent</div>
            
            <div class="chat-messages" id="messages">
                <div class="message agent">
                    👋 سلام! من AgentOS هستم. چطور می‌تونم کمکت کنم؟
                </div>
            </div>
            
            <div class="loading" id="loading">
                <div class="spinner"></div>
                <p style="margin-top: 10px;">در حال پردازش...</p>
            </div>
            
            <div class="chat-input-area">
                <input type="text" class="chat-input" id="userInput" 
                       placeholder="پیام خود را بنویسید..." 
                       onkeypress="if(event.key==='Enter')sendMessage()">
                <button class="send-btn" onclick="sendMessage()">ارسال</button>
            </div>
        </div>
        
        <!-- Sidebar -->
        <div class="sidebar">
            <!-- Stats -->
            <div class="card">
                <h3>📊 آمار سیستم</h3>
                <div class="stat-grid">
                    <div class="stat-item">
                        <div class="stat-value" id="expCount">0</div>
                        <div class="stat-label">تجربیات</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="toolCount">0</div>
                        <div class="stat-label">ابزارها</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="intCount">0</div>
                        <div class="stat-label">اینتررپت‌ها</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value" id="msgCount">0</div>
                        <div class="stat-label">پیام‌ها</div>
                    </div>
                </div>
            </div>
            
            <!-- Tools -->
            <div class="card">
                <h3>🔧 ابزارها</h3>
                <div class="tools-list" id="toolsList">
                    <!-- Populated by JS -->
                </div>
            </div>
            
            <!-- Memory -->
            <div class="card">
                <h3>🧠 حافظه اخیر</h3>
                <div id="memoryList">
                    <div class="memory-item">هنوز تجربه‌ای ذخیره نشده</div>
                </div>
            </div>
            
            <!-- API -->
            <div class="card">
                <h3>🔌 API Access</h3>
                <div class="api-code">
                    curl -X POST http://localhost:5000/api/chat \\
                    -H "Content-Type: application/json" \\
                    -d '{"message": "سلام"}'
                </div>
                <button class="copy-btn" onclick="copyApi()">📋 کپی</button>
            </div>
            
            <!-- Interrupts -->
            <div class="card">
                <h3>⚡ اینتررپت‌ها</h3>
                <div class="interrupt-grid" id="interruptsGrid">
                    <!-- Populated by JS -->
                </div>
            </div>
        </div>
    </div>
    
    <script>
        let messageCount = 0;
        
        async function sendMessage() {
            const input = document.getElementById('userInput');
            const message = input.value.trim();
            if (!message) return;
            
            // Add user message
            addMessage(message, 'user');
            input.value = '';
            
            // Show loading
            document.getElementById('loading').style.display = 'block';
            
            try {
                const response = await fetch('/api/chat', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({message: message})
                });
                
                const data = await response.json();
                addMessage(data.response || data.error, 'agent');
            } catch (e) {
                addMessage('خطا در ارتباط با سرور', 'agent');
            }
            
            document.getElementById('loading').style.display = 'none';
        }
        
        function addMessage(text, type) {
            const container = document.getElementById('messages');
            const div = document.createElement('div');
            div.className = 'message ' + type;
            div.textContent = text;
            container.appendChild(div);
            container.scrollTop = container.scrollHeight;
            messageCount++;
            document.getElementById('msgCount').textContent = messageCount;
        }
        
        function copyApi() {
            const code = `curl -X POST http://localhost:5000/api/chat \\
  -H "Content-Type: application/json" \\
  -d '{"message": "سلام"}'`;
            navigator.clipboard.writeText(code);
            alert('کپی شد!');
        }
        
        // Load stats
        async function loadStats() {
            try {
                const res = await fetch('/api/status');
                const data = await res.json();
                
                document.getElementById('expCount').textContent = data.memory_count || 0;
                document.getElementById('toolCount').textContent = data.tools_count || 0;
                document.getElementById('intCount').textContent = data.interrupts_count || 0;
                
                // Tools list
                if (data.tools) {
                    document.getElementById('toolsList').innerHTML = 
                        data.tools.map(t => `
                            <div class="tool-item">
                                <div class="tool-icon">🔧</div>
                                <span>${t}</span>
                            </div>
                        `).join('');
                }
                
                // Interrupts
                if (data.interrupts) {
                    document.getElementById('interruptsGrid').innerHTML = 
                        data.interrupts.map(i => `
                            <div class="interrupt-item">
                                <div class="interrupt-code">${i}</div>
                            </div>
                        `).join('');
                }
            } catch (e) {
                console.log('Stats loading...');
            }
        }
        
        // Load memory
        async function loadMemory() {
            try {
                const res = await fetch('/api/memory');
                const data = await res.json();
                
                if (data.experiences && data.experiences.length > 0) {
                    document.getElementById('memoryList').innerHTML = 
                        data.experiences.slice(0, 5).map(e => `
                            <div class="memory-item">${e.content.substring(0, 80)}...</div>
                        `).join('');
                }
            } catch (e) {}
        }
        
        // Init
        loadStats();
        loadMemory();
        setInterval(loadStats, 5000);
    </script>
</body>
</html>
"""


# ═══════════════════════════════════════════════════════════════════════
# API ROUTES
# ═══════════════════════════════════════════════════════════════════════

@app.route('/')
def index():
    """صفحه اصلی داشبورد"""
    return render_template_string(DASHBOARD_HTML)


@app.route('/api/chat', methods=['POST'])
def api_chat():
    """API برای گفتگو با Agent"""
    data = request.json
    message = data.get('message', '')
    
    if not message:
        return jsonify({"error": "No message provided"})
    
    if not global_agent:
        return jsonify({
            "response": "Agent not initialized. Start with AgentFactory first.",
            "error": True
        })
    
    response = global_agent.think(message)
    return jsonify({
        "response": response.text,
        "learned": response.learned,
        "actions": len(response.actions)
    })


@app.route('/api/status', methods=['GET'])
def api_status():
    """آمار سیستم"""
    if not global_agent:
        return jsonify({
            "error": "Agent not initialized",
            "memory_count": 0,
            "tools_count": 0,
            "interrupts_count": 0
        })
    
    return jsonify({
        "name": global_agent.name,
        "version": global_agent.version,
        "memory_count": global_agent.memory.count(),
        "tools_count": len(global_agent.tools.tools),
        "interrupts_count": len(global_agent.interrupts.interrupts),
        "tools": list(global_agent.tools.tools.keys()),
        "interrupts": list(global_agent.interrupts.interrupts.keys())
    })


@app.route('/api/memory', methods=['GET'])
def api_memory():
    """لیست تجربیات"""
    if not global_agent:
        return jsonify({"experiences": []})
    
    stats = global_agent.memory.get_stats()
    return jsonify({
        "count": stats['total_experiences'],
        "success_rate": stats['avg_success_rate'],
        "experiences": [
            {"id": e.id, "content": e.content[:100], "success_rate": e.success_rate}
            for e in global_agent.memory.embeddings[-10:]
        ]
    })


@app.route('/api/tools', methods=['GET'])
def api_tools():
    """لیست ابزارها"""
    if not global_agent:
        return jsonify({"tools": []})
    
    return jsonify({
        "tools": global_agent.tools.list()
    })


@app.route('/api/tool/execute', methods=['POST'])
def api_tool_execute():
    """اجرای ابزار"""
    data = request.json
    tool_name = data.get('tool')
    args = data.get('args', [])
    
    if not global_agent:
        return jsonify({"success": False, "error": "Agent not initialized"})
    
    result = global_agent.tools.execute(tool_name, *args)
    return jsonify(result)


@app.route('/api/learn', methods=['POST'])
def api_learn():
    """یادگیری"""
    data = request.json
    content = data.get('content')
    result = data.get('result', '')
    context = data.get('context', '')
    
    if not global_agent:
        return jsonify({"success": False, "error": "Agent not initialized"})
    
    exp_id = global_agent.memory.add_experience(content, context, result)
    return jsonify({"success": True, "experience_id": exp_id})


@app.route('/api/search', methods=['GET'])
def api_search():
    """جستجو در حافظه"""
    query = request.args.get('q', '')
    limit = int(request.args.get('limit', 5))
    
    if not global_agent:
        return jsonify({"results": []})
    
    results = global_agent.memory.search(query, limit=limit)
    return jsonify({"results": results})


# ═══════════════════════════════════════════════════════════════════════
# SERVER START
# ═══════════════════════════════════════════════════════════════════════

def run_dashboard(agent, host='0.0.0.0', port=5000):
    """راه‌اندازی داشبورد"""
    set_agent(agent)
    
    print(f"""
╔═══════════════════════════════════════════════════════════════╗
║              🚀 Agent Factory Dashboard Starting              ║
╠═══════════════════════════════════════════════════════════════╣
║  📍 Dashboard: http://{host}:{port}                           ║
║  📍 API:       http://{host}:{port}/api/chat                   ║
╚═══════════════════════════════════════════════════════════════╝
    """)
    
    app.run(host=host, port=port, debug=False)


# ═══════════════════════════════════════════════════════════════════════
# STANDALONE MODE
# ═══════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    
    from agent_factory import Agent
    
    # Initialize agent
    agent = Agent()
    
    # Run dashboard
    run_dashboard(agent)