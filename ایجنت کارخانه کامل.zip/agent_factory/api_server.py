"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    API SERVER - سرور API                               ║
║                                                                       ║
║  سرور REST API برای دسترسی به Agent از هر جا                          ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import argparse
import os

# ═══════════════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════

app = Flask(__name__)
CORS(app)

# Global agent instance
agent_instance = None


# ═══════════════════════════════════════════════════════════════════════
# API ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════

@app.route('/health', methods=['GET'])
def health():
    """Health check"""
    return jsonify({
        "status": "ok",
        "agent": agent_instance is not None,
        "version": "1.0.0"
    })


@app.route('/api/v1/chat', methods=['POST'])
def chat():
    """
    گفتگو با Agent
    
    POST /api/v1/chat
    {
        "message": "سلام",
        "history": true
    }
    """
    data = request.json or {}
    message = data.get('message', '')
    
    if not message:
        return jsonify({"error": "message is required"}), 400
    
    if not agent_instance:
        return jsonify({"error": "Agent not initialized"}), 500
    
    response = agent_instance.think(message)
    
    return jsonify({
        "response": response.text,
        "learned": response.learned,
        "actions": [
            {"type": a["type"], "tool": a.get("tool")}
            for a in response.actions
        ],
        "tool_results": response.tool_results
    })


@app.route('/api/v1/think', methods=['POST'])
def think():
    """
    تفکر عمیق با context
    
    POST /api/v1/think
    {
        "prompt": "تحلیل کن...",
        "context": {"key": "value"},
        "model": "qwen2.5"
    }
    """
    data = request.json or {}
    prompt = data.get('prompt', '')
    context = data.get('context', {})
    
    if not prompt:
        return jsonify({"error": "prompt is required"}), 400
    
    if not agent_instance:
        return jsonify({"error": "Agent not initialized"}), 500
    
    # Build prompt with context
    context_str = "\n".join([f"{k}: {v}" for k, v in context.items()])
    full_prompt = f"Context:\n{context_str}\n\nTask:\n{prompt}"
    
    response = agent_instance.think(full_prompt)
    
    return jsonify({
        "response": response.text,
        "context_used": bool(context)
    })


@app.route('/api/v1/tool/<tool_name>', methods=['POST'])
def execute_tool(tool_name):
    """
    اجرای ابزار
    
    POST /api/v1/tool/file_read
    {
        "args": ["/path/to/file"]
    }
    """
    if not agent_instance:
        return jsonify({"error": "Agent not initialized"}), 500
    
    data = request.json or {}
    args = data.get('args', [])
    kwargs = data.get('kwargs', {})
    
    result = agent_instance.tools.execute(tool_name, *args, **kwargs)
    
    return jsonify(result)


@app.route('/api/v1/tool/list', methods=['GET'])
def list_tools():
    """لیست ابزارها"""
    if not agent_instance:
        return jsonify({"tools": []})
    
    return jsonify({
        "tools": agent_instance.tools.list(),
        "count": len(agent_instance.tools.tools)
    })


@app.route('/api/v1/memory/store', methods=['POST'])
def store_memory():
    """
    ذخیره در حافظه
    
    POST /api/v1/memory/store
    {
        "content": "تجربه من...",
        "result": "نتیجه",
        "context": "زمینه"
    }
    """
    if not agent_instance:
        return jsonify({"error": "Agent not initialized"}), 500
    
    data = request.json
    exp_id = agent_instance.memory.add_experience(
        content=data.get('content', ''),
        result=data.get('result', ''),
        context=data.get('context', '')
    )
    
    return jsonify({
        "success": True,
        "experience_id": exp_id
    })


@app.route('/api/v1/memory/search', methods=['GET'])
def search_memory():
    """
    جستجو در حافظه
    
    GET /api/v1/memory/search?q=سوال&limit=5
    """
    if not agent_instance:
        return jsonify({"results": []})
    
    query = request.args.get('q', '')
    limit = int(request.args.get('limit', 5))
    threshold = float(request.args.get('threshold', 0.5))
    
    results = agent_instance.memory.search(query, limit=limit, threshold=threshold)
    
    return jsonify({
        "query": query,
        "count": len(results),
        "results": results
    })


@app.route('/api/v1/memory/stats', methods=['GET'])
def memory_stats():
    """آمار حافظه"""
    if not agent_instance:
        return jsonify({"total_experiences": 0})
    
    return jsonify(agent_instance.memory.get_stats())


@app.route('/api/v1/interrupt/<interrupt_code>', methods=['POST'])
def call_interrupt(interrupt_code):
    """
    فراخوانی اینتررپت
    
    POST /api/v1/interrupt/INT_03
    {
        "args": ["تجربه", "زمینه", "نتیجه"]
    }
    """
    if not agent_instance:
        return jsonify({"error": "Agent not initialized"}), 500
    
    data = request.json or {}
    args = data.get('args', [])
    
    result = agent_instance.interrupts.execute(interrupt_code, *args)
    
    return jsonify({
        "success": result.success,
        "data": result.data,
        "error": result.error,
        "execution_time": result.execution_time
    })


@app.route('/api/v1/interrupt/list', methods=['GET'])
def list_interrupts():
    """لیست اینتررپت‌ها"""
    if not agent_instance:
        return jsonify({"interrupts": []})
    
    return jsonify({
        "interrupts": agent_instance.interrupts.list_interrupts(),
        "count": len(agent_instance.interrupts.interrupts)
    })


@app.route('/api/v1/system/status', methods=['GET'])
def system_status():
    """وضعیت سیستم"""
    if not agent_instance:
        return jsonify({
            "status": "no_agent",
            "model": None,
            "ollama_url": None
        })
    
    return jsonify({
        "status": "running",
        "agent_name": agent_instance.name,
        "agent_version": agent_instance.version,
        "model": agent_instance.llm.config.model,
        "ollama_url": agent_instance.llm.config.base_url,
        "memory_count": agent_instance.memory.count(),
        "tools_count": len(agent_instance.tools.tools),
        "interrupts_count": len(agent_instance.interrupts.interrupts)
    })


@app.route('/api/v1/system/reset', methods=['POST'])
def reset_system():
    """ریست سیستم"""
    if not agent_instance:
        return jsonify({"error": "No agent to reset"})
    
    agent_instance.llm.clear_history()
    return jsonify({"success": True, "message": "History cleared"})


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def start_server(agent, host='0.0.0.0', port=5000, api_key=None):
    """راه‌اندازی سرور"""
    global agent_instance
    agent_instance = agent
    
    # Add API key middleware if provided
    if api_key:
        @app.before_request
        def check_api_key():
            if request.path.startswith('/api/'):
                key = request.headers.get('X-API-Key')
                if key != api_key:
                    return jsonify({"error": "Invalid API key"}), 401
    
    print(f"""
╔════════════════════════════════════════════════════════════════════════╗
║                    🔌 Agent Factory API Server                         ║
╠════════════════════════════════════════════════════════════════════════╣
║                                                                        ║
║  📍 Server:     http://{host}:{port}                                ║
║  📍 API Base:   http://{host}:{port}/api/v1                          ║
║  📍 Health:     http://{host}:{port}/health                          ║
║                                                                        ║
║  ═══════════════════════════════════════════════════════════════════  ║
║  📋 AVAILABLE ENDPOINTS:                                              ║
║                                                                        ║
║  POST /api/v1/chat          - گفتگو با Agent                          ║
║  POST /api/v1/think         - تفکر عمیق                               ║
║  POST /api/v1/tool/<name>   - اجرای ابزار                             ║
║  GET  /api/v1/tool/list     - لیست ابزارها                            ║
║  POST /api/v1/memory/store  - ذخیره در حافظه                          ║
║  GET  /api/v1/memory/search - جستجو در حافظه                          ║
║  POST /api/v1/interrupt/<c> - فراخوانی اینتررپت                       ║
║  GET  /api/v1/system/status - وضعیت سیستم                             ║
║                                                                        ║
╚════════════════════════════════════════════════════════════════════════╝
    """)
    
    app.run(host=host, port=port, debug=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Agent Factory API Server")
    parser.add_argument('--host', default='0.0.0.0', help='Host')
    parser.add_argument('--port', type=int, default=5000, help='Port')
    parser.add_argument('--model', default='qwen2.5', help='Model name')
    parser.add_argument('--ollama', default='http://localhost:11434', help='Ollama URL')
    parser.add_argument('--api-key', help='API Key for authentication')
    
    args = parser.parse_args()
    
    # Import here to avoid circular imports
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    from agent_factory import Agent
    
    # Create agent
    agent = Agent(model_name=args.model, ollama_url=args.ollama)
    
    # Start server
    start_server(agent, args.host, args.port, args.api_key)