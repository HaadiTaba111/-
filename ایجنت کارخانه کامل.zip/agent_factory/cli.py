"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    DOS-LIKE INTERFACE - خط فرمان                       ║
║                                                                       ║
║  رابط کاربری شبیه DOS با پشتیبانی دوزبانه                              ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import sys
import os

# Add parent directory to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent_factory.core.agent import Agent


class DOSInterface:
    """
    رابط خط فرمان شبیه DOS
    """
    
    # ANSI Colors
    class Colors:
        RESET = "\033[0m"
        BOLD = "\033[1m"
        DIM = "\033[2m"
        
        # Foreground
        BLACK = "\033[30m"
        RED = "\033[31m"
        GREEN = "\033[32m"
        YELLOW = "\033[33m"
        BLUE = "\033[34m"
        MAGENTA = "\033[35m"
        CYAN = "\033[36m"
        WHITE = "\033[37m"
        
        # Background
        BG_BLACK = "\033[40m"
        BG_BLUE = "\033[44m"
        BG_GREEN = "\033[42m"
        BG_YELLOW = "\033[43m"
    
    def __init__(self):
        self.agent: Agent = None
        self.running = True
        self.prompt = f"{Colors.CYAN}AgentOS{Colors.RESET}:{Colors.GREEN}~{Colors.RESET}> "
        
        # Banner ASCII art
        self.banner = f"""
{Colors.CYAN}╔══════════════════════════════════════════════════════════════════════════╗
║                                                                          ║
║   {Colors.YELLOW}███████╗███████╗ █████╗ ██████╗ ██████╗██╗  ██╗{Colors.CYAN}                      ║
║   {Colors.YELLOW}██╔════╝██╔════╝██╔══██╗██╔══██╗██╔══██╗██║  ██║{Colors.CYAN}                      ║
║   {Colors.YELLOW}███████╗███████╗███████║██████╔╝███████║███████║{Colors.CYAN}                      ║
║   {Colors.YELLOW}╚════██║╚════██║██╔══██║██╔═══╝ ██╔══██║██╔══██║{Colors.CYAN}                      ║
║   {Colors.YELLOW}███████║███████║██║  ██║██║     ██║  ██║██║  ██║{Colors.CYAN}                      ║
║   {Colors.YELLOW}╚══════╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝  ╚═╝╚═╝  ╚═╝{Colors.CYAN}                      ║
║                                                                          ║
║   {Colors.WHITE}Agent Factory System v1.0 - Powered by Qwen2.5 + Ollama{Colors.CYAN}            ║
║   {Colors.DIM}──────────────────────────────────────────────────────────────────{Colors.CYAN}  ║
║   {Colors.WHITE}Commands: /help | /status | /tools | /learn | /exit{Colors.CYAN}                ║
╚══════════════════════════════════════════════════════════════════════════╝{Colors.RESET}
"""
    
    def init_agent(self, model: str = "qwen2.5", ollama_url: str = "http://localhost:11434"):
        """راه‌اندازی Agent"""
        try:
            self.agent = Agent(model_name=model, ollama_url=ollama_url)
            return True
        except Exception as e:
            print(f"{self.Colors.RED}❌ Failed to initialize agent: {e}{self.Colors.RESET}")
            return False
    
    def print_banner(self):
        """نمایش بنر"""
        print(self.banner)
    
    def print_welcome(self):
        """پیام خوش‌آمدگویی"""
        print(f"""
{self.Colors.GREEN}✅ Agent initialized successfully!{self.Colors.RESET}

{self.Colors.YELLOW}Quick Start:{self.Colors.RESET}
  • Type your message and press Enter
  • Start with {self.Colors.CYAN}/help{self.Colors.RESET} for commands
  • Start with {self.Colors.CYAN}[TOOL:...]{self.Colors.RESET} for direct tool calls
  • Start with {self.Colors.CYAN}[MEMORY:...]{self.Colors.RESET} to search memory

{self.Colors.DIM}────────────────────────────────────────────────────────────────────{self.Colors.RESET}
""")
    
    def process_input(self, user_input: str) -> str:
        """پردازش ورودی کاربر"""
        
        if not user_input.strip():
            return ""
        
        # Check for exit command
        if user_input.strip().lower() in ["/exit", "exit", "quit", "خروج"]:
            self.running = False
            return f"{self.Colors.YELLOW}👋 Goodbye!{self.Colors.RESET}"
        
        # Process with agent
        response = self.agent.think(user_input)
        
        # Format output
        output_parts = []
        
        # Main response
        output_parts.append(f"{self.Colors.WHITE}{response.text}{self.Colors.RESET}")
        
        # Show tool results if any
        if response.tool_results:
            output_parts.append(f"\n{self.Colors.CYAN}─── Tool Results ───{self.Colors.RESET}")
            for result in response.tool_results:
                if result.get("success"):
                    output_parts.append(f"  {self.Colors.GREEN}✓{self.Colors.RESET} {result}")
                else:
                    output_parts.append(f"  {self.Colors.RED}✗{self.Colors.RESET} {result.get('error', 'Unknown error')}")
        
        # Learning indicator
        if response.learned:
            output_parts.append(f"\n{self.Colors.YELLOW}🧠 New experience learned!{self.Colors.RESET}")
        
        return "\n".join(output_parts)
    
    def run(self):
        """حلقه اصلی"""
        self.print_banner()
        
        # Initialize agent
        if not self.init_agent():
            print(f"{self.Colors.RED}Failed to start. Check Ollama connection.{self.Colors.RESET}")
            return
        
        self.print_welcome()
        
        # Main loop
        while self.running:
            try:
                # Get input
                user_input = input(self.prompt).strip()
                
                # Process
                output = self.process_input(user_input)
                
                # Print output
                if output:
                    print(output)
                    print()  # Empty line for readability
                
            except KeyboardInterrupt:
                print(f"\n{self.Colors.YELLOW}⚠️ Press /exit to quit{self.Colors.RESET}")
            except EOFError:
                break
            except Exception as e:
                print(f"{self.Colors.RED}❌ Error: {e}{self.Colors.RESET}")
        
        print(f"{self.Colors.CYAN}Agent Factory shutdown complete.{self.Colors.RESET}")


# ═══════════════════════════════════════════════════════════════════════
# BILINGUAL HELPER
# ═══════════════════════════════════════════════════════════════════════

class BilingualHelper:
    """
    کمک‌کننده دوزبانه
    ترجمه دستورات و پیام‌ها
    """
    
    # ترجمه‌های پایه
    TRANSLATIONS = {
        # Greetings
        "hello": "سلام",
        "hi": "سلام",
        "goodbye": "خداحافظ",
        "bye": "خداحافظ",
        
        # Commands
        "help": "کمک",
        "status": "وضعیت",
        "search": "جستجو",
        "learn": "یادگیری",
        "save": "ذخیره",
        "load": "بارگذاری",
        "exit": "خروج",
        "clear": "پاک کردن",
        
        # Responses
        "welcome": "خوش آمدید",
        "ready": "آماده",
        "error": "خطا",
        "success": "موفق",
        "done": "انجام شد",
        
        # Common words
        "yes": "بله",
        "no": "نه",
        "please": "لطفا",
        "thanks": "ممنون",
        "sorry": "ببخشید",
        "ok": "باشه",
        "okay": "باشه"
    }
    
    @classmethod
    def translate(cls, text: str, to: str = "fa") -> str:
        """ترجمه متن"""
        if to == "fa":
            text_lower = text.lower()
            for en, fa in cls.TRANSLATIONS.items():
                text_lower = text_lower.replace(en, fa)
            return text_lower
        return text
    
    @classmethod
    def is_persian(cls, text: str) -> bool:
        """چک کردن فارسی بودن"""
        return any('\u0600' <= char <= '\u06FF' for char in text)
    
    @classmethod
    def normalize_input(cls, text: str) -> str:
        """نرمال‌سازی ورودی"""
        # Replace Persian numbers with English
        persian_numbers = {'۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
                          '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9'}
        for fa, en in persian_numbers.items():
            text = text.replace(fa, en)
        
        # Normalize spaces
        text = ' '.join(text.split())
        
        return text


# ═══════════════════════════════════════════════════════════════════════
# MAIN ENTRY POINT
# ═══════════════════════════════════════════════════════════════════════

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Agent Factory - AI Agent System")
    parser.add_argument("--model", "-m", default="qwen2.5", help="Model name (default: qwen2.5)")
    parser.add_argument("--url", "-u", default="http://localhost:11434", help="Ollama URL")
    parser.add_argument("--lang", "-l", choices=["fa", "en", "both"], default="both", help="Language mode")
    
    args = parser.parse_args()
    
    # Run interface
    interface = DOSInterface()
    interface.agent_language = args.lang
    interface.run()


if __name__ == "__main__":
    main()