"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    LLM CLIENT - اتصال به Ollama/Qwen                  ║
║                                                                       ║
║  مغز اصلی سیستم - اتصال به مدل‌های زبانی محلی                         ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import requests
import json
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum


class ModelStatus(Enum):
    """وضعیت مدل"""
    LOADING = "loading"
    READY = "ready"
    ERROR = "error"
    BUSY = "busy"


@dataclass
class LLMConfig:
    """تنظیمات مدل"""
    base_url: str = "http://localhost:11434"
    model: str = "qwen2.5"
    temperature: float = 0.7
    max_tokens: int = 4096
    top_p: float = 0.9
    top_k: int = 40
    repeat_penalty: float = 1.1
    num_ctx: int = 8192  # Context window


@dataclass
class Message:
    """یک پیام در مکالمه"""
    role: str  # system, user, assistant
    content: str
    timestamp: str = ""


class OllamaClient:
    """
    کلاینت اتصال به Ollama
    پشتیبانی از Qwen2.5 و سایر مدل‌ها
    """
    
    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or LLMConfig()
        self.status = ModelStatus.LOADING
        self.conversation_history: List[Message] = []
        self.system_prompt = self._get_default_system_prompt()
        
        self._check_connection()
    
    def _get_default_system_prompt(self) -> str:
        """پرامپت سیستم پیش‌فرض"""
        return """تو یک AI Agent هستی با نام AgentOS.
        
توانایی‌ها:
- می‌توانی از ابزارها (Tools) استفاده کنی
- از اینتررپت‌های سیستمی استفاده کن: INT_00 تا INT_07
- یاد می‌گیری و تجربیاتت را ذخیره می‌کنی
- دوزبانه هستی (فارسی و انگلیسی)

وقتی کاری نمی‌توانی انجام بده، صادقانه بگو.

برای استفاده از ابزارها، از فرمت خاص استفاده کن:
[TOOL:tool_name:arg1:arg2]

برای یادگیری:
[LEARN:experience:context:result]

برای جستجو در حافظه:
[MEMORY:query]
"""
    
    def _check_connection(self):
        """بررسی اتصال به Ollama"""
        try:
            response = requests.get(f"{self.config.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                self.status = ModelStatus.READY
                models = response.json().get("models", [])
                print(f"✅ Connected to Ollama. Available models: {[m['name'] for m in models]}")
            else:
                self.status = ModelStatus.ERROR
        except requests.exceptions.ConnectionError:
            self.status = ModelStatus.ERROR
            print("❌ Cannot connect to Ollama. Make sure Ollama is running.")
        except Exception as e:
            self.status = ModelStatus.ERROR
            print(f"❌ Connection error: {e}")
    
    def set_system_prompt(self, prompt: str):
        """تنظیم پرامپت سیستم"""
        self.system_prompt = prompt
    
    def chat(
        self, 
        message: str, 
        system_prompt: Optional[str] = None,
        stream: bool = False,
        history: bool = True
    ) -> Dict[str, Any]:
        """
        ارسال پیام به مدل
        """
        if self.status != ModelStatus.READY:
            return {"error": "Model not ready", "status": self.status.value}
        
        # ساخت پرامپت نهایی
        final_prompt = system_prompt or self.system_prompt
        
        # تاریخچه مکالمه
        messages = []
        if history and self.conversation_history:
            messages.extend([
                {"role": m.role, "content": m.content}
                for m in self.conversation_history[-10:]  # آخرین 10 پیام
            ])
        
        messages.append({"role": "user", "content": message})
        
        try:
            response = requests.post(
                f"{self.config.base_url}/api/chat",
                json={
                    "model": self.config.model,
                    "messages": messages,
                    "stream": stream,
                    "options": {
                        "temperature": self.config.temperature,
                        "num_predict": self.config.max_tokens,
                        "top_p": self.config.top_p,
                        "top_k": self.config.top_k,
                        "repeat_penalty": self.config.repeat_penalty
                    }
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                
                if history:
                    # ذخیره در تاریخچه
                    self.conversation_history.append(Message("user", message))
                    self.conversation_history.append(
                        Message("assistant", result["message"]["content"])
                    )
                
                return {
                    "success": True,
                    "response": result["message"]["content"],
                    "model": result.get("model", self.config.model),
                    "done": result.get("done", True)
                }
            else:
                return {
                    "success": False,
                    "error": f"HTTP {response.status_code}",
                    "details": response.text
                }
                
        except requests.exceptions.Timeout:
            return {"success": False, "error": "Request timeout"}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def generate(
        self, 
        prompt: str,
        system_prompt: Optional[str] = None,
        stream: bool = False
    ) -> Dict[str, Any]:
        """
        تولید متن با prompt
        """
        if self.status != ModelStatus.READY:
            return {"error": "Model not ready"}
        
        final_prompt = f"{system_prompt or self.system_prompt}\n\n{prompt}"
        
        try:
            response = requests.post(
                f"{self.config.base_url}/api/generate",
                json={
                    "model": self.config.model,
                    "prompt": final_prompt,
                    "stream": stream,
                    "options": {
                        "temperature": self.config.temperature,
                        "num_predict": self.config.max_tokens,
                        "top_p": self.config.top_p,
                        "top_k": self.config.top_k
                    }
                },
                timeout=120
            )
            
            if response.status_code == 200:
                result = response.json()
                return {
                    "success": True,
                    "response": result["response"],
                    "done": result.get("done", True)
                }
            else:
                return {"success": False, "error": response.text}
                
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def list_models(self) -> List[Dict]:
        """لیست مدل‌های موجود"""
        try:
            response = requests.get(f"{self.config.base_url}/api/tags", timeout=5)
            if response.status_code == 200:
                return response.json().get("models", [])
            return []
        except:
            return []
    
    def pull_model(self, model_name: str) -> Dict:
        """دانلود مدل"""
        try:
            response = requests.post(
                f"{self.config.base_url}/api/pull",
                json={"name": model_name},
                stream=True
            )
            
            progress = []
            for line in response.iter_lines():
                if line:
                    data = json.loads(line)
                    progress.append(data)
                    if data.get("status") == "success":
                        break
            
            return {"success": True, "progress": progress}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def clear_history(self):
        """پاک کردن تاریخچه"""
        self.conversation_history = []
    
    def get_history(self, limit: int = 10) -> List[Dict]:
        """دریافت تاریخچه"""
        return [
            {"role": m.role, "content": m.content}
            for m in self.conversation_history[-limit:]
        ]
    
    def set_model(self, model_name: str):
        """تغییر مدل"""
        self.config.model = model_name
        print(f"🔄 Switched to model: {model_name}")


# ═══════════════════════════════════════════════════════════════════════
# AGENT PROMPT BUILDER - ساخت پرامپت برای Agent
# ═══════════════════════════════════════════════════════════════════════

class AgentPromptBuilder:
    """
    ساخت پرامپت‌های هوشمند برای Agent
    شامل ابزارها، اینتررپت‌ها، و زمینه
    """
    
    def __init__(
        self, 
        llm_client: OllamaClient,
        tool_registry, 
        interrupt_manager,
        vector_memory
    ):
        self.llm = llm_client
        self.tools = tool_registry
        self.interrupts = interrupt_manager
        self.memory = vector_memory
    
    def build_system_prompt(self, agent_name: str = "AgentOS") -> str:
        """ساخت پرامپت سیستم کامل"""
        
        tools_desc = self._build_tools_description()
        interrupts_desc = self._build_interrupts_description()
        memory_stats = self.memory.get_stats()
        
        prompt = f"""╔═══════════════════════════════════════════════════════════════╗
║                   {agent_name} - Agent Factory System                 ║
╚═══════════════════════════════════════════════════════════════════════╝

تو یک AI Agent هوشمند هستی که:
- می‌توانی از ابزارها استفاده کنی
- از اینتررپت‌های سیستمی استفاده کنی
- از تجربیات گذشته یاد بگیری
- دوزبانه هستی (فارسی و انگلیسی)

═══════════════════════════════════════════════════════════════════════
📦 AVAILABLE TOOLS ({len(self.tools.tools)} tools):
═══════════════════════════════════════════════════════════════════════
{tools_desc}

═══════════════════════════════════════════════════════════════════════
⚡ SYSTEM INTERRUPTS:
═══════════════════════════════════════════════════════════════════════
{interrupts_desc}

═══════════════════════════════════════════════════════════════════════
🧠 MEMORY STATUS:
═══════════════════════════════════════════════════════════════════════
- Total Experiences: {memory_stats['total_experiences']}
- Average Success Rate: {memory_stats['avg_success_rate']:.2f}
- Tags: {', '.join(memory_stats['tags'][:10]) if memory_stats['tags'] else 'None'}

═══════════════════════════════════════════════════════════════════════
📋 USAGE GUIDE:
═══════════════════════════════════════════════════════════════════════
• برای استفاده از ابزار: [TOOL:tool_name:arg1:arg2]
• برای یادگیری: [LEARN:what_you_learned:context:result]
• برای جستجو در حافظه: [MEMORY:what_to_find]
• برای ذخیره نتیجه: [SAVE:key:value]
• برای تصمیم‌گیری: [DECIDE:context:option1:option2]

"""
        return prompt
    
    def _build_tools_description(self) -> str:
        """توصیف ابزارها"""
        lines = []
        for tool in self.tools.tools.values():
            params = ", ".join([
                f"{p['name']}: {p.get('type', 'any')}"
                for p in tool.parameters
            ]) or "none"
            
            lines.append(f"• {tool.name}({params})")
            lines.append(f"  └─ {tool.description_fa}")
            lines.append(f"  └─ Examples: {', '.join(tool.examples[:2])}")
            lines.append("")
        
        return "\n".join(lines)
    
    def _build_interrupts_description(self) -> str:
        """توصیف اینتررپت‌ها"""
        lines = []
        for code, interrupt in self.interrupts.interrupts.items():
            lines.append(f"• {code}: {interrupt.name} ({interrupt.name_en})")
            lines.append(f"  └─ {interrupt.description}")
            lines.append(f"  └─ Example: {interrupt.example}")
            lines.append("")
        
        return "\n".join(lines)
    
    def build_context_prompt(
        self, 
        user_input: str, 
        relevant_experiences: List[Dict] = None
    ) -> str:
        """ساخت پرامپت با زمینه"""
        
        context_parts = [f"User: {user_input}"]
        
        if relevant_experiences:
            context_parts.append("\n📚 Related Experiences:")
            for i, exp in enumerate(relevant_experiences[:3]):
                context_parts.append(
                    f"{i+1}. Similar: {exp.get('content', '')[:200]}...\n"
                    f"   Success: {exp.get('success_rate', 0):.0%}"
                )
        
        return "\n".join(context_parts)