"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    TOOL REGISTRY - ثبت ابزارها                         ║
║                                                                       ║
║  ابزارها مثل دستورات DOS هستند که Agent با آنها کار می‌کند             ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import subprocess
import json
from typing import Dict, List, Any, Callable, Optional
from dataclasses import dataclass, field
from enum import Enum
import inspect


class ToolCategory(Enum):
    """دسته‌بندی ابزارها"""
    SYSTEM = "system"
    FILE = "file"
    NETWORK = "network"
    COMPUTATION = "computation"
    AI = "ai"
    CUSTOM = "custom"


@dataclass
class Tool:
    """تعریف یک ابزار"""
    name: str                      # نام ابزار
    description: str               # توضیحات
    description_fa: str            # توضیح فارسی
    category: ToolCategory         # دسته
    function: Callable             # تابع اصلی
    parameters: List[Dict] = field(default_factory=list)  # پارامترها
    examples: List[str] = field(default_factory=list)     # مثال‌ها
    requires_approval: bool = False  # نیاز به تأیید
    
    def get_signature(self) -> str:
        """امضای تابع"""
        sig = inspect.signature(self.function)
        params = [p for p in sig.parameters.keys()]
        return f"{self.name}({', '.join(params)})"


class ToolRegistry:
    """
    ثبت و مدیریت ابزارها
    مثل COMMAND.COM در DOS
    """
    
    def __init__(self):
        self.tools: Dict[str, Tool] = {}
        self._register_default_tools()
    
    def _register_default_tools(self):
        """ثبت ابزارهای پیش‌فرض"""
        
        # ═══════════════════════════════════════════════════
        # SYSTEM TOOLS - ابزارهای سیستمی
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="sys_info",
            description="Get system information",
            description_fa="نمایش اطلاعات سیستم",
            category=ToolCategory.SYSTEM,
            function=self._sys_info,
            examples=["sys_info()", "sys_info:cpu"]
        ))
        
        self.register(Tool(
            name="sys_exec",
            description="Execute system command",
            description_fa="اجرای دستور سیستمی",
            category=ToolCategory.SYSTEM,
            parameters=[
                {"name": "command", "type": "string", "required": True, "description": "دستور اجرایی"}
            ],
            function=self._sys_exec,
            examples=["sys_exec:ls -la", "sys_exec:dir"],
            requires_approval=True
        ))
        
        self.register(Tool(
            name="echo",
            description="Print message",
            description_fa="چاپ پیام",
            category=ToolCategory.SYSTEM,
            parameters=[
                {"name": "message", "type": "string", "required": True}
            ],
            function=self._echo,
            examples=["echo:سلام دنیا!", "echo:نتیجه = 42"]
        ))
        
        # ═══════════════════════════════════════════════════
        # FILE TOOLS - ابزارهای فایل
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="file_read",
            description="Read file contents",
            description_fa="خواندن فایل",
            category=ToolCategory.FILE,
            parameters=[
                {"name": "path", "type": "string", "required": True, "description": "مسیر فایل"}
            ],
            function=self._file_read,
            examples=["file_read:/path/to/file.txt"]
        ))
        
        self.register(Tool(
            name="file_write",
            description="Write to file",
            description_fa="نوشتن در فایل",
            category=ToolCategory.FILE,
            parameters=[
                {"name": "path", "type": "string", "required": True},
                {"name": "content", "type": "string", "required": True},
                {"name": "mode", "type": "string", "default": "w"}
            ],
            function=self._file_write,
            examples=["file_write:/path/file.txt:محتوا", "file_write:data.json:{}:a"],
            requires_approval=True
        ))
        
        self.register(Tool(
            name="file_list",
            description="List directory contents",
            description_fa="لیست پوشه",
            category=ToolCategory.FILE,
            parameters=[
                {"name": "path", "type": "string", "default": "."}
            ],
            function=self._file_list,
            examples=["file_list:/home", "file_list:."]
        ))
        
        self.register(Tool(
            name="file_search",
            description="Search for files",
            description_fa="جستجوی فایل",
            category=ToolCategory.FILE,
            parameters=[
                {"name": "directory", "type": "string", "required": True},
                {"name": "pattern", "type": "string", "required": True}
            ],
            function=self._file_search,
            examples=["file_search:/home:*.py"]
        ))
        
        # ═══════════════════════════════════════════════════
        # NETWORK TOOLS - ابزارهای شبکه
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="web_search",
            description="Search the web",
            description_fa="جستجوی اینترنت",
            category=ToolCategory.NETWORK,
            parameters=[
                {"name": "query", "type": "string", "required": True},
                {"name": "limit", "type": "int", "default": 5}
            ],
            function=self._web_search,
            examples=["web_search:اخبار فناوری", "web_search:AI news:3"]
        ))
        
        self.register(Tool(
            name="web_fetch",
            description="Fetch webpage content",
            description_fa="دریافت صفحه وب",
            category=ToolCategory.NETWORK,
            parameters=[
                {"name": "url", "type": "string", "required": True}
            ],
            function=self._web_fetch,
            examples=["web_fetch:https://example.com"]
        ))
        
        # ═══════════════════════════════════════════════════
        # COMPUTATION TOOLS - ابزارهای محاسباتی
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="calc",
            description="Calculate expression",
            description_fa="محاسبه عبارت",
            category=ToolCategory.COMPUTATION,
            parameters=[
                {"name": "expression", "type": "string", "required": True}
            ],
            function=self._calc,
            examples=["calc:2+2", "calc:sqrt(16)"]
        ))
        
        self.register(Tool(
            name="code_run",
            description="Run code snippet",
            description_fa="اجرای کد",
            category=ToolCategory.COMPUTATION,
            parameters=[
                {"name": "language", "type": "string", "required": True},
                {"name": "code", "type": "string", "required": True}
            ],
            function=self._code_run,
            examples=["code_run:python:print('Hello')"],
            requires_approval=True
        ))
        
        # ═══════════════════════════════════════════════════
        # AI TOOLS - ابزارهای هوش مصنوعی
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="llm_chat",
            description="Chat with LLM",
            description_fa="گفتگو با مدل زبانی",
            category=ToolCategory.AI,
            parameters=[
                {"name": "message", "type": "string", "required": True},
                {"name": "system_prompt", "type": "string", "default": ""}
            ],
            function=self._llm_chat,
            examples=["llm_chat:سلام چطوری"]
        ))
        
        self.register(Tool(
            name="embed",
            description="Generate text embedding",
            description_fa="تولید امبدینگ",
            category=ToolCategory.AI,
            parameters=[
                {"name": "text", "type": "string", "required": True}
            ],
            function=self._embed,
            examples=["embed:متن برای امبدینگ"]
        ))
        
        self.register(Tool(
            name="image_gen",
            description="Generate image",
            description_fa="تولید تصویر",
            category=ToolCategory.AI,
            parameters=[
                {"name": "prompt", "type": "string", "required": True},
                {"name": "path", "type": "string", "required": True}
            ],
            function=self._image_gen,
            examples=["image_gen:یک گربه سفید:/tmp/cat.png"]
        ))
        
        # ═══════════════════════════════════════════════════
        # MEMORY TOOLS - ابزارهای حافظه
        # ═══════════════════════════════════════════════════
        
        self.register(Tool(
            name="memory_save",
            description="Save to memory",
            description_fa="ذخیره در حافظه",
            category=ToolCategory.CUSTOM,
            parameters=[
                {"name": "key", "type": "string", "required": True},
                {"name": "value", "type": "string", "required": True}
            ],
            function=self._memory_save,
            examples=["memory_save:تجربه۱:یاد گرفتم که..."]
        ))
        
        self.register(Tool(
            name="memory_recall",
            description="Recall from memory",
            description_fa="بازیابی از حافظه",
            category=ToolCategory.CUSTOM,
            parameters=[
                {"name": "query", "type": "string", "required": True}
            ],
            function=self._memory_recall,
            examples=["memory_recall:یادت هست چی یاد گرفتی؟"]
        ))
        
        self.register(Tool(
            name="memory_stats",
            description="Memory statistics",
            description_fa="آمار حافظه",
            category=ToolCategory.CUSTOM,
            function=self._memory_stats,
            examples=["memory_stats()"]
        ))
    
    def register(self, tool: Tool):
        """ثبت ابزار جدید"""
        self.tools[tool.name] = tool
        print(f"📦 Registered tool: {tool.name}")
    
    def unregister(self, name: str):
        """حذف ابزار"""
        if name in self.tools:
            del self.tools[name]
    
    def execute(self, tool_name: str, *args, **kwargs) -> Dict:
        """اجرای ابزار"""
        if tool_name not in self.tools:
            return {"success": False, "error": f"Tool '{tool_name}' not found"}
        
        tool = self.tools[tool_name]
        
        try:
            result = tool.function(*args, **kwargs)
            return {
                "success": True,
                "tool": tool_name,
                "result": result
            }
        except Exception as e:
            return {
                "success": False,
                "tool": tool_name,
                "error": str(e)
            }
    
    def list(self) -> List[Dict]:
        """لیست همه ابزارها"""
        return [{
            "name": t.name,
            "description": t.description,
            "description_fa": t.description_fa,
            "category": t.category.value,
            "examples": t.examples,
            "requires_approval": t.requires_approval
        } for t in self.tools.values()]
    
    def list_by_category(self, category: ToolCategory) -> List[Tool]:
        """لیست ابزارهای یک دسته"""
        return [t for t in self.tools.values() if t.category == category]
    
    # ══════════════════════════════════════════════════════════════════════
    # DEFAULT TOOL IMPLEMENTATIONS
    # ══════════════════════════════════════════════════════════════════════
    
    def _sys_info(self) -> Dict:
        """اطلاعات سیستم"""
        import platform
        return {
            "os": platform.system(),
            "version": platform.version(),
            "machine": platform.machine(),
            "python": platform.python_version()
        }
    
    def _sys_exec(self, command: str) -> Dict:
        """اجرای دستور سیستمی"""
        try:
            result = subprocess.run(
                command, 
                shell=True, 
                capture_output=True, 
                text=True,
                timeout=30
            )
            return {
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _echo(self, message: str) -> str:
        """چاپ پیام"""
        return message
    
    def _file_read(self, path: str) -> Dict:
        """خواندن فایل"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            return {"content": content, "size": len(content)}
        except FileNotFoundError:
            return {"error": "File not found"}
        except Exception as e:
            return {"error": str(e)}
    
    def _file_write(self, path: str, content: str, mode: str = "w") -> Dict:
        """نوشتن در فایل"""
        try:
            with open(path, mode, encoding='utf-8') as f:
                f.write(content)
            return {"success": True, "path": path}
        except Exception as e:
            return {"error": str(e)}
    
    def _file_list(self, path: str = ".") -> List[str]:
        """لیست پوشه"""
        import os
        try:
            return os.listdir(path)
        except Exception as e:
            return [str(e)]
    
    def _file_search(self, directory: str, pattern: str) -> List[str]:
        """جستجوی فایل"""
        import glob
        try:
            search_path = f"{directory}/**/{pattern}"
            return glob.glob(search_path, recursive=True)
        except Exception as e:
            return [str(e)]
    
    def _web_search(self, query: str, limit: int = 5) -> Dict:
        """جستجوی اینترنت - نیاز به پیاده‌سازی واقعی"""
        return {
            "query": query,
            "results": [],
            "message": "Web search not implemented. Install web_search tool."
        }
    
    def _web_fetch(self, url: str) -> Dict:
        """دریافت صفحه وب"""
        import requests
        try:
            response = requests.get(url, timeout=10)
            return {
                "url": url,
                "status": response.status_code,
                "content": response.text[:1000],  # Limit content
                "content_length": len(response.text)
            }
        except Exception as e:
            return {"error": str(e)}
    
    def _calc(self, expression: str) -> Any:
        """محاسبه عبارت"""
        try:
            # Safe evaluation
            allowed = {"__builtins__": {}, "sqrt": lambda x: x**0.5}
            return eval(expression, allowed)
        except Exception as e:
            return {"error": str(e)}
    
    def _code_run(self, language: str, code: str) -> Dict:
        """اجرای کد"""
        # این باید در محیط sandbox اجرا شود
        return {
            "language": language,
            "code": code,
            "message": "Code execution requires sandbox setup"
        }
    
    def _llm_chat(self, message: str, system_prompt: str = "") -> str:
        """گفتگو با LLM"""
        return {"message": message, "system_prompt": system_prompt}
    
    def _embed(self, text: str) -> List[float]:
        """تولید امبدینگ"""
        # نیاز به پیاده‌سازی با Ollama
        return [0.0] * 384
    
    def _image_gen(self, prompt: str, path: str) -> Dict:
        """تولید تصویر"""
        return {"prompt": prompt, "path": path, "status": "Not implemented"}
    
    def _memory_save(self, key: str, value: str) -> Dict:
        """ذخیره در حافظه"""
        return {"key": key, "saved": True}
    
    def _memory_recall(self, query: str) -> Dict:
        """بازیابی از حافظه"""
        return {"query": query, "results": []}
    
    def _memory_stats(self) -> Dict:
        """آمار حافظه"""
        return {"experiences": 0, "patterns": 0}