"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    INTERRUPT SYSTEM - اینتررپت‌های سیستم              ║
║                                                                       ║
║  مانند DOS، هر اینتررپت یک تابع سیستمی است که LLM با آن کار می‌کند    ║
╚═══════════════════════════════════════════════════════════════════════╝

Basic Interrupts (INT):
├── INT 00: System Control      - کنترل سیستم
├── INT 01: Memory Access       - دسترسی به حافظه
├── INT 02: Tool Execution      - اجرای ابزارها
├── INT 03: Learning            - یادگیری
├── INT 04: Communication       - ارتباط
├── INT 05: File Operations     - عملیات فایل
├── INT 06: Search & Query      - جستجو
└── INT 07: Decision Making     - تصمیم‌گیری
"""

from typing import Dict, List, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import json
from datetime import datetime


class InterruptType(Enum):
    """نوع اینتررپت‌ها"""
    SYSTEM = "INT_00_SYSTEM"
    MEMORY = "INT_01_MEMORY"
    TOOL = "INT_02_TOOL"
    LEARNING = "INT_03_LEARNING"
    COMMUNICATION = "INT_04_COMM"
    FILE = "INT_05_FILE"
    SEARCH = "INT_06_SEARCH"
    DECISION = "INT_07_DECISION"


@dataclass
class Interrupt:
    """تعریف یک اینتررپت"""
    code: str                    # مثل INT_00
    name: str                    # نام فارسی
    name_en: str                 # نام انگلیسی
    description: str             # توضیحات
    handler: Callable            # تابع handler
    parameters: List[str] = field(default_factory=list)  # پارامترهای ورودی
    return_type: str = "any"     # نوع خروجی
    example: str = ""            # مثال استفاده


@dataclass
class InterruptResult:
    """نتیجه اجرای اینتررپت"""
    success: bool
    data: Any = None
    error: str = None
    execution_time: float = 0.0


class InterruptManager:
    """
    مدیریت اینتررپت‌ها - هسته اصلی سیستم
    مانند BIOS در DOS، این کلاس عملیات پایه را فراهم می‌کند
    """
    
    def __init__(self, llm_client, vector_db, tool_registry):
        self.llm = llm_client
        self.vector_db = vector_db
        self.tools = tool_registry
        self.interrupts: Dict[str, Interrupt] = {}
        self.execution_log: List[Dict] = []
        
        self._register_basic_interrupts()
    
    def _register_basic_interrupts(self):
        """ثبت اینتررپت‌های پایه"""
        
        # INT 00 - کنترل سیستم
        self.interrupts["INT_00"] = Interrupt(
            code="INT_00",
            name="کنترل سیستم",
            name_en="System Control",
            description="عملیات کنترلی سطح بالا",
            parameters=["action", "params"],
            return_type="json",
            handler=self._handle_system,
            example="INT_00:status | INT_00:reset | INT_00:info"
        )
        
        # INT 01 - دسترسی به حافظه
        self.interrupts["INT_01"] = Interrupt(
            code="INT_01",
            name="حافظه",
            name_en="Memory Access",
            description="خواندن و نوشتن در حافظه",
            parameters=["operation", "key", "value"],
            return_type="any",
            handler=self._handle_memory,
            example="INT_01:read:experience_001 | INT_01:write:key:value"
        )
        
        # INT 02 - اجرای ابزار
        self.interrupts["INT_02"] = Interrupt(
            code="INT_02",
            name="ابزار",
            name_en="Tool Execution",
            description="اجرای ابزارهای سیستم",
            parameters=["tool_name", "args"],
            return_type="json",
            handler=self._handle_tool,
            example="INT_02:file_read:/path/to/file"
        )
        
        # INT 03 - یادگیری
        self.interrupts["INT_03"] = Interrupt(
            code="INT_03",
            name="یادگیری",
            name_en="Learning",
            description="ذخیره و بازیابی تجربیات",
            parameters=["experience", "context", "result"],
            return_type="embedding_id",
            handler=self._handle_learning,
            example="INT_03:learn:سوال:جواب:موفق"
        )
        
        # INT 04 - ارتباط
        self.interrupts["INT_04"] = Interrupt(
            code="INT_04",
            name="ارتباط",
            name_en="Communication",
            description="ارتباط با کاربر یا سایر سیستم‌ها",
            parameters=["message", "format"],
            return_type="response",
            handler=self._handle_communication,
            example="INT_04:respond:سلام چطوری؟"
        )
        
        # INT 05 - فایل
        self.interrupts["INT_05"] = Interrupt(
            code="INT_05",
            name="فایل",
            name_en="File Operations",
            description="عملیات فایل سیستم",
            parameters=["operation", "path", "content"],
            return_type="result",
            handler=self._handle_file,
            example="INT_05:read:/config.json | INT_05:write:/data.json:content"
        )
        
        # INT 06 - جستجو
        self.interrupts["INT_06"] = Interrupt(
            code="INT_06",
            name="جستجو",
            name_en="Search & Query",
            description="جستجو در بردارهای ذخیره شده",
            parameters=["query", "limit", "threshold"],
            return_type="results",
            handler=self._handle_search,
            example="INT_06:query:چطوری؟:5:0.7"
        )
        
        # INT 07 - تصمیم‌گیری
        self.interrupts["INT_07"] = Interrupt(
            code="INT_07",
            name="تصمیم‌گیری",
            name_en="Decision Making",
            description="تصمیم‌گیری با استفاده از تجربیات",
            parameters=["context", "options"],
            return_type="decision",
            handler=self._handle_decision,
            example="INT_07:decide:موقعیت:[گزینه۱,گزینه۲]"
        )
    
    def execute(self, interrupt_code: str, *args) -> InterruptResult:
        """اجرای یک اینتررپت"""
        import time
        start = time.time()
        
        if interrupt_code not in self.interrupts:
            return InterruptResult(
                success=False,
                error=f"Interrupt {interrupt_code} not found"
            )
        
        try:
            handler = self.interrupts[interrupt_code].handler
            result = handler(*args)
            
            self.execution_log.append({
                "interrupt": interrupt_code,
                "args": args,
                "success": True,
                "time": time.time() - start
            })
            
            return InterruptResult(
                success=True,
                data=result,
                execution_time=time.time() - start
            )
        except Exception as e:
            return InterruptResult(
                success=False,
                error=str(e),
                execution_time=time.time() - start
            )
    
    def _handle_system(self, action: str, *params) -> Dict:
        """INT 00: کنترل سیستم"""
        if action == "status":
            return {
                "memory_used": len(self.execution_log),
                "registered_interrupts": list(self.interrupts.keys()),
                "vector_count": self.vector_db.count(),
                "tools_count": len(self.tools.list())
            }
        elif action == "info":
            return {"system": "Agent Factory OS v1.0", "version": "1.0.0"}
        return {"status": "ok"}
    
    def _handle_memory(self, operation: str, *args) -> Any:
        """INT 01: حافظه"""
        if operation == "read":
            return self.vector_db.get(args[0] if args else "")
        elif operation == "write":
            key, value = args[0], args[1] if len(args) > 1 else ""
            return self.vector_db.set(key, value)
        return None
    
    def _handle_tool(self, tool_name: str, *args) -> Dict:
        """INT 02: ابزار"""
        return self.tools.execute(tool_name, *args)
    
    def _handle_learning(self, *args) -> str:
        """INT 03: یادگیری"""
        if len(args) >= 3:
            return self.vector_db.add_experience(args[0], args[1], args[2])
        return self.vector_db.add_experience(str(args[0]) if args else "", "", "")
    
    def _handle_communication(self, message: str, *args) -> str:
        """INT 04: ارتباط"""
        return message
    
    def _handle_file(self, operation: str, *args) -> Any:
        """INT 05: فایل"""
        return {"operation": operation, "path": args[0] if args else ""}
    
    def _handle_search(self, query: str, *args) -> List:
        """INT 06: جستجو"""
        limit = int(args[0]) if args else 5
        threshold = float(args[1]) if len(args) > 1 else 0.7
        return self.vector_db.search(query, limit, threshold)
    
    def _handle_decision(self, context: str, *args) -> Dict:
        """INT 07: تصمیم‌گیری"""
        options = json.loads(args[0]) if args else []
        relevant = self.vector_db.search(context, limit=3)
        return {
            "decision": "based_on_experience",
            "context": context,
            "relevant_experiences": relevant,
            "recommended": options[0] if options else None
        }
    
    def list_interrupts(self) -> List[Dict]:
        """لیست همه اینتررپت‌ها"""
        return [{
            "code": i.code,
            "name": i.name,
            "name_en": i.name_en,
            "description": i.description,
            "example": i.example
        } for i in self.interrupts.values()]


# ═══════════════════════════════════════════════════════════════════════
# REGISTRY - ثبت اینتررپت‌های سفارشی
# ═══════════════════════════════════════════════════════════════════════

class InterruptRegistry:
    """ثبت اینتررپت‌های جدید توسط کاربر"""
    
    def __init__(self, interrupt_manager: InterruptManager):
        self.manager = interrupt_manager
        self.custom_interrupts: List[Interrupt] = []
    
    def register(self, interrupt: Interrupt):
        """ثبت اینتررپت جدید"""
        self.manager.interrupts[interrupt.code] = interrupt
        self.custom_interrupts.append(interrupt)
        print(f"✅ Registered: {interrupt.code} - {interrupt.name}")
    
    def unregister(self, code: str):
        """حذف اینتررپت"""
        if code in self.manager.interrupts:
            del self.manager.interrupts[code]
    
    def list_custom(self) -> List[str]:
        """لیست اینتررپت‌های سفارشی"""
        return [i.code for i in self.custom_interrupts]