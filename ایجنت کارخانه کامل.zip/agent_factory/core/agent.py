"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    AGENT CORE - هسته اصلی Agent                        ║
║                                                                       ║
║  این کلاس همه اجزا را به هم متصل می‌کند                                ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import json
import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field

from .llm_client import OllamaClient, LLMConfig, AgentPromptBuilder
from .tool_registry import ToolRegistry
from .interrupts import InterruptManager, InterruptRegistry
from .vector_memory import VectorMemory


@dataclass
class AgentResponse:
    """پاسخ Agent"""
    text: str
    actions: List[Dict] = field(default_factory=list)  # اکشن‌های انجام شده
    learned: bool = False
    memory_updated: bool = False
    tool_results: List[Dict] = field(default_factory=list)


class Agent:
    """
    Agent اصلی - مغز + چشم + دست
    اتصال همه اجزا به هم
    """
    
    def __init__(
        self,
        model_name: str = "qwen2.5",
        ollama_url: str = "http://localhost:11434"
    ):
        print("🚀 Initializing Agent Factory...")
        
        # ═══════════════════════════════════════════════════════
        # INITIALIZE COMPONENTS
        # ═══════════════════════════════════════════════════════
        
        # 1. LLM Client (مغز)
        self.llm = OllamaClient(LLMConfig(
            base_url=ollama_url,
            model=model_name
        ))
        
        # 2. Vector Memory (حافظه بلندمدت)
        self.memory = VectorMemory("./data/memory.db")
        
        # 3. Tool Registry (دست)
        self.tools = ToolRegistry()
        
        # 4. Interrupt Manager (سیستم‌عامل)
        self.interrupts = InterruptManager(self.llm, self.memory, self.tools)
        self.interrupt_registry = InterruptRegistry(self.interrupts)
        
        # 5. Prompt Builder
        self.prompt_builder = AgentPromptBuilder(
            self.llm, 
            self.tools, 
            self.interrupts, 
            self.memory
        )
        
        # ═══════════════════════════════════════════════════════
        # AGENT STATE
        # ═══════════════════════════════════════════════════════
        
        self.name = "AgentOS"
        self.version = "1.0.0"
        self.is_learning = True  # یادگیری فعال
        self.auto_tool_use = True  # استفاده خودکار از ابزار
        self.language = "both"  # فارسی/انگلیسی/هردو
        
        print(f"✅ Agent initialized: {self.name} v{self.version}")
        print(f"   📦 Tools: {len(self.tools.tools)}")
        print(f"   🧠 Memory: {self.memory.count()} experiences")
        print(f"   ⚡ Interrupts: {len(self.interrupts.interrupts)}")
    
    def think(self, user_input: str) -> AgentResponse:
        """
        فرآیند اصلی تفکر Agent
        1. Parse input for special commands
        2. Search memory for relevant experiences
        3. Build context-aware prompt
        4. Call LLM
        5. Execute actions (tools, interrupts)
        6. Learn from interaction
        """
        
        response = AgentResponse(text="")
        actions = []
        
        # ═══════════════════════════════════════════════════════
        # STEP 1: Parse special commands
        # ═══════════════════════════════════════════════════════
        
        # چک برای دستورات خاص
        if user_input.startswith("/"):
            return self._handle_command(user_input)
        
        # چک برای Tool call
        tool_match = re.match(r'\[TOOL:(\w+)(?::(.+))?\]', user_input)
        if tool_match:
            tool_name = tool_match.group(1)
            args = tool_match.group(2).split(":") if tool_match.group(2) else []
            result = self.tools.execute(tool_name, *args)
            return AgentResponse(
                text=f"Tool executed: {tool_name}",
                tool_results=[result]
            )
        
        # چک برای Learn command
        learn_match = re.match(r'\[LEARN:([^\]]+)\]', user_input)
        if learn_match:
            content = learn_match.group(1)
            parts = content.split(":")
            exp_id = self.memory.add_experience(
                content=parts[0] if len(parts) > 0 else "",
                context=":".join(parts[1:-1]) if len(parts) > 2 else "",
                result=parts[-1] if len(parts) > 1 else ""
            )
            return AgentResponse(
                text=f"Learned! ID: {exp_id}",
                learned=True
            )
        
        # چک برای Memory search
        memory_match = re.match(r'\[MEMORY:([^\]]+)\]', user_input)
        if memory_match:
            query = memory_match.group(1)
            results = self.memory.search(query, limit=5)
            return AgentResponse(
                text=f"Found {len(results)} experiences",
                tool_results=[{"type": "memory", "results": results}]
            )
        
        # ═══════════════════════════════════════════════════════
        # STEP 2: Search memory for relevant experiences
        # ═══════════════════════════════════════════════════════
        
        relevant = self.memory.search(user_input, limit=3, threshold=0.5)
        
        # ═══════════════════════════════════════════════════════
        # STEP 3: Build prompt
        # ═══════════════════════════════════════════════════════
        
        system_prompt = self.prompt_builder.build_system_prompt(self.name)
        context_prompt = self.prompt_builder.build_context_prompt(
            user_input, 
            relevant
        )
        
        # ═══════════════════════════════════════════════════════
        # STEP 4: Call LLM
        # ═══════════════════════════════════════════════════════
        
        llm_response = self.llm.chat(
            message=context_prompt,
            system_prompt=system_prompt,
            history=True
        )
        
        if not llm_response.get("success"):
            return AgentResponse(text=f"Error: {llm_response.get('error')}")
        
        response.text = llm_response["response"]
        
        # ═══════════════════════════════════════════════════════
        # STEP 5: Execute embedded actions
        # ═══════════════════════════════════════════════════════
        
        # Parse tool calls in response
        tool_calls = re.findall(r'\[TOOL:(\w+)(?::([^\]]+))?\]', response.text)
        for tool_name, args_str in tool_calls:
            args = args_str.split(":") if args_str else []
            result = self.tools.execute(tool_name, *args)
            response.tool_results.append(result)
            actions.append({
                "type": "tool",
                "tool": tool_name,
                "result": result
            })
        
        # Parse learn commands in response
        learn_calls = re.findall(r'\[LEARN:([^\]]+)\]', response.text)
        for content in learn_calls:
            parts = content.split(":")
            if len(parts) >= 2:
                exp_id = self.memory.add_experience(
                    content=parts[0],
                    context=":".join(parts[1:-1]),
                    result=parts[-1]
                )
                response.learned = True
                actions.append({
                    "type": "learn",
                    "id": exp_id
                })
        
        response.actions = actions
        return response
    
    def learn_from_feedback(
        self, 
        query: str, 
        response: str, 
        feedback: str
    ):
        """
        یادگیری از بازخورد کاربر
        """
        success = feedback.lower() in ["good", "great", "excellent", "عالی", "خوب", "✓"]
        
        self.memory.learn_from_interaction(
            query=query,
            response=response,
            feedback=feedback,
            context={"source": "user_feedback"}
        )
        
        return {"learned": True, "success": success}
    
    def _handle_command(self, command: str) -> AgentResponse:
        """مدیریت دستورات سیستمی"""
        parts = command.split()
        cmd = parts[0].lower()
        args = parts[1:]
        
        commands = {
            "/help": self._cmd_help,
            "/status": self._cmd_status,
            "/tools": self._cmd_tools,
            "/interrupts": self._cmd_interrupts,
            "/memory": self._cmd_memory,
            "/clear": self._cmd_clear,
            "/history": self._cmd_history,
            "/learn": self._cmd_learn,
            "/export": self._cmd_export,
            "/import": self._cmd_import,
            "/model": self._cmd_model,
            "/exit": self._cmd_exit
        }
        
        if cmd in commands:
            return commands[cmd](args)
        else:
            return AgentResponse(text=f"Unknown command: {cmd}\nType /help for available commands")
    
    def _cmd_help(self, args) -> AgentResponse:
        """راهنما"""
        help_text = """
╔═══════════════════════════════════════════════════════════════╗
║                    AGENT OS - HELP                           ║
╚═══════════════════════════════════════════════════════════════╝

📋 COMMANDS:
  /help           - This help
  /status         - System status
  /tools          - List available tools
  /interrupts     - List system interrupts
  /memory         - Memory statistics
  /history        - Conversation history
  /learn          - Learn from text
  /export         - Export knowledge
  /import         - Import knowledge
  /model          - Switch model
  /clear          - Clear history

💡 SPECIAL SYNTAX:
  [TOOL:tool:args]    - Execute tool
  [LEARN:exp:ctx:res] - Save experience
  [MEMORY:query]      - Search memory

═══════════════════════════════════════════════════════════════
"""
        return AgentResponse(text=help_text)
    
    def _cmd_status(self, args) -> AgentResponse:
        """وضعیت سیستم"""
        stats = self.memory.get_stats()
        models = self.llm.list_models()
        
        status = f"""
╔═══════════════════════════════════════════════════════════════╗
║                    SYSTEM STATUS                             ║
╚═══════════════════════════════════════════════════════════════╝

🤖 Agent: {self.name} v{self.version}
📦 Model: {self.llm.config.model}
🔗 Ollama: {self.llm.config.base_url}
📊 Status: {self.llm.status.value}

🧠 Memory:
  • Experiences: {stats['total_experiences']}
  • Avg Success: {stats['avg_success_rate']:.1%}
  • Tags: {len(stats['tags'])}

📦 Tools: {len(self.tools.tools)}
⚡ Interrupts: {len(self.interrupts.interrupts)}

Available Models: {[m['name'] for m in models[:5]]}
"""
        return AgentResponse(text=status)
    
    def _cmd_tools(self, args) -> AgentResponse:
        """لیست ابزارها"""
        tools = self.tools.list()
        text = "╔═══════════════════════════════════════════════════════════════╗\n"
        text += "║                    AVAILABLE TOOLS                           ║\n"
        text += "╚═══════════════════════════════════════════════════════════════╝\n\n"
        
        for t in tools:
            text += f"📦 {t['name']}\n"
            text += f"   {t['description_fa']}\n"
            text += f"   Example: {t['examples'][0] if t['examples'] else 'N/A'}\n\n"
        
        return AgentResponse(text=text)
    
    def _cmd_interrupts(self, args) -> AgentResponse:
        """لیست اینتررپت‌ها"""
        ints = self.interrupts.list_interrupts()
        text = "╔═══════════════════════════════════════════════════════════════╗\n"
        text += "║                    SYSTEM INTERRUPTS                        ║\n"
        text += "╚═══════════════════════════════════════════════════════════════╝\n\n"
        
        for i in ints:
            text += f"⚡ {i['code']}: {i['name']} ({i['name_en']})\n"
            text += f"   {i['description']}\n"
            text += f"   Example: {i['example']}\n\n"
        
        return AgentResponse(text=text)
    
    def _cmd_memory(self, args) -> AgentResponse:
        """آمار حافظه"""
        stats = self.memory.get_stats()
        recent = self.memory.search(" ", limit=3)
        
        text = f"""
╔═══════════════════════════════════════════════════════════════╗
║                    MEMORY STATUS                             ║
╚═══════════════════════════════════════════════════════════════╝

📊 Statistics:
  • Total Experiences: {stats['total_experiences']}
  • Average Success Rate: {stats['avg_success_rate']:.1%}
  • Database Size: {stats['db_size_mb']:.2f} MB
  • Tags: {', '.join(stats['tags'][:10]) if stats['tags'] else 'None'}

🧠 Recent Memories:
"""
        for i, exp in enumerate(recent):
            text += f"  {i+1}. {exp['content'][:80]}... (score: {exp['similarity']:.2f})\n"
        
        return AgentResponse(text=text)
    
    def _cmd_clear(self, args) -> AgentResponse:
        """پاک کردن تاریخچه"""
        self.llm.clear_history()
        return AgentResponse(text="✅ History cleared")
    
    def _cmd_history(self, args) -> AgentResponse:
        """تاریخچه مکالمه"""
        history = self.llm.get_history(limit=10)
        
        text = "╔═══════════════════════════════════════════════════════════════╗\n"
        text += "║                    CONVERSATION HISTORY                      ║\n"
        text += "╚═══════════════════════════════════════════════════════════════╝\n\n"
        
        for i, msg in enumerate(history):
            role = "👤 User" if msg['role'] == 'user' else "🤖 Agent"
            text += f"{role}: {msg['content'][:150]}...\n\n"
        
        return AgentResponse(text=text)
    
    def _cmd_learn(self, args) -> AgentResponse:
        """یادگیری دستی"""
        if len(args) < 2:
            return AgentResponse(text="Usage: /learn <content> <result>")
        
        content = args[0]
        result = " ".join(args[1:])
        
        exp_id = self.memory.add_experience(content, "", result)
        return AgentResponse(
            text=f"✅ Learned! Experience ID: {exp_id}",
            learned=True
        )
    
    def _cmd_export(self, args) -> AgentResponse:
        """خروجی دانش"""
        if not args:
            path = "./data/exported_knowledge.json"
        else:
            path = args[0]
        
        count = self.memory.export_knowledge(path)
        return AgentResponse(text=f"✅ Exported {count} experiences to {path}")
    
    def _cmd_import(self, args) -> AgentResponse:
        """ورود دانش"""
        if not args:
            return AgentResponse(text="Usage: /import <file_path>")
        
        count = self.memory.import_knowledge(args[0])
        return AgentResponse(text=f"✅ Imported {count} experiences")
    
    def _cmd_model(self, args) -> AgentResponse:
        """تغییر مدل"""
        if not args:
            models = self.llm.list_models()
            text = "Available models:\n" + "\n".join([m['name'] for m in models])
            return AgentResponse(text=text)
        
        self.llm.set_model(args[0])
        return AgentResponse(text=f"✅ Switched to model: {args[0]}")
    
    def _cmd_exit(self, args) -> AgentResponse:
        """خروج"""
        return AgentResponse(text="👋 Goodbye! Agent shutting down...")