"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    VECTOR MEMORY - حافظه برداری                        ║
║                                                                       ║
║  تجربیات به صورت بردار ذخیره می‌شوند برای جستجوی semantic              ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import json
import numpy as np
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
import sqlite3
import hashlib


@dataclass
class Experience:
    """یک تجربه ذخیره‌شده"""
    id: str
    content: str                    # محتوای اصلی
    content_fa: str = ""            # معادل فارسی
    embedding: Optional[np.ndarray] = None
    metadata: Dict = field(default_factory=dict)
    created_at: str = ""
    access_count: int = 0
    success_rate: float = 1.0       # نرخ موفقیت
    
    def __post_init__(self):
        if not self.created_at:
            self.created_at = datetime.now().isoformat()
        if not self.id:
            self.id = hashlib.md5(self.content.encode()).hexdigest()[:12]


@dataclass
class KnowledgePattern:
    """الگوی دانش"""
    pattern: str
    examples: List[str]
    response_template: str
    contexts: List[str]
    usage_count: int = 0


class VectorMemory:
    """
    حافظه برداری برای ذخیره و جستجوی تجربیات
    از ChromaDB یا SQLite با امبدینگ ساده استفاده می‌کند
    """
    
    def __init__(self, db_path: str = "./data/memory.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self.embeddings: List[Experience] = []
        self.patterns: List[KnowledgePattern] = []
        self.metadata_index: Dict[str, List[int]] = {}  # tag -> experience indices
        
        self._init_db()
        self._load_from_disk()
    
    def _init_db(self):
        """راه‌اندازی دیتابیس SQLite"""
        self.conn = sqlite3.connect(str(self.db_path))
        self.cursor = self.conn.cursor()
        
        # جدول تجربیات
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS experiences (
                id TEXT PRIMARY KEY,
                content TEXT NOT NULL,
                content_fa TEXT,
                metadata TEXT,
                created_at TEXT,
                access_count INTEGER DEFAULT 0,
                success_rate REAL DEFAULT 1.0
            )
        """)
        
        # جدول الگوها
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS patterns (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                pattern TEXT UNIQUE,
                examples TEXT,
                response_template TEXT,
                contexts TEXT,
                usage_count INTEGER DEFAULT 0
            )
        """)
        
        # جدول امبدینگ‌ها
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS embeddings (
                experience_id TEXT,
                vector BLOB,
                FOREIGN KEY (experience_id) REFERENCES experiences(id)
            )
        """)
        
        self.conn.commit()
    
    def _simple_embed(self, text: str) -> np.ndarray:
        """
        امبدینگ ساده بدون نیاز به مدل خارجی
        برای production از OpenAI embedding یا local model استفاده کنید
        """
        # Simple hash-based embedding for demonstration
        # In production: use sentence-transformers or OpenAI embeddings
        np.random.seed(hash(text) % (2**32))
        embedding = np.random.randn(384)  # 384-dimensional vector
        
        # Normalize
        embedding = embedding / (np.linalg.norm(embedding) + 1e-8)
        
        # Add text-specific features
        for i, char in enumerate(text[:50]):
            if char.isalpha():
                embedding[i % 384] += ord(char.lower()) / 255.0
        
        return embedding / (np.linalg.norm(embedding) + 1e-8)
    
    def add_experience(
        self, 
        content: str, 
        context: str = "", 
        result: str = "",
        metadata: Optional[Dict] = None,
        success: bool = True
    ) -> str:
        """افزودن تجربه جدید"""
        
        # ایجاد محتوای ترکیبی
        full_content = f"Context: {context}\nQuery: {content}\nResult: {result}"
        
        # ایجاد امبدینگ
        embedding = self._simple_embed(full_content)
        
        # ایجاد تجربه
        exp = Experience(
            id=self._generate_id(content),
            content=full_content,
            content_fa=self._translate_to_fa(content),
            metadata=metadata or {
                "original_content": content,
                "result": result,
                "success": success
            },
            success_rate=1.0 if success else 0.0
        )
        
        # ذخیره در لیست
        self.embeddings.append(exp)
        
        # ذخیره در SQLite
        self._save_experience(exp, embedding)
        
        # به‌روزرسانی ایندکس
        self._update_index(exp)
        
        return exp.id
    
    def _generate_id(self, content: str) -> str:
        """تولید ID یکتا"""
        return hashlib.md5(content.encode()).hexdigest()[:12]
    
    def _translate_to_fa(self, text: str) -> str:
        """ترجمه ساده برای نمایش (در production از ترجمه ماشینی استفاده کنید)"""
        translations = {
            "hello": "سلام",
            "hi": "سلام",
            "how are you": "چطوری",
            "thank you": "ممنون",
            "bye": "خداحافظ",
            "yes": "بله",
            "no": "نه",
            "please": "لطفا",
            "sorry": "ببخشید",
            "help": "کمک",
            "search": "جستجو",
            "read": "خواندن",
            "write": "نوشتن",
            "execute": "اجرا",
            "learn": "یادگیری"
        }
        
        text_lower = text.lower().strip()
        for en, fa in translations.items():
            if en in text_lower:
                return text_lower.replace(en, fa)
        
        return text  # اگه ترجمه نبود، خود متن رو برگردون
    
    def _save_experience(self, exp: Experience, embedding: np.ndarray):
        """ذخیره در دیتابیس"""
        self.cursor.execute("""
            INSERT OR REPLACE INTO experiences 
            (id, content, content_fa, metadata, created_at, access_count, success_rate)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            exp.id,
            exp.content,
            exp.content_fa,
            json.dumps(exp.metadata),
            exp.created_at,
            exp.access_count,
            exp.success_rate
        ))
        
        # ذخیره امبدینگ
        self.cursor.execute("""
            INSERT OR REPLACE INTO embeddings (experience_id, vector)
            VALUES (?, ?)
        """, (exp.id, embedding.tobytes()))
        
        self.conn.commit()
    
    def _update_index(self, exp: Experience):
        """به‌روزرسانی ایندکس"""
        tags = exp.metadata.get("tags", [])
        for tag in tags:
            if tag not in self.metadata_index:
                self.metadata_index[tag] = []
            self.metadata_index[tag].append(len(self.embeddings) - 1)
    
    def search(
        self, 
        query: str, 
        limit: int = 5, 
        threshold: float = 0.7,
        lang: str = "both"
    ) -> List[Dict]:
        """
        جستجوی semantic در تجربیات
        """
        query_embedding = self._simple_embed(query)
        
        # محاسبه شباهت
        similarities = []
        for i, exp in enumerate(self.embeddings):
            if exp.embedding is None:
                continue
            
            similarity = self._cosine_similarity(query_embedding, exp.embedding)
            
            if similarity >= threshold:
                similarities.append({
                    "id": exp.id,
                    "content": exp.content,
                    "content_fa": exp.content_fa,
                    "similarity": float(similarity),
                    "metadata": exp.metadata,
                    "created_at": exp.created_at,
                    "success_rate": exp.success_rate
                })
        
        # مرتب‌سازی بر اساس شباهت
        similarities.sort(key=lambda x: x["similarity"], reverse=True)
        
        return similarities[:limit]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """محاسبه شباهت کسینوسی"""
        return float(np.dot(a, b))
    
    def get(self, experience_id: str) -> Optional[Experience]:
        """دریافت یک تجربه با ID"""
        for exp in self.embeddings:
            if exp.id == experience_id:
                exp.access_count += 1
                return exp
        return None
    
    def count(self) -> int:
        """تعداد تجربیات"""
        return len(self.embeddings)
    
    def get_stats(self) -> Dict:
        """آمار حافظه"""
        success_rates = [e.success_rate for e in self.embeddings]
        return {
            "total_experiences": len(self.embeddings),
            "avg_success_rate": np.mean(success_rates) if success_rates else 0,
            "tags": list(self.metadata_index.keys()),
            "db_size_mb": self.db_path.stat().st_size / (1024 * 1024) if self.db_path.exists() else 0
        }
    
    def learn_from_interaction(
        self, 
        query: str, 
        response: str, 
        feedback: str = "positive",
        context: Optional[Dict] = None
    ):
        """یادگیری از یک تعامل"""
        success = feedback.lower() in ["positive", "good", "success", "عالی", "خوب"]
        
        exp_id = self.add_experience(
            content=query,
            context=json.dumps(context) if context else "",
            result=response,
            metadata={
                "feedback": feedback,
                "tags": self._extract_tags(query)
            },
            success=success
        )
        
        # به‌روزرسانی نرخ موفقیت الگوهای مشابه
        similar = self.search(query, limit=3)
        for s in similar:
            if s["id"] != exp_id:
                self._update_pattern_success(s["content"], success)
        
        return exp_id
    
    def _extract_tags(self, text: str) -> List[str]:
        """استخراج تگ‌ها از متن"""
        # تگ‌های پایه
        tags = []
        text_lower = text.lower()
        
        if any(w in text_lower for w in ["search", "جستجو", "find"]):
            tags.append("search")
        if any(w in text_lower for w in ["read", "خواندن", "file"]):
            tags.append("file_read")
        if any(w in text_lower for w in ["write", "نوشتن", "save"]):
            tags.append("file_write")
        if any(w in text_lower for w in ["code", "کد", "program"]):
            tags.append("coding")
        if any(w in text_lower for w in ["learn", "یادگیری", "teach"]):
            tags.append("learning")
            
        return tags if tags else ["general"]
    
    def _update_pattern_success(self, pattern: str, success: bool):
        """به‌روزرسانی موفقیت یک الگو"""
        # Find and update similar experiences
        for exp in self.embeddings:
            if pattern in exp.content:
                delta = 0.1 if success else -0.1
                exp.success_rate = max(0, min(1, exp.success_rate + delta))
    
    def _load_from_disk(self):
        """بارگذاری از دیسک"""
        self.cursor.execute("SELECT * FROM experiences")
        rows = self.cursor.fetchall()
        
        for row in rows:
            exp = Experience(
                id=row[0],
                content=row[1],
                content_fa=row[2] or "",
                metadata=json.loads(row[3]) if row[3] else {},
                created_at=row[4],
                access_count=row[5],
                success_rate=row[6]
            )
            
            # بارگذاری امبدینگ
            self.cursor.execute("SELECT vector FROM embeddings WHERE experience_id = ?", (exp.id,))
            emb_row = self.cursor.fetchone()
            if emb_row:
                exp.embedding = np.frombuffer(emb_row[0], dtype=np.float32)
            
            self.embeddings.append(exp)
    
    def export_knowledge(self, path: str):
        """خروجی گرفتن از دانش"""
        data = {
            "experiences": [
                {
                    "id": e.id,
                    "content": e.content,
                    "metadata": e.metadata,
                    "success_rate": e.success_rate
                }
                for e in self.embeddings
            ],
            "patterns": [
                {
                    "pattern": p.pattern,
                    "examples": p.examples,
                    "response_template": p.response_template
                }
                for p in self.patterns
            ]
        }
        
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        return len(data["experiences"])
    
    def import_knowledge(self, path: str):
        """وارد کردن دانش"""
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        count = 0
        for exp_data in data.get("experiences", []):
            self.add_experience(
                content=exp_data["content"],
                context="",
                result=exp_data["metadata"].get("result", ""),
                metadata=exp_data["metadata"],
                success=exp_data.get("success_rate", 1.0) > 0.5
            )
            count += 1
        
        return count


# ═══════════════════════════════════════════════════════════════════════
# EMBEDDING SERVER - سرویس امبدینگ با Ollama
# ═══════════════════════════════════════════════════════════════════════

class OllamaEmbedder:
    """امبدینگ با استفاده از Ollama"""
    
    def __init__(self, base_url: str = "http://localhost:11434"):
        self.base_url = base_url
        self.model = "nomic-embed-text"  # مدل امبدینگ
        
    def embed(self, text: str) -> np.ndarray:
        """تبدیل متن به بردار"""
        import requests
        
        try:
            response = requests.post(
                f"{self.base_url}/api/embeddings",
                json={"model": self.model, "prompt": text},
                timeout=30
            )
            
            if response.status_code == 200:
                return np.array(response.json()["embedding"])
        except:
            pass
        
        # Fallback to simple embedding
        return np.random.randn(768)
    
    def embed_batch(self, texts: List[str]) -> List[np.ndarray]:
        """امبدینگ دسته‌ای"""
        return [self.embed(t) for t in texts]