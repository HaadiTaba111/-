"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    AGENT FACTORY - کارخانه ساخت Agent سفارشی           ║
║                                                                       ║
║  کلاس‌ها و توابع برای ساخت Agent‌های سفارشی با تنظیمات دلخواه          ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import json
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum

from .core.agent import Agent
from .core.llm_client import OllamaClient, LLMConfig
from .core.tool_registry import ToolRegistry, Tool, ToolCategory
from .core.vector_memory import VectorMemory
from .core.interrupts import InterruptManager, Interrupt, InterruptType


# ═══════════════════════════════════════════════════════════════════════
# AGENT TEMPLATES - قالب‌های آماده Agent
# ═══════════════════════════════════════════════════════════════════════

class AgentTemplate(Enum):
    """قالب‌های آماده"""
    GENERAL = "general"           # Agent عمومی
    CODER = "coder"               # Agent برنامه‌نویس
    RESEARCHER = "researcher"     # Agent پژوهشگر
    TEACHER = "teacher"           # Agent آموزشی
    ASSISTANT = "assistant"       # Agent دستیار
    CREATIVE = "creative"         # Agent خلاق


@dataclass
class AgentConfig:
    """تنظیمات Agent سفارشی"""
    name: str = "CustomAgent"
    model: str = "qwen2.5"
    ollama_url: str = "http://localhost:11434"
    
    # поведение
    temperature: float = 0.7
    max_tokens: int = 4096
    
    # زبان
    language: str = "both"  # fa, en, both
    
    # یادگیری
    auto_learn: bool = True
    memory_enabled: bool = True
    
    # ابزارها
    enabled_tools: List[str] = field(default_factory=list)  # خالی = همه
    custom_tools: List[Tool] = field(default_factory=list)
    
    # اینتررپت‌ها
    custom_interrupts: List[Interrupt] = field(default_factory=list)
    
    # پرامپت سیستم
    system_prompt: str = ""
    
    # رفتار
    creative_mode: bool = False
    strict_mode: bool = False


class AgentFactory:
    """
    کارخانه ساخت Agent سفارشی
    
    Usage:
        factory = AgentFactory()
        agent = factory.create(config=AgentConfig(name="MyAgent"))
        agent.think("Hello!")
    """
    
    def __init__(self):
        self.templates = self._load_templates()
        self.created_agents: Dict[str, Agent] = {}
    
    def _load_templates(self) -> Dict[str, Dict]:
        """بارگذاری قالب‌ها"""
        return {
            "general": {
                "temperature": 0.7,
                "max_tokens": 4096,
                "system_prompt": "تو یک Agent هوشمند و کاربردی هستی.",
                "enabled_tools": [],
                "custom_interrupts": []
            },
            "coder": {
                "temperature": 0.3,
                "max_tokens": 8192,
                "system_prompt": "تو یک برنامه‌نویس حرفه‌ای هستی. کد تمیز و بهینه بنویس.",
                "enabled_tools": ["file_read", "file_write", "code_run", "sys_exec"],
                "custom_interrupts": []
            },
            "researcher": {
                "temperature": 0.5,
                "max_tokens": 4096,
                "system_prompt": "تو یک پژوهشگر دقیق هستی. اطلاعات را تحلیل و خلاصه کن.",
                "enabled_tools": ["web_search", "web_fetch", "file_read"],
                "custom_interrupts": []
            },
            "teacher": {
                "temperature": 0.8,
                "max_tokens": 4096,
                "system_prompt": "تو یک معلم صبور و دقیق هستی. با مثال توضیح بده.",
                "enabled_tools": ["file_read", "echo"],
                "custom_interrupts": []
            },
            "assistant": {
                "temperature": 0.6,
                "max_tokens": 2048,
                "system_prompt": "تو یک دستیار کاربردی و سریع هستی.",
                "enabled_tools": [],
                "custom_interrupts": []
            },
            "creative": {
                "temperature": 0.9,
                "max_tokens": 4096,
                "system_prompt": "تو یک هنرمند خلاق هستی. ایده‌های نو ارائه بده.",
                "enabled_tools": ["image_gen", "web_search"],
                "custom_interrupts": []
            }
        }
    
    def create(
        self, 
        template: Optional[str] = None,
        config: Optional[AgentConfig] = None
    ) -> Agent:
        """
        ساخت Agent جدید
        
        Args:
            template: نام قالب آماده
            config: تنظیمات سفارشی
            
        Returns:
            Agent instance
        """
        
        # شروع با قالب یا تنظیمات پیش‌فرض
        if template and template in self.templates:
            template_config = self.templates[template]
            final_config = AgentConfig(
                name=config.name if config else template.capitalize(),
                model=config.model if config else "qwen2.5"
            )
            # اعمال تنظیمات قالب
            final_config.temperature = template_config["temperature"]
            final_config.max_tokens = template_config["max_tokens"]
            final_config.system_prompt = template_config["system_prompt"]
            final_config.enabled_tools = template_config["enabled_tools"]
        else:
            final_config = config or AgentConfig()
        
        # ساخت Agent
        agent = Agent(
            model_name=final_config.model,
            ollama_url=final_config.ollama_url
        )
        
        # تنظیم Agent
        agent.name = final_config.name
        agent.language = final_config.language
        agent.is_learning = final_config.auto_learn
        
        if final_config.system_prompt:
            agent.llm.set_system_prompt(final_config.system_prompt)
        
        # افزودن ابزارهای سفارشی
        for tool in final_config.custom_tools:
            agent.tools.register(tool)
        
        # افزودن اینتررپت‌های سفارشی
        for interrupt in final_config.custom_interrupts:
            agent.interrupt_registry.register(interrupt)
        
        # ذخیره
        self.created_agents[final_config.name] = agent
        
        return agent
    
    def create_coder(self, name: str = "CoderAgent") -> Agent:
        """ساخت Agent برنامه‌نویس"""
        return self.create(
            config=AgentConfig(
                name=name,
                template="coder"
            )
        )
    
    def create_researcher(self, name: str = "ResearchAgent") -> Agent:
        """ساخت Agent پژوهشگر"""
        return self.create(
            config=AgentConfig(
                name=name,
                template="researcher"
            )
        )
    
    def create_teacher(self, name: str = "TeacherAgent") -> Agent:
        """ساخت Agent معلم"""
        return self.create(
            config=AgentConfig(
                name=name,
                template="teacher"
            )
        )
    
    def list_agents(self) -> List[Dict]:
        """لیست Agent‌های ساخته شده"""
        return [{
            "name": name,
            "version": agent.version,
            "tools_count": len(agent.tools.tools),
            "experiences": agent.memory.count()
        } for name, agent in self.created_agents.items()]
    
    def get_agent(self, name: str) -> Optional[Agent]:
        """دریافت Agent با نام"""
        return self.created_agents.get(name)


# ═══════════════════════════════════════════════════════════════════════
# CUSTOM INTERRUPT BUILDER - ساخت اینتررپت سفارشی
# ═══════════════════════════════════════════════════════════════════════

class InterruptBuilder:
    """ساخت اینتررپت سفارشی"""
    
    def __init__(self, code: str):
        self.code = code
        self._name = ""
        self._name_en = ""
        self._description = ""
        self._parameters: List[str] = []
        self._return_type = "any"
        self._handler: Optional[Callable] = None
        self._examples: List[str] = []
    
    def name(self, fa: str, en: str) -> "InterruptBuilder":
        """تنظیم نام"""
        self._name = fa
        self._name_en = en
        return self
    
    def description(self, text: str) -> "InterruptBuilder":
        """تنظیم توضیحات"""
        self._description = text
        return self
    
    def params(self, *params: str) -> "InterruptBuilder":
        """تنظیم پارامترها"""
        self._parameters = list(params)
        return self
    
    def returns(self, return_type: str) -> "InterruptBuilder":
        """تنظیم نوع خروجی"""
        self._return_type = return_type
        return self
    
    def handler(self, func: Callable) -> "InterruptBuilder":
        """تنظیم handler"""
        self._handler = func
        return self
    
    def example(self, example: str) -> "InterruptBuilder":
        """افزودن مثال"""
        self._examples.append(example)
        return self
    
    def build(self) -> Interrupt:
        """ساخت اینتررپت"""
        return Interrupt(
            code=self.code,
            name=self._name,
            name_en=self._name_en,
            description=self._description,
            parameters=self._parameters,
            return_type=self._return_type,
            handler=self._handler or (lambda *args: {}),
            example=self._examples[0] if self._examples else ""
        )


# ═══════════════════════════════════════════════════════════════════════
# CUSTOM TOOL BUILDER - ساخت ابزار سفارشی
# ═══════════════════════════════════════════════════════════════════════

class ToolBuilder:
    """ساخت ابزار سفارشی"""
    
    def __init__(self, name: str):
        self.name = name
        self._description = ""
        self._description_fa = ""
        self._category = ToolCategory.CUSTOM
        self._parameters: List[Dict] = []
        self._function: Optional[Callable] = None
        self._examples: List[str] = []
        self._requires_approval = False
    
    def description(self, en: str, fa: str) -> "ToolBuilder":
        """تنظیم توضیحات"""
        self._description = en
        self._description_fa = fa
        return self
    
    def category(self, cat: ToolCategory) -> "ToolBuilder":
        """تنظیم دسته"""
        self._category = cat
        return self
    
    def param(
        self, 
        name: str, 
        param_type: str = "string",
        required: bool = True,
        description: str = ""
    ) -> "ToolBuilder":
        """افزودن پارامتر"""
        self._parameters.append({
            "name": name,
            "type": param_type,
            "required": required,
            "description": description
        })
        return self
    
    def function(self, func: Callable) -> "ToolBuilder":
        """تنظیم تابع"""
        self._function = func
        return self
    
    def example(self, ex: str) -> "ToolBuilder":
        """افزودن مثال"""
        self._examples.append(ex)
        return self
    
    def needs_approval(self, needs: bool = True) -> "ToolBuilder":
        """نیاز به تأیید"""
        self._requires_approval = needs
        return self
    
    def build(self) -> Tool:
        """ساخت ابزار"""
        return Tool(
            name=self.name,
            description=self._description,
            description_fa=self._description_fa,
            category=self._category,
            parameters=self._parameters,
            function=self._function or (lambda *args: {}),
            examples=self._examples,
            requires_approval=self._requires_approval
        )


# ═══════════════════════════════════════════════════════════════════════
# EXAMPLE: ساخت یک Agent کامل سفارشی
# ═══════════════════════════════════════════════════════════════════════

def create_custom_coding_agent():
    """مثال: ساخت Agent برنامه‌نویس سفارشی"""
    
    factory = AgentFactory()
    
    # ساخت اینتررپت سفارشی برای کامپایل
    compile_interrupt = (InterruptBuilder("INT_08")
        .name("کامپایل", "Compile")
        .description("کامپایل و اجرای کد")
        .params("language", "code")
        .returns("json")
        .handler(lambda lang, code: {"status": "compiled", "output": "OK"})
        .example("INT_08:python:print('hello')")
        .build())
    
    # ساخت ابزار سفارشی برای تست
    run_test_tool = (ToolBuilder("run_test")
        .description("Run test cases", "اجرای تست‌ها")
        .category(ToolCategory.COMPUTATION)
        .param("test_file", "string", True, "مسیر فایل تست")
        .function(lambda test_file: {"tests_passed": 10, "tests_failed": 0})
        .example("run_test:/tests/test_main.py")
        .build())
    
    # ساخت Agent
    agent = factory.create(
        config=AgentConfig(
            name="CodeMaster",
            model="qwen2.5-coder",
            temperature=0.3,
            system_prompt="تو یک استاد برنامه‌نویسی هستی که کد تمیز و بهینه می‌نویسد.",
            custom_tools=[run_test_tool],
            custom_interrupts=[compile_interrupt]
        )
    )
    
    return agent


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║              AGENT FACTORY - Demo Mode                        ║")
    print("╚═══════════════════════════════════════════════════════════════╝\n")
    
    factory = AgentFactory()
    
    # ساخت چند Agent نمونه
    agents = {
        "General": factory.create(template="general"),
        "Coder": factory.create_coder(),
        "Researcher": factory.create_researcher(),
        "Teacher": factory.create_teacher()
    }
    
    print(f"✅ Created {len(agents)} agents:\n")
    for name, agent in agents.items():
        print(f"  🤖 {agent.name}")
        print(f"     • Tools: {len(agent.tools.tools)}")
        print(f"     • Memory: {agent.memory.count()} experiences")
        print(f"     • Interrupts: {len(agent.interrupts.interrupts)}\n")
    
    print("Use CLI: python -m agent_factory.cli")