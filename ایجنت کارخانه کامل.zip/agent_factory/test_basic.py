"""
╔═══════════════════════════════════════════════════════════════════════╗
║                    TEST SUITE - تست سیستم                              ║
╚═══════════════════════════════════════════════════════════════════════╝
"""

import sys
import os

# Add parent to path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from agent_factory.factory import AgentFactory, AgentConfig
from agent_factory.core.vector_memory import VectorMemory
from agent_factory.core.tool_registry import ToolRegistry, Tool, ToolCategory
from agent_factory.core.interrupts import InterruptManager, Interrupt, InterruptRegistry


def test_vector_memory():
    """تست حافظه برداری"""
    print("\n🧪 Testing Vector Memory...")
    
    memory = VectorMemory("./data/test_memory.db")
    
    # افزودن تجربه
    exp_id = memory.add_experience(
        content="چطوری فلان کار رو انجام بدم",
        context="برنامه‌نویسی",
        result="باید از تابع X استفاده کنی"
    )
    print(f"   ✓ Added experience: {exp_id}")
    
    # جستجو
    results = memory.search("چطوری کار", limit=5)
    print(f"   ✓ Search found {len(results)} results")
    
    # آمار
    stats = memory.get_stats()
    print(f"   ✓ Memory stats: {stats['total_experiences']} experiences")
    
    assert memory.count() > 0, "Memory should have experiences"
    print("✅ Vector Memory: PASSED")


def test_tool_registry():
    """تست ثبت ابزار"""
    print("\n🧪 Testing Tool Registry...")
    
    registry = ToolRegistry()
    
    # چک ابزارهای پیش‌فرض
    assert len(registry.tools) > 0, "Should have default tools"
    print(f"   ✓ Default tools: {len(registry.tools)}")
    
    # ساخت ابزار سفارشی
    custom_tool = Tool(
        name="test_tool",
        description="Test tool",
        description_fa="ابزار تست",
        category=ToolCategory.CUSTOM,
        function=lambda: {"result": "test"},
        examples=["test_tool()"]
    )
    registry.register(custom_tool)
    assert "test_tool" in registry.tools, "Custom tool should be registered"
    print("   ✓ Custom tool registered")
    
    # اجرا
    result = registry.execute("echo", "Hello!")
    assert result["success"], "Tool execution should succeed"
    print("   ✓ Tool execution works")
    
    print("✅ Tool Registry: PASSED")


def test_interrupts():
    """تست اینتررپت‌ها"""
    print("\n🧪 Testing Interrupts...")
    
    # ساخت مینیمم dependencies
    class MockLLM:
        pass
    
    class MockVectorDB:
        def count(self): return 0
    
    class MockTools:
        def list(self): return []
        def execute(self, *args): return {}
    
    mock_llm = MockLLM()
    mock_db = MockVectorDB()
    mock_tools = MockTools()
    
    manager = InterruptManager(mock_llm, mock_db, mock_tools)
    
    # چک اینتررپت‌های پایه
    assert len(manager.interrupts) >= 8, "Should have 8 basic interrupts"
    print(f"   ✓ Basic interrupts: {len(manager.interrupts)}")
    
    # اجرای اینتررپت
    result = manager.execute("INT_00", "status")
    assert result.success, "Interrupt should execute"
    print("   ✓ Interrupt execution works")
    
    print("✅ Interrupts: PASSED")


def test_agent_factory():
    """تست کارخانه Agent"""
    print("\n🧪 Testing Agent Factory...")
    
    factory = AgentFactory()
    
    # ساخت از قالب
    agent = factory.create(template="general")
    assert agent is not None, "Agent should be created"
    print(f"   ✓ Created agent: {agent.name}")
    
    # لیست Agent‌ها
    agents = factory.list_agents()
    print(f"   ✓ Factory has {len(agents)} agents")
    
    print("✅ Agent Factory: PASSED")


def test_bilingual():
    """تست دوزبانه"""
    print("\n🧪 Testing Bilingual Support...")
    
    from agent_factory.cli import BilingualHelper
    
    # ترجمه
    result = BilingualHelper.translate("hello world", to="fa")
    assert "سلام" in result, "Should contain Persian translation"
    print(f"   ✓ Translation: 'hello' -> 'سلام'")
    
    # تشخیص فارسی
    is_fa = BilingualHelper.is_persian("سلام دنیا")
    assert is_fa, "Should detect Persian text"
    print("   ✓ Persian detection works")
    
    print("✅ Bilingual: PASSED")


def run_all_tests():
    """اجرای همه تست‌ها"""
    print("╔═══════════════════════════════════════════════════════════════╗")
    print("║           AGENT FACTORY - TEST SUITE                          ║")
    print("╚═══════════════════════════════════════════════════════════════╝")
    
    tests = [
        test_vector_memory,
        test_tool_registry,
        test_interrupts,
        test_agent_factory,
        test_bilingual
    ]
    
    passed = 0
    failed = 0
    
    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"   ❌ FAILED: {e}")
            failed += 1
    
    print("\n" + "═" * 62)
    print(f"📊 Results: {passed} passed, {failed} failed")
    
    if failed == 0:
        print("🎉 All tests passed!")
    else:
        print("⚠️ Some tests failed.")
    
    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)