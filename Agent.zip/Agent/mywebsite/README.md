# Mywebsite

یک وبسایت با پایتون بزن

## Setup

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python app.py
```

Open:

```text
http://127.0.0.1:5000
```

## Structure

```text
app.py
templates/index.html
static/style.css
```
