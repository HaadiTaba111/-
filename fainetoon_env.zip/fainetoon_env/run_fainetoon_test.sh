#!/bin/bash

# ============================================================
#   FAINETOON — تست نهایی و بی‌نقص
#   زمان: ۲-۴ ساعت روی GPU
# ============================================================

cat << 'PYEOF' > fainetoon_final_test.py
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import numpy as np
import time
import matplotlib
matplotlib.use('Agg')  # بدون GUI
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, Subset
import warnings
warnings.filterwarnings('ignore')

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed(SEED)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🖥️  Device: {DEVICE}")

BATCH_SIZE = 128
EPOCHS_PER_STAGE = 5
TOTAL_EPOCHS = 60
LR = 0.01
MOMENTUM = 0.9
WEIGHT_DECAY = 5e-4
LAMBDA = 0.15
GAMMA = 0.4
MIN_WEIGHT = 0.15
NUM_STAGES = 12

transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])
transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform_train)
testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform_test)

def build_stages(num_stages, seed=42):
    np.random.seed(seed)
    class_order = np.random.permutation(10)
    stages = []
    classes_per_stage = 10 // num_stages
    remainder = 10 % num_stages
    start = 0
    for i in range(num_stages):
        end = start + classes_per_stage + (1 if i < remainder else 0)
        stage_classes = class_order[start:end]
        indices = [idx for idx, (_, label) in enumerate(trainset) if label in stage_classes]
        stages.append(Subset(trainset, indices))
        start = end
    return stages

test_loader = DataLoader(testset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

class BasicBlock(nn.Module):
    expansion = 1
    def __init__(self, in_planes, planes, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )
    def forward(self, x):
        out = torch.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = torch.relu(out)
        return out

class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super().__init__()
        self.in_planes = 64
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        self.linear = nn.Linear(512 * block.expansion, num_classes)
    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)
    def forward(self, x):
        out = torch.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = torch.nn.functional.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out

def ResNet18():
    return ResNet(BasicBlock, [2, 2, 2, 2])

def compute_weight(k, last_visit, now, base_w):
    dt = now - last_visit
    fade = np.exp(-LAMBDA * dt) if dt > 0 else 1.0
    boost = 1.0 + GAMMA * abs(np.sin(k * np.pi / 2))
    w = base_w * fade * boost
    return max(w, MIN_WEIGHT)

def evaluate(model, loader):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            outputs = model(x)
            _, predicted = outputs.max(1)
            total += y.size(0)
            correct += predicted.eq(y).sum().item()
    return 100. * correct / total

def evaluate_stage(model, stage, full_testset):
    stage_classes = set()
    for _, label in stage:
        stage_classes.add(label)
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for x, y in DataLoader(full_testset, batch_size=BATCH_SIZE):
            x, y = x.to(DEVICE), y.to(DEVICE)
            outputs = model(x)
            _, predicted = outputs.max(1)
            mask = torch.tensor([label.item() in stage_classes for label in y]).to(DEVICE)
            correct += (predicted.eq(y) & mask).sum().item()
            total += mask.sum().item()
    return 100. * correct / total if total > 0 else 0.0

def train_linear(num_stages, total_epochs):
    print(f"\n{'='*60}")
    print(f"   LINEAR BASELINE")
    print(f"{'='*60}")
    stages = build_stages(num_stages)
    all_data = torch.utils.data.ConcatDataset(stages)
    loader = DataLoader(all_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    model = ResNet18().to(DEVICE)
    optimizer = optim.SGD(model.parameters(), lr=LR, momentum=MOMENTUM, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_epochs)
    criterion = nn.CrossEntropyLoss()
    acc_history = []
    loss_history = []
    start_time = time.time()
    for epoch in range(total_epochs):
        model.train()
        epoch_loss = 0.0
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            loss.backward()
            optimizer.step()
            epoch_loss += loss.item()
        scheduler.step()
        acc = evaluate(model, test_loader)
        acc_history.append(acc)
        loss_history.append(epoch_loss / len(loader))
        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}/{total_epochs} — Loss: {loss_history[-1]:.4f}, Test Acc: {acc:.2f}%")
    elapsed = time.time() - start_time
    return model, acc_history, loss_history, elapsed

def train_spiral_v1(num_stages, total_epochs):
    print(f"\n{'='*60}")
    print(f"   DEEPSPIRAL V1 (Single Spiral, {num_stages} stages)")
    print(f"{'='*60}")
    stages = build_stages(num_stages)
    weights = np.ones(num_stages)
    last_visit = np.zeros(num_stages)
    model = ResNet18().to(DEVICE)
    optimizer = optim.SGD(model.parameters(), lr=LR, momentum=MOMENTUM, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_epochs)
    criterion = nn.CrossEntropyLoss()
    acc_history = []
    loss_history = []
    now = 0
    start_time = time.time()
    for epoch in range(total_epochs):
        k = epoch % num_stages
        w = compute_weight(k+1, last_visit[k], now, weights[k])
        stage_data = stages[k]
        loader = DataLoader(stage_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
        model.train()
        epoch_loss = 0.0
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            (loss * w).backward()
            optimizer.step()
            epoch_loss += loss.item()
        scheduler.step()
        loss_history.append(epoch_loss / max(1, len(loader)))
        last_visit[k] = now
        now += 1
        acc = evaluate(model, test_loader)
        acc_history.append(acc)
        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}/{total_epochs} (Stage {k+1}) — Loss: {loss_history[-1]:.4f}, Test Acc: {acc:.2f}%, w={w:.3f}")
    elapsed = time.time() - start_time
    early_acc = evaluate_stage(model, stages[0], testset)
    return model, acc_history, loss_history, elapsed, early_acc

def cross_partner(k):
    mapping = {1:4, 4:1, 2:3, 3:2, 5:8, 8:5, 6:7, 7:6, 9:12, 12:9, 10:11, 11:10}
    return mapping.get(k, None)

def train_spiral_v2(num_stages, total_epochs):
    print(f"\n{'='*60}")
    print(f"   DEEPSPIRAL V2 (Dual Spiral, {num_stages} stages)")
    print(f"{'='*60}")
    stages = build_stages(num_stages)
    weights = np.ones(num_stages)
    last_visit = np.zeros(num_stages)
    model = ResNet18().to(DEVICE)
    optimizer = optim.SGD(model.parameters(), lr=LR, momentum=MOMENTUM, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=total_epochs)
    criterion = nn.CrossEntropyLoss()
    acc_history = []
    loss_history = []
    now = 0
    start_time = time.time()
    for epoch in range(total_epochs):
        k = epoch % num_stages
        w = compute_weight(k+1, last_visit[k], now, weights[k])
        stage_data = stages[k]
        loader = DataLoader(stage_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
        model.train()
        epoch_loss = 0.0
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            (loss * w).backward()
            optimizer.step()
            epoch_loss += loss.item()
        partner = cross_partner(k+1)
        if partner is not None:
            p_idx = partner - 1
            w_partner = compute_weight(partner, last_visit[p_idx], now, weights[p_idx])
            p_loader = DataLoader(stages[p_idx], batch_size=BATCH_SIZE//2, shuffle=True, num_workers=0)
            for x, y in p_loader:
                x, y = x.to(DEVICE), y.to(DEVICE)
                optimizer.zero_grad()
                loss_p = criterion(model(x), y)
                (0.3 * w_partner * loss_p).backward()
                optimizer.step()
            last_visit[p_idx] = now
        scheduler.step()
        loss_history.append(epoch_loss / max(1, len(loader)))
        last_visit[k] = now
        now += 1
        acc = evaluate(model, test_loader)
        acc_history.append(acc)
        if epoch % 10 == 0:
            print(f"  Epoch {epoch:3d}/{total_epochs} (Stage {k+1}) — Loss: {loss_history[-1]:.4f}, Test Acc: {acc:.2f}%, w={w:.3f}")
    elapsed = time.time() - start_time
    early_acc = evaluate_stage(model, stages[0], testset)
    return model, acc_history, loss_history, elapsed, early_acc

def test_stage_counts():
    print(f"\n{'#'*60}")
    print(f"   تست تعداد نقاط: ۸ vs ۱۲ vs ۱۶")
    print(f"{'#'*60}")
    results = {}
    for N in [8, 12, 16]:
        total_epochs = N * EPOCHS_PER_STAGE
        print(f"\n🔹 Spiral {N} stages ({total_epochs} epochs)")
        _, acc_hist, loss_hist, elapsed, early_acc = train_spiral_v1(N, total_epochs)
        results[N] = {
            'final_acc': acc_hist[-1],
            'max_acc': max(acc_hist),
            'early_acc': early_acc,
            'auc': np.trapz(acc_hist) / len(acc_hist),
            'time': elapsed
        }
    print(f"\n{'='*60}")
    print(f"   📊 نتایج تعداد نقاط")
    print(f"{'='*60}")
    print(f"{'N':>5} {'Final Acc':>10} {'Max Acc':>10} {'Early Acc':>10} {'Avg AUC':>10} {'Time (m)':>10}")
    for N, r in results.items():
        print(f"{N:5d} {r['final_acc']:>10.2f} {r['max_acc']:>10.2f} {r['early_acc']:>10.2f} {r['auc']:>10.2f} {r['time']/60:>10.1f}")
    plt.figure(figsize=(10, 4))
    plt.subplot(1, 2, 1)
    plt.bar(results.keys(), [r['final_acc'] for r in results.values()], color=['#3498db','#2ecc71','#e74c3c'])
    plt.title('Final Accuracy vs Points')
    plt.xlabel('Number of Spiral Points')
    plt.ylabel('Accuracy (%)')
    plt.subplot(1, 2, 2)
    plt.bar(results.keys(), [r['early_acc'] for r in results.values()], color=['#3498db','#2ecc71','#e74c3c'])
    plt.title('Early Recall vs Points')
    plt.xlabel('Number of Spiral Points')
    plt.ylabel('Accuracy on Stage 1 (%)')
    plt.tight_layout()
    plt.savefig('stage_count_comparison.png', dpi=150)
    print("📈 نمودار در stage_count_comparison.png ذخیره شد.")
    return results

# اجرای اصلی
print("🚀 شروع تست‌های اصلی...")
all_results = {}

model_lin, acc_lin, loss_lin, t_lin = train_linear(12, TOTAL_EPOCHS)
all_results['Linear'] = {'acc': acc_lin, 'loss': loss_lin, 'time': t_lin}

model_v1, acc_v1, loss_v1, t_v1, early_v1 = train_spiral_v1(12, TOTAL_EPOCHS)
all_results['Spiral V1'] = {'acc': acc_v1, 'loss': loss_v1, 'time': t_v1, 'early_acc': early_v1}

model_v2, acc_v2, loss_v2, t_v2, early_v2 = train_spiral_v2(12, TOTAL_EPOCHS)
all_results['Spiral V2'] = {'acc': acc_v2, 'loss': loss_v2, 'time': t_v2, 'early_acc': early_v2}

print(f"\n{'='*70}")
print(f"   🏆 نتایج نهایی — CIFAR-10 + ResNet-18")
print(f"{'='*70}")
print(f"{'Model':<15} {'Final Acc':>10} {'Max Acc':>10} {'Early Recall':>12} {'AUC':>10} {'Time (m)':>10}")
print(f"{'-'*70}")
for name, r in all_results.items():
    final = r['acc'][-1]
    mx = max(r['acc'])
    early = r.get('early_acc', float('nan'))
    auc = np.trapz(r['acc']) / len(r['acc'])
    tmin = r['time'] / 60
    print(f"{name:<15} {final:>10.2f} {mx:>10.2f} {early:>10.2f} {auc:>10.2f} {tmin:>10.1f}")

plt.figure(figsize=(12, 5))
plt.subplot(1, 2, 1)
for name, r in all_results.items():
    plt.plot(r['acc'], label=name)
plt.title('Test Accuracy over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Accuracy (%)')
plt.legend()
plt.grid(True, alpha=0.3)
plt.subplot(1, 2, 2)
for name, r in all_results.items():
    plt.plot(r['loss'], label=name)
plt.title('Training Loss over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.savefig('model_comparison.png', dpi=150)
print("📈 نمودار مقایسه در model_comparison.png ذخیره شد.")

stage_results = test_stage_counts()

with open('definitive_results.csv', 'w') as f:
    f.write("Model,FinalAcc,MaxAcc,EarlyRecall,AUC,TimeMin\n")
    for name, r in all_results.items():
        f.write(f"{name},{r['acc'][-1]:.2f},{max(r['acc']):.2f},{r.get('early_acc',0):.2f},{np.trapz(r['acc'])/len(r['acc']):.2f},{r['time']/60:.1f}\n")

print("\n✅ همه تست‌ها تمام شد!")
print("📄 نتایج در definitive_results.csv ذخیره شد.")
PYEOF

# اجرای تست
echo "🚀 در حال اجرای تست نهایی..."
python3.10 fainetoon_final_test.py
echo "🏁 پایان تست."