import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
import numpy as np
import time
from torch.utils.data import DataLoader, Subset
import warnings
warnings.filterwarnings('ignore')

SEED = 42
np.random.seed(SEED)
torch.manual_seed(SEED)
if torch.cuda.is_available():
    torch.cuda.manual_seed(SEED)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"🖥️  {DEVICE}")

BATCH_SIZE = 128
TOTAL_EPOCHS = 600          # معادل ۳ میلیون تصویر
LR = 0.01
MOMENTUM = 0.9
WEIGHT_DECAY = 5e-4
LAMBDA = 0.15
GAMMA = 0.4
MIN_WEIGHT = 0.15

transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])
transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True, download=False, transform=transform_train)
testset = torchvision.datasets.CIFAR10(root='./data', train=False, download=False, transform=transform_test)

def build_stages(num_stages):
    np.random.seed(42)
    class_order = np.random.permutation(10)
    stages = []
    for i in range(num_stages):
        stage_class = class_order[i % 10]
        indices = [idx for idx, (_, label) in enumerate(trainset) if label == stage_class]
        stages.append(Subset(trainset, indices))
    return stages

test_loader = DataLoader(testset, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

class BasicBlock(nn.Module):
    expansion = 1
    def __init__(self, in_planes, planes, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )
    def forward(self, x):
        out = torch.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = torch.relu(out)
        return out

class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super().__init__()
        self.in_planes = 64
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        self.linear = nn.Linear(512 * block.expansion, num_classes)
    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)
    def forward(self, x):
        out = torch.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = torch.nn.functional.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out

def ResNet18():
    return ResNet(BasicBlock, [2, 2, 2, 2])

def compute_weight(k, last_visit, now, base_w):
    dt = now - last_visit
    fade = np.exp(-LAMBDA * dt) if dt > 0 else 1.0
    boost = 1.0 + GAMMA * abs(np.sin(k * np.pi / 2))
    w = base_w * fade * boost
    return max(w, MIN_WEIGHT)

def evaluate(model, loader):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            outputs = model(x)
            _, predicted = outputs.max(1)
            total += y.size(0)
            correct += predicted.eq(y).sum().item()
    return 100. * correct / total

def evaluate_stage(model, class_list):
    model.eval()
    correct, total = 0, 0
    with torch.no_grad():
        for x, y in DataLoader(testset, batch_size=BATCH_SIZE):
            x, y = x.to(DEVICE), y.to(DEVICE)
            outputs = model(x)
            _, predicted = outputs.max(1)
            mask = torch.tensor([l.item() in class_list for l in y]).to(DEVICE)
            correct += (predicted.eq(y) & mask).sum().item()
            total += mask.sum().item()
    return 100. * correct / total if total > 0 else 0.0

def train_spiral_cyrus(N=12):
    """
    Spiral V2 با زمان‌بندی واقعی:
    - ۳↔۲ هر ۱۲ Epoch (یک "سال")
    - ۴↔۱ هر ۲۴ Epoch (دو "سال")
    """
    stages = build_stages(N)
    weights = np.ones(N)
    last_visit = np.zeros(N)
    model = ResNet18().to(DEVICE)
    optimizer = optim.SGD(model.parameters(), lr=LR, momentum=MOMENTUM, weight_decay=WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=TOTAL_EPOCHS)
    criterion = nn.CrossEntropyLoss()
    acc_history, loss_history = [], []
    now = 0
    start_time = time.time()

    # نگاشت نقاط به پل‌ها:
    # ۳↔۲: نقاط ۳ و ۲ (ایندکس‌های ۲ و ۱)
    cross_3_2 = {2: 1, 1: 2}  # mapping stage index for 3↔2
    # ۴↔۱: نقاط ۴ و ۱ (ایندکس‌های ۳ و ۰)
    cross_4_1 = {3: 0, 0: 3}

    for epoch in range(TOTAL_EPOCHS):
        k = epoch % N
        w = compute_weight(k+1, last_visit[k], now, weights[k])
        stage_data = stages[k]
        loader = DataLoader(stage_data, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
        model.train()
        epoch_loss = 0.0
        for x, y in loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            optimizer.zero_grad()
            loss = criterion(model(x), y)
            (loss * w).backward()
            optimizer.step()
            epoch_loss += loss.item()

        # پل ۳↔۲: هر ۱۲ Epoch یکبار
        if epoch % 12 == 0:
            partner = cross_3_2.get(k, None)
            if partner is not None:
                w_p = compute_weight(partner+1, last_visit[partner], now, weights[partner])
                loader_p = DataLoader(stages[partner], batch_size=BATCH_SIZE//2, shuffle=True, num_workers=0)
                for x, y in loader_p:
                    x, y = x.to(DEVICE), y.to(DEVICE)
                    optimizer.zero_grad()
                    (criterion(model(x), y) * w_p * 0.5).backward()
                    optimizer.step()
                last_visit[partner] = now

        # پل ۴↔۱: هر ۲۴ Epoch یکبار
        if epoch % 24 == 0:
            partner = cross_4_1.get(k, None)
            if partner is not None:
                w_p = compute_weight(partner+1, last_visit[partner], now, weights[partner])
                loader_p = DataLoader(stages[partner], batch_size=BATCH_SIZE//2, shuffle=True, num_workers=0)
                for x, y in loader_p:
                    x, y = x.to(DEVICE), y.to(DEVICE)
                    optimizer.zero_grad()
                    (criterion(model(x), y) * w_p * 0.7).backward()  # قوی‌تر چون نادرتر
                    optimizer.step()
                last_visit[partner] = now

        scheduler.step()
        loss_history.append(epoch_loss / max(1, len(loader)))
        last_visit[k] = now
        now += 1

        if epoch % 30 == 0:
            acc = evaluate(model, test_loader)
            acc_history.append(acc)
            print(f"Epoch {epoch:3d}/{TOTAL_EPOCHS} (Stage {k+1:2d}) | Acc={acc:.2f}% | w={w:.3f}")

    final_acc = evaluate(model, test_loader)
    first_stage_classes = set()
    for _, label in stages[0]:
        first_stage_classes.add(label)
    early_recall = evaluate_stage(model, list(first_stage_classes))
    elapsed = time.time() - start_time
    return model, acc_history, loss_history, final_acc, early_recall, elapsed

if __name__ == "__main__":
    print("\n📜 پخش منشور کوروش برای هوش مصنوعی...")
    model, acc_hist, loss_hist, final_acc, early_recall, elapsed = train_spiral_cyrus(12)
    print(f"\n✅ پایان آموزش.")
    print(f"🎯 دقت نهایی: {final_acc:.2f}%")
    print(f"🧠 Early Recall (ماده ۱ منشور): {early_recall:.2f}%")
    print(f"⏱️ زمان: {elapsed/60:.1f} دقیقه")
    with open("cyrus_results.csv", "w") as f:
        f.write("Epoch,Accuracy\n")
        for i, acc in enumerate(acc_hist):
            f.write(f"{(i+1)*30},{acc:.2f}\n")
    print("📄 نتایج در cyrus_results.csv ذخیره شد.")